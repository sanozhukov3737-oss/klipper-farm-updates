use kf_domain::SecretString;
use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::collections::BTreeMap;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum PrinterPhase {
    Discovered,
    Identifying,
    Ready,
    Operating,
    Printing,
    Degraded,
    Recovering,
    Quarantined,
}

impl PrinterPhase {
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Discovered => "discovered",
            Self::Identifying => "identifying",
            Self::Ready => "ready",
            Self::Operating => "operating",
            Self::Printing => "printing",
            Self::Degraded => "degraded",
            Self::Recovering => "recovering",
            Self::Quarantined => "quarantined",
        }
    }

    pub fn from_db(value: &str) -> Self {
        match value {
            "identifying" => Self::Identifying,
            "ready" => Self::Ready,
            "operating" => Self::Operating,
            "printing" => Self::Printing,
            "degraded" => Self::Degraded,
            "recovering" => Self::Recovering,
            "quarantined" => Self::Quarantined,
            _ => Self::Discovered,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum OperationState {
    Created,
    Queued,
    Sent,
    Confirmed,
    Cancelled,
    Unknown,
    Recovered,
    Failed,
}

impl OperationState {
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Created => "created",
            Self::Queued => "queued",
            Self::Sent => "sent",
            Self::Confirmed => "confirmed",
            Self::Cancelled => "cancelled",
            Self::Unknown => "unknown",
            Self::Recovered => "recovered",
            Self::Failed => "failed",
        }
    }

    pub fn from_db(value: &str) -> Self {
        match value {
            "queued" => Self::Queued,
            "sent" => Self::Sent,
            "confirmed" => Self::Confirmed,
            "cancelled" => Self::Cancelled,
            "unknown" => Self::Unknown,
            "recovered" => Self::Recovered,
            "failed" => Self::Failed,
            _ => Self::Created,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum RepeatPolicy {
    Safe,
    VerifyState,
    Never,
}

impl RepeatPolicy {
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Safe => "safe",
            Self::VerifyState => "verify_state",
            Self::Never => "never",
        }
    }

    pub fn from_db(value: &str) -> Self {
        match value {
            "safe" => Self::Safe,
            "verify_state" => Self::VerifyState,
            _ => Self::Never,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum OperationPriority {
    Emergency,
    Control,
    Telemetry,
    Upload,
    Background,
}

impl OperationPriority {
    pub fn rank(self) -> u8 {
        match self {
            Self::Emergency => 5,
            Self::Control => 4,
            Self::Telemetry => 3,
            Self::Upload => 2,
            Self::Background => 1,
        }
    }

    pub fn as_str(self) -> &'static str {
        match self {
            Self::Emergency => "emergency",
            Self::Control => "control",
            Self::Telemetry => "telemetry",
            Self::Upload => "upload",
            Self::Background => "background",
        }
    }

    pub fn from_db(value: &str) -> Self {
        match value {
            "emergency" => Self::Emergency,
            "control" => Self::Control,
            "telemetry" => Self::Telemetry,
            "upload" => Self::Upload,
            _ => Self::Background,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
#[serde(rename_all = "camelCase")]
pub struct GeometryCapabilities {
    pub x_min: Option<f64>,
    pub x_max: Option<f64>,
    pub y_min: Option<f64>,
    pub y_max: Option<f64>,
    pub z_max: Option<f64>,
    pub coordinate_system: Option<String>,
    pub kinematics: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PrinterCapabilities {
    pub version: u8,
    pub attested_at: i64,
    pub firmware_signature: Option<String>,
    pub geometry: GeometryCapabilities,
    pub max_nozzle_temp: Option<f64>,
    pub max_bed_temp: Option<f64>,
    pub camera: bool,
    pub bed_sensor: bool,
    pub macros: Vec<String>,
    pub queue_api: bool,
    pub rest: bool,
    pub websocket: bool,
    pub can_cancel: bool,
    pub can_pause: bool,
    pub can_resume: bool,
    pub firmware_features: Vec<String>,
    pub evidence: Vec<String>,
    pub compatible: bool,
    pub quarantine_reason: Option<String>,
}

impl Default for PrinterCapabilities {
    fn default() -> Self {
        Self {
            version: 6,
            attested_at: 0,
            firmware_signature: None,
            geometry: GeometryCapabilities::default(),
            max_nozzle_temp: None,
            max_bed_temp: None,
            camera: false,
            bed_sensor: false,
            macros: Vec::new(),
            queue_api: false,
            rest: false,
            websocket: false,
            can_cancel: false,
            can_pause: false,
            can_resume: false,
            firmware_features: Vec::new(),
            evidence: Vec::new(),
            compatible: true,
            quarantine_reason: None,
        }
    }
}

#[derive(Debug, Clone, Deserialize, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ActorConfigInput {
    pub stable_id: String,
    pub printer_id: String,
    pub model_id: Option<String>,
    pub host: String,
    pub default_port: Option<u16>,
    pub firmware_signature: Option<String>,
    #[serde(default)]
    pub capabilities_hint: Option<PrinterCapabilities>,
}

#[derive(Debug, Clone)]
pub struct ActorConfig {
    pub stable_id: String,
    pub printer_id: String,
    pub model_id: Option<String>,
    pub host: String,
    pub default_port: u16,
    pub api_key: Option<SecretString>,
    pub firmware_signature: Option<String>,
    pub capabilities_hint: Option<PrinterCapabilities>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ActorSnapshot {
    pub stable_id: String,
    pub printer_id: String,
    pub model_id: Option<String>,
    pub host: String,
    pub active_port: u16,
    pub active_protocol: String,
    pub session_epoch: u64,
    pub phase: PrinterPhase,
    pub connected: bool,
    pub last_eventtime: Option<f64>,
    pub last_seen_at: Option<i64>,
    pub telemetry_updated_at: Option<i64>,
    /// Independent wall-clock observations; a cached opposite heater is not
    /// refreshed by a delta for this one. None also covers older snapshots.
    #[serde(default)]
    pub nozzle_updated_at: Option<i64>,
    #[serde(default)]
    pub bed_updated_at: Option<i64>,
    pub job_updated_at: Option<i64>,
    pub reconnect_attempt: u32,
    pub queued_operations: usize,
    /// None is an older daemon: the updater conservatively checks all work.
    #[serde(default)]
    pub update_blocking_operations: Option<usize>,
    pub active_operation_id: Option<String>,
    pub active_upload_id: Option<String>,
    pub cached_status: Value,
    pub capabilities: PrinterCapabilities,
    pub identity_attestation: Option<PrinterIdentityAttestation>,
    pub last_error: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ActorConnectionPresentation {
    pub generation: u64,
    pub connection_state: String,
    pub reason: String,
    pub message: String,
    pub channel: String,
    pub port: u16,
    pub data_age_ms: Option<i64>,
    pub job_age_ms: Option<i64>,
}

impl ActorSnapshot {
    pub fn new(config: &ActorConfig) -> Self {
        Self {
            stable_id: config.stable_id.clone(),
            printer_id: config.printer_id.clone(),
            model_id: config.model_id.clone(),
            host: config.host.clone(),
            active_port: config.default_port,
            active_protocol: "disconnected".to_string(),
            session_epoch: 1,
            phase: PrinterPhase::Discovered,
            connected: false,
            last_eventtime: None,
            last_seen_at: None,
            telemetry_updated_at: None,
            nozzle_updated_at: None,
            bed_updated_at: None,
            job_updated_at: None,
            reconnect_attempt: 0,
            queued_operations: 0,
            update_blocking_operations: Some(0),
            active_operation_id: None,
            active_upload_id: None,
            cached_status: Value::Object(Default::default()),
            capabilities: config.capabilities_hint.clone().unwrap_or_default(),
            identity_attestation: None,
            last_error: None,
        }
    }

    pub fn connection_presentation(&self, observed_at: i64) -> ActorConnectionPresentation {
        let error = self.last_error.as_deref().unwrap_or_default();
        let lower_error = error.to_ascii_lowercase();
        let authorization = lower_error.contains("401")
            || lower_error.contains("403")
            || lower_error.contains("unauthorized")
            || lower_error.contains("forbidden")
            || lower_error.contains("api key")
            || lower_error.contains("api_key");
        let klippy = self
            .cached_status
            .pointer("/webhooks/state")
            .or_else(|| self.cached_status.pointer("/result/webhooks/state"))
            .and_then(Value::as_str)
            .unwrap_or_default()
            .to_ascii_lowercase();
        let (connection_state, reason, fallback_message) = if authorization {
            ("degraded", "authorization", "Moonraker найден — требуется API Key")
        } else if self.connected && matches!(klippy.as_str(), "startup" | "starting") {
            ("degraded", "klipper_startup", "Moonraker доступен, Klipper запускается")
        } else if self.connected && matches!(klippy.as_str(), "shutdown" | "disconnected") {
            ("degraded", "klipper_shutdown", "Klipper shutdown")
        } else if self.connected && klippy == "error" {
            ("degraded", "klipper_error", "Ошибка Klipper")
        } else if self.connected && self.phase == PrinterPhase::Quarantined {
            // Quarantine is an operation-safety state, not a network state.
            // A live Moonraker session must still count as online and keep
            // temperatures/job progress visible to the operator.
            (
                "online",
                "quarantine",
                "Moonraker доступен · управление ограничено",
            )
        } else if self.connected && self.active_protocol == "websocket" {
            ("online", "websocket", "WebSocket подключён")
        } else if self.connected {
            ("online", "rest_jsonrpc", "Moonraker доступен · REST/JSON-RPC")
        } else if matches!(self.phase, PrinterPhase::Degraded | PrinterPhase::Recovering)
            && self
                .last_seen_at
                .is_some_and(|seen| observed_at.saturating_sub(seen) <= 20_000)
        {
            ("degraded", "daemon_recovering", "Daemon восстанавливается")
        } else if self.phase == PrinterPhase::Quarantined {
            ("offline", "quarantine", "Нет сети · управление ограничено")
        } else if matches!(self.phase, PrinterPhase::Discovered | PrinterPhase::Identifying) {
            ("connecting", "connecting", "PrinterActor идентифицирует принтер")
        } else {
            ("offline", "network", "Нет сети")
        };
        ActorConnectionPresentation {
            generation: self.session_epoch,
            connection_state: connection_state.into(),
            reason: reason.into(),
            message: if error.is_empty()
                || self.connected
                || matches!(reason, "authorization" | "quarantine" | "connecting")
            {
                fallback_message.into()
            } else {
                error.chars().take(180).collect()
            },
            channel: self.active_protocol.clone(),
            port: self.active_port,
            data_age_ms: self
                .telemetry_updated_at
                .map(|value| observed_at.saturating_sub(value).max(0)),
            job_age_ms: self
                .job_updated_at
                .map(|value| observed_at.saturating_sub(value).max(0)),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ActorEvent {
    pub event_id: i64,
    pub stable_id: String,
    pub printer_id: String,
    pub session_epoch: u64,
    pub kind: String,
    pub phase: PrinterPhase,
    pub eventtime: Option<f64>,
    #[serde(default)]
    pub telemetry_updated_at: Option<i64>,
    #[serde(default)]
    pub nozzle_updated_at: Option<i64>,
    #[serde(default)]
    pub bed_updated_at: Option<i64>,
    #[serde(default)]
    pub job_updated_at: Option<i64>,
    pub status: Option<Value>,
    pub operation_id: Option<String>,
    pub payload: Option<Value>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PrinterIdentityAttestation {
    pub observed_stable_id: Option<String>,
    pub fingerprint: String,
    pub signals: BTreeMap<String, String>,
    pub verified: bool,
    pub reason: Option<String>,
    pub attested_at: i64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct OperationResult {
    pub operation_id: String,
    pub session_epoch: u64,
    pub state: OperationState,
    pub recovered: bool,
    pub result: Value,
}

#[derive(Debug, Clone)]
pub struct OperationRequest {
    pub operation_id: String,
    pub method: String,
    pub params: Option<Value>,
    pub priority: OperationPriority,
    pub repeat_policy: RepeatPolicy,
    pub prefer_rest: bool,
    pub timeout_ms: u64,
    /// Absolute wall-clock deadline fixed when the request enters the core.
    /// Queueing, scheduler admission and network I/O all consume this budget.
    pub deadline_at_ms: i64,
    pub expected_session_epoch: Option<u64>,
}

impl OperationRequest {
    pub fn typed_operation_id(&self) -> Result<kf_domain::OperationId, String> {
        kf_domain::OperationId::parse(&self.operation_id).map_err(|error| error.to_string())
    }

    pub fn deadline(&self) -> Result<kf_domain::DeadlineMs, String> {
        kf_domain::DeadlineMs::new(self.deadline_at_ms).map_err(|error| error.to_string())
    }

    pub fn expired(&self, now_ms: i64) -> bool {
        self.deadline()
            .map_or(true, |deadline| deadline.expired(now_ms))
    }

    pub fn remaining_ms(&self, now_ms: i64) -> u64 {
        self.deadline()
            .map_or(0, |deadline| deadline.remaining_ms(now_ms))
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SchedulerSnapshot {
    pub request_tokens: f64,
    pub bandwidth_tokens: f64,
    pub in_flight: usize,
    pub concurrency_limit: usize,
    pub latency_ema_ms: f64,
    pub loss_ema: f64,
    pub throttled_count: u64,
    pub queued_requests: usize,
    pub queued_bandwidth: usize,
    pub fair_printers: usize,
}

pub fn classify_method(method: &str) -> (RepeatPolicy, OperationPriority) {
    match method {
        "server.info"
        | "printer.info"
        | "machine.system_info"
        | "printer.objects.list"
        | "printer.objects.query"
        | "server.files.list"
        | "server.files.metadata"
        | "server.webcams.list"
        | "server.job_queue.status" => (RepeatPolicy::Safe, OperationPriority::Telemetry),
        "printer.print.start"
        | "printer.print.pause"
        | "printer.print.resume"
        | "printer.print.cancel" => (RepeatPolicy::VerifyState, OperationPriority::Control),
        "printer.emergency_stop" => (RepeatPolicy::Safe, OperationPriority::Emergency),
        "printer.gcode.script" => (RepeatPolicy::Never, OperationPriority::Control),
        _ => (RepeatPolicy::Never, OperationPriority::Control),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn temperature_legacy_actor_wire_fields_do_not_invent_provenance() {
        let config = ActorConfig {
            stable_id: "legacy-wire".into(), printer_id: "legacy-wire".into(), model_id: None,
            host: "127.0.0.1:7125".into(), default_port: 7125, api_key: None,
            firmware_signature: None, capabilities_hint: None,
        };
        let mut legacy_snapshot = serde_json::to_value(ActorSnapshot::new(&config)).unwrap();
        legacy_snapshot.as_object_mut().unwrap().remove("nozzleUpdatedAt");
        legacy_snapshot.as_object_mut().unwrap().remove("bedUpdatedAt");
        let snapshot: ActorSnapshot = serde_json::from_value(legacy_snapshot).unwrap();
        assert!(snapshot.nozzle_updated_at.is_none());
        assert!(snapshot.bed_updated_at.is_none());
        let event: ActorEvent = serde_json::from_value(serde_json::json!({
            "eventId":1,"stableId":"legacy-wire","printerId":"legacy-wire","sessionEpoch":1,
            "kind":"websocket","phase":"printing","eventtime":42,
            "status":{"extruder":{"temperature":220}},"operationId":null,"payload":null
        })).unwrap();
        assert!(event.nozzle_updated_at.is_none());
        assert!(event.bed_updated_at.is_none());
        assert!(event.telemetry_updated_at.is_none());
        assert!(event.job_updated_at.is_none());
    }

    #[test]
    fn actor_presentation_keeps_reason_channel_and_data_age_together() {
        let config = ActorConfig {
            stable_id: "stable-test".into(),
            printer_id: "printer-test".into(),
            model_id: None,
            host: "192.168.1.50:7125".into(),
            default_port: 7125,
            api_key: None,
            firmware_signature: None,
            capabilities_hint: None,
        };
        let mut snapshot = ActorSnapshot::new(&config);
        snapshot.phase = PrinterPhase::Degraded;
        snapshot.last_error = Some("Moonraker HTTP error: 401".into());
        snapshot.telemetry_updated_at = Some(75_000);
        let presentation = snapshot.connection_presentation(100_000);
        assert_eq!(presentation.reason, "authorization");
        assert_eq!(presentation.connection_state, "degraded");
        assert_eq!(presentation.message, "Moonraker найден — требуется API Key");
        assert_eq!(presentation.port, 7125);
        assert_eq!(presentation.data_age_ms, Some(25_000));
        assert_eq!(presentation.generation, snapshot.session_epoch);
    }

    #[test]
    fn connected_quarantine_does_not_lie_about_network_reachability() {
        let config = ActorConfig {
            stable_id: "stable-live".into(),
            printer_id: "printer-live".into(),
            model_id: None,
            host: "192.168.1.50:7125".into(),
            default_port: 7125,
            api_key: None,
            firmware_signature: None,
            capabilities_hint: None,
        };
        let mut snapshot = ActorSnapshot::new(&config);
        snapshot.phase = PrinterPhase::Quarantined;
        snapshot.connected = true;
        snapshot.active_protocol = "websocket".into();
        snapshot.last_seen_at = Some(99_000);
        let presentation = snapshot.connection_presentation(100_000);
        assert_eq!(presentation.connection_state, "online");
        assert_eq!(presentation.reason, "quarantine");
    }
}
