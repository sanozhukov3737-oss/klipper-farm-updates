use serde_json::Value;

const HEATER_OBJECTS: [&str; 2] = ["extruder", "heater_bed"];

// Vendor Moonraker builds may serialize a real thermometer reading as a
// numeric string. Only a finite value received in this payload proves that
// heater telemetry was observed; cached values, targets and fan/job traffic do
// not establish that freshness.
pub(super) fn observed_temperature(status: &Value, heater: &str) -> Option<f64> {
    let value = status.get(heater)?.get("temperature")?;
    let number = value
        .as_f64()
        .or_else(|| value.as_str()?.trim().parse::<f64>().ok())?;
    number.is_finite().then_some(number)
}

pub(super) fn missing_temperature_objects(status: &Value) -> Vec<&'static str> {
    HEATER_OBJECTS
        .into_iter()
        .filter(|heater| observed_temperature(status, heater).is_none())
        .collect()
}

pub(super) fn core_temperature_observed_at(nozzle_at: Option<i64>, bed_at: Option<i64>) -> Option<i64> {
    Some(nozzle_at?.min(bed_at?))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn temperature_accepts_finite_numeric_json_and_vendor_strings() {
        for value in [serde_json::json!(219.5), serde_json::json!(" 219.5 "), serde_json::json!("0")] {
            let status = serde_json::json!({"extruder":{"temperature":value}});
            assert!(observed_temperature(&status, "extruder").is_some());
            assert_eq!(missing_temperature_objects(&status), vec!["heater_bed"]);
        }
        assert_eq!(observed_temperature(&serde_json::json!({"heater_bed":{"temperature":"6.05e1"}}), "heater_bed"), Some(60.5));
        assert!(missing_temperature_objects(&serde_json::json!({
            "extruder":{"temperature":"220"},"heater_bed":{"temperature":60.0}
        })).is_empty());
    }

    #[test]
    fn temperature_rejects_absent_malformed_and_nonfinite_readings() {
        for value in [Value::Null, serde_json::json!(true), serde_json::json!(""),
            serde_json::json!("220 C"), serde_json::json!("NaN"), serde_json::json!("inf"),
            serde_json::json!("-Infinity"), serde_json::json!("1e999"), serde_json::json!({"value":220})] {
            assert_eq!(observed_temperature(&serde_json::json!({"extruder":{"temperature":value}}), "extruder"), None);
        }
        assert_eq!(missing_temperature_objects(&serde_json::json!({
            "extruder":{"target":220},"heater_bed":{"target":60},
            "print_stats":{"state":"printing"},"fan":{"speed":0.8}
        })), vec!["extruder", "heater_bed"]);
    }

    #[test]
    fn temperature_core_freshness_requires_both_observations_and_uses_older_one() {
        assert_eq!(core_temperature_observed_at(None, None), None);
        assert_eq!(core_temperature_observed_at(Some(200), None), None);
        assert_eq!(core_temperature_observed_at(None, Some(200)), None);
        assert_eq!(core_temperature_observed_at(Some(100), Some(200)), Some(100));
        assert_eq!(core_temperature_observed_at(Some(300), Some(200)), Some(200));
    }
}
