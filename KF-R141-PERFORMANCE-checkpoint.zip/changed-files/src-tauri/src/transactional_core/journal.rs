use super::database_writer::{ActorStateWrite, DatabaseWriter, DatabaseWriterSnapshot};
use super::types::{
    ActorConfig, ActorEvent, OperationPriority, OperationRequest, OperationState, PrinterCapabilities,
    PrinterIdentityAttestation, PrinterPhase, RepeatPolicy,
};
use rusqlite::{params, Connection, OptionalExtension};
use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::path::{Path, PathBuf};
use std::sync::Arc;

const READ_POOL_SIZE: usize = 4;
// Epochs cross the JSON/WebView boundary and must remain exact JavaScript integers.
const MAX_SESSION_EPOCH: u64 = 9_007_199_254_740_991;

#[derive(Debug, Clone)]
pub struct Journal {
    database_path: Arc<PathBuf>,
    readers: kf_storage::ReadPool,
    writer: DatabaseWriter,
}

#[derive(Debug, Clone)]
pub struct JournalRecord {
    pub operation_id: String,
    pub method: String,
    pub params: Option<Value>,
    pub repeat_policy: RepeatPolicy,
    pub priority: OperationPriority,
    pub state: OperationState,
    pub deadline_at_ms: i64,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
#[serde(rename_all = "camelCase")]
pub(crate) struct JournalOperationView {
    pub operation_id: String,
    pub stable_id: String,
    pub method: String,
    pub state: String,
    pub priority: String,
    pub attempt_count: u64,
    pub created_at: i64,
    pub updated_at: i64,
    pub deadline_at: i64,
    pub last_error: Option<String>,
    pub resolution: Option<String>,
    pub resolution_reason: Option<String>,
    pub resolved_by: Option<String>,
    pub resolved_at: Option<i64>,
}

#[derive(Debug, Clone, Copy, Default, Deserialize, Serialize)]
#[serde(rename_all = "camelCase")]
pub(crate) struct JournalHousekeepingReport {
    pub archived_commands: usize,
    pub expired_archives: usize,
    pub expired_events: usize,
    pub expired_maintenance_rows: usize,
    pub expired_farm_jobs: usize,
    pub expired_telemetry_rollups: usize,
}

impl Journal {
    pub fn new(database_path: impl AsRef<Path>) -> Result<Self, String> {
        let database_path = database_path.as_ref();
        Ok(Self {
            database_path: Arc::new(database_path.to_path_buf()),
            readers: kf_storage::ReadPool::new(database_path, READ_POOL_SIZE),
            writer: DatabaseWriter::new(database_path)?,
        })
    }

    pub(crate) fn database_path(&self) -> &Path {
        self.database_path.as_ref().as_path()
    }

    pub(crate) fn read<T, F>(&self, operation: F) -> Result<T, String>
    where
        F: FnOnce(&Connection) -> Result<T, String>,
    {
        self.readers.read_string(operation)
    }

    pub fn writer_snapshot(&self) -> DatabaseWriterSnapshot {
        self.writer.snapshot()
    }

    pub(crate) fn flush_telemetry(&self) -> Result<(), String> {
        self.writer.flush_telemetry()
    }

    pub(crate) fn critical<T, F>(&self, operation: F) -> Result<T, String>
    where
        T: Send + 'static,
        F: FnOnce(&mut Connection) -> Result<T, String> + Send + 'static,
    {
        self.writer.critical(operation)
    }

    pub(crate) fn normal<T, F>(&self, operation: F) -> Result<T, String>
    where
        T: Send + 'static,
        F: FnOnce(&mut Connection) -> Result<T, String> + Send + 'static,
    {
        self.writer.normal(operation)
    }

    pub(crate) fn reserve_actor_session_epoch(
        &self,
        config: &ActorConfig,
        minimum_epoch: u64,
    ) -> Result<u64, String> {
        let config = config.clone();
        self.critical(move |connection| {
            // Reserve before publishing an actor or opening its transport. The
            // immediate transaction also serializes independent Journal writers.
            let transaction = connection
                .transaction_with_behavior(rusqlite::TransactionBehavior::Immediate)
                .map_err(|error| format!("SESSION_EPOCH_RESERVATION_FAILED: {error}"))?;
            let persisted: i64 = transaction
                .query_row(
                    "SELECT COALESCE(MAX(session_epoch),0) FROM (
                         SELECT session_epoch FROM printer_actor_state WHERE stable_id=?1
                         UNION ALL SELECT session_epoch FROM ui_event_outbox WHERE stable_id=?1
                         UNION ALL SELECT session_epoch FROM command_journal WHERE stable_id=?1
                         UNION ALL SELECT session_epoch FROM command_journal_archive WHERE stable_id=?1
                         UNION ALL SELECT session_epoch FROM durable_workflows WHERE stable_id=?1
                     )",
                    params![config.stable_id],
                    |row| row.get(0),
                )
                .map_err(|error| format!("SESSION_EPOCH_RESERVATION_FAILED: {error}"))?;
            let previous = minimum_epoch.max(persisted.max(0) as u64);
            let epoch = previous
                .checked_add(1)
                .filter(|epoch| *epoch <= MAX_SESSION_EPOCH)
                .ok_or_else(|| "SESSION_EPOCH_EXHAUSTED: безопасный счётчик сессий исчерпан".to_string())?;
            // Only the durable high-water mark changes on an existing row.
            // Fresh runtime snapshots are deliberately empty: historical job or
            // temperature values are never restored as current telemetry.
            transaction
                .execute(
                    "INSERT INTO printer_actor_state(
                         stable_id,printer_id,model_id,host,active_port,session_epoch,phase,
                         firmware_signature,capabilities_json,cached_status_json,last_eventtime,
                         last_seen_at,updated_at
                     ) VALUES(?1,?2,?3,?4,?5,?6,'discovered',?7,'{}','{}',NULL,NULL,?8)
                     ON CONFLICT(stable_id) DO UPDATE SET session_epoch=excluded.session_epoch",
                    params![
                        config.stable_id, config.printer_id, config.model_id, config.host,
                        config.default_port, epoch as i64, config.firmware_signature, crate::now_ms(),
                    ],
                )
                .map_err(|error| format!("SESSION_EPOCH_RESERVATION_FAILED: {error}"))?;
            transaction
                .commit()
                .map_err(|error| format!("SESSION_EPOCH_RESERVATION_FAILED: {error}"))?;
            Ok(epoch)
        })
    }

    pub fn create(
        &self,
        stable_id: &str,
        session_epoch: u64,
        request: &OperationRequest,
        now_ms: i64,
    ) -> Result<(), String> {
        let params_json = request
            .params
            .as_ref()
            .map(serde_json::to_string)
            .transpose()
            .map_err(|error| error.to_string())?;
        let stable_id = stable_id.to_string();
        let operation_id = request.operation_id.clone();
        let method = request.method.clone();
        let repeat_policy = request.repeat_policy.as_str().to_string();
        let priority = request.priority.as_str().to_string();
        let deadline_at_ms = request.deadline_at_ms;
        self.writer.critical(move |connection| {
            connection
                .execute(
                    "INSERT INTO command_journal(
                     operation_id,stable_id,session_epoch,method,params_json,repeat_policy,
                     priority,state,attempt_count,created_at,updated_at,deadline_at
                 ) VALUES(?1,?2,?3,?4,?5,?6,?7,'created',0,?8,?8,?9)",
                    params![
                        operation_id,
                        stable_id,
                        session_epoch as i64,
                        method,
                        params_json,
                        repeat_policy,
                        priority,
                        now_ms,
                        deadline_at_ms,
                    ],
                )
                .map(|_| ())
                .map_err(|error| error.to_string())
        })
    }

    pub fn transition(
        &self,
        operation_id: &str,
        state: OperationState,
        now_ms: i64,
        result: Option<&Value>,
        error: Option<&str>,
        increment_attempt: bool,
    ) -> Result<(), String> {
        let result_json = result
            .map(serde_json::to_string)
            .transpose()
            .map_err(|value| value.to_string())?;
        let operation_id = operation_id.to_string();
        let state = state.as_str().to_string();
        let error = error.map(|value| value.chars().take(2048).collect::<String>());
        self.writer.critical(move |connection| {
            let changed = connection
                .execute(
                    "UPDATE command_journal
                 SET state=?2,updated_at=?3,result_json=?4,last_error=?5,
                     attempt_count=attempt_count+CASE WHEN ?6 THEN 1 ELSE 0 END
                 WHERE operation_id=?1",
                    params![
                        operation_id,
                        state,
                        now_ms,
                        result_json,
                        error,
                        increment_attempt,
                    ],
                )
                .map_err(|value| value.to_string())?;
            if changed != 1 {
                return Err("Операция отсутствует в транзакционном журнале".into());
            }
            Ok(())
        })
    }

    pub fn recoverable(&self, stable_id: &str) -> Result<Vec<JournalRecord>, String> {
        self.read(|connection| {
            let mut statement = connection
                .prepare(
                    "SELECT operation_id,method,params_json,repeat_policy,priority,state,deadline_at
                     FROM command_journal
                     WHERE stable_id=?1 AND state IN ('created','queued','sent','unknown')
                     ORDER BY created_at ASC LIMIT 256",
                )
                .map_err(|error| error.to_string())?;
            let rows = statement
                .query_map(params![stable_id], |row| {
                    Ok((
                        row.get::<_, String>(0)?,
                        row.get::<_, String>(1)?,
                        row.get::<_, Option<String>>(2)?,
                        row.get::<_, String>(3)?,
                        row.get::<_, String>(4)?,
                        row.get::<_, String>(5)?,
                        row.get::<_, i64>(6)?,
                    ))
                })
                .map_err(|error| error.to_string())?;
            let rows = rows
                .collect::<Result<Vec<_>, _>>()
                .map_err(|error| format!("Повреждена запись command_journal: {error}"))?;
            rows.into_iter()
                .map(
                    |(
                        operation_id,
                        method,
                        params_json,
                        repeat_policy,
                        priority,
                        state,
                        deadline_at_ms,
                    )| {
                        let params = params_json
                            .map(|value| serde_json::from_str(&value))
                            .transpose()
                            .map_err(|error| {
                                format!(
                                    "Повреждены параметры command_journal {operation_id}: {error}"
                                )
                            })?;
                        Ok(JournalRecord {
                            operation_id,
                            method,
                            params,
                            repeat_policy: RepeatPolicy::from_db(&repeat_policy),
                            priority: OperationPriority::from_db(&priority),
                            state: OperationState::from_db(&state),
                            deadline_at_ms,
                        })
                    },
                )
                .collect()
        })
    }

    pub(crate) fn list_operations(
        &self,
        state: Option<&str>,
        limit: usize,
    ) -> Result<Vec<JournalOperationView>, String> {
        if state.is_some_and(|value| {
            !matches!(
                value,
                "created"
                    | "queued"
                    | "sent"
                    | "confirmed"
                    | "cancelled"
                    | "unknown"
                    | "recovered"
                    | "failed"
            )
        }) {
            return Err("Недопустимый фильтр состояния операции".into());
        }
        self.read(|connection| {
            let mut statement = connection
                .prepare(
                    "SELECT operation_id,stable_id,method,state,priority,attempt_count,
                        created_at,updated_at,deadline_at,last_error,resolution,
                        resolution_reason,resolved_by,resolved_at
                 FROM command_journal
                 WHERE (?1 IS NULL OR state=?1)
                 ORDER BY updated_at DESC LIMIT ?2",
                )
                .map_err(|error| error.to_string())?;
            let rows = statement
                .query_map(params![state, limit.clamp(1, 2_000) as i64], |row| {
                    Ok(JournalOperationView {
                        operation_id: row.get(0)?,
                        stable_id: row.get(1)?,
                        method: row.get(2)?,
                        state: row.get(3)?,
                        priority: row.get(4)?,
                        attempt_count: row.get::<_, i64>(5)?.max(0) as u64,
                        created_at: row.get(6)?,
                        updated_at: row.get(7)?,
                        deadline_at: row.get(8)?,
                        last_error: row.get(9)?,
                        resolution: row.get(10)?,
                        resolution_reason: row.get(11)?,
                        resolved_by: row.get(12)?,
                        resolved_at: row.get(13)?,
                    })
                })
                .map_err(|error| error.to_string())?;
            rows.collect::<Result<Vec<_>, _>>()
                .map_err(|error| format!("Повреждена запись command_journal: {error}"))
        })
    }

    pub(crate) fn resolve_unknown(
        &self,
        operation_id: &str,
        resolution: &str,
        reason: &str,
        resolved_by: &str,
        resolved_at: i64,
    ) -> Result<(), String> {
        let (target_state, resolution) = match resolution {
            "confirmed" => ("confirmed", "manual_confirmed"),
            "cancelled" => ("cancelled", "manual_cancelled"),
            _ => return Err("Resolution должна быть confirmed или cancelled".into()),
        };
        let reason = reason.trim();
        if reason.len() < 3 || reason.len() > 2_048 {
            return Err("Причина ручного закрытия должна содержать 3–2048 символов".into());
        }
        let operation_id = operation_id.to_string();
        let target_state = target_state.to_string();
        let resolution = resolution.to_string();
        let reason = reason.to_string();
        let resolved_by = resolved_by.to_string();
        self.writer.critical(move |connection| {
            let changed = connection
                .execute(
                    "UPDATE command_journal
                     SET state=?2,resolution=?3,resolution_reason=?4,resolved_by=?5,
                         resolved_at=?6,updated_at=?6
                     WHERE operation_id=?1 AND state='unknown'",
                    params![
                        operation_id,
                        target_state,
                        resolution,
                        reason,
                        resolved_by,
                        resolved_at,
                    ],
                )
                .map_err(|error| error.to_string())?;
            if changed != 1 {
                return Err(
                    "UNKNOWN_OPERATION_NOT_FOUND: операция уже закрыта или отсутствует".into(),
                );
            }
            Ok(())
        })
    }

    pub(crate) fn housekeeping(
        &self,
        now_ms: i64,
        command_retention_days: u64,
    ) -> Result<JournalHousekeepingReport, String> {
        let command_cutoff = now_ms
            .saturating_sub(command_retention_days.clamp(7, 365) as i64 * 24 * 60 * 60 * 1_000);
        let archive_cutoff = now_ms.saturating_sub(365_i64 * 24 * 60 * 60 * 1_000);
        let event_cutoff = now_ms.saturating_sub(7_i64 * 24 * 60 * 60 * 1_000);
        let maintenance_cutoff = archive_cutoff;
        let farm_cutoff = now_ms.saturating_sub(90_i64 * 24 * 60 * 60 * 1_000);
        let telemetry_cutoff = now_ms.saturating_sub(395_i64 * 24 * 60 * 60 * 1_000);
        self.writer.critical(move |connection| {
            let transaction = connection
                .transaction()
                .map_err(|error| error.to_string())?;
            transaction
                .execute(
                    "INSERT OR IGNORE INTO command_journal_archive(
                         operation_id,stable_id,session_epoch,method,params_json,repeat_policy,
                         priority,state,attempt_count,created_at,updated_at,deadline_at,
                         result_json,last_error,resolution,resolution_reason,resolved_by,
                         resolved_at,archived_at
                     )
                     SELECT operation_id,stable_id,session_epoch,method,params_json,repeat_policy,
                            priority,state,attempt_count,created_at,updated_at,deadline_at,
                            result_json,last_error,resolution,resolution_reason,resolved_by,
                            resolved_at,?2
                     FROM command_journal
                     WHERE state IN ('confirmed','cancelled','recovered','failed') AND updated_at<?1",
                    params![command_cutoff, now_ms],
                )
                .map_err(|error| error.to_string())?;
            let archived_commands = transaction
                .execute(
                    "DELETE FROM command_journal
                     WHERE state IN ('confirmed','cancelled','recovered','failed') AND updated_at<?1
                       AND operation_id IN(SELECT operation_id FROM command_journal_archive)",
                    params![command_cutoff],
                )
                .map_err(|error| error.to_string())?;
            let expired_archives = transaction
                .execute(
                    "DELETE FROM command_journal_archive WHERE archived_at<?1",
                    params![archive_cutoff],
                )
                .map_err(|error| error.to_string())?;
            let expired_events = transaction
                .execute(
                    "DELETE FROM ui_event_outbox
                     WHERE acked_at IS NOT NULL AND acked_at<?1 AND event_id NOT IN(
                         SELECT event_id FROM ui_event_outbox ORDER BY event_id DESC LIMIT 10000
                     )",
                    params![event_cutoff],
                )
                .map_err(|error| error.to_string())?;
            let expired_maintenance_rows = transaction
                .execute(
                    "DELETE FROM maintenance_observations WHERE observed_at<?1",
                    params![maintenance_cutoff],
                )
                .map_err(|error| error.to_string())?;
            let expired_farm_jobs = transaction
                .execute(
                    "DELETE FROM farm_queue_v2
                     WHERE state IN ('dispatched','completed','cancelled') AND updated_at<?1",
                    params![farm_cutoff],
                )
                .map_err(|error| error.to_string())?;
            let expired_telemetry_rollups = transaction
                .execute(
                    "DELETE FROM telemetry_rollups_hourly WHERE bucket_start<?1",
                    params![telemetry_cutoff],
                )
                .map_err(|error| error.to_string())?;
            transaction.commit().map_err(|error| error.to_string())?;
            Ok(JournalHousekeepingReport {
                archived_commands,
                expired_archives,
                expired_events,
                expired_maintenance_rows,
                expired_farm_jobs,
                expired_telemetry_rollups,
            })
        })
    }

    #[allow(clippy::too_many_arguments)]
    pub fn save_actor_state(
        &self,
        stable_id: &str,
        printer_id: &str,
        model_id: Option<&str>,
        host: &str,
        active_port: u16,
        session_epoch: u64,
        phase: PrinterPhase,
        firmware_signature: Option<&str>,
        capabilities: &PrinterCapabilities,
        cached_status: &Value,
        last_eventtime: Option<f64>,
        last_seen_at: Option<i64>,
        now_ms: i64,
    ) -> Result<(), String> {
        let capabilities_json =
            serde_json::to_string(capabilities).map_err(|error| error.to_string())?;
        let cached_status_json =
            serde_json::to_string(cached_status).map_err(|error| error.to_string())?;
        self.writer.actor_snapshot(ActorStateWrite {
            stable_id: stable_id.to_string(),
            printer_id: printer_id.to_string(),
            model_id: model_id.map(str::to_string),
            host: host.to_string(),
            active_port,
            session_epoch,
            phase: phase.as_str().to_string(),
            firmware_signature: firmware_signature.map(str::to_string),
            capabilities_json,
            cached_status_json,
            last_eventtime,
            last_seen_at,
            updated_at: now_ms,
        })
    }

    pub fn stable_id_for_printer(&self, printer_id: &str) -> Result<Option<String>, String> {
        self.read(|connection| {
            connection
                .query_row(
                    "SELECT stable_id FROM printer_actor_state
                 WHERE printer_id=?1 AND stable_id LIKE 'kf-device-%'
                 ORDER BY updated_at DESC LIMIT 1",
                    params![printer_id],
                    |row| row.get(0),
                )
                .optional()
                .map_err(|error| error.to_string())
        })
    }

    pub(crate) fn farm_job_events(
        &self,
        job_id: &str,
        limit: usize,
    ) -> Result<Vec<super::farm_queue::FarmJobEvent>, String> {
        self.read(|connection| super::farm_queue::list_events(connection, job_id, limit))
    }

    pub fn record_frame(
        &self,
        trace_id: &str,
        stable_id: &str,
        direction: &str,
        sequence_no: u64,
        frame: Value,
        recorded_at: i64,
    ) -> Result<(), String> {
        let trace_id = trace_id.to_string();
        let stable_id = stable_id.to_string();
        let direction = direction.to_string();
        self.writer.critical(move |connection| {
            super::verification::record_frame(
                connection,
                &trace_id,
                &stable_id,
                &super::verification::ReplayFrame {
                    sequence_no,
                    delay_ms: 0,
                    direction,
                    frame,
                },
                recorded_at,
            )?;
            if sequence_no.is_multiple_of(256) {
                connection.execute(
                    "DELETE FROM replay_frames WHERE stable_id=?1 AND id NOT IN(
                         SELECT id FROM replay_frames WHERE stable_id=?1 ORDER BY id DESC LIMIT 20000
                     )",
                    params![stable_id],
                )
                .map_err(|error| error.to_string())?;
            }
            Ok(())
        })
    }

    pub fn append_event(&self, event: &ActorEvent, created_at: i64) -> Result<i64, String> {
        let status_json = event
            .status
            .as_ref()
            .map(serde_json::to_string)
            .transpose()
            .map_err(|error| error.to_string())?;
        let payload_json = event
            .payload
            .as_ref()
            .map(serde_json::to_string)
            .transpose()
            .map_err(|error| error.to_string())?;
        let stable_id = event.stable_id.clone();
        let printer_id = event.printer_id.clone();
        let session_epoch = event.session_epoch;
        let kind = event.kind.clone();
        let phase = event.phase.as_str().to_string();
        let eventtime = event.eventtime;
        let operation_id = event.operation_id.clone();
        self.writer.critical(move |connection| {
            connection
                .execute(
                    "INSERT INTO ui_event_outbox(
                     stable_id,printer_id,session_epoch,kind,phase,eventtime,status_json,
                     operation_id,payload_json,created_at,acked_at
                 ) VALUES(?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,NULL)",
                    params![
                        stable_id,
                        printer_id,
                        session_epoch as i64,
                        kind,
                        phase,
                        eventtime,
                        status_json,
                        operation_id,
                        payload_json,
                        created_at,
                    ],
                )
                .map_err(|error| error.to_string())?;
            Ok(connection.last_insert_rowid())
        })
    }

    pub fn pending_events(
        &self,
        printer_id: &str,
        limit: usize,
    ) -> Result<Vec<ActorEvent>, String> {
        self.read(|connection| {
            let mut statement = connection
                .prepare(
                    "SELECT event_id,stable_id,printer_id,session_epoch,kind,phase,eventtime,
                        status_json,operation_id,payload_json
                 FROM ui_event_outbox
                 WHERE printer_id=?1 AND acked_at IS NULL
                 ORDER BY event_id ASC LIMIT ?2",
                )
                .map_err(|error| error.to_string())?;
            let rows = statement
                .query_map(params![printer_id, limit.clamp(1, 2_000) as i64], |row| {
                    Ok((
                        row.get::<_, i64>(0)?,
                        row.get::<_, String>(1)?,
                        row.get::<_, String>(2)?,
                        row.get::<_, i64>(3)?,
                        row.get::<_, String>(4)?,
                        row.get::<_, String>(5)?,
                        row.get::<_, Option<f64>>(6)?,
                        row.get::<_, Option<String>>(7)?,
                        row.get::<_, Option<String>>(8)?,
                        row.get::<_, Option<String>>(9)?,
                    ))
                })
                .map_err(|error| error.to_string())?;
            let rows = rows
                .collect::<Result<Vec<_>, _>>()
                .map_err(|error| format!("Повреждена запись ui_event_outbox: {error}"))?;
            rows.into_iter()
                .map(
                    |(
                        event_id,
                        stable_id,
                        printer_id,
                        session_epoch,
                        kind,
                        phase,
                        eventtime,
                        status_json,
                        operation_id,
                        payload_json,
                    )| {
                        let status = status_json
                            .map(|value| serde_json::from_str(&value))
                            .transpose()
                            .map_err(|error| {
                                format!("Повреждён status_json события {event_id}: {error}")
                            })?;
                        let payload = payload_json
                            .map(|value| serde_json::from_str(&value))
                            .transpose()
                            .map_err(|error| {
                                format!("Повреждён payload_json события {event_id}: {error}")
                            })?;
                        Ok(ActorEvent {
                            event_id,
                            stable_id,
                            printer_id,
                            session_epoch: session_epoch.max(0) as u64,
                            kind,
                            phase: PrinterPhase::from_db(&phase),
                            eventtime,
                            // Old durable rows have no per-group observation
                            // provenance. Replaying them must not make cached
                            // temperatures or job values appear newly seen.
                            telemetry_updated_at: None,
                            nozzle_updated_at: None,
                            bed_updated_at: None,
                            job_updated_at: None,
                            status,
                            operation_id,
                            payload,
                        })
                    },
                )
                .collect()
        })
    }

    pub fn acknowledge_events(
        &self,
        printer_id: &str,
        through_event_id: i64,
        acknowledged_at: i64,
    ) -> Result<usize, String> {
        if through_event_id <= 0 {
            return Ok(0);
        }
        let printer_id = printer_id.to_string();
        self.writer.critical(move |connection| {
            let changed = connection
                .execute(
                    "UPDATE ui_event_outbox SET acked_at=?3
                 WHERE printer_id=?1 AND event_id<=?2 AND acked_at IS NULL",
                    params![printer_id, through_event_id, acknowledged_at],
                )
                .map_err(|error| error.to_string())?;
            connection
                .execute(
                    "DELETE FROM ui_event_outbox
                 WHERE acked_at IS NOT NULL AND acked_at<?1 AND event_id NOT IN(
                     SELECT event_id FROM ui_event_outbox ORDER BY event_id DESC LIMIT 10000
                 )",
                    params![acknowledged_at.saturating_sub(7 * 24 * 60 * 60 * 1_000)],
                )
                .map_err(|error| error.to_string())?;
            Ok(changed)
        })
    }

    pub fn save_identity_attestation(
        &self,
        stable_id: &str,
        attestation: &PrinterIdentityAttestation,
    ) -> Result<(), String> {
        let signals_json =
            serde_json::to_string(&attestation.signals).map_err(|error| error.to_string())?;
        let trusted_observed = attestation
            .verified
            .then(|| attestation.observed_stable_id.clone())
            .flatten();
        let trusted_fingerprint = if attestation.verified {
            attestation.fingerprint.as_str()
        } else {
            ""
        };
        let trusted_signals = if attestation.verified {
            signals_json.as_str()
        } else {
            "{}"
        };
        let stable_id = stable_id.to_string();
        let trusted_fingerprint = trusted_fingerprint.to_string();
        let trusted_signals = trusted_signals.to_string();
        let verified = attestation.verified;
        let reason = attestation.reason.clone();
        let attested_at = attestation.attested_at;
        self.writer.critical(move |connection| {
            connection.execute(
                "INSERT INTO printer_identity_attestation(
                     stable_id,observed_stable_id,fingerprint,signals_json,verified,reason,attested_at
                 ) VALUES(?1,?2,?3,?4,?5,?6,?7)
                 ON CONFLICT(stable_id) DO UPDATE SET
                     observed_stable_id=CASE WHEN excluded.verified
                         THEN excluded.observed_stable_id
                         ELSE printer_identity_attestation.observed_stable_id END,
                     fingerprint=CASE WHEN excluded.verified
                         THEN excluded.fingerprint
                         ELSE printer_identity_attestation.fingerprint END,
                     signals_json=CASE WHEN excluded.verified
                         THEN excluded.signals_json
                         ELSE printer_identity_attestation.signals_json END,
                     verified=excluded.verified,reason=excluded.reason,attested_at=excluded.attested_at",
                params![
                    stable_id,
                    trusted_observed,
                    trusted_fingerprint,
                    trusted_signals,
                    verified,
                    reason,
                    attested_at,
                ],
            )
            .map(|_| ())
            .map_err(|error| error.to_string())
        })
    }

    pub fn identity_baseline(&self, stable_id: &str) -> Result<Option<(String, String)>, String> {
        self.read(|connection| {
            connection
                .query_row(
                    "SELECT observed_stable_id,fingerprint
                 FROM printer_identity_attestation
                 WHERE stable_id=?1 AND observed_stable_id IS NOT NULL",
                    params![stable_id],
                    |row| Ok((row.get(0)?, row.get(1)?)),
                )
                .optional()
                .map_err(|error| error.to_string())
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::BTreeMap;
    use std::time::{SystemTime, UNIX_EPOCH};

    fn epoch_fixture(label: &str) -> (PathBuf, Journal, ActorConfig) {
        let nonce = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos();
        let path = std::env::temp_dir().join(format!("kf-session-epoch-{label}-{}-{nonce}.sqlite3", std::process::id()));
        let mut connection = Connection::open(&path).unwrap();
        super::super::migrations::migrate(&mut connection, 1).unwrap();
        drop(connection);
        let journal = Journal::new(&path).unwrap();
        let config = ActorConfig {
            stable_id: "epoch-printer".into(), printer_id: "epoch-printer".into(),
            model_id: Some("custom".into()), host: "127.0.0.1:7125".into(),
            default_port: 7125, api_key: None, firmware_signature: None, capabilities_hint: None,
        };
        (path, journal, config)
    }

    #[test]
    fn session_epoch_reservation_exceeds_every_durable_generation_after_restart() {
        let (path, journal, config) = epoch_fixture("legacy-restart");
        assert_eq!(journal.reserve_actor_session_epoch(&config, 0).unwrap(), 1);
        journal.critical(|connection| {
            connection.execute_batch(
                "UPDATE printer_actor_state SET session_epoch=31;
                 INSERT INTO ui_event_outbox(stable_id,printer_id,session_epoch,kind,phase,created_at)
                     VALUES('epoch-printer','epoch-printer',48,'connected','ready',1);
                 INSERT INTO command_journal(operation_id,stable_id,session_epoch,method,repeat_policy,priority,state,created_at,updated_at)
                     VALUES('old-command','epoch-printer',51,'server.info','safe','telemetry','confirmed',1,1);
                 INSERT INTO command_journal_archive(operation_id,stable_id,session_epoch,method,repeat_policy,priority,state,attempt_count,created_at,updated_at,deadline_at,archived_at)
                     VALUES('archived-command','epoch-printer',54,'server.info','safe','telemetry','confirmed',1,1,1,2,2);
                 INSERT INTO durable_workflows(workflow_id,operation_id,stable_id,session_epoch,kind,state,deadline_at,idempotency_key,payload_json,created_at,updated_at)
                     VALUES('old-workflow','old-upload','epoch-printer',57,'upload','completed',2,'old-workflow','{}',1,1);"
            ).map_err(|error| error.to_string())
        }).unwrap();
        drop(journal);
        let restarted = Journal::new(&path).unwrap();
        assert_eq!(restarted.reserve_actor_session_epoch(&config, 0).unwrap(), 58);
        assert_eq!(restarted.reserve_actor_session_epoch(&config, 80).unwrap(), 81);
        let persisted: i64 = restarted.read(|connection| connection.query_row(
            "SELECT session_epoch FROM printer_actor_state WHERE stable_id='epoch-printer'", [], |row| row.get(0)
        ).map_err(|error| error.to_string())).unwrap();
        assert_eq!(persisted, 81);
        drop(restarted);
        let _ = std::fs::remove_file(path);
    }

    #[test]
    fn session_epoch_reservations_serialize_independent_writers_and_seven_printers() {
        let (path, journal, config) = epoch_fixture("concurrent");
        let barrier = Arc::new(std::sync::Barrier::new(7));
        let threads: Vec<_> = (0..7).map(|_| {
            let writer = Journal::new(&path).unwrap();
            let config = config.clone();
            let barrier = Arc::clone(&barrier);
            std::thread::spawn(move || { barrier.wait(); writer.reserve_actor_session_epoch(&config, 0).unwrap() })
        }).collect();
        let mut epochs: Vec<_> = threads.into_iter().map(|thread| thread.join().unwrap()).collect();
        epochs.sort_unstable();
        assert_eq!(epochs, vec![1, 2, 3, 4, 5, 6, 7]);
        let barrier = Arc::new(std::sync::Barrier::new(7));
        let threads: Vec<_> = (0..7).map(|index| {
            let writer = journal.clone();
            let mut config = config.clone();
            config.stable_id = format!("independent-{index}");
            config.printer_id = config.stable_id.clone();
            let barrier = Arc::clone(&barrier);
            std::thread::spawn(move || { barrier.wait(); writer.reserve_actor_session_epoch(&config, 0).unwrap() })
        }).collect();
        for thread in threads { assert_eq!(thread.join().unwrap(), 1); }
        assert_eq!(journal.reserve_actor_session_epoch(&config, 0).unwrap(), 8);
        drop(journal);
        let _ = std::fs::remove_file(path);
    }

    #[test]
    fn session_epoch_reservation_failure_and_exhaustion_never_advance_the_counter() {
        let (path, journal, config) = epoch_fixture("fail-closed");
        assert_eq!(journal.reserve_actor_session_epoch(&config, 0).unwrap(), 1);
        journal.critical(|connection| connection.execute_batch(
            "CREATE TRIGGER reject_session_epoch BEFORE UPDATE OF session_epoch ON printer_actor_state
                 BEGIN SELECT RAISE(ABORT,'injected reservation failure'); END;"
        ).map_err(|error| error.to_string())).unwrap();
        assert!(journal.reserve_actor_session_epoch(&config, 0).unwrap_err().contains("SESSION_EPOCH_RESERVATION_FAILED"));
        journal.critical(|connection| connection.execute_batch("DROP TRIGGER reject_session_epoch;").map_err(|error| error.to_string())).unwrap();
        assert_eq!(journal.reserve_actor_session_epoch(&config, 0).unwrap(), 2);
        for maximum in [MAX_SESSION_EPOCH, u64::MAX] {
            assert!(journal.reserve_actor_session_epoch(&config, maximum).unwrap_err().contains("SESSION_EPOCH_EXHAUSTED"));
        }
        assert_eq!(journal.reserve_actor_session_epoch(&config, 0).unwrap(), 3);
        drop(journal);
        let _ = std::fs::remove_file(path);
    }

    fn attestation(
        stable_id: &str,
        fingerprint: &str,
        verified: bool,
    ) -> PrinterIdentityAttestation {
        PrinterIdentityAttestation {
            observed_stable_id: Some(stable_id.to_string()),
            fingerprint: fingerprint.to_string(),
            signals: BTreeMap::from([("machineId".into(), stable_id.into())]),
            verified,
            reason: (!verified).then(|| "IDENTITY_MISMATCH".into()),
            attested_at: 1,
        }
    }

    #[test]
    fn failed_identity_check_does_not_replace_trusted_baseline() {
        let nonce = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        let path = std::env::temp_dir().join(format!(
            "klipper-farm-journal-{}-{nonce}.sqlite3",
            std::process::id()
        ));
        let mut connection = Connection::open(&path).unwrap();
        super::super::migrations::migrate(&mut connection, 1).unwrap();
        drop(connection);

        let journal = Journal::new(&path).unwrap();
        journal
            .save_identity_attestation(
                "legacy-printer",
                &attestation("kf-device-1111111111111111", "fingerprint-a", true),
            )
            .unwrap();
        journal
            .save_identity_attestation(
                "legacy-printer",
                &attestation("kf-device-2222222222222222", "fingerprint-b", false),
            )
            .unwrap();
        assert_eq!(
            journal.identity_baseline("legacy-printer").unwrap(),
            Some(("kf-device-1111111111111111".into(), "fingerprint-a".into()))
        );

        drop(journal);
        let _ = std::fs::remove_file(&path);
        let _ = std::fs::remove_file(path.with_extension("sqlite3-wal"));
        let _ = std::fs::remove_file(path.with_extension("sqlite3-shm"));
    }

    #[test]
    fn corrupt_command_payload_is_reported_instead_of_skipped() {
        let nonce = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        let path = std::env::temp_dir().join(format!(
            "klipper-farm-corrupt-journal-{}-{nonce}.sqlite3",
            std::process::id()
        ));
        let mut connection = Connection::open(&path).unwrap();
        super::super::migrations::migrate(&mut connection, 1).unwrap();
        drop(connection);

        let journal = Journal::new(&path).unwrap();
        let request = OperationRequest {
            operation_id: "11111111111111111111111111111111".into(),
            method: "printer.objects.query".into(),
            params: Some(serde_json::json!({"objects":{"print_stats":null}})),
            priority: OperationPriority::Telemetry,
            repeat_policy: RepeatPolicy::Safe,
            prefer_rest: false,
            timeout_ms: 8_000,
            deadline_at_ms: 9_000,
            expected_session_epoch: None,
        };
        journal.create("stable-printer", 1, &request, 1).unwrap();
        journal
            .transition(
                &request.operation_id,
                OperationState::Unknown,
                2,
                None,
                None,
                false,
            )
            .unwrap();
        let operation_id = request.operation_id.clone();
        journal
            .critical(move |connection| {
                connection
                    .execute(
                        "UPDATE command_journal SET params_json='{' WHERE operation_id=?1",
                        params![operation_id],
                    )
                    .map(|_| ())
                    .map_err(|error| error.to_string())
            })
            .unwrap();

        let error = journal
            .recoverable("stable-printer")
            .expect_err("corrupt JSON must fail closed");
        assert!(error.contains("Повреждены параметры command_journal"));

        drop(journal);
        let _ = std::fs::remove_file(&path);
        let _ = std::fs::remove_file(path.with_extension("sqlite3-wal"));
        let _ = std::fs::remove_file(path.with_extension("sqlite3-shm"));
    }

    #[test]
    fn unknown_operation_requires_audited_resolution_before_retention() {
        let nonce = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        let path = std::env::temp_dir().join(format!(
            "klipper-farm-resolution-journal-{}-{nonce}.sqlite3",
            std::process::id()
        ));
        let mut connection = Connection::open(&path).unwrap();
        super::super::migrations::migrate(&mut connection, 1).unwrap();
        drop(connection);
        let journal = Journal::new(&path).unwrap();
        let request = OperationRequest {
            operation_id: "22222222222222222222222222222222".into(),
            method: "printer.print.start".into(),
            params: Some(serde_json::json!({"filename":"part.gcode"})),
            priority: OperationPriority::Control,
            repeat_policy: RepeatPolicy::Never,
            prefer_rest: false,
            timeout_ms: 8_000,
            deadline_at_ms: 9_000,
            expected_session_epoch: None,
        };
        journal.create("stable-printer", 1, &request, 1).unwrap();
        journal
            .transition(
                &request.operation_id,
                OperationState::Unknown,
                2,
                None,
                Some("result uncertain"),
                true,
            )
            .unwrap();
        assert_eq!(
            journal.list_operations(Some("unknown"), 10).unwrap().len(),
            1
        );
        journal
            .resolve_unknown(
                &request.operation_id,
                "confirmed",
                "operator verified printer state",
                "admin-1",
                3,
            )
            .unwrap();
        let resolved = journal.list_operations(Some("confirmed"), 10).unwrap();
        assert_eq!(resolved.len(), 1);
        assert_eq!(resolved[0].resolution.as_deref(), Some("manual_confirmed"));
        let report = journal
            .housekeeping(100_i64 * 24 * 60 * 60 * 1_000, 90)
            .unwrap();
        assert_eq!(report.archived_commands, 1);
        assert!(journal
            .list_operations(Some("confirmed"), 10)
            .unwrap()
            .is_empty());
        let archived: i64 = journal
            .read(|connection| {
                connection
                    .query_row(
                        "SELECT COUNT(*) FROM command_journal_archive WHERE operation_id=?1",
                        params![request.operation_id],
                        |row| row.get(0),
                    )
                    .map_err(|error| error.to_string())
            })
            .unwrap();
        assert_eq!(archived, 1);
        drop(journal);
        let _ = std::fs::remove_file(&path);
        let _ = std::fs::remove_file(path.with_extension("sqlite3-wal"));
        let _ = std::fs::remove_file(path.with_extension("sqlite3-shm"));
    }
}
