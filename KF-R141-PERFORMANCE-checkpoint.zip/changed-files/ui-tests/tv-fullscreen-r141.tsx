import { useState } from 'react';
import { createRoot } from 'react-dom/client';
import { TvDashboard } from '../src/components/TvDashboard';
import { hasPrinterCamera } from '../src/components/PrinterCamera';
import { I18nProvider } from '../src/i18n';
import { setAuthSession } from '../src/lib/auth';
import { emptyFilamentInventory, FILAMENT_INVENTORY_KEY } from '../src/lib/filamentInventory';
import type { PrinterModel } from '../src/types';
import '../src/styles.css';

const w=window as any,params=new URLSearchParams(location.search),now=Date.now();
w.isTauri=params.get('native')==='true';
const calls:unknown[]=[],listeners=new Set<()=>void>(),nativeCalls:string[]=[],domCalls:string[]=[];
let fullscreen=params.get('borrowed')==='true',maximized=params.get('maximized')!=='false',listenerDelay=Number(params.get('listenerDelay')??0),enterDelay=0,rejectEntry=false;
let releaseEntry:(()=>void)|undefined;
const request=Element.prototype.requestFullscreen,exit=Document.prototype.exitFullscreen;
Element.prototype.requestFullscreen=function(options){domCalls.push('requestFullscreen');return request.call(this,options)};
Document.prototype.exitFullscreen=function(){domCalls.push('exitFullscreen');return exit.call(this)};
const nativeWindow={
  async isFullscreen(){nativeCalls.push('readFullscreen');return fullscreen},
  async isMaximized(){nativeCalls.push('readMaximized');return maximized},
  async setFullscreen(value:boolean){nativeCalls.push('set:'+value);if(value&&enterDelay)await new Promise<void>(resolve=>{releaseEntry=resolve});if(value&&rejectEntry)throw new Error('native permission denied');fullscreen=value;maximized=false;for(const listener of listeners)listener()},
  async maximize(){nativeCalls.push('maximize');maximized=true},
  async onResized(callback:()=>void){nativeCalls.push('listen');if(listenerDelay)await new Promise(resolve=>setTimeout(resolve,listenerDelay));listeners.add(callback);return()=>{nativeCalls.push('unlisten');listeners.delete(callback)}},
};
const ledger=emptyFilamentInventory(now-86400000);
w.__TAURI_INTERNALS__={invoke:async(command:string,args:any={})=>{calls.push({command,args});if(command==='db_get_json'&&args.key===FILAMENT_INVENTORY_KEY)return JSON.stringify(ledger);throw new Error('Unexpected fullscreen fixture IPC '+command)}};
setAuthSession({token:'fullscreen-fixture-only',user:{id:'operator',name:'Operator',role:'operator',enabled:true,createdAt:0}});
// Fullscreen lifecycle tests intentionally have no camera inference or media
// negotiation. The separate TV/camera suites exercise actual media behavior.
const printers:PrinterModel[]=Array.from({length:7},(_,index)=>({id:'printer-'+index,name:'Fullscreen fixture printer '+(index+1),host:'192.0.2.'+(index+1),webcams:[],status:{state:'printing',connectionState:'online',progress:.54,filename:'fixture.gcode',printDuration:3660,nozzle:255,nozzleTarget:260,bed:80,bedTarget:80,telemetryUpdatedAt:now,jobUpdatedAt:now,lastSeen:now}}));
const fixture={nativeWindow,nativeCalls,domCalls,calls,cameraAvailability:printers.map(printer=>({id:printer.id,hasCamera:hasPrinterCamera(printer)})),closed:0,opened:0,open:()=>{},close:()=>{},
  state:()=>({fullscreen,maximized,listeners:listeners.size,bodyOverflow:document.body.style.overflow,domFullscreen:document.fullscreenElement?.className??null}),
  setDelays:(entry:number,listener:number)=>{enterDelay=entry;listenerDelay=listener},
  rejectEntry:(value:boolean)=>{rejectEntry=value},
  releaseEntry:()=>{enterDelay=0;releaseEntry?.();releaseEntry=undefined},
  externalExit:()=>{fullscreen=false;for(const listener of listeners)listener()},
};
w.__fullscreenFixture=fixture;
function Fixture(){
  const [open,setOpen]=useState(true);fixture.open=()=>{fixture.opened++;setOpen(true)};fixture.close=()=>{fixture.closed++;setOpen(false)};
  return open?<TvDashboard printers={printers} onClose={fixture.close}/>:<div id="fixtureClosed">Панель закрыта</div>;
}
document.getElementById('fixtureOpener')!.onclick=()=>fixture.open();
document.getElementById('fixtureOpener')!.focus();
createRoot(document.getElementById('root')!).render(<I18nProvider><Fixture/></I18nProvider>);
