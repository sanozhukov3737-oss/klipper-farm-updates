import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import http from 'node:http';
import {createHash} from 'node:crypto';
import {build} from 'vite';

const root=path.resolve(import.meta.dirname,'..'),out=fs.mkdtempSync(path.join(os.tmpdir(),'kf-tv-fullscreen-r141-'));
const proof=path.resolve(process.env.KF_R141_FULLSCREEN_UI_PROOF_DIR??path.join(root,'../r141-fullscreen-proof'));
const sourceFiles=['src/lib/tvFullscreen.ts','src/components/TvDashboard.tsx','src/components/TvDashboard.css','src/lib/tvSpotlight.ts'];
const hashes=()=>Object.fromEntries(sourceFiles.map(file=>[file,createHash('sha256').update(fs.readFileSync(path.join(root,file))).digest('hex')]));
const sources=hashes(),cases=[],runtimeErrors=[],externalRequests=[];
let browser,server,page,currentCase='build';
const passed=(name,details={})=>{cases.push({name,passed:true,...details});console.log('PASS '+name)};
const snapshot=page=>page.evaluate(()=>({...window.__fullscreenFixture.state(),nativeCalls:window.__fullscreenFixture.nativeCalls,domCalls:window.__fullscreenFixture.domCalls,closed:window.__fullscreenFixture.closed,calls:window.__fullscreenFixture.calls}));
const nativeEffects=state=>state.nativeCalls.filter(call=>call.startsWith('set:')||call==='maximize');
const enter=page=>page.getByRole('button',{name:'На весь экран',exact:true}).click();
const close=page=>page.getByRole('button',{name:'Закрыть TV-панель',exact:true}).click();
const leave=page=>page.getByRole('button',{name:'Выйти из полного экрана',exact:true}).click();
const closed=async page=>{await page.locator('#fixtureClosed').waitFor();await page.waitForFunction(()=>window.__fullscreenFixture.state().listeners===0&&document.fullscreenElement===null);assert.notEqual((await snapshot(page)).bodyOverflow,'hidden');assert.equal(await page.evaluate(()=>document.activeElement?.id),'fixtureOpener')};
const assertNoWrites=async page=>assert.ok((await snapshot(page)).calls.every(call=>call.command==='db_get_json'),'Fullscreen must not dispatch printer, G-code, inventory or configuration writes');
try{
  await build({root,base:'./',publicDir:false,logLevel:'error',resolve:{alias:{'@tauri-apps/api/window':path.join(root,'ui-tests/tv-fullscreen-r141-window.ts')}},build:{outDir:out,emptyOutDir:true,rollupOptions:{input:path.join(root,'ui-tests/tv-fullscreen-r141.html')}}});
  server=http.createServer((req,res)=>{
    const relative=new URL(req.url,'http://localhost').pathname.slice(1),built=path.resolve(out,relative),publicFile=path.resolve(root,'public',relative);
    const file=[built,publicFile].find(file=>(file.startsWith(out+path.sep)||file.startsWith(path.join(root,'public')+path.sep))&&fs.existsSync(file)&&fs.statSync(file).isFile());
    if(!file){res.writeHead(404).end();return}
    res.setHeader('Content-Type',({'.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png','.webp':'image/webp','.jpg':'image/jpeg','.svg':'image/svg+xml','.woff2':'font/woff2'})[path.extname(file)]??'application/octet-stream');res.end(fs.readFileSync(file));
  });
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const origin='http://127.0.0.1:'+server.address().port;
  const {chromium}=await import(process.env.PLAYWRIGHT_MODULE_PATH??'playwright');
  browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_EXECUTABLE,args:['--no-sandbox','--disable-dev-shm-usage','--enable-unsafe-swiftshader']});
  fs.mkdirSync(proof,{recursive:true});
  const open=async(params={})=>{
    page=await browser.newPage({viewport:{width:1366,height:900},locale:'ru-RU',reducedMotion:'reduce'});page.setDefaultTimeout(10000);
    page.on('pageerror',error=>runtimeErrors.push({case:currentCase,message:error.message}));
    await page.route('**/*',route=>{if(route.request().url().startsWith(origin+'/'))return route.continue();externalRequests.push(route.request().url());return route.abort()});
    await page.goto(origin+'/ui-tests/tv-fullscreen-r141.html?'+new URLSearchParams(params));await page.locator('.tvDashboard').waitFor();
    await page.waitForFunction(()=>window.__fullscreenFixture.calls.some(call=>call.command==='db_get_json'));
    return page;
  };
  const check=async(name,params,run)=>{currentCase=name;await open(params);await run(page);await assertNoWrites(page);passed(name);await page.close()};

  await check('native-maximized-fullscreen-X-restores-main-window-and-focus',{native:'true'},async page=>{
    await enter(page);await page.getByRole('button',{name:'Выйти из полного экрана',exact:true}).waitFor();assert.equal((await snapshot(page)).fullscreen,true);
    await page.screenshot({path:path.join(proof,'native-fullscreen-before-close.png')});await close(page);await closed(page);await page.waitForFunction(()=>window.__fullscreenFixture.state().maximized);
    const state=await snapshot(page);assert.deepEqual(nativeEffects(state),['set:true','set:false','maximize']);assert.deepEqual(state.domCalls,[]);assert.equal(state.fullscreen,false);assert.equal(state.closed,1);
    await page.screenshot({path:path.join(proof,'native-main-window-after-close.png')});
  });
  await check('native-normal-window-X-does-not-force-maximize',{native:'true',maximized:'false'},async page=>{
    await enter(page);await page.getByRole('button',{name:'Выйти из полного экрана',exact:true}).waitFor();await close(page);await closed(page);
    const state=await snapshot(page);assert.deepEqual(nativeEffects(state),['set:true','set:false']);assert.equal(state.maximized,false);assert.deepEqual(state.domCalls,[]);
  });
  await check('native-borrowed-fullscreen-X-does-not-alter-main-window',{native:'true',borrowed:'true'},async page=>{
    await enter(page);await page.getByRole('button',{name:'Выйти из полного экрана',exact:true}).waitFor();await close(page);await closed(page);
    const state=await snapshot(page);assert.equal(state.fullscreen,true);assert.deepEqual(nativeEffects(state),[]);assert.deepEqual(state.domCalls,[]);
  });
  await check('native-manual-arrow-leaves-TV-open-and-restores-maximize',{native:'true'},async page=>{
    await enter(page);await leave(page);await page.getByRole('button',{name:'На весь экран',exact:true}).waitFor();assert.equal(await page.locator('.tvDashboard').count(),1);const state=await snapshot(page);assert.equal(state.closed,0);assert.equal(state.maximized,true);assert.equal(state.fullscreen,false);assert.deepEqual(state.domCalls,[]);await close(page);await closed(page);
  });
  await check('native-Escape-closes-and-restores-owned-fullscreen',{native:'true'},async page=>{
    await enter(page);await page.getByRole('button',{name:'Выйти из полного экрана',exact:true}).waitFor();await page.keyboard.press('Escape');await closed(page);await page.waitForFunction(()=>window.__fullscreenFixture.state().maximized);assert.deepEqual(nativeEffects(await snapshot(page)),['set:true','set:false','maximize']);
  });
  await check('native-external-fullscreen-exit-closes-TV-without-DOM-fullscreen',{native:'true'},async page=>{
    await enter(page);await page.getByRole('button',{name:'Выйти из полного экрана',exact:true}).waitFor();await page.evaluate(()=>window.__fullscreenFixture.externalExit());await closed(page);await page.waitForFunction(()=>window.__fullscreenFixture.state().maximized);assert.deepEqual((await snapshot(page)).domCalls,[]);
  });
  await check('native-permission-denial-remains-inline-and-never-enters-DOM-fullscreen',{native:'true'},async page=>{
    await page.evaluate(()=>window.__fullscreenFixture.rejectEntry(true));await enter(page);await page.getByText('Полный экран недоступен. Панель занимает всё окно программы.',{exact:true}).waitFor();const state=await snapshot(page);assert.equal(state.fullscreen,false);assert.equal(state.maximized,true);assert.deepEqual(state.domCalls,[]);assert.equal(state.closed,0);await close(page);await closed(page);
  });
  await check('native-delayed-entry-close-reopen-restores-before-new-entry',{native:'true'},async page=>{
    await page.evaluate(()=>window.__fullscreenFixture.setDelays(1,0));await enter(page);await page.waitForFunction(()=>window.__fullscreenFixture.nativeCalls.includes('set:true'));
    await close(page);await page.locator('#fixtureClosed').waitFor();await page.locator('#fixtureOpener').click();await page.locator('.tvDashboard').waitFor();await enter(page);await page.evaluate(()=>window.__fullscreenFixture.releaseEntry());await page.getByRole('button',{name:'Выйти из полного экрана',exact:true}).waitFor();
    assert.deepEqual(nativeEffects(await snapshot(page)),['set:true','set:false','maximize','set:true']);await close(page);await closed(page);await page.waitForFunction(()=>window.__fullscreenFixture.state().maximized);assert.equal((await snapshot(page)).fullscreen,false);
  });
  await check('native-listener-resolving-after-TV-close-is-unsubscribed',{native:'true',listenerDelay:'100'},async page=>{
    await close(page);await page.locator('#fixtureClosed').waitFor();await page.waitForFunction(()=>window.__fullscreenFixture.nativeCalls.includes('unlisten'));const state=await snapshot(page);assert.equal(state.listeners,0);assert.equal(state.nativeCalls.filter(call=>call==='unlisten').length,1);assert.deepEqual(nativeEffects(state),[]);assert.deepEqual(state.domCalls,[]);
  });
  await check('browser-real-DOM-fullscreen-X-exits-and-restores-focus',{},async page=>{
    await enter(page);await page.waitForFunction(()=>document.fullscreenElement===document.querySelector('.tvDashboard'));await page.screenshot({path:path.join(proof,'browser-real-fullscreen-before-close.png')});await close(page);await closed(page);
    // Removing the fullscreen DOM node can itself exit fullscreen before its
    // effect cleanup. An additional exitFullscreen call is then unnecessary.
    const state=await snapshot(page);assert.equal(state.domCalls.filter(call=>call==='requestFullscreen').length,1);assert.ok(state.domCalls.filter(call=>call==='exitFullscreen').length<=1);assert.deepEqual(state.nativeCalls,[]);
  });
  await check('browser-real-DOM-fullscreen-manual-arrow-keeps-TV-open',{},async page=>{
    await enter(page);await page.waitForFunction(()=>!!document.fullscreenElement);await leave(page);await page.waitForFunction(()=>!document.fullscreenElement);assert.equal(await page.locator('.tvDashboard').count(),1);assert.equal((await snapshot(page)).closed,0);await close(page);await closed(page);
  });
  await check('browser-external-DOM-fullscreen-exit-closes-TV',{},async page=>{
    await enter(page);await page.waitForFunction(()=>!!document.fullscreenElement);await page.evaluate(()=>document.exitFullscreen());await closed(page);assert.equal((await snapshot(page)).closed,1);
  });
  await check('browser-Escape-closes-TV-and-repeated-open-close-leaks-no-fullscreen',{},async page=>{
    await enter(page);await page.waitForFunction(()=>!!document.fullscreenElement);await page.keyboard.press('Escape');await closed(page);
    await page.locator('#fixtureOpener').click();await page.locator('.tvDashboard').waitFor();await enter(page);await page.waitForFunction(()=>!!document.fullscreenElement);await close(page);await closed(page);assert.equal((await snapshot(page)).closed,2);
  });
  assert.deepEqual(runtimeErrors,[],'Unexpected browser errors');assert.deepEqual(externalRequests,[],'Fixture must remain local');assert.deepEqual(hashes(),sources,'Production source changed during the fullscreen tests');
  const result={passed:cases.length,cases,sources,browserVersion:browser.version(),runtimeErrors,externalRequests,scope:'Actual React TvDashboard and production fullscreen helper; real Chromium browser Fullscreen API, actual Tauri core.isTauri with a module-level native-window port mock. Seven fixture printers; no physical printers or Windows window manager exercised.'};
  fs.writeFileSync(path.join(proof,'tv-fullscreen-r141-report.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
}catch(error){
  fs.mkdirSync(proof,{recursive:true});if(page&&!page.isClosed()){await page.screenshot({path:path.join(proof,'tv-fullscreen-r141-failure.png')}).catch(()=>{});fs.writeFileSync(path.join(proof,'tv-fullscreen-r141-failure.json'),JSON.stringify({currentCase,error:String(error.stack??error),runtimeErrors,externalRequests,state:await snapshot(page).catch(()=>null)},null,2))}throw error;
}finally{await browser?.close();if(server)await new Promise(resolve=>server.close(resolve));fs.rmSync(out,{recursive:true,force:true})}
