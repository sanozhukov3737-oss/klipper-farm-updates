// This replaces only the native window module in the acceptance build.
// Actual core.isTauri(), React, TvDashboard and fullscreen session are retained.
export function getCurrentWindow(){return (window as any).__fullscreenFixture.nativeWindow}
