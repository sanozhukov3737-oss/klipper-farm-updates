import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import http from 'node:http';
import { createHash } from 'node:crypto';
import { gzipSync } from 'node:zlib';
import { build } from 'vite';
import ts from '../scripts/typescript-runtime.mjs';

// Real production components, existing authenticated native fixtures and the
// approved renderer. Counters exist only in the temporary Vite test build.
const root=path.resolve(import.meta.dirname,'..');
const baselineRoot=path.resolve(process.env.KF_R141_BASELINE_SOURCE||path.join(root,'../r141-baseline-source'));
const proof=path.resolve(process.env.KF_R141_PERF_PROOF||path.join(root,'../r141-performance-proof'));
const baselineOnly=process.argv.includes('--baseline-only');
const refreshProductionOnly=process.argv.includes('--refresh-production-metrics-only');
const samples=Math.max(3,Math.min(9,Number(process.env.KF_R141_PERF_SAMPLES||5)));
const sourceNames=['src/App.tsx','src/components/TvDashboard.tsx','src/components/TvDashboard.css','src/lib/tvSpotlight.ts','src/lib/spool-viewer.mjs'];
const sourceHashes=base=>Object.fromEntries(sourceNames.map(name=>[name,createHash('sha256').update(fs.readFileSync(path.join(base,name))).digest('hex')]));
const baselineHashes=sourceHashes(baselineRoot),currentHashes=sourceHashes(root);
const originalDetailsRule='.tvSpotlightInfo > .tvSpotlightDetails { width: 100%; max-width: 480px; gap: clamp(11px, 1.4vh, 18px); }';
const approvedDetailsRule=`.tvSpotlightInfo > .tvSpotlightDetails {
  width: 100%;
  max-width: 480px;
  gap: clamp(11px, 1.4vh, 18px);
  /* Frame the existing job column without narrowing or moving its contents. */
  border-radius: 18px;
  outline: 1px solid color-mix(in srgb, var(--tv-blue) 38%, var(--tv-line));
  outline-offset: clamp(8px, .7vw, 13px);
}`;
const baselineTvCss=fs.readFileSync(path.join(baselineRoot,'src/components/TvDashboard.css'),'utf8'),currentTvCss=fs.readFileSync(path.join(root,'src/components/TvDashboard.css'),'utf8');
assert.equal(baselineTvCss.split(originalDetailsRule).length,2,'One original middle-column rule must exist');
assert.equal(currentTvCss.split(approvedDetailsRule).length,2,'Only the exact approved middle-column frame is allowed');
assert.equal(currentTvCss.replace(approvedDetailsRule,originalDetailsRule),baselineTvCss,'All other TV CSS bytes and column geometry rules must remain unchanged');
const approvedMiddleFrameCss={baselineSha256:baselineHashes['src/components/TvDashboard.css'],currentSha256:currentHashes['src/components/TvDashboard.css'],restoredSha256:createHash('sha256').update(currentTvCss.replace(approvedDetailsRule,originalDetailsRule)).digest('hex'),radiusPx:18,outlineWidthPx:1,outlineStyle:'solid',outlineOffset:'clamp(8px, .7vw, 13px)',onlyApprovedDelta:true};
const allSourceHashes=base=>Object.fromEntries(fs.readdirSync(path.join(base,'src'),{recursive:true,withFileTypes:true}).filter(entry=>entry.isFile()).map(entry=>path.join(entry.parentPath??entry.path,entry.name)).sort().map(file=>[path.relative(base,file).split(path.sep).join('/'),createHash('sha256').update(fs.readFileSync(file)).digest('hex')]));
const baselineTreeHashes=allSourceHashes(baselineRoot),currentTreeHashes=allSourceHashes(root);
const counterFunctions=new Set(['TvDashboard','TvPrinter','TvInventoryInsights','TvInventoryTotals','tvFilamentStats','tvFilamentInventoryStats','tvFilamentCurrentStats','filamentUsageInPeriod']);
const loadedPanels=new Set(['AnalyticsPanel','SystemPanel','ControlPanel','TvDashboard','ProductionPanel']);
const temp=fs.mkdtempSync(path.join(os.tmpdir(),'kf-r141-performance-'));
const modes=baselineOnly?['baseline']:['baseline','current'];
const cases=[],runtimeErrors=[],unexpectedRequests=[];
const outputs={},buildMetrics={},results={};
const middleFrameLayoutChecks=[];
let browser,server,currentPage;
const normalized=file=>path.normalize(file.split('?')[0]);
const relative=file=>path.relative(root,normalized(file)).split(path.sep).join('/');
const instrument=(code,file)=>{
 const source=ts.createSourceFile(file,code,ts.ScriptTarget.Latest,true,file.endsWith('.tsx')?ts.ScriptKind.TSX:ts.ScriptKind.TS),edits=[];
 const visit=node=>{
  if((ts.isFunctionDeclaration(node)||ts.isFunctionExpression(node))&&node.body&&node.name&&counterFunctions.has(node.name.text)){
   const name=node.name.text,at=node.body.getStart(source)+1;
   edits.push([at,`;(globalThis as any).__r141PerfCounts??={};(globalThis as any).__r141PerfCounts[${JSON.stringify(name)}]=((globalThis as any).__r141PerfCounts[${JSON.stringify(name)}]??0)+1;`]);
  }
  ts.forEachChild(node,visit);
 };
 visit(source);
 for(const [at,text]of edits.sort((a,b)=>b[0]-a[0]))code=code.slice(0,at)+text+code.slice(at);
 const panel=path.basename(file,'.tsx');
 if(loadedPanels.has(panel)&&relative(file).startsWith('src/components/'))code=`;(globalThis as any).__r141PerfLoaded??=[];(globalThis as any).__r141PerfLoaded.push(${JSON.stringify(panel)});\n`+code;
 return code;
};
const plugin=(mode,counters)=>({name:`r141-${mode}-exact-source-and-test-counters`,enforce:'pre',
 load(id){
  const rel=relative(id),snapshot=path.join(baselineRoot,rel);
  if(mode==='baseline'&&rel.startsWith('src/')&&/\.(?:[cm]?[jt]sx?|css)$/.test(rel)&&fs.existsSync(snapshot))return fs.readFileSync(snapshot,'utf8');
 },
 transform(code,id){
  const rel=relative(id);
  if(counters&&/^src\/.+\.tsx?$/.test(rel))return {code:instrument(code,normalized(id)),map:null};
  if(rel==='ui-tests/tv-spotlight-r140.tsx'){
   const marker='const memory = new Map';
   assert.ok(code.includes(marker),'Actual existing TV fixture boundary changed');
   const extension=`if(params.get('r141Coverage')==='future'){ledger.usageHistory!.startedAt=now+4_000;ledger.usageHistory!.days=[];ledger.printers['printer-0'].trackingAt=now+4_000;}\n`;
   return {code:code.replace(marker,extension+marker),map:null};
  }
 }
});
const closure=(directory)=>{
 const manifest=JSON.parse(fs.readFileSync(path.join(directory,'.vite/manifest.json'),'utf8')),seen=new Set();
 const visit=key=>{if(seen.has(key))return;seen.add(key);for(const dependency of manifest[key]?.imports||[])visit(dependency)};
 visit('index.html');
 const files=[...seen].map(key=>manifest[key]?.file).filter(name=>name?.endsWith('.js'));
 return {files,javaScriptBytes:files.reduce((sum,file)=>sum+fs.statSync(path.join(directory,file)).size,0),gzipBytes:files.reduce((sum,file)=>sum+gzipSync(fs.readFileSync(path.join(directory,file))).length,0),manifest};
};
const metrics=async session=>Object.fromEntries((await session.send('Performance.getMetrics')).metrics.map(row=>[row.name,row.value]));
const resetCounters=page=>page.evaluate(()=>{window.__r141PerfCounts={}});
const counters=page=>page.evaluate(()=>({...window.__r141PerfCounts}));
const realFlush=()=>new Promise(resolve=>setTimeout(resolve,20));
const countsDelta=(before,after)=>Object.fromEntries([...new Set([...Object.keys(before),...Object.keys(after)])].map(key=>[key,(after[key]||0)-(before[key]||0)]));
const measure=async(page,session,work)=>{
 await session.send('HeapProfiler.collectGarbage');const initial=await metrics(session),before=await counters(page);
 await work();await realFlush();const final=await metrics(session),after=await counters(page);
 await session.send('HeapProfiler.collectGarbage');const collected=await metrics(session);
 return {counts:countsDelta(before,after),rendererTaskMs:(final.TaskDuration-initial.TaskDuration)*1000,rendererScriptMs:(final.ScriptDuration-initial.ScriptDuration)*1000,jsHeapUsedBytes:collected.JSHeapUsedSize,jsHeapChangeBytes:collected.JSHeapUsedSize-initial.JSHeapUsedSize};
};
const active=page=>page.locator('.tvSpotlight').getAttribute('data-printer-id');
const stat=(page,name)=>page.locator(`.tvSpotlightStats .tvStat[data-stat="${name}"] strong`);
const frameGeometry=page=>page.evaluate(()=>{
 const selectors=['.tvSpotlight','.tvSpotlightBody','.tvSpotlightVisual','.tvSpotlightInfo','.tvSpotlightDetails','.tvInsightRail','.tvSpoolFeature','.tvWeekUsage','.tvSpotlightStats','.tvTemperatures'];
 const rectangles=Object.fromEntries(selectors.map(selector=>{const element=document.querySelector(selector);if(!element)throw new Error('Missing TV geometry element '+selector);const box=element.getBoundingClientRect();return [selector,{x:box.x,y:box.y,width:box.width,height:box.height}]}));
 const style=getComputedStyle(document.querySelector('.tvSpotlightDetails'));
 return {rectangles,frame:{outlineStyle:style.outlineStyle,outlineWidth:parseFloat(style.outlineWidth),outlineOffset:parseFloat(style.outlineOffset),borderRadius:parseFloat(style.borderRadius)},viewport:{width:innerWidth,height:innerHeight}};
});
const passed=(name,extra={})=>{cases.push({name,passed:true,...extra});console.log('PASS '+name)};
try{measurement:{
 fs.mkdirSync(proof,{recursive:true});
 for(const mode of modes){
  const production=path.join(temp,mode+'-production'),fixtures=path.join(temp,mode+'-fixtures');
  await build({root,logLevel:'error',publicDir:false,plugins:[plugin(mode,false)],build:{outDir:production,emptyOutDir:true,manifest:true,rollupOptions:{input:path.join(root,'index.html')}}});
  const graph=closure(production);buildMetrics[mode]={initialJavaScriptBytes:graph.javaScriptBytes,initialGzipBytes:graph.gzipBytes,initialJavaScriptFiles:graph.files};
  if(refreshProductionOnly)continue;
  await build({root,base:'./',logLevel:'error',publicDir:false,plugins:[plugin(mode,true)],build:{outDir:fixtures,emptyOutDir:true,manifest:true,rollupOptions:{input:[path.join(root,'ui-tests/r141-performance-app.html'),path.join(root,'ui-tests/r141-performance-tv.html')]}}});
  outputs[mode]={directory:fixtures,manifest:JSON.parse(fs.readFileSync(path.join(fixtures,'.vite/manifest.json'),'utf8'))};
  results[mode]={app:[],tv:[]};
 }
 const productionBundleMeasurement={base:'/',matchesProjectDefaultBase:true,fixtureBase:'./',scope:'Actual production index.html static JavaScript dependency closure using the project default base. Fixture browser workloads retain their relative base.'};
 fs.writeFileSync(path.join(proof,'r141-performance-build.json'),JSON.stringify({schemaVersion:1,scope:'Actual production index.html static JavaScript dependency closure; module bytes before compression and gzip.',productionBundleMeasurement,baselineSources:baselineHashes,productionSources:currentHashes,baselineSourceTree:baselineTreeHashes,productionSourceTree:currentTreeHashes,modes:buildMetrics},null,2)+'\n');
 if(refreshProductionOnly){
  assert.equal(baselineOnly,false);const target=path.join(proof,'r141-performance-report.json'),report=JSON.parse(fs.readFileSync(target,'utf8'));
  assert.equal(report.mode,'matched-comparison');assert.deepEqual(report.productionSourceTree,currentTreeHashes);assert.deepEqual(report.baselineSourceTree,baselineTreeHashes);assert.deepEqual(sourceHashes(root),currentHashes);
  const fixtureFiles=['ui-tests/farm-startup-r125.tsx','ui-tests/tv-spotlight-r140.tsx','ui-tests/r141-performance-app.html','ui-tests/r141-performance-tv.html'];
  for(const name of fixtureFiles.slice(0,2))assert.equal(createHash('sha256').update(fs.readFileSync(path.join(root,name))).digest('hex'),createHash('sha256').update(fs.readFileSync(path.join(baselineRoot,name))).digest('hex'),name);
  for(const mode of modes)Object.assign(report.summary[mode],buildMetrics[mode]);
  report.productionBundleMeasurement={...productionBundleMeasurement,refreshedAt:new Date().toISOString(),browserSamplesReused:true,unchangedProductionSourceFilesVerified:Object.keys(currentTreeHashes).length,fixtureSources:Object.fromEntries(fixtureFiles.map(name=>[name,createHash('sha256').update(fs.readFileSync(path.join(root,name))).digest('hex')])),browserSampleReuseReason:'Only the separate production build base was corrected. The fixture base, fixture HTML, temporary counter instrumentation and all production source bytes used for the existing three browser samples are unchanged.'};
  fs.writeFileSync(target,JSON.stringify(report,null,2)+'\n');
  const samplesPath=path.join(proof,'r141-performance-samples.json');if(fs.existsSync(samplesPath)){const samplesReport=JSON.parse(fs.readFileSync(samplesPath,'utf8'));assert.deepEqual(samplesReport.productionSourceTree,currentTreeHashes);samplesReport.modes=buildMetrics;samplesReport.productionBundleMeasurement=report.productionBundleMeasurement;fs.writeFileSync(samplesPath,JSON.stringify(samplesReport,null,2)+'\n')}
  console.log(JSON.stringify({passed:true,refreshedOnlyProductionMetrics:true,browserSamplesReused:true,modes:buildMetrics}));break measurement;
 }
 server=http.createServer((request,response)=>{
  const segments=new URL(request.url,'http://localhost').pathname.split('/').filter(Boolean),mode=segments[0],directory=outputs[mode]?.directory;
  const pathname=directory?segments.slice(1):segments,publicRoot=path.join(root,'public');
  let file=directory?path.resolve(directory,...pathname):undefined;
  if(!file||!file.startsWith(directory+path.sep)||!fs.existsSync(file)||!fs.statSync(file).isFile())file=path.resolve(publicRoot,...pathname);
  if(!file.startsWith(publicRoot+path.sep)&&!(directory&&file.startsWith(directory+path.sep))||!fs.existsSync(file)||!fs.statSync(file).isFile()){response.writeHead(404).end();return}
  response.setHeader('Cache-Control','no-store');response.setHeader('Content-Type',({'.html':'text/html','.js':'text/javascript','.css':'text/css','.svg':'image/svg+xml','.png':'image/png','.webp':'image/webp','.jpg':'image/jpeg'})[path.extname(file)]||'application/octet-stream');response.end(fs.readFileSync(file));
 });
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const origin=`http://127.0.0.1:${server.address().port}`;
 const {chromium}=await import(process.env.PLAYWRIGHT_MODULE_PATH||'playwright');
 browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_EXECUTABLE,args:['--no-sandbox','--disable-dev-shm-usage','--enable-unsafe-swiftshader']});
 const contextFor=async(mode,{clock,query=''}={})=>{
  const context=await browser.newContext({viewport:{width:1366,height:900},locale:'ru-RU',timezoneId:'UTC',reducedMotion:'reduce'}),page=await context.newPage();currentPage=page;page.setDefaultTimeout(15000);
  page.on('pageerror',error=>runtimeErrors.push({mode,message:error.message}));
  await page.route('**/*',route=>{if(route.request().url().startsWith(origin+'/'))return route.continue();unexpectedRequests.push(route.request().url());return route.abort()});
  await page.addInitScript(()=>{window.__r141PerfCounts={};window.__r141PerfLoaded=[]});
  // Freeze the blank page before app code loads; leave RPC time to reach the requested instant.
  if(clock){await page.clock.install({time:new Date(new Date(clock).getTime()-60_000)});await page.clock.pauseAt(new Date(clock))}
  return {context,page,url:`${origin}/${mode}/ui-tests/r141-performance-${clock?'tv':'app'}.html${query}`};
 };
 const openTv=async(mode,clock='2026-10-25T12:00:00.000Z',query='')=>{
  const target=await contextFor(mode,{clock,query});await target.page.goto(target.url);await target.page.getByRole('dialog',{name:'TV-панель фермы',exact:true}).waitFor();await stat(target.page,'spool').waitFor();
  await target.page.waitForFunction(()=>document.querySelector('.tvStat[data-stat="spool"] strong')?.textContent?.includes('679'));
  const pause=target.page.getByRole('button',{name:'Приостановить смену принтеров',exact:true});if(await pause.count())await pause.click();
  return target;
 };
 const warmTv=async page=>{
  await page.locator('.tvSpotlightCamera[data-ready="true"] img').waitFor();
  const stage=page.locator('.tvSpotlightStage'),previousScroll=await stage.evaluate(element=>element.scrollTop);await page.locator('.tvSpoolFeature [data-spool-thumbnail="true"]').scrollIntoViewIfNeeded();
  const start=Date.now();while(Date.now()-start<12000){if(await page.evaluate(()=>{const s=window.__tvFixture.thumbnailStats();return s.pending>0||s.cached>0||s.unavailable}))break;await realFlush()}
  await page.clock.runFor(150);await page.locator('.tvSpoolFeature [data-thumbnail-cached="true"] > img').waitFor();
  await page.waitForFunction(()=>{const e=document.querySelector('.tvSpoolFeature [data-thumbnail-cached="true"] > img');return e instanceof HTMLImageElement&&e.complete&&e.naturalWidth>0});
  await stage.evaluate((element,previous)=>{element.scrollTop=previous},previousScroll);await realFlush();
 };
 for(let sample=0;sample<samples;sample++)for(const mode of sample%2?[...modes].reverse():modes){
  {
   const {context,page,url}=await contextFor(mode);const at=performance.now();await page.goto(url);await page.locator('.infoPrinterGrid [data-testid^="live-printer-"]').nth(6).waitFor();
   await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
   const firstFarmReadyMs=performance.now()-at,loadedBefore=await page.evaluate(()=>[...window.__r141PerfLoaded]);
   const openAt=performance.now();await page.locator('.kfSidebar nav').getByRole('button',{name:'История',exact:true}).click();await page.locator('.analyticsPanel').waitFor();const firstHistoryReadyMs=performance.now()-openAt;
   const loadedAfter=await page.evaluate(()=>[...window.__r141PerfLoaded]);
   assert.equal(await page.evaluate(()=>window.__farmStartup.state().database['printers.config'].length),7);
   if(sample===0)await page.screenshot({path:path.join(proof,`r141-performance-${mode}-app.png`)});
   results[mode].app.push({firstFarmReadyMs,firstHistoryReadyMs,loadedBefore,loadedAfter});await context.close();currentPage=undefined;
  }
  {
   const {context,page}=await openTv(mode);await warmTv(page);assert.equal(await active(page),'printer-0');
   const session=await context.newCDPSession(page);await session.send('Performance.enable');await session.send('HeapProfiler.enable');
   if(sample===0)await page.screenshot({path:path.join(proof,`r141-performance-${mode}-tv.png`)});
   await resetCounters(page);
   const clockOnly=await measure(page,session,async()=>{for(let index=0;index<6;index++){await page.clock.runFor(1000);await realFlush()}});
   assert.equal(await active(page),'printer-0');assert.equal(await page.locator('.tvSpotlight').getAttribute('data-live-printing'),'true');
   assert.equal(await page.locator('.tvSpotlightCamera[data-ready="true"] img').count(),1);assert.equal(await page.locator('.tvSpoolFeature [data-thumbnail-cached="true"] > img').count(),1);
   const beforeCurrent=await stat(page,'current').innerText();
   await resetCounters(page);
   const telemetry=await measure(page,session,async()=>{for(let index=0;index<6;index++){await page.clock.runFor(1000);await page.evaluate(index=>window.__tvFixture.patchStatus('printer-0',{progress:.54+index*.01,filamentUsedMm:11000+index*1000,nozzle:255+index*.1,jobUpdatedAt:Date.now(),telemetryUpdatedAt:Date.now()}),index);await realFlush()}});
   assert.notEqual(await stat(page,'current').innerText(),beforeCurrent,'Real extrusion updates remain visible');assert.equal(await page.locator('.tvSpotlight').getAttribute('data-live-printing'),'true');
   const calls=await page.evaluate(()=>window.__tvFixture.calls);assert.equal(calls.filter(call=>call.command==='db_get_json').length,1);assert.deepEqual(calls.filter(call=>call.command!=='db_get_json'),[]);
   results[mode].tv.push({clockOnly,telemetry,configuredPrinters:7,cameraReady:true,approvedSpoolReady:true,inventoryReads:1,automaticInventoryWrites:0});await context.close();currentPage=undefined;
  }
 }
 fs.writeFileSync(path.join(proof,'r141-performance-samples.json'),JSON.stringify({schemaVersion:1,scope:'Samples completed; remaining behavioral acceptance may still be pending.',samplesPerMode:samples,baselineSources:baselineHashes,productionSources:currentHashes,baselineSourceTree:baselineTreeHashes,productionSourceTree:currentTreeHashes,modes:buildMetrics,raw:results},null,2)+'\n');
 passed('matched-actual-seven-printer-app-and-tv-samples',{samplesPerMode:samples,modes});
 for(const mode of modes){
  const first=results[mode].app[0];assert.ok(first.loadedAfter.includes('AnalyticsPanel'));
  assert.equal(first.loadedBefore.includes('AnalyticsPanel'),mode==='baseline','Actual history panel module is deferred only in optimized App');
  passed(`${mode}-actual-module-load-boundary`);
 }
 if(!baselineOnly){
  assert.ok(buildMetrics.current.initialJavaScriptBytes<buildMetrics.baseline.initialJavaScriptBytes,'Actual production static JS closure must shrink');
  for(const result of results.current.tv){assert.equal(result.clockOnly.counts.TvDashboard||0,0);assert.equal(result.clockOnly.counts.TvPrinter||0,0);assert.equal(result.clockOnly.counts.filamentUsageInPeriod||0,0);assert.equal(result.telemetry.counts.filamentUsageInPeriod||0,0)}
  for(const result of results.baseline.tv){assert.ok(result.clockOnly.counts.TvDashboard>=6);assert.ok(result.clockOnly.counts.TvPrinter>=6);assert.ok(result.clockOnly.counts.filamentUsageInPeriod>=48);assert.ok(result.telemetry.counts.filamentUsageInPeriod>=48)}
  passed('clock-only-heavy-renders-and-ledger-scans-removed');passed('live-telemetry-retains-visible-updates-without-ledger-rescans');
  for(const [width,height]of [[1366,900],[1920,1080],[390,844]]){
   const pair={};
   for(const mode of ['baseline','current']){const {context,page}=await openTv(mode);await page.setViewportSize({width,height});await warmTv(page);pair[mode]=await frameGeometry(page);if(mode==='current')await page.screenshot({path:path.join(proof,`r141-middle-frame-${width}x${height}.png`)});await context.close();currentPage=undefined}
   for(const [selector,before]of Object.entries(pair.baseline.rectangles))for(const key of ['x','y','width','height'])assert.ok(Math.abs(pair.current.rectangles[selector][key]-before[key])<=.75,`${width}x${height}: approved outline moved or resized ${selector}.${key}`);
   console.log('FRAME '+JSON.stringify({width,height,baseline:pair.baseline.frame,current:pair.current.frame}));
   assert.equal(pair.baseline.frame.outlineStyle,'none');assert.equal(pair.current.frame.outlineStyle,'solid');assert.equal(pair.current.frame.outlineWidth,1);assert.equal(pair.current.frame.borderRadius,18);assert.ok(pair.current.frame.outlineOffset>=8&&pair.current.frame.outlineOffset<=13);assert.ok(Math.abs(pair.current.frame.outlineOffset-Math.max(8,Math.min(13,width*.007)))<=1,'Blink may quantize computed outline-offset to an integer CSS pixel');
   middleFrameLayoutChecks.push({width,height,...pair,geometryUnchanged:true});
  }
  passed('approved-middle-column-outline-preserves-all-column-geometry',{viewports:middleFrameLayoutChecks.map(({width,height})=>({width,height})),onlyApprovedCssDelta:true});
  const chunk=outputs.current.manifest['src/components/AnalyticsPanel.tsx']?.file;assert.ok(chunk,'Analytics remains an actual separate generated module');
  {
   const {context,page,url}=await contextFor('current');let release,requests=0;const gate=new Promise(resolve=>{release=resolve});
   await page.route(`${origin}/current/${chunk}`,async route=>{requests++;await gate;await route.continue()});
   await page.goto(url);await page.locator('.infoPrinterGrid [data-testid^="live-printer-"]').nth(6).waitFor();await page.locator('.kfSidebar nav').getByRole('button',{name:'История',exact:true}).click();
   const pending=page.locator('[data-deferred-state="loading"]');await pending.waitFor();await pending.getByRole('button',{name:/^Закрыть:/}).click();await page.locator('.infoPrinterGrid [data-testid^="live-printer-"]').nth(6).waitFor();release();await realFlush();assert.equal(await page.locator('.analyticsPanel').count(),0);
   await page.locator('.kfSidebar nav').getByRole('button',{name:'История',exact:true}).click();await page.locator('.analyticsPanel').waitFor();assert.equal(requests,1,'Successful deferred module is reused');await context.close();currentPage=undefined;passed('pending-secondary-panel-can-close-without-hiding-farm');
  }
  {
   const chunk=outputs.current.manifest['src/components/TvDashboard.tsx']?.file;assert.ok(chunk,'TV remains an actual generated deferred module');
   const {context,page,url}=await contextFor('current');let release;const gate=new Promise(resolve=>{release=resolve});
   await page.route(`${origin}/current/${chunk}`,async route=>{await gate;await route.continue()});
   await page.goto(url);await page.locator('.infoPrinterGrid [data-testid^="live-printer-"]').nth(6).waitFor();await page.locator('.kfSidebar nav').getByRole('button',{name:'Инструменты',exact:true}).click();
   const trigger=page.getByRole('button',{name:/^TV-панель/});await trigger.click();await page.locator('[data-deferred-state="loading"]').waitFor();
   assert.equal(await page.evaluate(()=>!!document.activeElement?.closest('[data-deferred-state="loading"]')),true,'Pending TV owns focus');
   release();await page.locator('.tvDashboard').waitFor();await page.waitForFunction(()=>!!document.activeElement?.closest('.tvDashboard'));await realFlush();
   assert.equal(await page.evaluate(()=>!!document.activeElement?.closest('.tvDashboard')),true,'Resolving the fallback does not steal focus from the actual TV');
   await page.getByRole('button',{name:'Закрыть TV-панель',exact:true}).click();await page.locator('.tvDashboard').waitFor({state:'hidden'});await realFlush();
   assert.equal(await trigger.evaluate(element=>document.activeElement===element),true,'Closing a resolved TV restores its original launcher');
   await context.close();currentPage=undefined;passed('cold-tv-fallback-hands-off-focus-and-restores-original-launcher');
  }
  {
   const chunk=outputs.current.manifest['src/components/PrinterSettings.tsx']?.file;assert.ok(chunk,'Printer settings remain a generated deferred module');
   const {context,page,url}=await contextFor('current');let release;const gate=new Promise(resolve=>{release=resolve});
   await page.route(`${origin}/current/${chunk}`,async route=>{await gate;await route.continue()});
   await page.goto(url);await page.locator('.infoPrinterGrid [data-testid^="live-printer-"]').nth(6).waitFor();await page.locator('.kfSidebar nav').getByRole('button',{name:'Принтеры',exact:true}).click();
   await page.locator('[data-testid="live-printer-printer-2"]').getByRole('button',{name:/^Открыть /}).click();await page.locator('.kfDetailShell').waitFor();
   await page.locator('.kfDetailShell').getByRole('button',{name:'Настройки',exact:true}).click();await page.locator('[data-deferred-state="loading"]').waitFor();await realFlush();
   assert.equal(await page.evaluate(()=>!!document.activeElement?.closest('[data-deferred-state="loading"]')),true,'Closing the printer controls must not steal focus from pending settings');
   release();await page.locator('.printerSetup').waitFor();await realFlush();assert.equal(await page.evaluate(()=>!!document.activeElement?.closest('.printerSetup')),true,'Loaded settings retain focus after the control-to-settings transition');
   await context.close();currentPage=undefined;passed('control-to-cold-settings-handoff-keeps-focus-inside-new-panel');
  }
  {
   const {context,page,url}=await contextFor('current');let requests=0,navigations=0;page.on('framenavigated',frame=>{if(frame===page.mainFrame())navigations++});
   await page.route(`${origin}/current/${chunk}`,route=>++requests===1?route.abort('failed'):route.continue());
   await page.goto(url);await page.locator('.infoPrinterGrid [data-testid^="live-printer-"]').nth(6).waitFor();await page.waitForFunction(()=>window.__farmStartup.state().calls.some(call=>call.command==='printer_actor_upsert'));
   const initialState=await page.evaluate(()=>window.__farmStartup.state()),configs=initialState.database['printers.config'];assert.equal(configs.length,7);
   await page.locator('.kfSidebar nav').getByRole('button',{name:'История',exact:true}).click();await page.locator('[data-deferred-state="error"]').waitFor();
   await page.locator('[data-deferred-state="error"]').getByRole('button',{name:/^Закрыть:/}).click();await page.locator('.infoPrinterGrid [data-testid^="live-printer-"]').nth(6).waitFor();
   await page.locator('.kfSidebar nav').getByRole('button',{name:'История',exact:true}).click();await page.locator('[data-deferred-state="error"]').waitFor();assert.equal(requests,1,'A failed ESM module is not advertised as a successful same-document retry');assert.equal(navigations,1,'A load failure must never automatically reload the interface');
   const beforeReload=await page.evaluate(()=>window.__farmStartup.state());assert.deepEqual(beforeReload.database['printers.config'],configs);
   await Promise.all([page.waitForNavigation({waitUntil:'load'}),page.getByRole('button',{name:'Перезагрузить интерфейс',exact:true}).click()]);await page.locator('.infoPrinterGrid [data-testid^="live-printer-"]').nth(6).waitFor();await page.waitForFunction(()=>window.__farmStartup.state().calls.some(call=>call.command==='printer_actor_upsert'));
   const afterReload=await page.evaluate(()=>window.__farmStartup.state());assert.deepEqual(afterReload.database['printers.config'],configs,'Explicit interface reload preserves all seven configured printers');
   await page.locator('.kfSidebar nav').getByRole('button',{name:'История',exact:true}).click();await page.locator('.analyticsPanel').waitFor();assert.equal(requests,2,'A fresh document can fetch and load the previously failed module');assert.equal(navigations,2);
   const finalState=await page.evaluate(()=>window.__farmStartup.state()),calls=[...beforeReload.calls,...finalState.calls];
   assert.deepEqual(calls.filter(call=>call.command==='filament_inventory_commit'||call.command==='printer_actor_rpc'&&/^(?:printer\.print\.|printer\.gcode\.)/.test(call.args.method??'')),[],'Deferred-load failure and explicit UI recovery never send print or inventory commands');
   await context.close();currentPage=undefined;passed('failed-secondary-panel-closes-and-explicit-ui-reload-recovers',{sevenConfigurationsPreserved:true,automaticReloads:0,explicitUserReload:true,actuatorCommands:0});
  }
  {
   const {context,page}=await openTv('current','2026-10-25T23:59:58.000Z');const before=await page.locator('.tvWeekDay[data-today="true"]').getAttribute('aria-label');await page.clock.runFor(4000);await page.waitForFunction(()=>document.querySelector('.tvWeekDay[data-today="true"]')?.getAttribute('aria-label')?.startsWith('2026-10-26'));
   assert.ok(before.startsWith('2026-10-25'));assert.equal(await stat(page,'today').innerText(),'0 г');await context.close();currentPage=undefined;passed('cached-ledger-rolls-over-at-local-midnight');
  }
  {
   const {context,page}=await openTv('current','2026-10-25T12:00:00.000Z','?r141Coverage=future');assert.equal(await stat(page,'today').innerText(),'—');await page.clock.runFor(4100);await page.waitForFunction(()=>document.querySelector('.tvStat[data-stat="today"] strong')?.textContent==='0 г');await context.close();currentPage=undefined;passed('cached-ledger-invalidates-at-future-coverage-boundary');
  }
  {
   const {context,page}=await openTv('current');await page.clock.runFor(21000);await page.locator('.tvSpotlight[data-live-printing="false"]').waitFor();assert.equal(await stat(page,'current').innerText(),'—');await context.close();currentPage=undefined;passed('freshness-expiry-still-stops-live-state-without-telemetry');
  }
 }
 assert.equal(approvedMiddleFrameCss.restoredSha256,approvedMiddleFrameCss.baselineSha256);assert.equal(currentHashes['src/lib/spool-viewer.mjs'],baselineHashes['src/lib/spool-viewer.mjs']);
 assert.deepEqual(sourceHashes(baselineRoot),baselineHashes);assert.deepEqual(sourceHashes(root),currentHashes,'Production sources changed during measurement; rerun against completed edits');assert.deepEqual(allSourceHashes(root),currentTreeHashes);assert.deepEqual(allSourceHashes(baselineRoot),baselineTreeHashes);
 assert.deepEqual(runtimeErrors,[]);assert.deepEqual(unexpectedRequests,[]);
 const median=values=>[...values].sort((a,b)=>a-b)[Math.floor(values.length/2)],distribution=values=>({median:median(values),minimum:Math.min(...values),maximum:Math.max(...values),samples:values});
 const summary=Object.fromEntries(modes.map(mode=>[mode,{...buildMetrics[mode],firstFarmReadyMs:distribution(results[mode].app.map(x=>x.firstFarmReadyMs)),firstHistoryReadyMs:distribution(results[mode].app.map(x=>x.firstHistoryReadyMs)),clockWorkTaskMs:distribution(results[mode].tv.map(x=>x.clockOnly.rendererTaskMs)),telemetryWorkTaskMs:distribution(results[mode].tv.map(x=>x.telemetry.rendererTaskMs)),clockJsHeapUsedBytes:distribution(results[mode].tv.map(x=>x.clockOnly.jsHeapUsedBytes)),telemetryJsHeapUsedBytes:distribution(results[mode].tv.map(x=>x.telemetry.jsHeapUsedBytes))}]));
 const report={schemaVersion:1,release:'R141-performance-draft',passed:cases.length,cases,scope:'Headless Chromium on Linux with actual production React components, seven synthetic printers, local camera frame and exact approved spool renderer. Renderer task CPU time and JavaScript heap only; not installed Windows startup, total process RAM or the user computer.',browser:browser.version(),platform:process.platform,cpu:os.cpus()[0]?.model,mode:baselineOnly?'baseline-only':'matched-comparison',samplesPerMode:samples,clockTicksPerSample:6,telemetryUpdatesPerSample:6,baselineSources:baselineHashes,productionSources:currentHashes,baselineSourceTree:baselineTreeHashes,productionSourceTree:currentTreeHashes,productionBundleMeasurement,approvedSpoolRendererUnchanged:true,approvedMiddleFrameCssDelta:true,approvedMiddleFrameCss,middleFrameLayoutChecks,tvColumnGeometryUnchanged:middleFrameLayoutChecks.length===3,instrumentation:'Temporary Vite-only function counters; production source files are never patched by the harness. CPU durations include that same instrumentation in both variants. No timing threshold is a test gate.',summary,raw:results,runtimeErrors,unexpectedRequests,physicalPrintersTested:false,installedWindowsTested:false};
 const target=path.join(proof,baselineOnly?'r141-performance-baseline.json':'r141-performance-report.json');fs.writeFileSync(target,JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({passed:report.passed,report:target,summary},null,2));
}}catch(error){if(currentPage){await currentPage.screenshot({path:path.join(proof,'r141-performance-failure.png')}).catch(()=>{});const focus=await currentPage.evaluate(()=>({active:document.activeElement?.outerHTML,dialogs:[...document.querySelectorAll('[role="dialog"]')].map(node=>({className:node.className,label:node.getAttribute('aria-label')}))})).catch(()=>undefined);fs.writeFileSync(path.join(proof,'r141-performance-failure.json'),JSON.stringify({error:String(error.stack||error),focus,cases,runtimeErrors,unexpectedRequests},null,2)+'\n');console.error(JSON.stringify(focus));console.error((await currentPage.locator('body').innerText().catch(()=>'' )).slice(-4000));}throw error}
finally{await browser?.close();if(server)await new Promise(resolve=>server.close(resolve));fs.rmSync(temp,{recursive:true,force:true})}
