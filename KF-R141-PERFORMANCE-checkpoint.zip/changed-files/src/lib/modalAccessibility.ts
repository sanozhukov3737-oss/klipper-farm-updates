import {useEffect,useRef} from 'react';

const focusable='button:not([disabled]),[href],input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])';

export function useModalAccessibility(onClose:()=>void,selector:string,label:string,active=true,restoreFocus=true){
  const close=useRef(onClose);
  close.current=onClose;
  useEffect(()=>{
    if(!active)return;
    const node=document.querySelector<HTMLElement>(selector);
    if(!node)return;
    node.setAttribute('role','dialog');
    node.setAttribute('aria-modal','true');
    node.setAttribute('aria-label',label);
    node.tabIndex=-1;
    for(const button of node.querySelectorAll<HTMLButtonElement>('button')){
      if(button.hasAttribute('aria-label')||button.hasAttribute('title')||button.textContent?.trim())continue;
      const inferred=button.querySelector('.lucide-x')?'Закрыть'
        :button.querySelector('.lucide-chevron-left')?'Предыдущий элемент'
        :button.querySelector('.lucide-chevron-right')?'Следующий элемент'
        :button.querySelector('.lucide-refresh-cw')?'Обновить'
        :button.querySelector('.lucide-camera')?'Открыть камеру'
        :'Действие в диалоге';
      button.setAttribute('aria-label',inferred);
    }
    const previous=document.activeElement instanceof HTMLElement?document.activeElement:undefined;
    queueMicrotask(()=>{
      if(!node.isConnected)return;
      const initial=[...node.querySelectorAll<HTMLElement>(focusable)].filter(item=>item.getClientRects().length>0);
      (initial.find(item=>item.hasAttribute('data-modal-initial-focus'))??initial[0]??node).focus();
    });
    const onKeyDown=(event:KeyboardEvent)=>{
      const dialogs=[...document.querySelectorAll<HTMLElement>('[role="dialog"][aria-modal="true"]')];
      if(dialogs.at(-1)!==node)return;
      if(event.key==='Escape'){
        event.preventDefault();event.stopPropagation();close.current();return;
      }
      if(event.key!=='Tab')return;
      const items=[...node.querySelectorAll<HTMLElement>(focusable)].filter(item=>item.getClientRects().length>0);
      if(!items.length){event.preventDefault();node.focus();return}
      const first=items[0],last=items.at(-1)!;
      if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus()}
      else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus()}
    };
    document.addEventListener('keydown',onKeyDown,true);
    return()=>{document.removeEventListener('keydown',onKeyDown,true);if(restoreFocus)queueMicrotask(()=>previous?.focus())};
  },[active,selector,label,restoreFocus]);
}
