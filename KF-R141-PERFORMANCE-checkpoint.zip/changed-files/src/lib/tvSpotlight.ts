import type { PrinterModel, Spool } from '../types';
import { calculatedFilamentGrams, filamentDayKey, type FilamentInventory } from './filamentInventory';
import { filamentUsageInPeriod } from './filamentAnalytics';
import { jobFreshness } from './printerTelemetry';
import { tvPrinterState } from './tvDashboard';

export type TvFilamentStats = {
  currentLabel: string;
  currentHint: string;
  todayLabel: string;
  todayHint: string;
  totalLabel: string;
  totalHint: string;
  materialLabel: string;
  spoolLabel: string;
  spoolHint: string;
  spoolColor?: string;
  spoolFraction?: number;
  boundSpool?: Spool;
  spoolDiameter?: number;
  weeklyDays: { key: string; label: string; grams: number | null; today: boolean }[];
  weeklyLabel: string;
  weeklyHint: string;
};

const nonnegative = (value: unknown): value is number => typeof value === 'number' && Number.isFinite(value) && value >= 0;
const numberFormats = [0, 1, 2].map(maximumFractionDigits => new Intl.NumberFormat('ru-RU', { maximumFractionDigits }));
const number = (value: number, maximumFractionDigits: number) => numberFormats[maximumFractionDigits].format(value);
const weight = (grams: number) => grams >= 1000 ? `${number(grams / 1000, 2)} кг` : `${number(grams, grams < 10 ? 1 : 0)} г`;
const length = (mm: number) => `${number(mm / 1000, 2)} м`;

export type TvFilamentCurrentStats = Pick<TvFilamentStats, 'currentLabel' | 'currentHint'>;
export type TvFilamentInventoryStats = Omit<TvFilamentStats, 'currentLabel' | 'currentHint'>;

/** Ledger-only projection; callers may retain it until inventory/calendar eligibility changes. */
export function tvFilamentInventoryStats(printerId: string, inventory: FilamentInventory | undefined, now = Date.now()): TvFilamentInventoryStats {
  const result: TvFilamentInventoryStats = {
    todayLabel: '—', todayHint: 'Учтённые списания за сегодня',
    totalLabel: '—', totalHint: 'С начала учёта в приложении',
    materialLabel: 'Пластик не выбран', spoolLabel: '—', spoolHint: 'Катушка не выбрана',
    weeklyDays: [], weeklyLabel: '—', weeklyHint: 'Нет истории учёта за эти дни',
  };
  const account = inventory?.printers[printerId], binding = account?.binding;
  const material = binding && inventory?.materials[binding.material];
  if (binding) {
    result.materialLabel = binding.material;
    if (!binding.spoolId) {
      result.spoolLabel = 'Общий запас';
      result.spoolHint = `Без отдельной катушки · ${binding.material}`;
    } else {
      const spool = inventory?.spools.find(row => row.id === binding.spoolId && row.material === binding.material);
      if (spool && nonnegative(spool.remainingWeight)) {
        result.spoolLabel = weight(spool.remainingWeight);
        result.spoolHint = `${spool.name} · учтённый остаток`;
        if (/^#[\da-f]{3}(?:[\da-f]{3})?$/i.test(spool.color ?? '')) result.spoolColor = spool.color;
        if (nonnegative(spool.initialWeight) && spool.initialWeight > 0) {
          result.spoolFraction = Math.max(0, Math.min(1, spool.remainingWeight / spool.initialWeight));
          result.boundSpool = spool;
          if (material && Number.isFinite(material.diameter) && material.diameter >= .5 && material.diameter <= 4) result.spoolDiameter = material.diameter;
        }
      }
    }
  }
  if (account && nonnegative(account.usedGrams)) result.totalLabel = weight(account.usedGrams);
  const day = filamentDayKey(now), history = inventory?.usageHistory;
  if (inventory && account && history && Number.isFinite(history.startedAt) && history.startedAt <= now) {
    const today = filamentUsageInPeriod(inventory, day, day)[printerId] ?? 0;
    if (nonnegative(today)) result.todayLabel = weight(today);
  }

  const today = new Date(now);
  today.setHours(0, 0, 0, 0);
  const firstDay = new Date(today);
  firstDay.setDate(firstDay.getDate() - 6);
  const bindingDates = account ? [...account.bindings, ...(binding ? [binding] : [])]
    .map(row => row.effectiveAt).filter(value => Number.isFinite(value) && value > 0 && value <= now) : [];
  const printerTrackingAt = account && Number.isFinite(account.trackingAt) && account.trackingAt! > 0
    ? account.trackingAt! : bindingDates.length ? Math.min(...bindingDates) : undefined;
  const coverageStart = history && Number.isFinite(history.startedAt) && history.startedAt > 0 && history.startedAt <= now && printerTrackingAt !== undefined && printerTrackingAt <= now
    ? Math.max(history.startedAt, printerTrackingAt) : undefined;
  const recordedDays = new Set(history?.days.filter(row => row.printerId === printerId).map(row => row.day) ?? []);
  let recordedOutsideCoverage = false;
  result.weeklyDays = Array.from({ length: 7 }, (_, index) => {
    // Local calendar arithmetic avoids repeating or skipping a day across DST.
    const date = new Date(firstDay);
    date.setDate(date.getDate() + index);
    const followingDay = new Date(date);
    followingDay.setDate(followingDay.getDate() + 1);
    const key = filamentDayKey(date.getTime());
    const covered = inventory && account && coverageStart !== undefined && coverageStart < followingDay.getTime();
    const recorded = !!account && recordedDays.has(key);
    // Resolving an older pending print may commit a dated row before automatic
    // tracking began. That real debit remains visible; neighbouring missing
    // dates still cannot become invented zero-usage days.
    if (recorded && !covered) recordedOutsideCoverage = true;
    const value = inventory && (covered || recorded) ? filamentUsageInPeriod(inventory, key, key)[printerId] ?? 0 : undefined;
    return { key, label: date.toLocaleDateString('ru-RU', { weekday: 'short' }), grams: nonnegative(value) ? value : null, today: key === day };
  });
  const knownDays = result.weeklyDays.filter(row => row.grams !== null);
  if (knownDays.length) {
    result.weeklyLabel = weight(knownDays.reduce((sum, row) => sum + row.grams!, 0));
    result.weeklyHint = recordedOutsideCoverage ? 'Неполная история · учтённые списания'
      : coverageStart !== undefined && coverageStart > firstDay.getTime()
        ? `Учёт с ${new Date(coverageStart).toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })} · учтённые списания`
        : 'Учтённые списания за 7 дней';
  }

  return result;
}

/** Fresh received extrusion is independent of the cached historical projection. */
export function tvFilamentCurrentStats(printer: PrinterModel, inventory: FilamentInventory | undefined, now = Date.now()): TvFilamentCurrentStats {
  const result: TvFilamentCurrentStats = { currentLabel: '—', currentHint: 'Нет свежих данных о расходе' };
  const binding = inventory?.printers[printer.id]?.binding;
  const material = binding && inventory?.materials[binding.material];
  const state = tvPrinterState(printer, now), status = printer.status;
  if ((state !== 'printing' && state !== 'paused') || status.connectionState !== 'online' || status.remoteControlSuspended || jobFreshness(status, now) !== 'live' || !nonnegative(status.filamentUsedMm)) return result;
  const usedMm = status.filamentUsedMm;
  result.currentLabel = length(usedMm);
  result.currentHint = 'Длина по данным принтера';
  // A new material binding in the middle of a print cannot explain the mass
  // extruded before that binding. Preserve the real length in that case.
  const startedAt = nonnegative(status.printDuration) ? now - status.printDuration * 1000 : undefined;
  const wholePrintMaterial = binding && !binding.baselinePending && !(binding.activeBaseline && binding.activeBaseline.usedMm > 0)
    && startedAt !== undefined && binding.effectiveAt <= startedAt;
  const materialParametersKnown = material && Number.isFinite(material.diameter) && material.diameter >= .5 && material.diameter <= 4
    && Number.isFinite(material.density) && material.density >= .1 && material.density <= 10;
  if (wholePrintMaterial && materialParametersKnown) {
    const grams = calculatedFilamentGrams(usedMm, material);
    if (grams !== undefined) {
      result.currentLabel = `≈ ${weight(grams)}`;
      result.currentHint = `${length(usedMm)} от принтера · вес рассчитан`;
    }
  }
  return result;
}

/** Time boundaries at which a retained ledger projection can change without a write. */
export function tvFilamentInventoryClockBoundaries(printerId: string, inventory: FilamentInventory | undefined): number[] {
  const account = inventory?.printers[printerId];
  const dates = account ? [...account.bindings, ...(account.binding ? [account.binding] : [])]
    .map(binding => binding.effectiveAt).filter(value => Number.isFinite(value) && value > 0) : [];
  const trackingAt = account && Number.isFinite(account.trackingAt) && account.trackingAt! > 0
    ? account.trackingAt! : dates.length ? Math.min(...dates) : undefined;
  return [inventory?.usageHistory?.startedAt, trackingAt].filter((value): value is number => typeof value === 'number' && Number.isFinite(value));
}

export function tvFilamentInventoryTimeKey(boundaries: readonly number[], now: number): string {
  return `${filamentDayKey(now)}:${new Date(now).getTimezoneOffset()}:${boundaries.map(at => now >= at ? 1 : 0).join('')}`;
}

/** Pure compatibility API: live extrusion never writes to, or pre-debits, the ledger. */
export function tvFilamentStats(printer: PrinterModel, inventory: FilamentInventory | undefined, now = Date.now()): TvFilamentStats {
  return { ...tvFilamentInventoryStats(printer.id, inventory, now), ...tvFilamentCurrentStats(printer, inventory, now) };
}
