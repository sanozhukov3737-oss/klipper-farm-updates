import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import ts from './typescript-runtime.mjs';

const root=path.resolve(import.meta.dirname,'..'),file=path.join(root,'src/lib/tvFullscreen.ts');
const source=fs.readFileSync(file,'utf8'),sourceSha256=createHash('sha256').update(source).digest('hex');
const compiled=ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ES2022},fileName:file,reportDiagnostics:true});
assert.deepEqual(compiled.diagnostics,[]);
const {createTvFullscreenSession}=await import('data:text/javascript;base64,'+Buffer.from(compiled.outputText).toString('base64'));
const cases=[],turn=()=>new Promise(resolve=>setImmediate(resolve));
const deferred=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b});return {promise,resolve,reject}};
const check=async(name,run)=>{await run();cases.push({name,passed:true});console.log('PASS '+name)};
function fixture({fullscreen=false,maximized=true,listenerGate}={}){
  const document=new EventTarget(),element={ownerDocument:document},calls=[],changes=[],listeners=new Set();
  let external=0,removed=0;
  const initialPosition=maximized?{x:-8,y:-8}:{x:120,y:80},initialSize=maximized?{width:1936,height:1048}:{width:960,height:640};
  let position={...initialPosition},size={...initialSize};
  document.fullscreenElement=null;
  document.exitFullscreen=async()=>{calls.push('DOM.exit');document.fullscreenElement=null;document.dispatchEvent(new Event('fullscreenchange'))};
  element.requestFullscreen=async()=>{calls.push('DOM.enter');document.fullscreenElement=element;document.dispatchEvent(new Event('fullscreenchange'))};
  const native={
    async isFullscreen(){calls.push('native.readFullscreen');return fullscreen},
    async isMaximized(){calls.push('native.readMaximized');return maximized},
    async setFullscreen(value){calls.push('native.set:'+value);fullscreen=value;if(value){position={x:0,y:0};size={width:1920,height:1080}}},
    async maximize(){calls.push('native.maximize');if(!maximized){position={...initialPosition};size={...initialSize}}maximized=true},
    async unmaximize(){calls.push('native.unmaximize');maximized=false},
    async outerPosition(){calls.push('native.readPosition');return {...position}},
    async innerSize(){calls.push('native.readSize');return {...size}},
    async setPosition(value){calls.push('native.position');position={...value}},
    async setSize(value){calls.push('native.size');size={...value}},
    async onResized(callback){calls.push('native.listen');if(listenerGate)await listenerGate.promise;listeners.add(callback);return()=>{removed++;listeners.delete(callback);calls.push('native.unlisten')}},
  };
  return {document,element,native,calls,changes,listeners,get bounds(){return {position:{...position},size:{...size}}},initialBounds:{position:initialPosition,size:initialSize},get external(){return external},get removed(){return removed},get fullscreen(){return fullscreen},get maximized(){return maximized},set fullscreen(value){fullscreen=value},emit(){for(const listener of listeners)listener()},session(useNative=true){return createTvFullscreenSession(element,{...(useNative?{nativeWindow:native}:{}),onChange:value=>changes.push(value),onExternalExit:()=>external++})}};
}
const mutations=f=>f.calls.filter(call=>/native\.(set:|unmaximize|maximize|size|position)|DOM\./.test(call));

await check('owned native fullscreen restores a previously maximized main window on close',async()=>{
  const f=fixture(),session=f.session();await session.toggle();assert.equal(f.fullscreen,true);await session.dispose();
  assert.deepEqual(mutations(f),['native.set:true','native.set:false','native.unmaximize','native.maximize']);assert.equal(f.maximized,true);assert.deepEqual(f.bounds,f.initialBounds);assert.equal(f.removed,1);assert.deepEqual(f.changes,[true]);
});
await check('owned native fullscreen preserves a previously normal window without maximizing',async()=>{
  const f=fixture({maximized:false}),session=f.session();await session.toggle();await session.dispose();
  assert.deepEqual(mutations(f),['native.set:true','native.set:false','native.size','native.position']);assert.equal(f.fullscreen,false);assert.equal(f.maximized,false);assert.deepEqual(f.bounds,f.initialBounds);
});
await check('borrowed native fullscreen is never switched off or maximized by TV',async()=>{
  const f=fixture({fullscreen:true}),session=f.session();await session.toggle();await session.toggle();await session.toggle();await session.dispose();
  assert.equal(f.fullscreen,true);assert.deepEqual(mutations(f),[]);assert.deepEqual(f.changes,[true,false,true]);assert.equal(f.external,0);
});
await check('manual native arrow restores the window and keeps the TV session open',async()=>{
  const f=fixture(),session=f.session();await session.toggle();await session.toggle();assert.deepEqual(f.changes,[true,false]);assert.equal(f.external,0);
  const before=mutations(f);await session.dispose();assert.deepEqual(mutations(f),before);
});
await check('rapid repeated toggles coalesce into one in-flight native transition',async()=>{
  const f=fixture(),gate=deferred(),original=f.native.setFullscreen;f.native.setFullscreen=async value=>{if(value)await gate.promise;return original(value)};
  const session=f.session(),first=session.toggle(),second=session.toggle();assert.equal(first,second);await turn();gate.resolve();await first;
  assert.deepEqual(mutations(f),['native.set:true']);await session.dispose();
});
await check('dispose before a queued native entry prevents all window mutations',async()=>{
  const f=fixture(),session=f.session(),pending=session.toggle(),disposed=session.dispose();await Promise.all([pending,disposed]);assert.deepEqual(mutations(f),[]);assert.deepEqual(f.changes,[]);
});
await check('dispose during native state reads prevents entry after those reads resolve',async()=>{
  const f=fixture(),gate=deferred();f.native.isFullscreen=async()=>{f.calls.push('native.readFullscreen');return gate.promise};
  const session=f.session(),pending=session.toggle();await turn();const disposed=session.dispose();gate.resolve(false);await Promise.all([pending,disposed]);assert.deepEqual(mutations(f),[]);assert.deepEqual(f.changes,[]);
});
await check('close and reopen serialize delayed entry and restore before the next state read',async()=>{
  const f=fixture(),gate=deferred(),original=f.native.setFullscreen;f.native.setFullscreen=async value=>{if(value){f.calls.push('enter.wait');await gate.promise}return original(value)};
  const first=f.session(),entry=first.toggle();await turn();const disposal=first.dispose(),second=f.session(),reentry=second.toggle();await turn();
  assert.equal(f.calls.filter(call=>call==='native.readFullscreen').length,1);gate.resolve();await Promise.all([entry,disposal,reentry]);
  const effects=f.calls.filter(call=>/^native\.(set:|unmaximize|maximize|readFullscreen)/.test(call));
  assert.deepEqual(effects,['native.readFullscreen','native.set:true','native.set:false','native.unmaximize','native.maximize','native.readFullscreen','native.set:true']);assert.deepEqual(f.changes,[true]);await second.dispose();assert.equal(f.maximized,true);
});
await check('listener registration resolving after unmount is removed exactly once',async()=>{
  const gate=deferred(),f=fixture({listenerGate:gate}),session=f.session();await turn();const disposed=session.dispose();gate.resolve();await disposed;await session.dispose();
  assert.equal(f.removed,1);assert.equal(f.listeners.size,0);f.emit();await turn();assert.equal(f.external,0);
});
await check('external native fullscreen exit closes TV while preserving prior maximization',async()=>{
  const f=fixture(),session=f.session();await session.toggle();f.fullscreen=false;f.emit();await turn();assert.equal(f.external,1);assert.deepEqual(f.changes,[true,false]);await session.dispose();assert.equal(f.maximized,true);
});
await check('stale resize reads cannot close a session after manual transition or disposal',async()=>{
  const f=fixture(),session=f.session();await session.toggle();const gate=deferred();f.native.isFullscreen=async()=>gate.promise;f.emit();await turn();
  const leave=session.toggle();gate.resolve(false);await leave;assert.equal(f.external,0);await session.dispose();assert.deepEqual(f.changes,[true,false]);
});
await check('native permissions failure rejects entry without browser fullscreen fallback',async()=>{
  const f=fixture(),session=f.session();f.native.setFullscreen=async value=>{f.calls.push('native.set:'+value);if(value)throw new Error('permission denied')};
  await assert.rejects(session.toggle(),/permission denied/);assert.deepEqual(f.changes,[]);assert.ok(!mutations(f).some(call=>call.startsWith('DOM.')));await session.dispose();
  const next=f.session();f.native.setFullscreen=async value=>{f.calls.push('native.set:'+value);f.fullscreen=value};await next.toggle();await next.dispose();assert.equal(f.fullscreen,false);
});
await check('partial native entry failure immediately restores original ownership before retry',async()=>{
  const f=fixture(),session=f.session(),original=f.native.setFullscreen;let fail=true;
  f.native.setFullscreen=async value=>{await original(value);if(value&&fail){fail=false;throw new Error('reply lost after native mutation')}};
  await assert.rejects(session.toggle(),/reply lost/);assert.equal(f.fullscreen,false);assert.equal(f.maximized,true);await session.toggle();await session.dispose();
  assert.equal(f.fullscreen,false);assert.equal(f.maximized,true);assert.deepEqual(mutations(f),['native.set:true','native.set:false','native.unmaximize','native.maximize','native.set:true','native.set:false','native.unmaximize','native.maximize']);
});
await check('rejected restore after a partial entry retains ownership until a successful retry',async()=>{
  const f=fixture(),session=f.session(),original=f.native.setFullscreen;let entryFailure=true,restoreFailure=true;
  f.native.setFullscreen=async value=>{if(!value&&restoreFailure){restoreFailure=false;f.calls.push('native.restoreRejected');throw new Error('restore denied once')}await original(value);if(value&&entryFailure){entryFailure=false;throw new Error('reply lost')}};
  await assert.rejects(session.toggle(),/reply lost/);assert.equal(f.fullscreen,true);await session.toggle();assert.equal(f.fullscreen,true);await session.dispose();
  assert.equal(f.fullscreen,false);assert.equal(f.maximized,true);assert.deepEqual(mutations(f),['native.set:true','native.set:false','native.unmaximize','native.maximize','native.set:true','native.set:false','native.unmaximize','native.maximize']);
});
await check('native listener rejection does not poison later close and entry',async()=>{
  const f=fixture();f.native.onResized=async()=>{throw new Error('listener permission denied')};const session=f.session();await session.toggle();await session.dispose();
  assert.equal(f.maximized,true);assert.ok(!mutations(f).some(call=>call.startsWith('DOM.')));
});
await check('native state-read permission rejection leaves all window modes unchanged',async()=>{
  const f=fixture(),session=f.session();f.native.isFullscreen=async()=>{throw new Error('read permission denied')};await assert.rejects(session.toggle(),/read permission denied/);await session.dispose();assert.deepEqual(mutations(f),[]);assert.deepEqual(f.changes,[]);assert.equal(f.maximized,true);assert.deepEqual(f.bounds,f.initialBounds);assert.equal(f.removed,1);
});
await check('rejected external resize read stays contained and later close still restores',async()=>{
  const f=fixture(),session=f.session();await session.toggle();f.native.isFullscreen=async()=>{throw new Error('resize read rejected')};f.emit();await turn();assert.equal(f.external,0);assert.deepEqual(f.changes,[true]);await session.dispose();assert.equal(f.fullscreen,false);assert.equal(f.maximized,true);
});
await check('failed dispose restore is repaired before the next session reads its starting state',async()=>{
  const f=fixture(),session=f.session(),original=f.native.setFullscreen;await session.toggle();let fail=true;
  f.native.setFullscreen=async value=>{if(!value&&fail){fail=false;f.calls.push('native.restoreRejected');throw new Error('restore rejected')}return original(value)};
  await assert.rejects(session.dispose(),/restore rejected/);assert.equal(f.fullscreen,true);const next=f.session();await next.toggle();
  const operations=f.calls.filter(call=>/^native\.(set:|unmaximize|maximize|readFullscreen|restoreRejected)/.test(call));
  assert.deepEqual(operations,['native.readFullscreen','native.set:true','native.restoreRejected','native.set:false','native.unmaximize','native.maximize','native.readFullscreen','native.set:true']);
  await next.dispose();assert.equal(f.removed,2);assert.equal(f.fullscreen,false);assert.equal(f.maximized,true);
});
await check('browser manual fullscreen exit keeps TV open and dispose does not exit twice',async()=>{
  const f=fixture(),session=f.session(false);await session.toggle();assert.equal(f.document.fullscreenElement,f.element);await session.toggle();assert.equal(f.external,0);await session.dispose();
  assert.deepEqual(mutations(f),['DOM.enter','DOM.exit']);assert.equal(f.document.fullscreenElement,null);
});
await check('browser external fullscreen exit reports close once and leaves no listener',async()=>{
  const f=fixture(),session=f.session(false);await session.toggle();await f.document.exitFullscreen();assert.equal(f.external,1);await session.dispose();f.document.dispatchEvent(new Event('fullscreenchange'));assert.equal(f.external,1);
});
await check('browser disposal waits for a pending fullscreen entry and then exits it',async()=>{
  const f=fixture(),gate=deferred(),original=f.element.requestFullscreen;f.element.requestFullscreen=async()=>{await gate.promise;return original()};
  const session=f.session(false),enter=session.toggle(),dispose=session.dispose();gate.resolve();await Promise.all([enter,dispose]);assert.equal(f.document.fullscreenElement,null);assert.deepEqual(f.changes,[]);assert.equal(f.external,0);
});
await check('browser denied fullscreen never reports expanded and can still dispose',async()=>{
  const f=fixture(),session=f.session(false);f.element.requestFullscreen=async()=>{throw new Error('browser denied')};await assert.rejects(session.toggle(),/browser denied/);await session.dispose();assert.deepEqual(f.changes,[]);assert.equal(f.external,0);
});
assert.equal(createHash('sha256').update(fs.readFileSync(file)).digest('hex'),sourceSha256,'Helper source changed during checks');
const result={passed:cases.length,cases,source:{file:'src/lib/tvFullscreen.ts',sha256:sourceSha256},scope:'Runtime-transpiled production helper with native-window and DOM ports; controlled IPC delays and failures. No physical printer or real Windows window.'};
if(process.env.KF_R141_FULLSCREEN_PROOF){fs.mkdirSync(path.dirname(path.resolve(process.env.KF_R141_FULLSCREEN_PROOF)),{recursive:true});fs.writeFileSync(process.env.KF_R141_FULLSCREEN_PROOF,JSON.stringify(result,null,2)+'\n')}
console.log(JSON.stringify(result));
