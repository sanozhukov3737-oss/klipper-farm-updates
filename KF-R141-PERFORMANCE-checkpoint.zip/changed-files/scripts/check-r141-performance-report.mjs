import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';

const file=process.argv[2];assert.ok(file,'Provide the actual matched R141 browser report');
const report=JSON.parse(fs.readFileSync(file,'utf8'));
assert.equal(report.schemaVersion,1);assert.equal(report.mode,'matched-comparison');assert.ok(report.samplesPerMode>=3);
assert.equal(report.physicalPrintersTested,false);assert.equal(report.installedWindowsTested,false);
assert.deepEqual(report.runtimeErrors,[]);assert.deepEqual(report.unexpectedRequests,[]);
assert.equal(report.approvedSpoolRendererUnchanged,true);assert.equal(report.tvCssUnchanged,true);
assert.equal(report.passed,report.cases.length);assert.ok(report.cases.length>=10);assert.ok(report.cases.every(value=>value.passed===true));
assert.ok(report.summary.current.initialJavaScriptBytes<report.summary.baseline.initialJavaScriptBytes);
for(const mode of ['baseline','current']){
 assert.equal(report.raw[mode].app.length,report.samplesPerMode);assert.equal(report.raw[mode].tv.length,report.samplesPerMode);
 for(const sample of report.raw[mode].tv){
  assert.equal(sample.configuredPrinters,7);assert.equal(sample.cameraReady,true);assert.equal(sample.approvedSpoolReady,true);assert.equal(sample.inventoryReads,1);assert.equal(sample.automaticInventoryWrites,0);
  for(const phase of ['clockOnly','telemetry']){assert.ok(Number.isFinite(sample[phase].rendererTaskMs)&&sample[phase].rendererTaskMs>=0);assert.ok(Number.isFinite(sample[phase].jsHeapUsedBytes)&&sample[phase].jsHeapUsedBytes>0)}
  if(mode==='current'){assert.equal(sample.clockOnly.counts.TvDashboard||0,0);assert.equal(sample.clockOnly.counts.TvPrinter||0,0);assert.equal(sample.clockOnly.counts.filamentUsageInPeriod||0,0);assert.equal(sample.telemetry.counts.filamentUsageInPeriod||0,0)}
  else{assert.ok(sample.clockOnly.counts.TvDashboard>=6);assert.ok(sample.clockOnly.counts.TvPrinter>=6);assert.ok(sample.clockOnly.counts.filamentUsageInPeriod>=48)}
 }
}
const root=path.resolve(import.meta.dirname,'..');
for(const [name,hash]of Object.entries(report.productionSourceTree))assert.equal(createHash('sha256').update(fs.readFileSync(path.join(root,name))).digest('hex'),hash,name);
console.log(JSON.stringify({passed:true,currentTvCases:report.passed,samplesPerMode:report.samplesPerMode,actualProductionSourcesVerified:Object.keys(report.productionSourceTree).length,timingThresholdUsed:false}));
