import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';

const file=process.argv[2];assert.ok(file,'Provide the actual matched R141 browser report');
const report=JSON.parse(fs.readFileSync(file,'utf8'));
assert.equal(report.schemaVersion,1);assert.equal(report.mode,'matched-comparison');assert.ok(report.samplesPerMode>=3);
assert.equal(report.physicalPrintersTested,false);assert.equal(report.installedWindowsTested,false);
assert.deepEqual(report.runtimeErrors,[]);assert.deepEqual(report.unexpectedRequests,[]);
assert.equal(report.approvedSpoolRendererUnchanged,true);assert.equal(report.approvedMiddleFrameCssDelta,true);assert.equal(report.tvColumnGeometryUnchanged,true);
assert.equal(report.passed,report.cases.length);assert.ok(report.cases.length>=13);assert.ok(report.cases.every(value=>value.passed===true));
assert.ok(report.cases.some(value=>value.name==='approved-middle-column-outline-preserves-all-column-geometry'&&value.onlyApprovedCssDelta===true));
assert.equal(report.approvedMiddleFrameCss.onlyApprovedDelta,true);assert.equal(report.approvedMiddleFrameCss.baselineSha256,'f0929056bab6feb648395022c4a0db605d2cfb1fb82164671e80fcbd2ebcfb29');assert.equal(report.approvedMiddleFrameCss.restoredSha256,report.approvedMiddleFrameCss.baselineSha256);
assert.equal(report.approvedMiddleFrameCss.currentSha256,report.productionSources['src/components/TvDashboard.css']);
assert.deepEqual(report.middleFrameLayoutChecks.map(value=>[value.width,value.height]),[[1366,900],[1920,1080],[390,844]]);
for(const check of report.middleFrameLayoutChecks){assert.equal(check.geometryUnchanged,true);assert.equal(check.baseline.frame.outlineStyle,'none');assert.equal(check.current.frame.outlineStyle,'solid');assert.equal(check.current.frame.outlineWidth,1);assert.equal(check.current.frame.borderRadius,18);assert.ok(check.current.frame.outlineOffset>=8&&check.current.frame.outlineOffset<=13);assert.ok(Math.abs(check.current.frame.outlineOffset-Math.max(8,Math.min(13,check.width*.007)))<=1);for(const [selector,before]of Object.entries(check.baseline.rectangles))for(const key of ['x','y','width','height'])assert.ok(Math.abs(check.current.rectangles[selector][key]-before[key])<=.75,`${selector}.${key}`)}
assert.ok(report.summary.current.initialJavaScriptBytes<report.summary.baseline.initialJavaScriptBytes);
for(const mode of ['baseline','current']){
 assert.equal(report.raw[mode].app.length,report.samplesPerMode);assert.equal(report.raw[mode].tv.length,report.samplesPerMode);
 for(const sample of report.raw[mode].tv){
  assert.equal(sample.configuredPrinters,7);assert.equal(sample.cameraReady,true);assert.equal(sample.approvedSpoolReady,true);assert.equal(sample.inventoryReads,1);assert.equal(sample.automaticInventoryWrites,0);
  for(const phase of ['clockOnly','telemetry']){assert.ok(Number.isFinite(sample[phase].rendererTaskMs)&&sample[phase].rendererTaskMs>=0);assert.ok(Number.isFinite(sample[phase].jsHeapUsedBytes)&&sample[phase].jsHeapUsedBytes>0)}
  if(mode==='current'){assert.equal(sample.clockOnly.counts.TvDashboard||0,0);assert.equal(sample.clockOnly.counts.TvPrinter||0,0);assert.equal(sample.clockOnly.counts.filamentUsageInPeriod||0,0);assert.equal(sample.telemetry.counts.filamentUsageInPeriod||0,0)}
  else{assert.ok(sample.clockOnly.counts.TvDashboard>=6);assert.ok(sample.clockOnly.counts.TvPrinter>=6);assert.ok(sample.clockOnly.counts.filamentUsageInPeriod>=48)}
 }
}
const root=path.resolve(import.meta.dirname,'..');
const originalDetailsRule='.tvSpotlightInfo > .tvSpotlightDetails { width: 100%; max-width: 480px; gap: clamp(11px, 1.4vh, 18px); }';
const approvedDetailsRule=`.tvSpotlightInfo > .tvSpotlightDetails {
  width: 100%;
  max-width: 480px;
  gap: clamp(11px, 1.4vh, 18px);
  /* Frame the existing job column without narrowing or moving its contents. */
  border-radius: 18px;
  outline: 1px solid color-mix(in srgb, var(--tv-blue) 38%, var(--tv-line));
  outline-offset: clamp(8px, .7vw, 13px);
}`;
const css=fs.readFileSync(path.join(root,'src/components/TvDashboard.css'),'utf8');assert.equal(css.split(approvedDetailsRule).length,2);assert.equal(createHash('sha256').update(css.replace(approvedDetailsRule,originalDetailsRule)).digest('hex'),report.approvedMiddleFrameCss.baselineSha256,'Only the approved middle-column frame may differ from R140 TV CSS');
for(const [name,hash]of Object.entries(report.productionSourceTree))assert.equal(createHash('sha256').update(fs.readFileSync(path.join(root,name))).digest('hex'),hash,name);
console.log(JSON.stringify({passed:true,currentTvCases:report.passed,samplesPerMode:report.samplesPerMode,actualProductionSourcesVerified:Object.keys(report.productionSourceTree).length,timingThresholdUsed:false}));
