import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import ts from './typescript-runtime.mjs';

const root=path.resolve(import.meta.dirname,'..'),modules=new Map();
const compile=filename=>{
  if(modules.has(filename))return modules.get(filename);
  const result=ts.transpileModule(fs.readFileSync(filename,'utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ES2022},fileName:filename,reportDiagnostics:true});
  assert.equal(result.diagnostics?.length??0,0);
  const source=result.outputText.replace(/from\s+(['"])(\.\/[^'"]+)\1/g,(_match,_quote,specifier)=>`from '${compile(path.resolve(path.dirname(filename),specifier+'.ts'))}'`);
  const url=`data:text/javascript;base64,${Buffer.from(source).toString('base64')}`;modules.set(filename,url);return url;
};
const {tvFilamentInventoryStats,tvFilamentCurrentStats,tvFilamentInventoryClockBoundaries,tvFilamentInventoryTimeKey}=await import(compile(path.join(root,'src/lib/tvSpotlight.ts')));
const {emptyFilamentInventory,filamentDayKey}=await import(compile(path.join(root,'src/lib/filamentInventory.ts')));
const now=new Date(2026,9,25,16,35).getTime(),cases=[];
const check=(name,run)=>{run();cases.push({name,passed:true});console.log('PASS '+name)};
const key=(data,at)=>tvFilamentInventoryTimeKey(tvFilamentInventoryClockBoundaries('p1',data),at);
const inventory=()=>{
  const value=emptyFilamentInventory(now-10*86400000);
  value.printers.p1={binding:{id:'b1',material:'PETG',spoolId:'s1',effectiveAt:now-7200000,baselinePending:false},bindings:[],trackingAt:now-9*86400000,status:'tracking',usedGrams:2345,calculatedGrams:2300,manualGrams:45,pendingJobs:0,lastMilestoneKg:2,byMaterial:{PETG:2345}};
  value.spools.push({id:'s1',name:'Катушка PETG',material:'PETG',initialWeight:1000,remainingWeight:684,color:'#287dd0',price:0,currency:'RUB',createdAt:now-86400000});
  value.usageHistory.days=[{day:filamentDayKey(now),printerId:'p1',material:'PETG',calculatedGrams:120,manualGrams:7}];
  return value;
};
const printer=(extra={})=>({id:'p1',name:'K1 Max',host:'192.168.1.102',webcams:[],status:{state:'printing',connectionState:'online',filename:'part.gcode',progress:.54,printDuration:3600,nozzle:255,nozzleTarget:255,bed:80,bedTarget:80,telemetryUpdatedAt:now,jobUpdatedAt:now,filamentUsedMm:10000,...extra}});

check('live extrusion changes only the live projection without changing confirmed ledger data',()=>{
  const data=inventory(),before=JSON.stringify(data),ledger=tvFilamentInventoryStats('p1',data,now);
  const first=tvFilamentCurrentStats(printer(),data,now),next=tvFilamentCurrentStats(printer({filamentUsedMm:20000}),data,now+1000);
  assert.notEqual(next.currentLabel,first.currentLabel);
  assert.deepEqual(tvFilamentInventoryStats('p1',data,now+1000),ledger);
  assert.equal(key(data,now),key(data,now+1000));assert.equal(JSON.stringify(data),before);
});
check('local midnight changes calendar key and moves recorded today usage into yesterday',()=>{
  const data=inventory(),before=new Date(now);before.setHours(23,59,59,999);const midnight=new Date(before);midnight.setDate(midnight.getDate()+1);midnight.setHours(0,0,0,0);
  assert.notEqual(key(data,before.getTime()),key(data,midnight.getTime()));
  const after=tvFilamentInventoryStats('p1',data,midnight.getTime());
  assert.equal(after.todayLabel,'0 г');assert.equal(after.weeklyDays.at(-2).grams,127);assert.equal(after.weeklyDays.at(-1).grams,0);
});
check('future history eligibility invalidates exactly when recorded history becomes available',()=>{
  const data=inventory(),cutoff=now+5000;data.usageHistory.startedAt=cutoff;data.usageHistory.days=[];
  assert.equal(key(data,now),key(data,cutoff-1));assert.notEqual(key(data,cutoff-1),key(data,cutoff));
  assert.equal(tvFilamentInventoryStats('p1',data,cutoff-1).todayLabel,'—');
  const after=tvFilamentInventoryStats('p1',data,cutoff);assert.equal(after.todayLabel,'0 г');assert.equal(after.weeklyDays.at(-1).grams,0);
});
check('future explicit tracking invalidates weekly coverage at its actual boundary',()=>{
  const data=inventory(),cutoff=now+5000;data.printers.p1.trackingAt=cutoff;data.usageHistory.days=[];
  assert.notEqual(key(data,cutoff-1),key(data,cutoff));
  assert.ok(tvFilamentInventoryStats('p1',data,cutoff-1).weeklyDays.every(day=>day.grams===null));
  assert.equal(tvFilamentInventoryStats('p1',data,cutoff).weeklyDays.at(-1).grams,0);
});
check('fallback binding eligibility uses earliest valid binding including the active binding',()=>{
  const data=inventory(),first=now+5000;delete data.printers.p1.trackingAt;data.printers.p1.binding.effectiveAt=first;data.printers.p1.bindings=[{id:'later',material:'PETG',effectiveAt:first+10000,baselinePending:false}];data.usageHistory.days=[];
  assert.equal(key(data,now),key(data,first-1));assert.notEqual(key(data,first-1),key(data,first));
  assert.ok(tvFilamentInventoryStats('p1',data,first-1).weeklyDays.every(day=>day.grams===null));
  assert.equal(tvFilamentInventoryStats('p1',data,first).weeklyDays.at(-1).grams,0);
  assert.equal(key(data,first),key(data,first+10000),'Later bindings cannot change the earliest tracking fallback');
});
check('historical debits stay visible while future coverage leaves missing neighbours unknown',()=>{
  const data=inventory(),yesterday=new Date(now);yesterday.setDate(yesterday.getDate()-1);data.printers.p1.trackingAt=now+5000;data.usageHistory.startedAt=now+5000;
  data.usageHistory.days=[{day:filamentDayKey(yesterday.getTime()),printerId:'p1',material:'PETG',calculatedGrams:25,manualGrams:0}];
  const projection=tvFilamentInventoryStats('p1',data,now);assert.equal(projection.weeklyDays.at(-2).grams,25);assert.equal(projection.weeklyDays.at(-1).grams,null);assert.equal(projection.weeklyLabel,'25 г');
});
check('DST repeated hour preserves seven unique calendar days and updates timezone boundary',()=>{
  const previous=process.env.TZ;
  try{
    process.env.TZ='Europe/Berlin';const before=Date.parse('2026-10-25T00:59:59.999Z'),after=before+1,data=inventory();data.printers.p1.trackingAt=Date.parse('2026-10-01T00:00:00Z');data.usageHistory.startedAt=data.printers.p1.trackingAt;data.usageHistory.days=[];
    assert.equal(filamentDayKey(before),filamentDayKey(after));assert.notEqual(key(data,before),key(data,after));
    for(const at of[before,after]){const days=tvFilamentInventoryStats('p1',data,at).weeklyDays;assert.equal(new Set(days.map(day=>day.key)).size,7);assert.equal(days.at(-1).key,'2026-10-25');assert.ok(days.every(day=>day.grams===0))}
  }finally{if(previous===undefined)delete process.env.TZ;else process.env.TZ=previous}
});
check('selected printer and replaced inventory use their own confirmed data',()=>{
  const data=inventory(),other={...data,printers:{...data.printers,p2:{...data.printers.p1,usedGrams:999,binding:undefined}}};
  assert.equal(tvFilamentInventoryStats('p2',other,now).totalLabel,'999 г');assert.equal(tvFilamentInventoryStats('p2',other,now).spoolLabel,'—');
  const updated={...data,spools:data.spools.map(spool=>({...spool,remainingWeight:600}))};assert.equal(tvFilamentInventoryStats('p1',updated,now).spoolLabel,'600 г');assert.equal(tvFilamentInventoryStats('p1',data,now).spoolLabel,'684 г');
});
check('received usage expires at the existing freshness boundary independently of cached history',()=>{
  const data=inventory(),before=JSON.stringify(data),p=printer();
  assert.notEqual(tvFilamentCurrentStats(p,data,now+20000).currentLabel,'—');assert.equal(tvFilamentCurrentStats(p,data,now+20001).currentLabel,'—');
  assert.equal(tvFilamentInventoryStats('p1',data,now+20001).spoolLabel,'684 г');assert.equal(JSON.stringify(data),before);
});
const report={passed:cases.length,cases,scope:'Pure R141 presentation/cache eligibility contracts; no inventory writes or physical printer commands.'};
if(process.env.KF_R141_TV_PROJECTION_PROOF)fs.writeFileSync(process.env.KF_R141_TV_PROJECTION_PROOF,JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report));
