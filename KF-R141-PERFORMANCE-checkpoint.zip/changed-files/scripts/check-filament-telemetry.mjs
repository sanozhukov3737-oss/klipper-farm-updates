import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import ts from './typescript-runtime.mjs';

const root=path.resolve(import.meta.dirname,'..');
const read=file=>fs.readFileSync(path.join(root,file),'utf8');
const compile=async(source,fileName)=>{
  const result=ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ES2022},fileName,reportDiagnostics:true});
  assert.equal(result.diagnostics?.length??0,0,`${fileName}: transpile diagnostics`);
  return import(`data:text/javascript;base64,${Buffer.from(result.outputText).toString('base64')}`);
};
const history=await compile(read('src/lib/filamentHistory.ts'),'filamentHistory.ts');
const core=await compile(read('src/lib/filamentInventory.ts'),'filamentInventory.ts');
const moonraker=read('src/lib/moonraker.ts');
const ast=ts.createSourceFile('moonraker.ts',moonraker,ts.ScriptTarget.ES2022,true);
const clientClass=ast.statements.find(node=>ts.isClassDeclaration(node)&&node.name?.text==='MoonrakerClient');
const method=name=>clientClass.members.find(node=>ts.isMethodDeclaration(node)&&node.name.getText(ast)===name).getText(ast).replace(/^private\s+/,'');
const field=name=>clientClass.members.find(node=>ts.isPropertyDeclaration(node)&&node.name.getText(ast)===name).getText(ast).replace(/^private\s+/,'');
const bufferState=clientClass.members.find(node=>ts.isMethodDeclaration(node)&&node.name.getText(ast)==='bufferStatus').body.statements.slice(0,2).map(node=>node.getText(ast)).join('\n');
// The extracted production method retains its real fan-helper dependency;
// real initializers and synchronous buffering keep its observation cache intact.
const fanControl=read('src/lib/fanControl.ts');
const probe=await compile(`${fanControl}\nconst normalizeKlippyState=value=>value??'unknown';export class Probe{sensorObjects=[];fanObject='fan';lastTelemetryKlippyState='unknown';lastState='offline';${field('fanControlStatus')}${field('statusBuffer')}patch={};bufferStatus(p){${bufferState}this.patch=p}getJson=async()=>({jobs:[]});runBackgroundRequest=async worker=>worker(new AbortController().signal);${method('applyStatus')} ${method('historyPage')}}`,'filament-telemetry-probe.ts');

const buffered=new probe.Probe();
assert.deepEqual(buffered.fanControlStatus,{state:'offline',connectionState:'offline'},'the probe must start with the production observation cache');
assert.deepEqual(buffered.statusBuffer,{},'the production pending buffer starts empty');
buffered.applyStatus({extruder:{temperature:220},heater_bed:{temperature:60}},5000);
assert.equal(buffered.fanControlStatus.nozzleUpdatedAt,5000);assert.equal(buffered.statusBuffer.bed,60);
buffered.applyStatus({extruder:{temperature:24},heater_bed:{temperature:22},virtual_sdcard:{progress:.1}},6000,{nozzleUpdatedAt:1000,bedUpdatedAt:1000,jobUpdatedAt:6000});
assert.equal(buffered.fanControlStatus.nozzle,220);assert.equal(buffered.fanControlStatus.bed,60);
assert.equal(buffered.statusBuffer.nozzle,220);assert.equal(buffered.statusBuffer.bed,60);assert.equal(buffered.statusBuffer.progress,.1,'pending observations merge while older heater cache is rejected');

const p=new probe.Probe();
p.applyStatus({print_stats:{state:'cancelled',filament_used:'123.5'}},1000);
assert.equal(p.patch.filamentUsedMm,123.5);
assert.equal(p.patch.printStatsState,'cancelled');
assert.equal(p.patch.state,'ready','legacy ready state mapping remains unchanged');
assert.equal(p.patch.jobUpdatedAt,1000);
for(const value of [null,-1,NaN,Infinity,'12oops','']){p.applyStatus({print_stats:{filament_used:value}},1100);assert.equal(p.patch.filamentUsedMm,undefined,'invalid printer counter cannot become usage');}
p.applyStatus({print_stats:{filament_used:0}},1200);
assert.equal(p.patch.filamentUsedMm,0,'zero is a reported counter, not unknown');
p.applyStatus({print_stats:{filename:'old.gcode',state:'complete',filament_used:50}},1300);
p.applyStatus({print_stats:{filename:'new.gcode',state:'printing'}},1400);
assert.equal(p.patch.filamentUsedMm,undefined,'a new print without a counter must not inherit the previous print counter');
let requested;
p.getJson=async url=>{requested=url;return{result:{count:999,jobs:[]}}};
assert.deepEqual(await p.historyPage({limit:100,start:200,since:42.5,order:'asc'}),{jobs:[],count:0});
const query=new URL(requested,'http://printer').searchParams;
assert.equal(query.get('start'),'200');assert.equal(query.get('since'),'42.5');assert.equal(query.get('order'),'asc');
await assert.rejects(p.historyPage({limit:251}),/страница/);
p.getJson=async()=>({result:{jobs:null}});await assert.rejects(p.historyPage(),/некорректную/);

const now=200_000;
const raw={job_id:'A1',filename:'part.gcode',status:'in_progress',start_time:100,filament_used:0};
const printer={id:'p1',name:'K1 Max',host:'printer',webcams:[],status:{state:'printing',connectionState:'online',filename:raw.filename,jobUpdatedAt:now,filamentUsedMm:500,printDuration:10,progress:.1,nozzle:200,nozzleTarget:200,bed:60,bedTarget:60}};
assert.deepEqual(history.activeFilamentBaseline(printer,[raw],now),{filename:'part.gcode',usedMm:500,startedAt:100_000});
assert.equal(history.activeFilamentBaseline({...printer,status:{...printer.status,jobUpdatedAt:now-20_001}},[raw],now).usedMm,undefined);
assert.equal(history.activeFilamentBaseline({...printer,status:{...printer.status,connectionState:'offline'}},[raw],now).usedMm,undefined);
assert.equal(history.activeFilamentBaseline(printer,[raw,{...raw,job_id:'A2'}],now).usedMm,undefined,'same filename is not a unique print identity');
assert.equal(history.filamentHistoryObservation({...raw,filament_used:undefined,metadata:{filament_total:999_999,filament_weight_total:1000}},printer).usedMm,undefined,'slicer metadata cannot replace missing printer counters');
assert.equal(history.filamentHistoryObservation({...raw,job_id:'x'.repeat(161)},printer).jobId,'','identity must never be truncated into a different real ID');

const calls=[];
const rows=Array.from({length:101},(_,index)=>({...raw,job_id:String(index),start_time:100+index,status:'completed',filament_used:index}));
const pageReader={historyPage:async options=>{calls.push(options);return{jobs:rows.slice(options.start,options.start+options.limit),count:999}}};
assert.equal((await history.collectFilamentHistory(pageReader,{sinceMs:100_000})).length,101);
assert.deepEqual(calls.map(call=>call.start),[0,100,101]);
assert.equal(calls[0].since,99,'one second overlap includes the strict server since boundary');
calls.length=0;assert.equal((await history.collectFilamentHistory(pageReader,{baseline:true})).length,100);assert.equal(calls.length,1);assert.equal(calls[0].since,undefined,'baseline cannot filter by unsynchronised client time');
await assert.rejects(history.collectFilamentHistory({historyPage:async()=>({jobs:rows.slice(0,100),count:100})}),/повторяет страницу/);
let largeCalls=0;
await assert.rejects(history.collectFilamentHistory({historyPage:async options=>{largeCalls++;return{jobs:Array.from({length:100},(_,i)=>({...raw,job_id:String(options.start+i)})),count:100}}}),/2000 заданий/);
assert.equal(largeCalls,21,'twenty bounded data pages plus an empty-page probe cannot silently skip unpaid jobs');
const clampedCalls=[];
const clamped=await history.collectFilamentHistory({historyPage:async options=>{clampedCalls.push(options.start);return{jobs:rows.slice(options.start,options.start+50),count:50}}});
assert.equal(clamped.length,101);assert.deepEqual(clampedCalls,[0,50,100,101],'vendor page-size clamps must not look like complete history');
const abort=new AbortController();let abortCalls=0;
await assert.rejects(history.collectFilamentHistory({historyPage:async()=>{abortCalls++;abort.abort();return{jobs:[],count:0}}},{signal:abort.signal}),error=>error.name==='AbortError');
assert.equal(abortCalls,1);

let state=core.emptyFilamentInventory(150_000);
const dispatch=(command,time)=>{state=core.reduceFilamentInventory(state,command,time).state};
dispatch({type:'add-stock',material:'PLA',grams:15_000,reserveGrams:5000},150_001);
dispatch({type:'bind-printer',printerId:'p1',material:'PLA'},150_002);
const observation=history.filamentHistoryObservation(raw,printer);
dispatch({type:'history-baseline',printerId:'p1',bindingId:state.printers.p1.binding.id,at:200_000,jobs:[observation],active:history.activeFilamentBaseline(printer,[raw],200_000)},200_000);
const cancelled=history.filamentHistoryObservation({...raw,status:'cancelled',end_time:210,filament_used:1500},printer);
dispatch({type:'observe-job',job:cancelled},210_000);
const expected=core.calculatedFilamentGrams(1000,state.materials.PLA);
assert(Math.abs(state.printers.p1.calculatedGrams-expected)<1e-9,'partial cancelled use counts only extrusion after current-stock baseline');
const remaining=state.materials.PLA.looseGrams;
state=core.restoreFilamentInventory(JSON.parse(JSON.stringify(state)));
dispatch({type:'observe-job',job:cancelled},211_000);
assert.equal(state.materials.PLA.looseGrams,remaining,'restart and repeated terminal history cannot bill twice');
dispatch({type:'observe-job',job:history.filamentHistoryObservation({...raw,job_id:'A3',status:'completed',start_time:212,end_time:213,filament_used:undefined,metadata:{filament_total:999999}},printer)},214_000);
assert.equal(state.materials.PLA.looseGrams,remaining);assert.equal(state.printers.p1.pendingJobs,1,'unknown usage requires confirmation');

// Reconciliation windows move only after durable complete accounting, retaining the oldest active print and overlap.
const day=86_400_000,origin=1_000_000;
let rolling=core.emptyFilamentInventory(origin);
const roll=(command,time)=>{rolling=core.reduceFilamentInventory(rolling,command,time).state};
roll({type:'add-stock',material:'PLA',grams:15_000},origin+1);
roll({type:'bind-printer',printerId:'p1',material:'PLA'},origin+2);
const rollingBinding=rolling.printers.p1.binding.id;
roll({type:'history-baseline',printerId:'p1',bindingId:rollingBinding,at:origin+3,jobs:[]},origin+3);
const terminalJob={printerId:'p1',jobId:'later',filename:'later.gcode',startTime:origin+4*day,endTime:origin+4*day+1000,status:'completed',usedMm:1000};
const oldFrom=rolling.printers.p1.reconcileSince;
roll({type:'history-reconciled',printerId:'p1',bindingId:rollingBinding,from:oldFrom,jobs:[terminalJob]},origin+5*day);
assert.equal(rolling.printers.p1.reconcileSince,oldFrom,'an unpaid terminal row cannot be skipped by the cursor');
roll({type:'observe-job',job:terminalJob},origin+5*day);
const activeJob={printerId:'p1',jobId:'active',filename:'long.gcode',startTime:origin+3*day,status:'in_progress',usedMm:0};
roll({type:'history-reconciled',printerId:'p1',bindingId:rollingBinding,from:oldFrom,jobs:[terminalJob,activeJob]},origin+5*day);
assert.equal(rolling.printers.p1.reconcileSince,origin+2*day,'oldest active job pins the moving range with one day overlap');
const movedFrom=rolling.printers.p1.reconcileSince;
roll({type:'history-reconciled',printerId:'p1',bindingId:rollingBinding,from:oldFrom,jobs:[terminalJob]},origin+5*day);
assert.equal(rolling.printers.p1.reconcileSince,movedFrom,'stale in-flight cursor updates cannot move the new range');
roll({type:'observe-job',job:{...activeJob,status:'cancelled',endTime:origin+5*day,usedMm:2000}},origin+5*day);
roll({type:'history-reconciled',printerId:'p1',bindingId:rollingBinding,from:movedFrom,jobs:[terminalJob,{...activeJob,status:'cancelled',endTime:origin+5*day,usedMm:2000}]},origin+5*day);
assert.equal(rolling.printers.p1.reconcileSince,origin+3*day,'finished pinned jobs permit the next complete window to advance');
rolling=core.restoreFilamentInventory(JSON.parse(JSON.stringify(rolling)));
assert.equal(rolling.printers.p1.reconcileSince,origin+3*day,'moving reconciliation cursor survives restart');

console.log('Filament telemetry OK: real counters, raw terminal states, strict read-only pages, complete bounded reconciliation, fresh active baseline, cancelled partial use, restart dedup, unknown-usage hold and durable rolling cursor');
