import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {build} from 'esbuild';

const root=path.resolve(import.meta.dirname,'..');
const {outputFiles}=await build({stdin:{contents:"export {MoonrakerClient} from './src/lib/moonraker';export {confirmedTemperature,telemetryFreshness} from './src/lib/printerTelemetry';",resolveDir:root,loader:'ts'},bundle:true,write:false,format:'esm',platform:'node',target:'node22',plugins:[{name:'native-boundary',setup(builder){
  builder.onResolve({filter:/^@tauri-apps\/api\/(core|event)$/},args=>({path:args.path,namespace:'native'}));
  builder.onLoad({filter:/.*/,namespace:'native'},()=>({contents:'export const invoke=()=>{throw Error("Unexpected native request")};export const listen=async()=>()=>{};',loader:'js'}));
}}]});
globalThis.window={setTimeout,clearTimeout,dispatchEvent:()=>{}};
globalThis.document={hidden:false,addEventListener:()=>{},removeEventListener:()=>{}};
const api=await import('data:text/javascript;base64,'+Buffer.from(outputFiles[0].text).toString('base64'));
const now=Date.now(),old=now-2*60*60*1000;
let passed=0;const cases=[];
const test=async(name,run)=>{try{await run();passed++;cases.push({name,passed:true});console.log('PASS '+name)}catch(error){throw new Error(name+': '+String(error instanceof Error?error.message:error),{cause:error})}};

function fixture(){
  const client=new api.MoonrakerClient({id:'r141-heaters',name:'Temperature fixture',host:'127.0.0.1:7125',profile:{preset:'creality-k1c-2025'}});
  client.actorActive=true;client.actorEpoch=1;client.scheduleActorEventAck=()=>{};
  let status={state:'offline',nozzle:0,bed:0};
  client.onStatus(patch=>{status={...status,...patch}});
  const snapshot=(cachedStatus,telemetryUpdatedAt=old,jobUpdatedAt=now,heaterDates={})=>client.applyActorSnapshot({printerId:client.config.id,host:client.config.host,stableId:'temperature-fixture',sessionEpoch:1,connected:true,activeProtocol:'websocket',activePort:7125,phase:'printing',capabilities:{},lastSeenAt:now,telemetryUpdatedAt,jobUpdatedAt,...heaterDates,cachedStatus});
  const observe=(data,at=now)=>{client.applyStatus(data,at);client.flushStatus()};
  return{client,snapshot,observe,status:()=>status};
}

await test('fresh-job-snapshot-cannot-backdate-or-replace-a-newer-heater-read',()=>{
  const f=fixture();
  f.observe({extruder:{temperature:219.5,target:220},heater_bed:{temperature:59.8,target:60}});
  f.snapshot({extruder:{temperature:24,target:0},heater_bed:{temperature:22,target:0},print_stats:{state:'printing',print_duration:420},virtual_sdcard:{progress:.02}});
  assert.equal(f.status().nozzle,219.5);assert.equal(f.status().bed,59.8);assert.equal(f.status().nozzleTarget,220);assert.equal(f.status().bedTarget,60);
  assert.equal(f.status().telemetryUpdatedAt,now);assert.equal(f.status().jobUpdatedAt,now);assert.equal(f.status().progress,.02);assert.equal(api.confirmedTemperature(f.status().nozzle,f.status(),now),'220°C');
  f.client.disconnect();
});
await test('undated-cached-heaters-cannot-overwrite-confirmed-readings',()=>{
  const f=fixture();f.observe({extruder:{temperature:215},heater_bed:{temperature:60}});
  f.client.applyStatus({extruder:{temperature:0},heater_bed:{temperature:0}},now,{jobUpdatedAt:now});f.client.flushStatus();
  assert.equal(f.status().nozzle,215);assert.equal(f.status().bed,60);assert.equal(f.status().telemetryUpdatedAt,now);f.client.disconnect();
});
await test('buffered-heater-read-is-protected-before-its-first-render',()=>{
  const f=fixture();f.client.applyStatus({extruder:{temperature:210},heater_bed:{temperature:55}},now);
  f.snapshot({extruder:{temperature:20},heater_bed:{temperature:20},virtual_sdcard:{progress:.03}});
  assert.equal(f.status().nozzle,210);assert.equal(f.status().bed,55);assert.equal(f.status().progress,.03);assert.equal(f.status().telemetryUpdatedAt,now);f.client.disconnect();
});
await test('websocket-temperature-delta-survives-an-older-actor-cache',async()=>{
  const f=fixture();f.snapshot({extruder:{temperature:20},heater_bed:{temperature:20}});
  await f.client.applyActorEvent({eventId:1,stableId:'temperature-fixture',printerId:f.client.config.id,sessionEpoch:1,kind:'websocket',phase:'printing',eventtime:now,telemetryUpdatedAt:now,nozzleUpdatedAt:now,bedUpdatedAt:now,status:{extruder:{temperature:220},heater_bed:{temperature:60}}},'temperature-fixture',f.client.connectionEpoch);
  f.snapshot({extruder:{temperature:20},heater_bed:{temperature:20},virtual_sdcard:{progress:.04}});
  assert.equal(f.status().nozzle,220);assert.equal(f.status().bed,60);assert.equal(f.status().telemetryUpdatedAt,now);assert.equal(f.status().progress,.04);f.client.disconnect();
});
await test('job-and-fan-updates-never-refresh-old-heater-data',()=>{
  const f=fixture();f.snapshot({extruder:{temperature:24},heater_bed:{temperature:22}});
  f.observe({print_stats:{state:'printing',print_duration:425},virtual_sdcard:{progress:.03},fan:{speed:.5}});
  assert.equal(f.status().telemetryUpdatedAt,old);assert.equal(f.status().jobUpdatedAt,now);assert.equal(f.status().fanSpeed,.5);assert.equal(api.telemetryFreshness(f.status(),now),'expired');assert.equal(api.confirmedTemperature(f.status().nozzle,f.status(),now),'—');f.client.disconnect();
});
await test('newer-real-heaters-recover-and-identical-values-still-refresh',()=>{
  const f=fixture();f.snapshot({extruder:{temperature:24},heater_bed:{temperature:22}});
  f.snapshot({extruder:{temperature:220},heater_bed:{temperature:60}},now);
  assert.equal(f.status().nozzle,220);assert.equal(f.status().bed,60);assert.equal(f.status().telemetryUpdatedAt,now);
  f.snapshot({extruder:{temperature:220},heater_bed:{temperature:60}},now+1);
  assert.equal(f.status().telemetryUpdatedAt,now+1);assert.equal(api.telemetryFreshness(f.status(),now+1),'live');f.client.disconnect();
});
await test('initial-undated-cache-stays-unavailable-and-zero-is-a-real-reading',()=>{
  const f=fixture();f.client.applyStatus({extruder:{temperature:200},heater_bed:{temperature:60}},now,{});f.client.flushStatus();
  assert.equal(f.status().telemetryUpdatedAt,undefined);assert.equal(api.confirmedTemperature(f.status().nozzle,f.status(),now),'—');
  f.observe({extruder:{temperature:0},heater_bed:{temperature:0}});
  assert.equal(f.status().nozzle,0);assert.equal(f.status().bed,0);assert.equal(api.confirmedTemperature(f.status().nozzle,f.status(),now),'0°C');f.client.disconnect();
});
await test('disconnect-clears-the-observation-guard-for-a-new-connection',()=>{
  const f=fixture();f.observe({extruder:{temperature:220},heater_bed:{temperature:60}});f.client.disconnect();
  f.client.closedByUser=false;f.observe({extruder:{temperature:25},heater_bed:{temperature:23}},old);
  assert.equal(f.status().nozzle,25);assert.equal(f.status().bed,23);assert.equal(f.status().telemetryUpdatedAt,old);assert.equal(api.telemetryFreshness(f.status(),now),'expired');f.client.disconnect();
});
await test('fresh-bed-cache-never-promotes-or-overwrites-an-older-cached-nozzle',()=>{
  const f=fixture();f.observe({extruder:{temperature:220},heater_bed:{temperature:60}});
  f.snapshot({extruder:{temperature:24,target:0},heater_bed:{temperature:61,target:65}},old,now,{nozzleUpdatedAt:old,bedUpdatedAt:now+1});
  assert.equal(f.status().nozzle,220);assert.equal(f.status().nozzleUpdatedAt,now);assert.equal(f.status().bed,61);assert.equal(f.status().bedUpdatedAt,now+1);assert.equal(f.status().telemetryUpdatedAt,now);f.client.disconnect();
});
await test('newer-nozzle-date-does-not-block-a-fresh-bed-observation',()=>{
  const f=fixture();f.client.applyStatus({extruder:{temperature:220},heater_bed:{temperature:24}},now,{nozzleUpdatedAt:now+10,bedUpdatedAt:old,telemetryUpdatedAt:old});f.client.flushStatus();
  assert.equal(api.confirmedTemperature(f.status().nozzle,f.status(),now),'—');
  f.snapshot({extruder:{temperature:220},heater_bed:{temperature:60}},now+5,now,{nozzleUpdatedAt:now+10,bedUpdatedAt:now+5});
  assert.equal(f.status().bed,60);assert.equal(f.status().bedUpdatedAt,now+5);assert.equal(f.status().nozzleUpdatedAt,now+10);assert.equal(f.status().telemetryUpdatedAt,now+5);f.client.disconnect();
});
await test('new-actor-with-one-unobserved-heater-does-not-confirm-its-default-zero',()=>{
  const f=fixture();f.snapshot({extruder:{temperature:220}},now,now,{nozzleUpdatedAt:now,bedUpdatedAt:null});
  assert.equal(f.status().nozzleUpdatedAt,now);assert.equal(f.status().bedUpdatedAt,undefined);assert.equal(f.status().bed,0);assert.equal(f.status().telemetryUpdatedAt,undefined);
  assert.equal(api.confirmedTemperature(f.status().nozzle,f.status(),now),'—');assert.equal(api.confirmedTemperature(f.status().bed,f.status(),now),'—');
  f.snapshot({extruder:{temperature:220},heater_bed:{temperature:60}},now+1,now,{nozzleUpdatedAt:now,bedUpdatedAt:now+1});
  assert.equal(f.status().telemetryUpdatedAt,now);assert.equal(api.confirmedTemperature(f.status().bed,f.status(),now),'60°C');f.client.disconnect();
});
await test('legacy-snapshot-global-date-preserves-the-earlier-bridge-contract',()=>{
  const f=fixture();f.snapshot({extruder:{temperature:215},heater_bed:{temperature:55}},now);
  assert.equal(f.status().nozzleUpdatedAt,now);assert.equal(f.status().bedUpdatedAt,now);assert.equal(f.status().telemetryUpdatedAt,now);assert.equal(api.confirmedTemperature(f.status().nozzle,f.status(),now),'215°C');f.client.disconnect();
});
await test('delayed-native-event-keeps-each-source-date-instead-of-receipt-time',async()=>{
  const f=fixture();f.observe({extruder:{temperature:220},heater_bed:{temperature:60}});
  await f.client.applyActorEvent({eventId:1,stableId:'temperature-fixture',printerId:f.client.config.id,sessionEpoch:1,kind:'websocket',phase:'printing',eventtime:1234,nozzleUpdatedAt:old,bedUpdatedAt:now+1,telemetryUpdatedAt:old,jobUpdatedAt:now,status:{extruder:{temperature:24},heater_bed:{temperature:61},virtual_sdcard:{progress:.05}}},'temperature-fixture',f.client.connectionEpoch);
  assert.equal(f.status().nozzle,220);assert.equal(f.status().nozzleUpdatedAt,now);assert.equal(f.status().bed,61);assert.equal(f.status().bedUpdatedAt,now+1);assert.equal(f.status().telemetryUpdatedAt,now);assert.equal(f.status().progress,.05);f.client.disconnect();
});
await test('unstamped-legacy-event-cannot-relabel-two-hour-old-heaters-as-live',async()=>{
  const f=fixture();f.snapshot({extruder:{temperature:24},heater_bed:{temperature:22}});
  await f.client.applyActorEvent({eventId:1,stableId:'temperature-fixture',printerId:f.client.config.id,sessionEpoch:1,kind:'websocket',phase:'printing',eventtime:1234,status:{extruder:{temperature:220},heater_bed:{temperature:60}}},'temperature-fixture',f.client.connectionEpoch);
  assert.equal(f.status().nozzle,24);assert.equal(f.status().bed,22);assert.equal(f.status().telemetryUpdatedAt,old);assert.equal(api.confirmedTemperature(f.status().nozzle,f.status(),now),'—');f.client.disconnect();
});
await test('invalid-numeric-prefixes-never-replace-confirmed-heater-values',()=>{
  const f=fixture();f.observe({extruder:{temperature:220},heater_bed:{temperature:60}});
  for(const invalid of ['24 C','0x10','1_000',' ','NaN','Infinity',null]){
    f.snapshot({extruder:{temperature:invalid},heater_bed:{temperature:invalid}},now,now,{nozzleUpdatedAt:now,bedUpdatedAt:now});
    assert.equal(f.status().nozzle,220);assert.equal(f.status().bed,60);assert.equal(f.status().telemetryUpdatedAt,now);
  }
  f.snapshot({extruder:{temperature:' 2.15e2 '},heater_bed:{temperature:' 6.05e1 '}},now+1,now,{nozzleUpdatedAt:now+1,bedUpdatedAt:now+1});
  assert.equal(f.status().nozzle,215);assert.equal(f.status().bed,60.5);assert.equal(f.status().telemetryUpdatedAt,now+1);f.client.disconnect();
});
await test('malformed-direct-heater-payload-does-not-refresh-and-real-zero-still-does',()=>{
  const f=fixture();f.observe({extruder:{temperature:220,target:220},heater_bed:{temperature:60,target:60}});
  for(const invalid of ['999 C','0x10','1_000',' ','NaN','Infinity',null]){
    f.observe({extruder:{temperature:invalid,target:invalid},heater_bed:{temperature:invalid,target:invalid}},now+1);
    assert.equal(f.status().nozzle,220);assert.equal(f.status().bed,60);assert.equal(f.status().nozzleTarget,220);assert.equal(f.status().bedTarget,60);assert.equal(f.status().telemetryUpdatedAt,now);
  }
  f.observe({extruder:{temperature:' 0 ',target:0},heater_bed:{temperature:0,target:'0'}},now+2);
  assert.equal(f.status().nozzle,0);assert.equal(f.status().bed,0);assert.equal(f.status().nozzleTarget,0);assert.equal(f.status().bedTarget,0);assert.equal(f.status().telemetryUpdatedAt,now+2);assert.equal(api.confirmedTemperature(f.status().nozzle,f.status(),now+2),'0°C');f.client.disconnect();
});
const report={passed,cases,sourceSha256:Object.fromEntries(['src/lib/moonraker.ts','src/types.ts','src/lib/printerTelemetry.ts','scripts/check-r141-temperature-merge.mjs'].map(filename=>[filename,createHash('sha256').update(fs.readFileSync(path.join(root,filename))).digest('hex')])),scope:'Actual production MoonrakerClient with isolated native boundary; no printer network requests or fabricated live heater fallback.'};
if(process.env.KF_R141_TEMPERATURE_MERGE_PROOF)fs.writeFileSync(process.env.KF_R141_TEMPERATURE_MERGE_PROOF,JSON.stringify(report,null,2)+'\n');
console.log(`r141 temperature merge: ${passed} runtime checks passed`);
