#[path = "/workspace/scratch/d006d396a32a/klipper-farm-r141-source/src-tauri/src/transactional_core/temperature.rs"]
mod temperature;
#[path = "/workspace/scratch/d006d396a32a/klipper-farm-r141-source/src-tauri/src/transactional_core/types.rs"]
mod actor_types;

#[cfg(test)]
mod wire_roundtrip {
    use super::actor_types::{ActorConfig, ActorSnapshot, ActorEvent};

    #[test]
    fn separate_heater_observation_dates_round_trip_snapshot_and_event() {
        let config = ActorConfig {
            stable_id: "wire-roundtrip".into(), printer_id: "wire-roundtrip".into(), model_id: None,
            host: "127.0.0.1:7125".into(), default_port: 7125, api_key: None,
            firmware_signature: None, capabilities_hint: None,
        };
        let mut snapshot = ActorSnapshot::new(&config);
        snapshot.telemetry_updated_at = Some(120_000);
        snapshot.nozzle_updated_at = Some(125_000);
        snapshot.bed_updated_at = Some(120_000);
        let wire = serde_json::to_value(&snapshot).unwrap();
        assert_eq!(wire["nozzleUpdatedAt"], 125_000);
        assert_eq!(wire["bedUpdatedAt"], 120_000);
        let restored: ActorSnapshot = serde_json::from_value(wire).unwrap();
        assert_eq!(restored.nozzle_updated_at, Some(125_000));
        assert_eq!(restored.bed_updated_at, Some(120_000));
        assert_eq!(restored.telemetry_updated_at, Some(120_000));

        let event: ActorEvent = serde_json::from_value(serde_json::json!({
            "eventId":1,"stableId":"wire-roundtrip","printerId":"wire-roundtrip","sessionEpoch":1,
            "kind":"websocket","phase":"printing","eventtime":42,
            "status":{"extruder":{"temperature":220}},"operationId":null,"payload":null,
            "nozzleUpdatedAt":125000,"bedUpdatedAt":120000,"telemetryUpdatedAt":120000,
            "jobUpdatedAt":124000
        })).unwrap();
        let event_wire = serde_json::to_value(&event).unwrap();
        let event_again: ActorEvent = serde_json::from_value(event_wire).unwrap();
        assert_eq!(event_again.nozzle_updated_at, Some(125_000));
        assert_eq!(event_again.bed_updated_at, Some(120_000));
        assert_eq!(event_again.telemetry_updated_at, Some(120_000));
        assert_eq!(event_again.job_updated_at, Some(124_000));
    }
}
