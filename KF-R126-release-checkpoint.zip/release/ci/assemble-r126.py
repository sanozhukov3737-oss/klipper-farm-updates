#!/usr/bin/env python3
"""Reassemble the exact reviewed package from bounded transport fragments."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent.parent
manifest = json.loads((root / 'r126-transfer/manifest.json').read_text())
expected = '20d20017dfa46ccbb53ffca6b243aeb4691a88e4f4c8c670f3fda83512ddfeae'
assert manifest['schemaVersion'] == 1 and manifest['sha256'] == expected
pieces = []
for index, part in enumerate(manifest['parts'], 1):
    assert part['path'] == f'r126-transfer/patch-{index:03}.part'
    data = (root / part['path']).read_bytes()
    assert len(data) == part['sizeBytes']
    assert hashlib.sha256(data).hexdigest() == part['sha256']
    pieces.append(data)
payload = b''.join(pieces)
assert len(payload) == manifest['sizeBytes']
assert hashlib.sha256(payload).hexdigest() == expected
assert len(json.loads(payload)) == 30
(root / 'r126-patch.json').write_bytes(payload)
print(f'Reassembled 30 reviewed files; SHA-256 {expected}')
