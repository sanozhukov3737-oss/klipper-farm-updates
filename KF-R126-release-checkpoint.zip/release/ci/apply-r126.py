import base64, hashlib, json, sys, zipfile
from pathlib import Path, PurePosixPath
root=Path(sys.argv[1]); patch=Path(sys.argv[2]); proof=Path(sys.argv[3]);baseline=Path(sys.argv[4])
rows=json.loads(patch.read_text());seen=set()
for row in rows:
 name=row['path'];parts=PurePosixPath(name).parts
 assert name and not name.startswith('/') and '\\' not in name and ':' not in name and all(x not in ('','.','..') for x in parts)
 assert name not in seen;seen.add(name)
 target=root/name;before=hashlib.sha256(target.read_bytes()).hexdigest() if target.exists() else None
 assert before==row['beforeSha256'],f'Baseline differs: {name}'
 data=base64.b64decode(row['content'],validate=True) if row['encoding']=='base64' else row['content'].encode()
 assert hashlib.sha256(data).hexdigest()==row['afterSha256'],f'Patch payload differs: {name}'
 target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
with zipfile.ZipFile(baseline) as archive:
 for info in archive.infolist():
  if info.is_dir():continue
  name=info.filename.removeprefix('Klipper-Farm-R125/')
  if name in seen:continue
  assert (root/name).read_bytes()==archive.read(info),f'Unreviewed source changed: {name}'
proof.mkdir(exist_ok=True)
(proof/'source-delta.json').write_text(json.dumps({'release':'R126','baseline':'R125','allUnreviewedSourceBytesPreserved':True,'modifiedFiles':[{'path':r['path'],'beforeSha256':r['beforeSha256'],'afterSha256':r['afterSha256']} for r in rows]},indent=2)+'\n')
print(f'Applied {len(rows)} checked R126 files; all other published source bytes unchanged')
