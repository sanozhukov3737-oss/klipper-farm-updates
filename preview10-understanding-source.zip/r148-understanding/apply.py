"""Apply reviewed PREVIEW10 source over the exact R144-based PREVIEW9 source."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import sys

root = Path(sys.argv[1]).resolve()
overlay = Path(__file__).resolve().parent
manifest = json.loads((overlay / 'source-manifest.json').read_text(encoding='utf-8'))
channel = json.loads((root / 'UPDATE-CHANNEL.json').read_text(encoding='utf-8-sig'))
if channel['installedSequence'] != 144:
    raise SystemExit('Expected the R144-based preview channel; stable channel is not changed')
identity = (root / 'RELEASE-BUILD-ID.txt').read_text(encoding='utf-8-sig').strip()
if identity not in (manifest['beforeBuildId'], manifest['buildId']):
    raise SystemExit('Expected exact PREVIEW9 source or this same PREVIEW10 candidate')

def canonical(data):
    return data.replace(b'\r\n', b'\n')

def digest(data):
    return hashlib.sha256(canonical(data)).hexdigest()

rows = []
for row in manifest['files']:
    path = PurePosixPath(row['path'])
    if path.is_absolute() or '..' in path.parts or '\\' in row['path']:
        raise SystemExit('Unsafe source path')
    target = root.joinpath(*path.parts)
    source = overlay.joinpath('changes', *path.parts)
    if not source.is_file() or digest(source.read_bytes()) != row['sha256']:
        raise SystemExit('Candidate source checksum differs: ' + row['path'])
    current = digest(target.read_bytes()) if target.is_file() else None
    if current not in (row['beforeSha256'], row['sha256']):
        raise SystemExit('Existing source differs; refusing overwrite: ' + row['path'])
    rows.append((target, source))
for target, source in rows:
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(canonical(source.read_bytes()))
(root / 'RELEASE-BUILD-ID.txt').write_bytes((manifest['buildId'] + '\n').encode('utf-8'))
print('Applied reviewed PREVIEW10 source; stable sequence remains 144. Windows verification still required.')
