"""Apply reviewed UPDATE-DELIVERY source over the exact R144-based PREVIEW9 source."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import sys

root = Path(sys.argv[1]).resolve()
overlay = Path(__file__).resolve().parent
manifest = json.loads((overlay / 'source-manifest.json').read_text(encoding='utf-8'))
channel = json.loads((root / 'UPDATE-CHANNEL.json').read_text(encoding='utf-8-sig'))
expected_channel = {'endpoint': 'https://github.com/sanozhukov3737-oss/klipper-farm-updates/releases/latest/download/update-v20.json', 'publicKeyHex': '28e0124c33f42704483d1aac89af829c44a00ef5dbc2e93dff630befddd495eb', 'channel': 'stable', 'installedSequence': 144}
if channel not in (expected_channel, dict(expected_channel, installedSequence=145), dict(expected_channel, installedSequence=146), dict(expected_channel, installedSequence=147), dict(expected_channel, installedSequence=148), dict(expected_channel, installedSequence=149)):
    raise SystemExit('Expected exact unchanged trust channel at sequence 144, the sequence-145 release, the sequence-146 release, the sequence-147 release, the sequence-148 release or this sequence-149 candidate')
identity = (root / 'RELEASE-BUILD-ID.txt').read_text(encoding='utf-8-sig').strip()
if identity not in (manifest['beforeBuildId'], manifest['buildId']):
    raise SystemExit('Expected exact PREVIEW9 source or this same UPDATE-DELIVERY candidate')

def canonical(data):
    return data.replace(b'\r\n', b'\n')

def digest(data):
    return hashlib.sha256(canonical(data)).hexdigest()

rows = []
for row in manifest['files']:
    path = PurePosixPath(row['path'])
    if path.is_absolute() or '..' in path.parts or '\\' in row['path']:
        raise SystemExit('Unsafe source path')
    target = root.joinpath(*path.parts)
    source = overlay.joinpath('changes', *path.parts)
    if not source.is_file() or digest(source.read_bytes()) != row['sha256']:
        raise SystemExit('Candidate source checksum differs: ' + row['path'])
    current = digest(target.read_bytes()) if target.is_file() else None
    if current not in (row['beforeSha256'], row['sha256']):
        raise SystemExit('Existing source differs; refusing overwrite: ' + row['path'])
    rows.append((target, source))
for target, source in rows:
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(canonical(source.read_bytes()))
(root / 'RELEASE-BUILD-ID.txt').write_bytes((manifest['buildId'] + '\n').encode('utf-8'))
applied_channel = json.loads((root / 'UPDATE-CHANNEL.json').read_text(encoding='utf-8-sig'))
if applied_channel not in (dict(expected_channel, installedSequence=145), dict(expected_channel, installedSequence=146), dict(expected_channel, installedSequence=147), dict(expected_channel, installedSequence=148), dict(expected_channel, installedSequence=149)):
    raise SystemExit('Applied production channel does not match sequence 145, 146, 147, 148 or 149 with unchanged endpoint, key and channel')
print('Applied reviewed UPDATE-DELIVERY source; production candidate sequence is 145, 146, 147, 148 or 149. Windows verification and stable publication still required.')
