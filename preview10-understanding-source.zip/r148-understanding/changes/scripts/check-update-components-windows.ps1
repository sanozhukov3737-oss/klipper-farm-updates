# Small, fully local Windows PowerShell 5.1 fixture tests. No external downloads.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$helper = Join-Path $PSScriptRoot 'install-update-components.ps1'
$testRoot = Join-Path ([IO.Path]::GetTempPath()) ('kf-components-fixture-' + [Guid]::NewGuid().ToString('N'))
$source = Join-Path $testRoot 'source'
$installed = Join-Path $testRoot 'installed'
$manifestPath = Join-Path $testRoot 'component-manifest.json'
$resultPath = Join-Path $testRoot 'result.txt'
[IO.Directory]::CreateDirectory($source) | Out-Null
function Pin([string]$Path, [string]$Relative) {
  return @{ path=$Relative; bytes=(Get-Item -LiteralPath $Path).Length;
    sha256=(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() }
}
function Save-Manifest($Value) {
  [IO.File]::WriteAllText($manifestPath, ($Value | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
}
function Write-RuntimeZip([string]$Path, [string[]]$EntryNames) {
  # WinPS5 targets older .NET Framework and CreateFromDirectory can write
  # backslashes. Use the production builder's explicit '/' manifest names.
  $archive = [IO.Compression.ZipFile]::Open($Path, [IO.Compression.ZipArchiveMode]::Create)
  try {
    for ($i = 0; $i -lt $rows.Count; $i++) {
      $file = Join-Path $runtime $rows[$i].path.Replace('/', '\')
      [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive, $file, $EntryNames[$i]) | Out-Null
    }
  } finally { $archive.Dispose() }
}
function Set-RuntimeZip([string[]]$EntryNames) {
  $zip = Join-Path $testRoot (([Guid]::NewGuid().ToString('N')) + '.zip')
  Write-RuntimeZip $zip $EntryNames
  $sha = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant()
  $name = 'klipper-farm-runtime-' + $sha + '.zip'
  $destination = Join-Path $source $name
  if (Test-Path -LiteralPath $destination) {
    if ((Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash.ToLowerInvariant() -cne $sha) { throw 'Fixture archive hash collision.' }
    Remove-Item -LiteralPath $zip
  } else { Move-Item -LiteralPath $zip -Destination $destination }
  $manifest.runtime.name = $name
  $manifest.runtime.sha256 = $sha
  $manifest.runtime.bytes = (Get-Item (Join-Path $source $name)).Length
  $manifest.runtime.url = 'https://github.com/sanozhukov3737-oss/klipper-farm-updates/releases/download/klipper-farm-runtime-v1/' + $name
  Save-Manifest $manifest
}
function Run-Fixture([bool]$ExpectSuccess) {
  $quoted = @('-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',('"' + $helper + '"'),
    '-InstallRoot',('"' + $installed + '"'),'-ManifestPath',('"' + $manifestPath + '"'),
    '-LocalSource',('"' + $source + '"'),'-ResultPath',('"' + $resultPath + '"'),'-Offline','-NoProgressWindow')
  $process = Start-Process -FilePath (Join-Path $PSHOME 'powershell.exe') -ArgumentList $quoted -Wait -PassThru -WindowStyle Hidden
  if (($process.ExitCode -eq 0) -ne $ExpectSuccess) { throw ('Unexpected fixture result: ' + [IO.File]::ReadAllText($resultPath)) }
}
try {
  $runtime = Join-Path $testRoot 'runtime'
  [IO.Directory]::CreateDirectory((Join-Path $runtime 'speech/whisper')) | Out-Null
  [IO.Directory]::CreateDirectory((Join-Path $runtime 'understanding/runtime')) | Out-Null
  [IO.File]::WriteAllText((Join-Path $runtime 'speech/whisper/engine.dll'), 'whisper-engine-fixture')
  [IO.File]::WriteAllText((Join-Path $runtime 'understanding/runtime/server.exe'), 'understanding-engine-fixture')
  [IO.File]::WriteAllText((Join-Path $source 'model.gguf'), 'GGUF-model-fixture')
  $rows = @((Pin (Join-Path $runtime 'speech/whisper/engine.dll') 'speech/whisper/engine.dll'),
    (Pin (Join-Path $runtime 'understanding/runtime/server.exe') 'understanding/runtime/server.exe'))
  $zip = Join-Path $testRoot 'runtime.zip'
  Write-RuntimeZip $zip @($rows | ForEach-Object { $_.path })
  $archive = [IO.Compression.ZipFile]::OpenRead($zip)
  try {
    if ($archive.Entries.Count -ne $rows.Count) { throw 'Fixture ZIP inventory differs from production layout.' }
    for ($i = 0; $i -lt $rows.Count; $i++) {
      if ($archive.Entries[$i].FullName -cne $rows[$i].path) { throw 'Fixture ZIP path differs from the production manifest name.' }
    }
  } finally { $archive.Dispose() }
  $sha = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant()
  $name = 'klipper-farm-runtime-' + $sha + '.zip'
  Move-Item -LiteralPath $zip -Destination (Join-Path $source $name)
  $model = Pin (Join-Path $source 'model.gguf') 'understanding/model.gguf'
  $model.url = 'https://huggingface.co/test/model/resolve/0000000000000000000000000000000000000000/model.gguf'
  $model.localName = 'model.gguf'
  $manifest = @{schema=1; runtime=@{name=$name;sha256=$sha;bytes=(Get-Item (Join-Path $source $name)).Length;
    url=('https://github.com/sanozhukov3737-oss/klipper-farm-updates/releases/download/klipper-farm-runtime-v1/' + $name);files=$rows};model=$model}
  Save-Manifest $manifest
  Run-Fixture $true
  $statePath = Join-Path $installed '.klipper-component-state.json'
  $fresh = [IO.File]::ReadAllText($statePath) | ConvertFrom-Json
  if ($fresh.modelReused -or $fresh.runtimeReusedFiles -ne 0 -or $fresh.localCopyBytes -le 0 -or $fresh.networkDownloadBytes -ne 0) { throw 'Fresh fixture report differs.' }
  $mtime = (Get-Item (Join-Path $installed 'understanding/model.gguf')).LastWriteTimeUtc.Ticks
  $sourceBackup = Join-Path $testRoot 'source-backup'
  Move-Item -LiteralPath $source -Destination $sourceBackup
  [IO.Directory]::CreateDirectory($source) | Out-Null
  Run-Fixture $true
  $reuse = [IO.File]::ReadAllText($statePath) | ConvertFrom-Json
  if (-not $reuse.modelReused -or $reuse.runtimeReusedFiles -ne 2 -or $reuse.localCopyBytes -ne 0 -or
      (Get-Item (Join-Path $installed 'understanding/model.gguf')).LastWriteTimeUtc.Ticks -ne $mtime) { throw 'Matching components were not reused.' }
  [IO.Directory]::Delete($source)
  Move-Item -LiteralPath $sourceBackup -Destination $source
  [IO.File]::WriteAllText((Join-Path $installed 'speech/whisper/engine.dll'), 'damaged')
  [IO.File]::WriteAllText((Join-Path $installed 'speech/whisper/obsolete.dll'), 'stale-module')
  Run-Fixture $true
  $repair = [IO.File]::ReadAllText($statePath) | ConvertFrom-Json
  if ($repair.runtimeReusedFiles -ne 1 -or -not $repair.modelReused -or
      (Test-Path -LiteralPath (Join-Path $installed 'speech/whisper/obsolete.dll'))) { throw 'Partial runtime repair/stale cleanup failed.' }
  [IO.File]::WriteAllText((Join-Path $installed 'understanding/model.gguf'), 'broken')
  Run-Fixture $true
  $repairModel = [IO.File]::ReadAllText($statePath) | ConvertFrom-Json
  if ($repairModel.modelReused -or $repairModel.runtimeReusedFiles -ne 2) { throw 'Corrupt model was not repaired independently.' }
  # A valid outer SHA must not permit legacy separators, traversal, aliases,
  # duplicates or renamed entries inside the archive. Repair must fail before
  # replacing any installed files or touching the verified model.
  $damagedPath = Join-Path $installed 'speech/whisper/engine.dll'
  foreach ($bad in @(
      @{label='backslash';names=@('speech\whisper\engine.dll','understanding/runtime/server.exe')},
      @{label='traversal';names=@('../escaped.dll','understanding/runtime/server.exe')},
      @{label='case alias';names=@('Speech/whisper/engine.dll','understanding/runtime/server.exe')},
      @{label='duplicate';names=@('speech/whisper/engine.dll','speech/whisper/engine.dll')},
      @{label='renamed';names=@('speech/whisper/other.dll','understanding/runtime/server.exe')}
  )) {
    [IO.File]::WriteAllText($damagedPath, 'requires repair')
    Set-RuntimeZip $bad.names
    Run-Fixture $false
    if ([IO.File]::ReadAllText($resultPath) -notmatch 'Unsafe or unexpected runtime ZIP entry') { throw ('Wrong rejection for ' + $bad.label) }
    if ([IO.File]::ReadAllText($damagedPath) -ne 'requires repair' -or
        [IO.File]::ReadAllText((Join-Path $installed 'understanding/model.gguf')) -ne 'GGUF-model-fixture' -or
        (Test-Path -LiteralPath (Join-Path $installed 'escaped.dll')) -or
        (Test-Path -LiteralPath (Join-Path $testRoot 'escaped.dll'))) { throw ('Rejected ZIP changed installed files: ' + $bad.label) }
  }
  Set-RuntimeZip @($rows | ForEach-Object { $_.path })
  Run-Fixture $true
  $name = $manifest.runtime.name
  [IO.File]::WriteAllText((Join-Path $source $name), 'corrupt archive')
  [IO.File]::WriteAllText((Join-Path $installed 'speech/whisper/engine.dll'), 'requires repair')
  Run-Fixture $false
  if ([IO.File]::ReadAllText((Join-Path $installed 'understanding/model.gguf')) -ne 'GGUF-model-fixture') { throw 'Failed repair modified the valid model.' }
  $manifest.runtime.files[0].path = '../escaped.dll'
  Save-Manifest $manifest
  Run-Fixture $false
  if ((Test-Path -LiteralPath (Join-Path $testRoot 'escaped.dll')) -or
      (Test-Path -LiteralPath (Join-Path $installed 'escaped.dll'))) { throw 'Unsafe manifest escaped its root.' }
  Write-Output 'PASS: Windows component fixtures: canonical ZIP, fresh, reuse without sources, partial/model repair, invalid entry names, corrupt archive and traversal rejection.'
} finally {
  if (Test-Path -LiteralPath $testRoot) { Remove-Item -LiteralPath $testRoot -Recurse -Force }
}
