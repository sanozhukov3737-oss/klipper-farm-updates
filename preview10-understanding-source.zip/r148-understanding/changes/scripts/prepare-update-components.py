"""Split verified offline engines from the small, signed Windows app installer.

Run after both prepare-neural-speech.py and prepare-voice-understanding.py.
The runtime archive is content addressed and may be published once to the fixed
runtime release. The manifest is embedded in the installer, never fetched from
that release. User-editable settings and library files are not inputs.
"""
import argparse
import hashlib
import json
import os
import re
import shutil
import tempfile
import zipfile
from pathlib import Path, PurePosixPath

RUNTIME_BASE = 'https://github.com/sanozhukov3737-oss/klipper-farm-updates/releases/download/klipper-farm-runtime-v1/'
SMALL_SPEECH = frozenset({'silero/tts.py', 'whisper/recognition.args', 'NEURAL-SPEECH-NOTICES.txt'})
MAX_ASSET_BYTES = 2 * 1024 ** 3


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def safe_relative(value):
    path = PurePosixPath(value)
    if (not isinstance(value, str) or not value or path.is_absolute() or '\\' in value or re.search(r'[\x00-\x1f:*?"<>|]', value)
            or any(part in ('', '.', '..') or ':' in part or part.endswith((' ', '.'))
                   or re.match(r'^(CON|PRN|AUX|NUL|COM[0-9]|LPT[0-9])(\.|$)', part, re.I)
                   for part in value.split('/'))):
        raise ValueError('Unsafe component path: ' + str(value))
    return path


def verified_rows(directory, rows):
    found = {}
    for row in rows:
        relative = safe_relative(row['path'])
        key = str(relative).casefold()
        if key in found or not re.fullmatch('[0-9a-f]{64}', row['sha256']):
            raise ValueError('Invalid or duplicate prepared component pin')
        path = directory.joinpath(*relative.parts)
        if path.is_symlink() or any(parent.is_symlink() for parent in path.parents):
            raise ValueError('Prepared component is a link: ' + str(relative))
        if not path.is_file() or path.stat().st_size != row['bytes'] or digest(path) != row['sha256']:
            raise ValueError('Prepared component differs from its manifest: ' + str(relative))
        found[key] = {'path': str(relative), 'bytes': row['bytes'], 'sha256': row['sha256']}
    actual = {path.relative_to(directory).as_posix().casefold() for path in directory.rglob('*')
              if path.is_file() and path.relative_to(directory).as_posix() != 'manifest.json'}
    if actual != set(found):
        raise ValueError('Prepared manifest does not cover the exact component inventory')
    return list(found.values())


def prepare(root, output):
    speech = root / 'src-tauri/speech'
    understanding = root / 'src-tauri/resources/understanding'
    speech_rows = verified_rows(speech, json.loads((speech / 'manifest.json').read_text(encoding='utf-8')))
    understanding_manifest = json.loads((understanding / 'manifest.json').read_text(encoding='utf-8'))
    understanding_rows = verified_rows(understanding, understanding_manifest['files'])
    pins = json.loads((root / 'scripts/voice-understanding-assets.json').read_text(encoding='utf-8'))
    model_pin = next(item for item in pins['assets'] if item['kind'] == 'model')
    model_row = next(item for item in understanding_rows if item['path'] == 'model.gguf')
    if (model_row['bytes'], model_row['sha256']) != (model_pin['bytes'], model_pin['sha256']):
        raise ValueError('Prepared model differs from the immutable model pin')
    if not re.fullmatch(r'https://huggingface\.co/[^/]+/[^/]+/resolve/[0-9a-f]{40}/[^?]+', model_pin['url']):
        raise ValueError('Model URL must pin an immutable Hugging Face revision')
    if not SMALL_SPEECH.issubset({row['path'] for row in speech_rows}):
        raise ValueError('Prepared small speech resources are incomplete')

    runtime = []
    sources = {}
    for prefix, directory, rows in [('speech', speech, speech_rows), ('understanding', understanding, understanding_rows)]:
        for row in rows:
            if prefix == 'speech' and row['path'] in SMALL_SPEECH:
                continue
            if prefix == 'understanding' and not row['path'].startswith('runtime/'):
                continue
            item = dict(row, path=prefix + '/' + row['path'])
            runtime.append(item)
            sources[item['path']] = directory.joinpath(*PurePosixPath(row['path']).parts)
    runtime.sort(key=lambda row: row['path'])
    if not runtime or not any(row['path'].startswith('understanding/runtime/') for row in runtime):
        raise ValueError('Offline engine component inventory is incomplete')

    output.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix='.runtime-', suffix='.zip', dir=output)
    os.close(fd)
    pending = Path(name)
    try:
        with zipfile.ZipFile(pending, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as archive:
            for row in runtime:
                info = zipfile.ZipInfo(row['path'], date_time=(2020, 1, 1, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.create_system = 3
                info.external_attr = 0o100644 << 16
                with sources[row['path']].open('rb') as source, archive.open(info, 'w', force_zip64=True) as target:
                    shutil.copyfileobj(source, target, 1024 * 1024)
        runtime_sha = digest(pending)
        asset_name = 'klipper-farm-runtime-' + runtime_sha + '.zip'
        asset_path = output / asset_name
        if pending.stat().st_size >= MAX_ASSET_BYTES:
            raise ValueError('Runtime component exceeds the GitHub release asset limit')
        if asset_path.exists():
            if digest(asset_path) != runtime_sha:
                raise ValueError('Existing content-addressed component differs')
            pending.unlink()
        else:
            pending.replace(asset_path)
    finally:
        pending.unlink(missing_ok=True)

    destination = root / 'src-tauri/resources/update-components'
    destination.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix='.update-components-', dir=destination.parent))
    try:
        for relative in sorted(SMALL_SPEECH | {'manifest.json'}):
            target = staging / 'speech' / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(speech / relative, target)
        manifest = {'schema': 1, 'runtime': {'name': asset_name, 'url': RUNTIME_BASE + asset_name,
                    'bytes': asset_path.stat().st_size, 'sha256': runtime_sha, 'files': runtime},
                    'model': dict(model_row, path='understanding/model.gguf', url=model_pin['url'], localName='model.gguf')}
        (staging / 'component-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8', newline='\n')
        if destination.exists():
            if destination.is_symlink():
                raise ValueError('Component output is a link')
            shutil.rmtree(destination)
        staging.replace(destination)
    finally:
        if staging.exists():
            shutil.rmtree(staging)
    report = {'schema': 1, 'assetPath': str(asset_path.resolve()), 'name': asset_name,
              'url': RUNTIME_BASE + asset_name, 'bytes': asset_path.stat().st_size, 'sha256': runtime_sha,
              'manifestPath': str((destination / 'component-manifest.json').resolve()),
              'modelPath': str((understanding / 'model.gguf').resolve()),
              'runtimeFileCount': len(runtime), 'runtimeUnpackedBytes': sum(row['bytes'] for row in runtime)}
    (output / 'component-build-report.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
    print(json.dumps(report))
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent.parent)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    prepare(args.root.resolve(), args.output or args.root / '.update-components')


if __name__ == '__main__':
    main()
