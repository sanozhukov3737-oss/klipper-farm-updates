import assert from 'node:assert/strict';
import {build} from 'esbuild';
import fs from 'node:fs';
const compiled=await build({stdin:{contents:"export {VoiceAssistant} from './src/lib/voiceAssistant';export {VoiceTaskQueue} from './src/lib/voiceTaskQueue';export {VoiceLearnedNames} from './src/lib/voiceLearnedNames';export {emptyFilamentInventory} from './src/lib/filamentInventory';export {profileForPreset} from './src/lib/printerProfile';",resolveDir:process.cwd(),loader:'ts'},bundle:true,write:false,format:'esm',platform:'node'});
const {VoiceAssistant,VoiceTaskQueue,VoiceLearnedNames,emptyFilamentInventory,profileForPreset}=await import('data:text/javascript;base64,'+Buffer.from(compiled.outputFiles[0].text).toString('base64'));
const results=[];const test=async(name,fn)=>{await fn();results.push({name,passed:true});console.log('PASS',name)};
const printer=(id='max',name='K1 Max',preset='creality-k1-max')=>({id,name,host:'192.168.1.'+(id==='max'?10:11),profile:profileForPreset(preset),status:{state:'ready',connectionState:'online'},webcams:[]});
const storage=()=>{const map=new Map();return{getItem:key=>map.get(key)??null,setItem:(key,value)=>map.set(key,value),removeItem:key=>map.delete(key)}};
function fixture({two=false,learningStorage=storage(),taskStorage=storage(),profile='user-a'}={}){
 const data={printers:[printer(),...(two?[printer('c','K1C','creality-k1c-2025')]:[])],clock:1_000_000,role:true,client:{},files:[{path:'детали/держатель.gcode',size:150}],filesByScope:{},list:[],validate:[],upload:0,start:0,hash:'a'.repeat(64),weight:25,inventory:emptyFilamentInventory()};
 data.inventory.spools=[{id:'spool',name:'PLA',material:'PLA',remainingWeight:750,initialWeight:1000,price:0,currency:'RUB',createdAt:1}];
 data.inventory.printers.max={binding:{spoolId:'spool'}};data.inventory.printers.c={binding:{spoolId:'spool'}};
 const learning=new VoiceLearnedNames(learningStorage,profile,()=>data.clock);
 const tasks=new VoiceTaskQueue(taskStorage,profile,()=>data.clock);
 const deps={printers:()=>data.printers,canOperate:()=>data.role,client:()=>data.client,now:()=>data.clock,learning,tasks,list:async scope=>{data.list.push(scope);return data.filesByScope[scope]??data.files},inventory:async()=>data.inventory,validate:async(p,c)=>{data.validate.push([p.id,c.scopeId,c.entry.path]);if(!(data.filesByScope[c.scopeId]??data.files).some(e=>e.path===c.entry.path))throw Error('Файл удалён');return{sha256:data.hash,report:{ok:true,issues:[],metadata:{filament_type:'PLA',filament_weight_total:data.weight}}}},ready:async()=>{},upload:async()=>{data.upload++;return 'держатель.gcode'},start:async()=>{data.start++},check:async()=>true,audit:async()=>{}};
 return{data,deps,tasks,taskStorage,learning,assistant:new VoiceAssistant(deps),learningStorage};
}
await test('missing filename keeps named printer and resumes from a bare title',async()=>{
 const f=fixture();const ask=await f.assistant.handle('K1 Max, поставь на печать');assert.equal(ask.clarification,'file');assert.equal(f.data.list.length,0);
 const selected=await f.assistant.handle('держатель');assert.equal(selected.proposal.candidate.printerId,'max');assert.equal(f.data.start,0);
 await f.assistant.handle('Подтверждаю печать');assert.equal(f.data.start,1);
});
await test('missing printer asks only its identity and accepts a current card name',async()=>{
 const f=fixture({two:true});const ask=await f.assistant.handle('Напечатай держатель');assert.equal(ask.clarification,'printer');assert.equal(ask.printerChoices.length,2);assert(!ask.proposal);
 const selected=await f.assistant.handle('K1C');assert.equal(selected.proposal.candidate.printerId,'c');assert.deepEqual(f.data.validate.at(-1).slice(0,2),['c','model:creality-k1c-2025']);assert.equal(f.data.upload,0);
});
await test('ordinal at printer clarification maps to displayed printer identities',async()=>{
 const f=fixture({two:true});await f.assistant.handle('Напечатай держатель');const reply=await f.assistant.handle('второй');assert.equal(reply.proposal.candidate.printerId,'c');assert.equal(f.data.start,0);
});
await test('target correction reloads the new model library and requires file choice',async()=>{
 const f=fixture({two:true});await f.assistant.handle('Напечатай держатель на K1 Max');const changed=await f.assistant.handle('Нет, лучше на K1C');assert(!changed.proposal);assert.equal(changed.choices.length,1);assert.equal(changed.choices[0].scopeId,'model:creality-k1c-2025');
 await f.assistant.handle('Подтверждаю печать');assert.equal(f.data.start,0);const chosen=await f.assistant.choose(changed.choices[0]);assert.equal(chosen.proposal.candidate.printerId,'c');
 await f.assistant.handle('Подтверждаю печать');assert.equal(f.data.start,1);
});
await test('target correction cannot reuse a file absent from the other model library',async()=>{
 const f=fixture({two:true});f.data.filesByScope['model:creality-k1c-2025']=[];await f.assistant.handle('Напечатай держатель на K1 Max');const r=await f.assistant.handle('Нет, лучше на K1C');assert(!r.proposal);assert.equal(r.choices.length,0);await f.assistant.handle('Подтверждаю печать');assert.equal(f.data.start,0);
});
await test('same-file reference retains a selected exact target without uploading',async()=>{
 const f=fixture({two:true});await f.assistant.handle('Напечатай держатель на K1 Max');const r=await f.assistant.handle('Напечатай этот файл');assert.equal(r.proposal.candidate.printerId,'max');assert.equal(f.data.start,0);
});
await test('file reference without history asks a specific question',async()=>{
 const f=fixture();const r=await f.assistant.handle('этот файл');assert.equal(r.clarification,'file');assert(!r.proposal);assert.equal(f.data.upload,0);
});
await test('ambiguous file reference never picks the first result',async()=>{
 const f=fixture();f.data.files=[{path:'держатель_левый.gcode',size:1},{path:'держатель_правый.gcode',size:1}];await f.assistant.handle('Найди держатель');const r=await f.assistant.handle('Напечатай этот файл');assert.equal(r.choices.length,2);assert(!r.proposal);await f.assistant.handle('Подтверждаю печать');assert.equal(f.data.start,0);
});
await test('other-printer request asks for an explicit alternative',async()=>{
 const f=fixture({two:true});await f.assistant.handle('Напечатай держатель на K1 Max');const r=await f.assistant.handle('На другом принтере');assert.equal(r.clarification,'printer');assert.deepEqual(r.printerChoices.map(p=>p.id),['c']);assert(!r.proposal);assert.equal(f.data.start,0);
});
await test('status followup remains a read-only printer question',async()=>{
 const f=fixture({two:true});f.data.printers[0].status.state='printing';await f.assistant.handle('Какие принтеры свободны?');const r=await f.assistant.handle('А на K1 Max?');assert.match(r.text,/K1 Max: печатает/);assert.equal(f.data.list.length,0);assert.equal(f.data.start,0);
});
await test('stock followup uses the referenced current printer',async()=>{
 const f=fixture({two:true});await f.assistant.handle('Сколько пластика на K1 Max?');const r=await f.assistant.handle('А на K1C?');assert.match(r.text,/^K1C:.*750/);assert.equal(f.data.list.length,0);assert.equal(f.data.start,0);
});
await test('forecast uses real file estimate and preserves unchanged separate confirmation',async()=>{
 const f=fixture();const first=await f.assistant.handle('Напечатай держатель на K1 Max'),inventory=JSON.stringify(f.data.inventory);const r=await f.assistant.handle('А сколько пластика останется после этой печати?');assert.match(r.text,/725 грамм/);assert.equal(r.proposal,first.proposal);assert.equal(r.proposal.expiresAt,first.proposal.expiresAt);assert.equal(JSON.stringify(f.data.inventory),inventory);assert.equal(f.data.start,0);
 await f.assistant.handle('Подтверждаю печать');assert.equal(f.data.start,1);
});
await test('implicit future stock question uses the selected file',async()=>{
 const f=fixture();await f.assistant.handle('Напечатай держатель на K1 Max');assert.match((await f.assistant.handle('А сколько пластика останется?')).text,/725 грамм/);assert.equal(f.data.start,0);
});
await test('changed file hash invalidates old confirmation after read-only forecast',async()=>{
 const f=fixture();await f.assistant.handle('Напечатай держатель на K1 Max');f.data.hash='b'.repeat(64);const r=await f.assistant.handle('Сколько пластика останется после этой печати?');assert(!r.proposal);await f.assistant.handle('Подтверждаю печать');assert.equal(f.data.upload,0);assert.equal(f.data.start,0);
});
await test('forecast without mass reports uncertainty instead of inventing a balance',async()=>{
 const f=fixture();f.data.weight=undefined;await f.assistant.handle('Напечатай держатель на K1 Max');const r=await f.assistant.handle('Сколько пластика останется после этой печати?');assert.match(r.text,/нет однозначной оценки/);assert(!/725/.test(r.text));assert.equal(f.data.start,0);
});
await test('forecast without file resumes a read-only selection dialogue',async()=>{
 const f=fixture();assert.equal((await f.assistant.handle('Сколько пластика останется после этой печати?')).clarification,'file');const found=await f.assistant.handle('держатель');assert.equal(found.choices.length,1);assert(!found.proposal);const r=await f.assistant.choose(found.choices[0]);assert.match(r.text,/725 грамм/);assert(!r.proposal);await f.assistant.handle('Подтверждаю печать');assert.equal(f.data.start,0);
});
await test('confirmed fuzzy filename correction persists and only returns live suggestions',async()=>{
 const f=fixture();f.data.files=[{path:'кронштейн.gcode',size:1}];const r=await f.assistant.handle('Найди конштейн');assert.equal(r.choices.length,1);assert.equal(f.learning.list().length,0);assert((await f.assistant.choose(r.choices[0])).learnedNameSaved);assert.equal(f.learning.list().length,1);
 const again=fixture({learningStorage:f.learningStorage});again.data.files=f.data.files;const learned=await again.assistant.handle('Напечатай конштейн на K1 Max');assert.equal(learned.choices[0].entry.path,'кронштейн.gcode');assert(!learned.proposal);await again.assistant.handle('Подтверждаю печать');assert.equal(again.data.start,0);
 again.data.files=[];assert.equal((await again.assistant.handle('Найди конштейн')).choices.length,0);
});
await test('plain new filename does not train an unrelated earlier failed query',async()=>{
 const f=fixture();await f.assistant.handle('Найди несуществующую модель');const r=await f.assistant.handle('держатель');await f.assistant.choose(r.choices[0]);assert(!f.learning.list().some(row=>row.query==='несуществующую модель'));
});
await test('explicit corrected title learns only after a deliberate file selection',async()=>{
 const f=fixture();await f.assistant.handle('Найди неразборчивое слово');const r=await f.assistant.handle('Правильно: держатель');assert.equal(f.learning.list().length,0);assert.equal(r.choices.length,1);assert((await f.assistant.choose(r.choices[0])).learnedNameSaved);assert(f.learning.list().some(row=>row.query==='неразборчивое слово'));
});
await test('conversation timeout and cancellation never reuse stale selection',async()=>{
 for(const cancel of [false,true]){const f=fixture();await f.assistant.handle('Напечатай держатель на K1 Max');if(cancel)await f.assistant.handle('Отмена');else f.data.clock+=240_001;const r=await f.assistant.handle('этот файл');assert(!r.proposal);assert.equal(r.clarification,'file');await f.assistant.handle('Подтверждаю печать');assert.equal(f.data.start,0);}
});
await test('deleted selected file and invalid printer identity cannot be confirmed',async()=>{
 const f=fixture();const r=await f.assistant.handle('Найди держатель');f.data.files=[];assert(!(await f.assistant.choose(r.choices[0])).proposal);await f.assistant.handle('Подтверждаю печать');assert.equal(f.data.start,0);
 const g=fixture({two:true});const ask=await g.assistant.handle('Напечатай держатель');g.data.printers=g.data.printers.filter(p=>p.id!==ask.printerChoices[1].id);assert(!(await g.assistant.choosePrinter(ask.printerChoices[1].id)).proposal);assert.equal(g.data.start,0);
});
await test('catalog hints use unique live scopes and stay bounded over many files',async()=>{
 const f=fixture({two:true});f.data.printers.push({...printer('max2','Второй Max')});f.data.files=Array.from({length:10_000},(_,i)=>({path:`детали/держатель_${i}.gcode`,size:1,modified:i}));const hints=await f.assistant.refreshSpeechHints();assert.equal(f.data.list.length,2);assert(hints.includes('K1 Max'));assert(hints.length<=16);assert(hints.join('').length<=512);assert(Buffer.byteLength(hints.join(''),'utf8')<=1024);assert(hints.every(s=>!s.includes('.gcode')&&!s.includes('/')));
});
await test('removed files and printer scopes disappear from refreshed speech hints',async()=>{
 const f=fixture({two:true});f.data.filesByScope['model:creality-k1c-2025']=[{path:'только_для_другой_модели.gcode',size:1}];assert((await f.assistant.refreshSpeechHints()).some(name=>name.includes('другой')));f.data.printers=f.data.printers.filter(p=>p.id==='max');f.data.files=[];const hints=await f.assistant.refreshSpeechHints();assert(!hints.some(name=>name.includes('другой')||name.includes('держатель')));
});
await test('inflight catalog result cannot restore closed conversation state',async()=>{
 const f=fixture();let resolve;f.deps.list=()=>new Promise(r=>resolve=r);const pending=f.assistant.refreshSpeechHints();f.assistant.dispose();resolve([{path:'закрытый_файл.gcode',size:1}]);assert.deepEqual(await pending,[]);assert.deepEqual(await f.assistant.refreshSpeechHints(),[]);
});
await test('printer replies are complete natural sentences for zero, one and multiple devices',async()=>{
 const f=fixture();assert.equal((await f.assistant.handle('Какие принтеры свободны?')).text,'Сейчас свободен один принтер: K1 Max.');
 f.data.printers[0].status.state='printing';assert.equal((await f.assistant.handle('Какие принтеры свободны?')).text,'Свободных принтеров сейчас нет.');
 assert.equal((await f.assistant.handle('Какие принтеры печатают?')).text,'Сейчас печатает: K1 Max.');
 f.data.printers.push(printer('second','Второй'));assert.equal((await f.assistant.handle('Какие принтеры свободны?')).text,'Сейчас свободен один принтер: Второй.');
 f.data.printers[0].status.state='ready';assert.equal((await f.assistant.handle('Какие принтеры свободны?')).text,'Сейчас свободны: K1 Max, Второй.');
 const all=(await f.assistant.handle('Какие принтеры?')).text;assert(!all.includes('Остальные: нет'));assert(all.includes('Сейчас ни один принтер не печатает.'));
});
await test('printer counts agree with Russian singular, plural and teen numbers',async()=>{
 const f=fixture();
 for(const [n,noun,single] of [[0,'принтеров',false],[1,'принтер',true],[2,'принтера',false],[5,'принтеров',false],[11,'принтеров',false],[21,'принтер',true],[24,'принтера',false]]){
   f.data.printers=Array.from({length:n},(_,i)=>printer('p'+i,'Принтер '+i));
   assert.equal((await f.assistant.handle('Сколько принтеров свободны?')).text,n?`Сейчас ${single?'свободен':'свободны'} ${n} ${noun}.`:'Свободных принтеров сейчас нет.');
   for(const p of f.data.printers)p.status.state='printing';
   assert.equal((await f.assistant.handle('Сколько принтеров печатают?')).text,n?`Сейчас ${single?'печатает':'печатают'} ${n} ${noun}.`:'Сейчас ни один принтер не печатает.');
   assert.equal((await f.assistant.handle('Сколько всего принтеров?')).text,n?`В ферме ${n} ${noun}.`:'В ферме пока нет принтеров.');
 }
});
await test('repeat without selected or confirmed history asks immediately and retains the named target',async()=>{
 const f=fixture({two:true});f.deps.interpret=()=>{throw Error('repeat must not need a model')};
 const r=await f.assistant.handle('Макс, поставь то же самое на печать');assert.equal(r.clarification,'file');assert.match(r.text,/Пока не знаю, какую печать повторить/);assert(!r.proposal);assert.equal(f.data.list.length,0);assert.equal(f.data.validate.length,0);
 // A model-enabled app retains the named target when a bare title answers this slot.
 f.deps.interpret=()=>({kind:'print',query:'держатель'});const named=await f.assistant.handle('держатель');assert.equal(named.proposal.candidate.printerId,'max');assert.equal(f.data.upload,0);assert.equal(f.data.start,0);
 const duplicate=fixture();duplicate.data.printers.push(printer('max2','Второй Макс'));duplicate.deps.interpret=()=>({kind:'print',query:'держатель'});
 await duplicate.assistant.handle('Макс поставь то же самое на печать');const ambiguous=await duplicate.assistant.handle('держатель');assert.equal(ambiguous.clarification,'printer');assert.equal(ambiguous.printerChoices.length,2);assert(!ambiguous.proposal);
});
await test('same-print request prepares the selected exact file with a fresh separate confirmation',async()=>{
 const f=fixture();f.deps.interpret=()=>{throw Error('repeat must not need a model')};
 const first=await f.assistant.handle('Напечатай держатель на K1 Max');f.data.clock+=1;
 const repeated=await f.assistant.handle('Макс, поставь тоже самое на печать');assert(repeated.proposal);assert.notEqual(repeated.proposal,first.proposal);assert.equal(repeated.proposal.candidate.entry.path,'детали/держатель.gcode');assert.equal(f.data.validate.length,2);assert.equal(f.data.upload,0);assert.equal(f.data.start,0);
 await f.assistant.handle('Подтверждаю печать');await f.assistant.handle('Подтверждаю печать');assert.equal(f.data.upload,1);assert.equal(f.data.start,1);
});
await test('same-print uses a new current selection while explicit last-print uses confirmed history',async()=>{
 const f=fixture();f.data.files.push({path:'корпус.gcode',size:1});
 await f.assistant.handle('Напечатай держатель на K1 Max');await f.assistant.handle('Подтверждаю печать');
 await f.assistant.handle('Напечатай корпус на K1 Max');assert.equal((await f.assistant.handle('Напечатай то же самое на Максе')).proposal.candidate.entry.path,'корпус.gcode');
 const last=await f.assistant.handle('Повтори последнюю печать на Максе');assert.equal(last.proposal.candidate.entry.path,'детали/держатель.gcode');assert.equal(f.data.start,1);
});
await test('confirmed repeat survives cancel and assistant recreation only within the current profile',async()=>{
 const f=fixture();await f.assistant.handle('Напечатай держатель на K1 Max');await f.assistant.handle('Подтверждаю печать');await f.assistant.handle('Отмена');
 assert((await f.assistant.handle('Макс поставь то же самое на печать')).proposal);f.assistant.dispose();
 const same=fixture({taskStorage:f.taskStorage});assert((await same.assistant.handle('Макс поставь то же самое на печать')).proposal);assert.equal(same.data.start,0);
 const other=fixture({taskStorage:f.taskStorage,profile:'other-profile'});const r=await other.assistant.handle('Макс поставь то же самое на печать');assert.equal(r.clarification,'file');assert(!r.proposal);assert.equal(other.data.list.length,0);
});
await test('cancelled preparation, search queries and ambiguous candidates never become print history',async()=>{
 for(const query of ['Напечатай держатель на K1 Max','Найди держатель','Найди неизвестный']){
   const f=fixture();await f.assistant.handle(query);await f.assistant.handle('Отмена');const r=await f.assistant.handle('Макс поставь то же самое на печать');assert.equal(r.clarification,'file',query);assert(!r.proposal);assert.equal(f.data.upload,0);assert.equal(f.data.start,0);
 }
 const f=fixture();f.data.files=[{path:'держатель_левый.gcode',size:1},{path:'держатель_правый.gcode',size:1}];await f.assistant.handle('Найди держатель');const before=f.data.validate.length;
 const r=await f.assistant.handle('Макс поставь то же самое на печать');assert.equal(r.clarification,'file');assert(!r.proposal);assert.equal(f.data.validate.length,before);assert.equal(f.data.start,0);
});
await test('repeat history ignores later failed and uncertain tasks and chooses the latest confirmed start',async()=>{
 const f=fixture();f.data.files.push({path:'корпус.gcode',size:1},{path:'куб.gcode',size:1});
 await f.assistant.handle('Напечатай держатель на K1 Max');await f.assistant.handle('Подтверждаю печать');f.data.clock++;
 await f.assistant.handle('Напечатай корпус на K1 Max');await f.assistant.handle('Подтверждаю печать');f.data.clock++;
 await f.assistant.handle('Напечатай куб на K1 Max');f.deps.upload=async()=>{throw Error('upload failed')};await f.assistant.handle('Подтверждаю печать');await f.assistant.handle('Отмена');
 assert.equal((await f.assistant.handle('Повтори последнюю печать на Максе')).proposal.candidate.entry.path,'корпус.gcode');assert.equal(f.data.start,2);
 const uncertain=fixture();await uncertain.assistant.handle('Напечатай держатель на K1 Max');uncertain.deps.start=async()=>{throw Error('transport lost')};await uncertain.assistant.handle('Подтверждаю печать');await uncertain.assistant.handle('Отмена');
 assert.equal(uncertain.tasks.list()[0].status,'needs-check');assert(!(await uncertain.assistant.handle('Макс поставь то же самое на печать')).proposal);
});
await test('repeat verifies the exact live file and refuses changed bytes or a deleted source',async()=>{
 for(const mutation of ['change','delete','similar']){
   const f=fixture();await f.assistant.handle('Напечатай держатель на K1 Max');
   if(mutation==='change')f.data.hash='b'.repeat(64);else f.data.files=mutation==='delete'?[]:[{path:'другая_папка/держатель.gcode',size:1}];
   const r=await f.assistant.handle('Макс поставь то же самое на печать');assert(!r.proposal,mutation);if(mutation==='change')assert.match(r.text,/изменилось/);
   await f.assistant.handle('Подтверждаю печать');assert.equal(f.data.upload,0);assert.equal(f.data.start,0);
 }
});
await test('cross-model repeat searches only the destination library and requires an explicit file choice',async()=>{
 const f=fixture({two:true});f.data.filesByScope['model:creality-k1c-2025']=[{path:'для_K1C/держатель.gcode',size:1}];
 await f.assistant.handle('Напечатай держатель на K1 Max');const before=f.data.validate.length;
 const r=await f.assistant.handle('K1C поставь то же самое на печать');assert.equal(r.clarification,'choice');assert(!r.proposal);assert.equal(r.choices.length,1);assert.equal(r.choices[0].scopeId,'model:creality-k1c-2025');assert.equal(f.data.validate.length,before);assert.equal(f.data.list.at(-1),'model:creality-k1c-2025');
 await f.assistant.handle('Подтверждаю печать');assert.equal(f.data.start,0);
 const chosen=await f.assistant.choose(r.choices[0]);assert.equal(chosen.proposal.candidate.entry.path,'для_K1C/держатель.gcode');assert.deepEqual(f.data.validate.at(-1),['c','model:creality-k1c-2025','для_K1C/держатель.gcode']);assert.equal(f.data.upload,0);
});
await test('cross-model repeat cannot substitute a source file or a merely similar destination title',async()=>{
 for(const files of [[],[{path:'держатель_другой.gcode',size:1}]]){
   const f=fixture({two:true});f.data.filesByScope['model:creality-k1c-2025']=files;await f.assistant.handle('Напечатай держатель на K1 Max');
   const r=await f.assistant.handle('K1C поставь то же самое на печать');assert(!r.proposal);assert.equal(r.choices.length,0);await f.assistant.handle('Подтверждаю печать');assert.equal(f.data.upload,0);assert.equal(f.data.start,0);
 }
});
await test('duplicate model names clarify and a bare printer answer retains the repeat hash without inference',async()=>{
 const f=fixture();f.data.printers.push(printer('max2','Второй Макс'));await f.assistant.handle('Напечатай держатель на принтере K1 Max');
 // Resolve the model alias ambiguity explicitly, then retain this exact selected file.
 if(!f.data.validate.length)await f.assistant.choosePrinter('max');
 let interpreted=0;f.deps.interpret=()=>{interpreted++;return{kind:'print',query:'держатель',printerId:'max2'}};
 const r=await f.assistant.handle('Макс поставь то же самое на печать');assert.equal(r.clarification,'printer');assert.equal(r.printerChoices.length,2);assert(!r.proposal);
 f.data.hash='b'.repeat(64);const answer=await f.assistant.handle('Второй Макс');assert(!answer.proposal);assert.match(answer.text,/изменилось/);assert.equal(interpreted,0);assert.equal(f.data.upload,0);assert.equal(f.data.start,0);
});
await test('repeat stays blocked for busy, offline and model-unconfirmed destinations',async()=>{
 for(const state of ['printing','offline','suspended','model-conflict']){
   const f=fixture();await f.assistant.handle('Напечатай держатель на K1 Max');
   if(state==='suspended')f.data.printers[0].status.remoteControlSuspended=true;else if(state==='offline')f.data.printers[0].status.connectionState='offline';else if(state==='model-conflict')f.data.printers[0].modelSelection={mode:'automatic',selectedPreset:'creality-k1-max',lastDetection:{decision:'conflict'}};else f.data.printers[0].status.state='printing';
   assert(!(await f.assistant.handle('Макс поставь то же самое на печать')).proposal);await f.assistant.handle('Подтверждаю печать');assert.equal(f.data.upload,0);assert.equal(f.data.start,0);
 }
});
await test('repeat creates one fresh print even when its source was a multi-launch plan',async()=>{
 const f=fixture();const found=await f.assistant.handle('Нужно три держателя');const plan=await f.assistant.choose(found.choices[0]);assert.equal(plan.plan.length,3);
 await f.assistant.prepareTask(plan.plan[0].id);await f.assistant.handle('Подтверждаю печать');await f.assistant.handle('Отмена');
 const repeated=await f.assistant.handle('Макс поставь то же самое на печать');assert(repeated.proposal);assert(!repeated.plan);assert.equal(f.tasks.list().length,3);
 await f.assistant.handle('Подтверждаю печать');assert.equal(f.tasks.list().length,4);assert.equal(f.tasks.list().filter(t=>t.status==='started').length,2);assert.equal(f.data.start,2);
});
if(process.env.KF_VOICE_CONVERSATION_PROOF)fs.writeFileSync(process.env.KF_VOICE_CONVERSATION_PROOF,JSON.stringify({passed:true,cases:results.length,results},null,2)+'\n');
console.log('Voice conversation:',results.length,'cases passed');
