import assert from 'node:assert/strict';
import {build} from 'esbuild';
const bundle=await build({stdin:{contents:"export * from './src/lib/voicePrinterForecast'; export {finishTime} from './src/lib/printerFinish';",resolveDir:process.cwd(),loader:'ts'},bundle:true,write:false,format:'esm',platform:'node'});
const {voicePrinterForecast:forecast,finishTime}=await import('data:text/javascript;base64,'+Buffer.from(bundle.outputFiles[0].text).toString('base64'));
const now=new Date(2026,9,31,12,0,0).getTime(),cases=[];
const printer=(name='K1 Max',status={})=>({id:name,name,host:'printer.invalid',webcams:[],status:{state:'printing',connectionState:'online',filename:'куб.gcode',progress:.5,printDuration:600,nozzle:200,nozzleTarget:200,bed:60,bedTarget:60,jobUpdatedAt:now,...status}});
const ready=name=>printer(name,{state:'ready',filename:undefined,progress:0,printDuration:0});
const test=(name,fn)=>{fn();cases.push({name,passed:true});console.log('PASS',name)};

test('an empty farm never invents jobs or a free printer',()=>{
 for(const request of [{mode:'finish'},{mode:'first'},{mode:'after',minutes:60}])assert.equal(forecast([],request,now),'В ферме пока нет принтеров.');
});
test('one live current print gives an explicitly approximate duration and local finish time',()=>{
 const text=forecast([printer()],{mode:'finish'},now);
 assert.match(text,/K1 Max: печать закончится примерно через 10 мин/);
 assert(text.includes('около '+finishTime(now+600_000,now)));
});
test('remaining time stays anchored to the observed sample instead of extending on each question',()=>{
 const p=printer();const text=forecast([p],{mode:'finish'},now+15_000);
 assert(text.includes('около '+finishTime(now+600_000,now)));
 assert(text.includes('примерно через 10 мин'));
});
test('a genuinely fresh idle printer is already free',()=>{
 assert.equal(forecast([ready('Макс')],{mode:'finish'},now),'Макс уже свободен.');
 assert.equal(forecast([ready('Макс')],{mode:'first'},now),'Макс уже свободен.');
});
test('retained live partial job telemetry is not reported as an idle printer',()=>{
 const text=forecast([printer('Макс',{state:'ready'})],{mode:'finish'},now);
 assert.match(text,/печать закончится примерно/);assert(!text.includes('уже свободен'));
});
test('offline, connecting and degraded printers never receive a finish promise',()=>{
 for(const status of [{connectionState:'offline'},{state:'offline'},{connectionState:'connecting'},{connectionState:'degraded'},{connectionState:undefined}]){
  const text=forecast([printer('Макс',status)],{mode:'finish'},now);assert.match(text,/связ/);assert(!text.includes('через'));
 }
});
test('paused and failed prints state why their finish is unknown',()=>{
 assert.match(forecast([printer('Макс',{state:'paused'})],{mode:'finish'},now),/на паузе/);
 assert.match(forecast([printer('Макс',{state:'error'})],{mode:'finish'},now),/ошибка печати/);
});
test('suspended remote control cannot be turned into a timed promise',()=>{
 const text=forecast([printer('Макс',{remoteControlSuspended:true})],{mode:'finish'},now);
 assert.match(text,/управление приостановлено/);assert(!text.includes('через'));
});
test('stale and missing samples do not report a cached ready or printing state as current',()=>{
 for(const state of ['ready','printing'])for(const jobUpdatedAt of [undefined,now-20_001,now-120_001,NaN,Infinity,now+1001]){
  const text=forecast([printer('Макс',{state,jobUpdatedAt})],{mode:'finish'},now);
  assert.match(text,/свежих данных/);assert(!text.includes('уже свободен'));assert(!text.includes('через'));
 }
});
test('warmup, insufficient progress and invalid readings remain unestimated',()=>{
 for(const patch of [{progress:0},{progress:.01},{printDuration:29},{progress:NaN},{printDuration:NaN},{progress:1},{progress:.02,printDuration:1_000_000}]){
  const text=forecast([printer('Макс',patch)],{mode:'finish'},now);assert.match(text,/пока рассчитывается/);assert(!text.includes('через'));
 }
});
test('earliest current estimate is selected across several live jobs',()=>{
 const text=forecast([printer('Долго',{printDuration:1200}),printer('Быстро',{printDuration:300})],{mode:'first'},now);
 assert.match(text,/раньше закончит Быстро: примерно через 5 мин/);assert(!text.includes('раньше закончит Долго'));
});
test('equal finish estimates are spoken as a tie rather than an arbitrary winner',()=>{
 const text=forecast([printer('Макс'),printer('K1C')],{mode:'first'},now);
 assert.match(text,/примерно одновременно закончат: Макс, K1C/);assert(!text.includes('раньше закончит'));
});
test('a known earliest estimate is scoped when another printer has unknown timing',()=>{
 const text=forecast([printer('Макс'),printer('K1C',{state:'paused'}),printer('Эндер',{connectionState:'offline'})],{mode:'first'},now);
 assert.match(text,/Среди принтеров с известным прогнозом раньше закончит Макс/);
 assert.match(text,/K1C: печать на паузе/);assert.match(text,/Эндер: нет подтверждённой связи/);
});
test('an already free printer is named separately from the next finishing active job',()=>{
 const text=forecast([ready('Свободный'),printer('Печатающий')],{mode:'first'},now);
 assert.match(text,/Свободный уже свободен/);assert.match(text,/Из занятых принтеров раньше закончит Печатающий/);
});
test('an entirely uncertain farm never claims that nobody is printing',()=>{
 const text=forecast([printer('Макс',{jobUpdatedAt:undefined}),printer('K1C',{state:'paused'})],{mode:'first'},now);
 assert.match(text,/Пока не могу определить, кто освободится первым/);assert.match(text,/свежих данных/);assert.match(text,/на паузе/);
});
test('after-time questions name only current prints whose projection extends past the horizon',()=>{
 const text=forecast([printer('Короткий',{printDuration:300}),printer('Длинный',{printDuration:7200}),ready('Свободный')],{mode:'after',minutes:60},now);
 assert.match(text,/через 1 ч ещё будет печатать Длинный/);assert(!text.includes('Короткий'));assert(!text.includes('Свободный'));
 assert.match(text,/Новые задания в этот прогноз не входят/);
});
test('a current job ending exactly at the horizon is not counted as still printing',()=>{
 const text=forecast([printer()],{mode:'after',minutes:10},now);
 assert.match(text,/текущие задания с известным временем закончатся/);assert(!text.includes('ещё будет печатать'));
});
test('after-time uncertainty is named even if every known job would finish',()=>{
 const text=forecast([printer('Макс'),printer('K1C',{state:'paused'})],{mode:'after',minutes:60},now);
 assert.match(text,/с известным временем/);assert.match(text,/K1C: печать на паузе/);assert(!text.includes('все принтеры свободны'));
});
test('the current all-idle farm does not promise that no new job will be started later',()=>{
 const text=forecast([ready('Макс'),ready('K1C')],{mode:'after',minutes:60},now);
 assert.match(text,/Сейчас все принтеры свободны/);assert.match(text,/Новые задания в этот прогноз не входят/);
});
test('crossing midnight uses the shared tomorrow-aware clock formatter',()=>{
 const late=new Date(2026,9,31,23,50,0).getTime();
 const p=printer('Макс',{jobUpdatedAt:late,printDuration:1200});
 const text=forecast([p],{mode:'finish'},late);assert.match(text,/завтра около/);assert(!text.includes('около завтра'));
});
test('invalid or unbounded horizons and invalid clocks return a concrete clarification',()=>{
 for(const minutes of [undefined,0,-1,10081,NaN,Infinity,1.5,'60'])assert.match(forecast([printer()],{mode:'after',minutes},now),/от 1 минуты до 7 суток/);
 assert(!forecast([printer()],{mode:'after',minutes:10080},now).includes('от 1 минуты'));
 assert.match(forecast([printer()],{mode:'other'},now),/Уточни/);
 assert.match(forecast([printer()],{mode:'finish'},Infinity),/не могу надёжно/);
});
test('forecast reads new state each time and never mutates input telemetry',()=>{
 const p=printer('Макс');const before=structuredClone(p);Object.freeze(p.status);Object.freeze(p);
 assert.match(forecast([p],{mode:'finish'},now),/печать закончится/);assert.deepEqual(p,before);
 const changed={...p,status:{...p.status,state:'paused'}};assert.match(forecast([changed],{mode:'finish'},now),/на паузе/);
});

console.log('Voice printer forecast:',cases.length,'cases passed');
