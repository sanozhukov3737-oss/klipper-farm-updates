"""Prepare pinned local understanding assets before building; never run in the app.

Windows builds need CMake and Visual Studio 2022 C++ tools. --offline requires
verified cached inputs. The installed application needs no compiler, DLL runtime,
model downloads, external network service, or Python for understanding.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import struct
import subprocess
import sys
import tarfile
import tempfile
import time
import urllib.request
from pathlib import Path, PurePosixPath

CHUNK = 1024 * 1024
SYSTEM_IMPORTS = {'kernel32.dll', 'advapi32.dll', 'shell32.dll', 'ws2_32.dll',
                  'crypt32.dll', 'psapi.dll', 'user32.dll', 'ole32.dll',
                  'bcrypt.dll', 'ntdll.dll', 'userenv.dll'}


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open('rb') as stream:
        while data := stream.read(CHUNK):
            value.update(data)
    return value.hexdigest()


def safe_path(name: str) -> PurePosixPath:
    path = PurePosixPath(name)
    if (not name or not path.parts or path.is_absolute() or '\\' in name or '\x00' in name
            or '..' in path.parts or any(':' in part for part in path.parts)
            or any(part.endswith((' ', '.')) for part in path.parts)):
        raise ValueError('Unsafe understanding asset path: ' + repr(name))
    return path


def matches(path: Path, expected: dict) -> bool:
    return (not path.is_symlink() and path.is_file()
            and path.stat().st_size == expected['bytes']
            and digest(path) == expected['sha256'])


def download(item: dict, cache: Path, offline: bool) -> Path:
    name = safe_path(item['name'])
    if len(name.parts) != 1:
        raise ValueError('Cache asset names must be flat')
    target = cache / name.name
    if matches(target, item):
        return target
    if offline:
        raise ValueError('Missing verified offline asset: ' + item['name'])
    if not item['url'].startswith('https://'):
        raise ValueError('Understanding downloads require HTTPS')
    pending = cache / (name.name + '.part')
    # Never follow an old link or reuse an incomplete response.
    pending.unlink(missing_ok=True)
    started = time.monotonic()
    expected, count, value = item['bytes'], 0, hashlib.sha256()
    try:
        request = urllib.request.Request(item['url'], headers={'User-Agent': 'KlipperFarm-Build-Assets/1'})
        with urllib.request.urlopen(request, timeout=120) as response, pending.open('xb') as output:
            if not response.url.startswith('https://'):
                raise ValueError('Asset download redirected away from HTTPS')
            length = response.headers.get('Content-Length')
            if length is not None and int(length) != expected:
                raise ValueError('Asset Content-Length differs: ' + item['name'])
            while data := response.read(min(CHUNK, expected - count + 1)):
                count += len(data)
                if count > expected or time.monotonic() - started > 1800:
                    raise ValueError('Asset exceeded download bound: ' + item['name'])
                value.update(data)
                output.write(data)
        if count != expected or value.hexdigest() != item['sha256']:
            raise ValueError('Asset length or SHA256 differs: ' + item['name'])
        pending.replace(target)
    finally:
        pending.unlink(missing_ok=True)
    return target


def extract_source(archive_path: Path, destination: Path, revision: str) -> None:
    """Extract regular source files only; never trust tar links or absolute names."""
    with tarfile.open(archive_path, 'r:gz') as archive:
        seen, total, entries = set(), 0, []
        for entry in archive:
            parts = safe_path(entry.name).parts
            if parts[0] != 'llama.cpp-' + revision or not (entry.isfile() or entry.isdir()):
                raise ValueError('Unsafe runtime source archive entry')
            relative = PurePosixPath(*parts[1:])
            key = str(relative).casefold()
            if key in seen:
                raise ValueError('Duplicate runtime source archive entry')
            seen.add(key)
            total += entry.size
            if entry.size > 64 * CHUNK or total > 512 * CHUNK or len(seen) > 12000:
                raise ValueError('Runtime source archive exceeds extraction bounds')
            entries.append((entry, relative))
        for entry, relative in entries:
            target = destination.joinpath(*relative.parts)
            if entry.isdir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            count = 0
            with archive.extractfile(entry) as source, target.open('xb') as output:
                while data := source.read(min(CHUNK, entry.size - count + 1)):
                    count += len(data)
                    if count > entry.size:
                        raise ValueError('Runtime source extraction exceeded bound')
                    output.write(data)
            if count != entry.size:
                raise ValueError('Incomplete runtime source archive entry')


def pe_imports(binary: bytes) -> list[str]:
    """Read the PE import names without executing Windows binaries or extra tools."""
    if len(binary) < 64 or binary[:2] != b'MZ':
        raise ValueError('Runtime file is not a Windows PE binary')
    pe = struct.unpack_from('<I', binary, 60)[0]
    if pe + 24 > len(binary) or binary[pe:pe + 4] != b'PE\0\0':
        raise ValueError('Invalid Windows PE header')
    machine, sections = struct.unpack_from('<HH', binary, pe + 4)
    optional_bytes = struct.unpack_from('<H', binary, pe + 20)[0]
    optional = pe + 24
    if machine != 0x8664 or struct.unpack_from('<H', binary, optional)[0] != 0x20b:
        raise ValueError('Understanding runtime must be Windows x64 PE32+')
    section_table = optional + optional_bytes
    if sections > 128 or section_table + sections * 40 > len(binary):
        raise ValueError('Invalid Windows PE sections')
    def offset(rva: int) -> int:
        for index in range(sections):
            virtual_size, address, raw_size, raw_offset = struct.unpack_from('<IIII', binary, section_table + index * 40 + 8)
            if address <= rva < address + max(virtual_size, raw_size):
                result = raw_offset + rva - address
                if result >= len(binary):
                    break
                return result
        raise ValueError('Unmapped Windows PE address')
    import_rva, import_size = struct.unpack_from('<II', binary, optional + 112 + 8)
    if not import_rva:
        return []
    table, imports = offset(import_rva), []
    for index in range(min(import_size // 20, 256)):
        descriptor = struct.unpack_from('<IIIII', binary, table + index * 20)
        if not any(descriptor):
            return imports
        start = offset(descriptor[3])
        end = binary.find(b'\0', start, start + 256)
        if end < 0:
            raise ValueError('Unterminated Windows PE import')
        name = binary[start:end].decode('ascii').lower()
        if not re.fullmatch(r'[a-z0-9_.-]+\.dll', name):
            raise ValueError('Unsafe Windows PE import')
        imports.append(name)
    raise ValueError('Unterminated Windows PE import table')


def verify_standalone(executable: Path) -> list[str]:
    if executable.stat().st_size > 64 * CHUNK:
        raise ValueError('Understanding executable exceeds size bound')
    imports = pe_imports(executable.read_bytes())
    for dependency in imports:
        if dependency.startswith('api-ms-win-crt-') or (dependency not in SYSTEM_IMPORTS and not dependency.startswith('api-ms-win-')):
            raise ValueError('Understanding runtime is not standalone: ' + dependency)
    return imports


def build_runtimes(pins: dict, inputs: dict, cache: Path) -> tuple[Path, dict]:
    if sys.platform != 'win32':
        raise ValueError('Static Windows understanding runtime must be built on Windows with Visual Studio 2022')
    source_pin = next(item for item in pins['assets'] if item['kind'] == 'runtime-source')
    recipe = {'source': source_pin, 'runtime': pins['runtime'], 'build': pins['build']}
    recipe_hash = hashlib.sha256(json.dumps(recipe, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    result_dir = cache / ('runtime-' + recipe_hash)
    report_path = result_dir / 'build-provenance.json'
    if report_path.is_file() and not result_dir.is_symlink():
        report = json.loads(report_path.read_text(encoding='utf-8'))
        expected_names = {item['fileName'] for variant in pins['build']['variants'] for item in variant['executables']}
        if (report.get('recipeSha256') == recipe_hash
                and {row['path'] for row in report.get('files', [])} == expected_names
                and all(matches(result_dir / row['path'], row) for row in report['files'])):
            if len(report['files']) == len(expected_names):
                for row in report['files']:
                    if verify_standalone(result_dir / row['path']) != row['imports']:
                        raise ValueError('Cached executable import table changed')
                return result_dir, report
    work = Path(tempfile.mkdtemp(prefix='llama-static-', dir=cache))
    try:
        source = work / 'source'
        source.mkdir()
        extract_source(inputs['runtime-source'], source, pins['runtime']['revision'])
        if digest(source / 'LICENSE') != next(item['sha256'] for item in pins['assets'] if item['kind'] == 'runtime-license'):
            raise ValueError('Runtime source LICENSE differs from the pinned copy')
        output = work / 'result'
        output.mkdir()
        files, toolchains = [], []
        for variant in pins['build']['variants']:
            build = work / variant['name']
            options = pins['build']['cmakeOptions'] + variant['cmakeOptions']
            command = ['cmake', '-S', str(source), '-B', str(build), '-G', 'Visual Studio 17 2022', '-A', 'x64']
            subprocess.run(command + options, check=True, timeout=180)
            subprocess.run(['cmake', '--build', str(build), '--config', 'Release', '--target',
                            *[item['target'] for item in variant['executables']],
                            '--parallel', str(min(os.cpu_count() or 2, 4))], check=True, timeout=1500)
            for item in variant['executables']:
                binary = build / 'bin' / 'Release' / (item['target'] + '.exe')
                imports = verify_standalone(binary)
                # The prepared cache contains exactly four reviewed executables.
                target = output / item['fileName']
                shutil.copyfile(binary, target)
                files.append({'path': target.name, 'bytes': target.stat().st_size, 'sha256': digest(target), 'imports': imports})
            cmake_cache = (build / 'CMakeCache.txt').read_text(encoding='utf-8')
            toolchains.append({'variant': variant['name'], 'cacheEntries': [line for line in cmake_cache.splitlines()
                if re.match(r'CMAKE_(C|CXX)_COMPILER[:_]|CMAKE_GENERATOR[:_]|CMAKE_MSVC_RUNTIME_LIBRARY:', line)]})
        report = {'schema': 1, 'recipeSha256': recipe_hash, 'source': source_pin,
                  'runtime': pins['runtime'], 'build': pins['build'], 'toolchains': toolchains, 'files': files}
        report['genericVersionOutputs'] = {}
        for name in ('llama-completion.exe', 'llama-server.exe'):
            version = subprocess.run([str(output / name), '--version'], check=True,
                                     capture_output=True, text=True, encoding='utf-8', timeout=30)
            report['genericVersionOutputs'][name] = (version.stdout + version.stderr)[:8192]
        (output / 'build-provenance.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
        if result_dir.exists():
            shutil.rmtree(result_dir)
        output.replace(result_dir)
        return result_dir, report
    finally:
        shutil.rmtree(work)


def copy_source_notices(source_archive: Path, destination: Path, revision: str) -> None:
    with tarfile.open(source_archive, 'r:gz') as archive:
        for entry in archive:
            if not entry.isfile():
                continue
            parts = safe_path(entry.name).parts
            if parts[0] != 'llama.cpp-' + revision:
                raise ValueError('Runtime source notice has wrong root')
            relative = PurePosixPath(*parts[1:])
            name = relative.as_posix()
            legal = (name.startswith(('licenses/', 'vendor/'))
                     and re.search(r'(^|/)(LICENSE|COPYING|NOTICE)([._-]|$)', name, re.I))
            legal = legal or name == 'vendor/sheredom/subprocess.h'
            header_license = name in ('vendor/miniaudio/miniaudio.h', 'vendor/stb/stb_image.h')
            if header_license:
                if entry.size > 8 * CHUNK:
                    raise ValueError('Runtime source header exceeds notice extraction bound')
                with archive.extractfile(entry) as source:
                    data = source.read(entry.size + 1)
                if len(data) != entry.size:
                    raise ValueError('Runtime source header length differs')
                comment = data[data.rfind(b'\n/*'):].strip()
                if not comment.endswith(b'*/') or b'ALTERNATIVE' not in comment or b'THE SOFTWARE' not in comment:
                    raise ValueError('Runtime header license comment changed')
                target = destination.joinpath('source-notices', *relative.parent.parts, 'LICENSE-from-header.txt')
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(comment + b'\n')
            if legal:
                target = destination.joinpath('source-notices', *relative.parts)
                target.parent.mkdir(parents=True, exist_ok=True)
                if entry.size > 2 * CHUNK:
                    raise ValueError('Runtime source notice exceeds bound')
                with archive.extractfile(entry) as source, target.open('xb') as output:
                    data = source.read(entry.size + 1)
                    if len(data) != entry.size:
                        raise ValueError('Runtime source notice length differs')
                    output.write(data)


def prepare(root: Path, cache: Path, offline: bool, pins_path: Path, runtime_only: bool = False,
            model_sidecar: bool = False) -> dict:
    pins_bytes = pins_path.read_bytes()
    pins = json.loads(pins_bytes)
    cache.mkdir(parents=True, exist_ok=True)
    if pins['schema'] != 1:
        raise ValueError('Unsupported understanding asset pin schema')
    if len({item['kind'] for item in pins['assets']}) != len(pins['assets']):
        raise ValueError('Duplicate understanding asset kinds')
    if {item['kind'] for item in pins['assets']} != {'model', 'runtime-source', 'model-license', 'runtime-license'}:
        raise ValueError('Incomplete understanding asset pins')
    inputs = {item['kind']: download(item, cache, offline) for item in pins['assets'] if item['kind'].startswith('runtime-')}
    runtime_dir, runtime_report = build_runtimes(pins, inputs, cache)
    if runtime_only:
        print('Verified static CPU runtimes:', runtime_dir)
        return runtime_report
    inputs.update({item['kind']: download(item, cache, offline) for item in pins['assets'] if not item['kind'].startswith('runtime-')})
    destination = root / 'src-tauri' / 'resources' / 'understanding'
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.is_symlink():
        raise ValueError('Understanding destination must not be a symbolic link')
    staging = Path(tempfile.mkdtemp(prefix='.understanding-', dir=destination.parent))
    backup = destination.with_name('.understanding-previous')
    try:
        (staging / 'runtime').mkdir()
        (staging / 'licenses').mkdir()
        for row in runtime_report['files']:
            shutil.copyfile(runtime_dir / row['path'], staging / 'runtime' / row['path'])
        for kind, name in [('model-license', 'model-LICENSE.txt'), ('runtime-license', 'llama.cpp-MIT.txt')]:
            shutil.copyfile(inputs[kind], staging / 'licenses' / name)
        copy_source_notices(inputs['runtime-source'], staging / 'licenses', pins['runtime']['revision'])
        shutil.copyfile(inputs['model'], staging / 'model.gguf')
        with (staging / 'model.gguf').open('rb') as model:
            if model.read(4) != b'GGUF':
                raise ValueError('Pinned understanding model is not GGUF')
        model_info = pins['model']
        notice = ('Offline command understanding for Klipper Farm\n\n'
                  + 'Original model: ' + model_info['baseRepository'] + ' at ' + model_info['baseRevision'] + '\n'
                  + 'GGUF quantization producer: ' + model_info['producer'] + '\n'
                  + model_info['repository'] + ' at ' + model_info['revision'] + '\n'
                  + 'Artifact: ' + model_info['fileName'] + ' (' + model_info['quantization'] + ')\n'
                  + 'The packaged GGUF is an unmodified copy of that quantized artifact, derived from the original model.\n'
                  + 'Model license: ' + model_info['license'] + '. See licenses/model-LICENSE.txt.\n'
                  + 'llama.cpp ' + pins['runtime']['release'] + ' (' + pins['runtime']['revision'] + ')\n'
                  + 'Runtime: MIT. See licenses/llama.cpp-MIT.txt.\n'
                  + 'Third-party source notices: licenses/source-notices/.\n'
                  + 'Both generic x64 and AVX2 CPU executables use a statically linked Microsoft CRT.\n'
                  + 'No external VC++ runtime, OpenMP, RPC or GPU binaries are included.\n'
                  + 'Completion and server helpers are packaged for generic x64 and AVX2 CPUs.\n'
                  + 'The desktop starts its persistent helper on authenticated loopback only.\n'
                  + 'All downloads occur at build time. Inference uses --offline and packaged local files.\n')
        (staging / 'NOTICE.txt').write_text(notice, encoding='utf-8', newline='\n')
        files = [{'path': path.relative_to(staging).as_posix(), 'bytes': path.stat().st_size, 'sha256': digest(path)}
                 for path in sorted(staging.rglob('*')) if path.is_file()]
        model_pin = next(item for item in pins['assets'] if item['kind'] == 'model')
        packaging = {'modelDelivery': 'sidecar' if model_sidecar or model_pin['bytes'] >= 2 * 1024**3 else 'bundle',
                     'preparedModelPath': 'model.gguf', 'installedModelPath': 'understanding/model.gguf',
                     'modelBytes': model_pin['bytes'], 'modelSha256': model_pin['sha256'],
                     'excludeModelFromInstallerResources': model_sidecar or model_pin['bytes'] >= 2 * 1024**3}
        report = {'schema': 1, 'pinsSha256': hashlib.sha256(pins_bytes).hexdigest(),
                  'model': pins['model'], 'runtime': pins['runtime'], 'runtimeBuild': runtime_report,
                  'packaging': packaging, 'files': files}
        (staging / 'manifest.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
        if backup.exists():
            raise ValueError('Previous understanding backup exists; inspect it before retrying')
        if destination.exists():
            destination.replace(backup)
        try:
            staging.replace(destination)
        except BaseException:
            if backup.exists():
                backup.replace(destination)
            raise
        if backup.exists():
            shutil.rmtree(backup)
        print('Prepared', len(files), 'verified offline understanding files')
        return report
    finally:
        if staging.exists():
            shutil.rmtree(staging)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent.parent)
    parser.add_argument('--cache', type=Path)
    parser.add_argument('--offline', action='store_true')
    parser.add_argument('--runtime-only', action='store_true', help='Build/cache all four static executables before preparing the model')
    parser.add_argument('--model-sidecar', action='store_true', help='Record sidecar delivery; automatic for models at or above the NSIS 2 GiB limit')
    args = parser.parse_args()
    root = args.root.resolve()
    prepare(root, (args.cache or root / '.understanding-downloads').resolve(), args.offline,
            Path(__file__).with_name('voice-understanding-assets.json'), args.runtime_only, args.model_sidecar)


if __name__ == '__main__':
    main()
