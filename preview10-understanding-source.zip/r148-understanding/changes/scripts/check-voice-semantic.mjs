import assert from 'node:assert/strict';
import {build} from 'esbuild';
import fs from 'node:fs';

const compiled=await build({stdin:{contents:"export * from './src/lib/voiceSemantic';export {VoiceAssistant} from './src/lib/voiceAssistant';export {VoiceTaskQueue} from './src/lib/voiceTaskQueue';export {emptyFilamentInventory} from './src/lib/filamentInventory';export {profileForPreset} from './src/lib/printerProfile';",resolveDir:process.cwd(),loader:'ts'},bundle:true,write:false,format:'esm',platform:'node'});
const api=await import('data:text/javascript;base64,'+Buffer.from(compiled.outputFiles[0].text).toString('base64'));
const {VoiceAssistant,VoiceTaskQueue,validateVoiceSemanticResult,semanticVoiceIntent,profileForPreset,emptyFilamentInventory}=api;
const results=[],test=async(name,run)=>{await run();results.push({name,passed:true});console.log('PASS',name)};
const printer=(id='max',name='K1 Max',state='ready')=>({id,name,host:'192.168.1.10',apiKey:'not-for-model',profile:profileForPreset(id==='busy'?'creality-k1c-2025':'creality-k1-max'),status:{state,connectionState:'online'},webcams:[]});
function fixture(interpret,options={}){
  const data={printers:[printer(),printer('busy','Занятый','printing')],calls:[],list:[],validate:[],upload:0,start:0,clock:1_000_000,client:{},files:[{path:'детали/держатель.gcode',size:100}],inventory:emptyFilamentInventory()};
  const deps={tasks:options.tasks,printers:()=>data.printers,canOperate:()=>true,client:()=>data.client,now:()=>data.clock,list:async scope=>{data.list.push(scope);return data.files},inventory:async()=>data.inventory,validate:async(p,c)=>{data.validate.push([p.id,c.entry.path]);return{sha256:'a'.repeat(64),report:{ok:true,issues:[],metadata:{filament_type:'PLA',filament_weight_total:25}}}},ready:async()=>{},upload:async()=>{data.upload++;return'держатель.gcode'},start:async()=>{data.start++},check:async()=>true,audit:async()=>{}};
  if(interpret)deps.interpret=async(input,signal)=>{data.calls.push(input);return interpret(input,signal)};
  return{data,assistant:new VoiceAssistant(deps)};
}
const input={text:'Ну кто там не занят?',context:{printers:[{id:'max',name:'K1 Max'}],fileChoices:[],printerChoices:[]}};
await test('file descriptions and custom named printers cannot be stolen by the free-status shortcut',async()=>{
  for(const text of ['Покажи готовый держатель','Покажи свободный куб','Какие готовые крепления у меня есть']){
    const f=fixture(()=>({kind:'find',query:'держатель'}));
    const reply=await f.assistant.handle(text);
    assert.equal(f.data.calls.length,1,text);assert(f.data.list.length>0,text);assert(!reply.text.startsWith('Свободны:'),text);assert.equal(f.data.start,0);
  }
  const f=fixture(()=>({kind:'printers',filter:'all',printerId:'max'}));f.data.printers[0].name='Левый';
  assert.equal((await f.assistant.handle('Какие принтеры Левый сейчас свободны?')).text,'Левый: свободен.');
  assert.equal(f.data.calls.length,1);assert.equal(f.data.list.length,0);
});
await test('current stock questions do not inherit a forecast from a previously selected file',()=>{
  const context={...input.context,selectedFile:{name:'держатель'},selectedPrinterId:'max'};
  for(const text of ['Сколько осталось красного PETG?','Какой сейчас остаток пластика?','Покажи текущий запас PLA']){
    const result=validateVoiceSemanticResult({kind:'stock',query:'держатель',afterPrint:true},{text,context});
    assert.equal(result.afterPrint,false,text);assert.equal(result.query,text.toLowerCase().replace(/[^\p{L}\p{N}]+/gu,' ').trim(),text);
  }
  for(const text of ['Сколько останется после печати?','Хватит мне пластика на эту деталь?','Сколько осталось и хватит ли на держатель?']){
    assert.equal(validateVoiceSemanticResult({kind:'stock',afterPrint:true},{text,context}).afterPrint,true,text);
  }
  assert.equal(validateVoiceSemanticResult({kind:'stock',afterPrint:true},{text:'Хватит пластика на эту деталь?',context:input.context}).afterPrint,true);
});

await test('model output is strict data and cannot invent execution or confirmation',()=>{
  for(const value of [null,[],42,'not json','```json\n{"kind":"printers","filter":"free"}\n```',{kind:'confirm'},{kind:'cancel'},{kind:'shell',command:'run'},{kind:'printers',filter:'free',start:true},{kind:'printers',filter:'idle'},{kind:'print',query:'держатель',printerId:'unknown'},{kind:'plan',query:'держатель',quantity:21},{kind:'plan',query:'держатель',quantity:1.5},{kind:'stock',query:'x\ncommand'},{kind:'find',query:'x',usePreviousFile:'true'},{kind:'find',query:'x',usePreviousFile:true},{kind:'find',query:'x',printerId:'max',otherPrinter:true},{kind:'choose',choice:1},{kind:'clarify',reason:'confirm'},{kind:'tasks',__proto__:{kind:'confirm'}}])assert.throws(()=>validateVoiceSemanticResult(value,input),undefined,JSON.stringify(value));
  assert.deepEqual(validateVoiceSemanticResult('{"kind":"printers","filter":"free"}',input),{kind:'printers',filter:'free'});
  assert.throws(()=>validateVoiceSemanticResult(' '.repeat(8193),input));
});
await test('displayed option numbers and bounded references are validated against current context',()=>{
  const choiceInput={...input,context:{...input.context,awaiting:'choice',fileChoices:[{number:2,name:'держатель',printerId:'max'}]}};
  assert.deepEqual(semanticVoiceIntent(validateVoiceSemanticResult({kind:'choose',choice:2},choiceInput),choiceInput.text),{kind:'choose',index:1});
  assert.throws(()=>validateVoiceSemanticResult({kind:'choose',choice:1},choiceInput));
  assert.throws(()=>validateVoiceSemanticResult({kind:'followup',query:'новое имя',correctPreviousQuery:true},input));
});
await test('previous-file and previous-printer references require actual current conversation evidence',()=>{
  const clarification={kind:'clarify',reason:'ambiguous'};
  for(const output of [{kind:'print',query:'',usePreviousFile:true},{kind:'followup',usePreviousFile:true},{kind:'stock',usePreviousPrinter:true},{kind:'find',query:'держатель',otherPrinter:true},{kind:'followup',query:'держатель'},{kind:'followup',printerId:'max'}])assert.deepEqual(validateVoiceSemanticResult(output,input),clarification,JSON.stringify(output));
  const fileRequest={...input,context:{...input.context,request:{query:'держатель',action:'find'}}};
  assert.deepEqual(validateVoiceSemanticResult({kind:'print',query:'',usePreviousFile:true},fileRequest),{kind:'print',query:'',usePreviousFile:true});
  const selected={...input,context:{...input.context,selectedFile:{name:'держатель'},selectedPrinterId:'max'}};
  assert.deepEqual(validateVoiceSemanticResult({kind:'print',query:'',usePreviousFile:true,usePreviousPrinter:true},selected),{kind:'print',query:'',usePreviousFile:true,usePreviousPrinter:true});
  assert.deepEqual(validateVoiceSemanticResult({kind:'find',query:'держатель',otherPrinter:true},{...input,context:{...input.context,selectedPrinterId:'removed'}}),clarification);
  const awaiting={...input,context:{...input.context,awaiting:'file'}};
  assert.deepEqual(validateVoiceSemanticResult({kind:'followup',query:'держатель'},awaiting),{kind:'followup',query:'держатель'});
  const status={...input,context:{...input.context,topic:'printers'}};
  assert.deepEqual(validateVoiceSemanticResult({kind:'followup',printerId:'max'},status),{kind:'followup',printerId:'max'});
  assert.deepEqual(validateVoiceSemanticResult({kind:'followup',query:'держатель'},status),clarification);
});
await test('a clear spoken known printer cannot silently become a different model target',()=>{
  const context={printers:[{id:'max',name:'K1 Max',preset:'creality-k1-max'},{id:'compact',name:'K1C',preset:'creality-k1c-2025'}],fileChoices:[],printerChoices:[]};
  const request={text:'Ксения закинь держатель на Макс',context};
  assert.deepEqual(validateVoiceSemanticResult({kind:'print',query:'держатель',printerId:'compact'},request),{kind:'clarify',reason:'ambiguous'});
  assert.deepEqual(validateVoiceSemanticResult({kind:'print',query:'держатель',printerId:'max'},request),{kind:'print',query:'держатель',printerId:'max'});
  assert.deepEqual(validateVoiceSemanticResult({kind:'printers',filter:'all',printerId:'max'},{text:'А K1C сейчас чем занят?',context}),{kind:'clarify',reason:'ambiguous'});
  assert.deepEqual(validateVoiceSemanticResult({kind:'print',query:'держатель',printerId:'max'},{text:'Закинь держатель на большой',context}),{kind:'print',query:'держатель',printerId:'max'});
  const previous={text:'Лучше теперь на Максе',context:{...context,selectedFile:{name:'держатель'},selectedPrinterId:'compact'}};
  assert.deepEqual(validateVoiceSemanticResult({kind:'followup',usePreviousPrinter:true},previous),{kind:'clarify',reason:'ambiguous'});
  // A mention of two known printers is not enough to override semantic scope (comparison, source or target).
  const two={text:'Макс пока занят, этот держатель давай на K1C',context};
  assert.deepEqual(validateVoiceSemanticResult({kind:'print',query:'держатель',printerId:'compact'},two),{kind:'print',query:'держатель',printerId:'compact'});
});
await test('already understood commands stay fast and do not invoke the model',async()=>{
  const f=fixture(()=>{throw Error('must not run')});
  assert.equal((await f.assistant.handle('Какие принтеры свободны?')).text,'Свободны: K1 Max.');
  assert.equal(f.data.calls.length,0);assert.equal(f.data.start,0);assert.equal(f.data.list.length,0);
});
await test('the reported spoken variants stay immediate and use only live ready printers',async()=>{
  const f=fixture(()=>{throw Error('must not need inference')});
  f.data.printers.push({...printer('offline','Отключённый'),status:{state:'ready',connectionState:'offline'}});
  for(const text of ['Ксения, какие принтеры свободны?','Ну какие принтеры сейчас свободны-то?','Принтеры свободны?','Можешь сказать, какие принтеры свободны?','Какой принтер свободен?','Кто из принтеров не занят?','Подскажи, какие принтеры свободны для работы?']){
    assert.equal((await f.assistant.handle(text)).text,'Свободны: K1 Max.',text);
  }
  assert.equal(f.data.calls.length,0);assert.equal(f.data.list.length,0);assert.equal(f.data.start,0);
});
await test('ordinary open questions use the provider and answer only live free printers',async()=>{
  const f=fixture(()=>({kind:'printers',filter:'free'}));
  for(const text of ['У какого аппарата сейчас пустой стол?','Ксения, найди мне свободного работягу','У кого из наших можно сейчас занять стол?']){
    assert.equal((await f.assistant.handle(text)).text,'Свободны: K1 Max.');
  }
  assert.equal(f.data.calls.length,3);assert.equal(f.data.list.length,0);assert.equal(f.data.validate.length,0);assert.equal(f.data.upload,0);assert.equal(f.data.start,0);
  f.data.printers[0].status.state='printing';assert.equal((await f.assistant.handle('Ну кто там не занят?')).text,'Свободны: нет.');
});
await test('semantic named status resolves an exact ID without inspecting or preparing files',async()=>{
  const f=fixture(()=>({kind:'printers',filter:'all',printerId:'busy'}));
  assert.equal((await f.assistant.handle('Вторая карточка чем сейчас занята?')).text,'Занятый: печатает.');assert.equal(f.data.list.length,0);assert.equal(f.data.start,0);
});
await test('a root utterance cannot inherit a model-invented previous file or wrong known target',async()=>{
  for(const output of [{kind:'followup',usePreviousFile:true},{kind:'followup',query:'держатель'},{kind:'print',query:'держатель',printerId:'busy'}]){
    const f=fixture(()=>output);
    const reply=await f.assistant.handle('Ксения закинь держатель на K1 Max');
    assert.match(reply.text,/Я услышала:/);assert.equal(reply.diagnosticOutcome,'needs-input');assert(!reply.proposal);
    assert.equal(f.data.list.length,0);assert.equal(f.data.validate.length,0);assert.equal(f.data.upload,0);assert.equal(f.data.start,0);
  }
});
await test('duplicate card names ask a real choice and resume the original read-only intent',async()=>{
  const f=fixture(()=>({kind:'printers',filter:'all',printerId:'max'}));f.data.printers[1].name='K1 Max';
  const reply=await f.assistant.handle('Большой сейчас работает?');assert.equal(reply.clarification,'printer');assert.deepEqual(reply.printerChoices.map(p=>p.id),['max','busy']);
  assert.equal((await f.assistant.choosePrinter('busy')).text,'K1 Max: печатает.');assert.equal(f.data.list.length,0);assert.equal(f.data.start,0);
});
await test('preparing or checking a queued task invalidates a different pending semantic printer choice',async()=>{
  for(const action of ['prepare','check','check-command']){
    const values=new Map(),storage={getItem:key=>values.get(key)??null,setItem:(key,value)=>values.set(key,value),removeItem:key=>values.delete(key)};
    const tasks=new VoiceTaskQueue(storage,'semantic-review',()=>1_000_000);
    const f=fixture(()=>({kind:'print',query:'first',printerId:'max'}),{tasks});f.data.printers[1].name='K1 Max';f.data.printers[1].status.state='ready';
    f.data.files=[{path:'first.gcode',size:100},{path:'second.gcode',size:100}];
    assert.equal((await f.assistant.handle('Ксения добавь первую штуку в печать')).clarification,'printer');
    const saved=tasks.addPlan([{query:'second',scopeId:'model:creality-k1-max',path:'second.gcode',printerId:'max',printerName:'K1 Max'}],'semantic-new-task');assert(saved.ok);
    if(action==='prepare')assert.equal((await f.assistant.prepareTask(saved.tasks[0].id)).proposal.candidate.entry.path,'second.gcode');
    else if(action==='check')await f.assistant.checkTask(saved.tasks[0].id);
    else await f.assistant.handle('Проверь запуск');
    const count=f.data.validate.length,reply=await f.assistant.handle('Выбери второй');
    assert(!reply.proposal,action);assert.equal(f.data.validate.length,count,action);assert.equal(f.data.upload,0);assert.equal(f.data.start,0);
    assert(!(await f.assistant.choosePrinter('busy')).proposal,action);
  }
});
await test('an explicit current file choice discards an unrelated pending semantic printer action',async()=>{
  const f=fixture(()=>({kind:'print',query:'second',printerId:'max'}));f.data.printers[1].name='K1 Max';f.data.printers[1].status.state='ready';f.data.files=[{path:'first.gcode',size:100},{path:'second.gcode',size:100}];
  const files=await f.assistant.handle('Найди first');assert(files.choices?.length);
  assert.equal((await f.assistant.handle('Ксения добавь вторую штуку в печать')).clarification,'printer');
  const chosen=await f.assistant.choose(files.choices[0]);assert.equal(chosen.proposal.candidate.entry.path,'first.gcode');
  const count=f.data.validate.length,stale=await f.assistant.choosePrinter('busy');assert(!stale.proposal);assert.equal(f.data.validate.length,count);assert.equal(f.data.upload,0);assert.equal(f.data.start,0);
});
await test('semantic preparation keeps validation and a separate exact confirmation boundary',async()=>{
  const f=fixture(()=>({kind:'print',query:'держатель',printerId:'max'}));
  const reply=await f.assistant.handle('Мне бы тот держатель на большого поставить');assert.equal(reply.proposal.candidate.printerId,'max');assert.equal(f.data.validate.length,1);assert.equal(f.data.upload,0);assert.equal(f.data.start,0);
  await f.assistant.handle('Подтверждаю печать');assert.equal(f.data.upload,1);assert.equal(f.data.start,1);assert.equal(f.data.calls.length,1);
});
await test('unknown or unavailable understanding echoes what was heard without generic help or stale confirmation',async()=>{
  for(const output of [{kind:'clarify',reason:'unknown'}, {kind:'confirm'}, Error('missing runtime')]){
    const f=fixture(()=>{if(output instanceof Error)throw output;return output});
    await f.assistant.handle('Напечатай держатель на K1 Max');const result=await f.assistant.handle('Ну ты поняла, сделай как там');
    assert.match(result.text,/Я услышала: «Ну ты поняла, сделай как там»/);assert(!result.text.includes('Что сделать:'));assert(!result.proposal);
    await f.assistant.handle('Подтверждаю печать');assert.equal(f.data.upload,0);assert.equal(f.data.start,0);
  }
});
await test('semantic clarification, malformed output and provider failures discard hidden old printer choices',async()=>{
  for(const outcome of [{kind:'clarify',reason:'unsupported'},{kind:'clarify',reason:'unknown'},{kind:'clarify',reason:'ambiguous'},{kind:'confirm'},Error('runtime unavailable')]){
    let call=0;const f=fixture(()=>{if(++call===1)return{kind:'print',query:'first',printerId:'max'};if(outcome instanceof Error)throw outcome;return outcome});
    f.data.printers[1].name='K1 Max';f.data.printers[1].status.state='ready';f.data.files=[{path:'first.gcode',size:100}];
    assert.equal((await f.assistant.handle('Ксения добавь первую штуку в печать')).clarification,'printer');
    const next=await f.assistant.handle('Теперь займись совсем другим');assert.match(next.text,/Я услышала:/);assert(!next.printerChoices?.length);assert(!next.proposal);
    const later=await f.assistant.handle('Выбери второй');assert(!later.proposal);assert(!(await f.assistant.choosePrinter('busy')).proposal);
    assert.equal(call,2);assert.equal(f.data.list.length,0);assert.equal(f.data.validate.length,0);assert.equal(f.data.upload,0);assert.equal(f.data.start,0);
  }
});
await test('cancelling a running interpretation invalidates its later result and signals the provider',async()=>{
  let release,receivedSignal;const f=fixture((_,signal)=>{receivedSignal=signal;return new Promise(resolve=>{release=resolve})});
  const pending=f.assistant.handle('Ну давай мне держатель куда-нибудь');await Promise.resolve();
  await f.assistant.handle('Отмена');assert.equal(receivedSignal.aborted,true);release({kind:'print',query:'держатель',printerId:'max'});await pending;
  assert.equal(f.data.list.length,0);assert.equal(f.data.validate.length,0);assert.equal(f.data.upload,0);assert.equal(f.data.start,0);
});
await test('model context is bounded conversation data and excludes connection credentials or clients',async()=>{
  const f=fixture(()=>({kind:'clarify',reason:'unknown'}));
  await f.assistant.handle('Напечатай держатель на K1 Max');await f.assistant.handle('Ну этот туда же');
  const request=f.data.calls[0],serialized=JSON.stringify(request);assert.equal(request.context.selectedPrinterId,'max');assert.equal(request.context.selectedFile.name,'держатель');assert.equal(request.context.request.action,'print');
  for(const hidden of ['host','apiKey','not-for-model','192.168','client','sha256','target'])assert(!serialized.includes(hidden),hidden);
  f.data.clock+=4*60_000+1;await f.assistant.handle('Ну этот туда же');assert.equal(f.data.calls.at(-1).context.selectedFile,undefined);
});

const report={passed:true,cases:results.length,results};if(process.env.KF_VOICE_SEMANTIC_PROOF)fs.writeFileSync(process.env.KF_VOICE_SEMANTIC_PROOF,JSON.stringify(report,null,2));
console.log(`Voice semantic boundary: ${results.length} cases passed`);
