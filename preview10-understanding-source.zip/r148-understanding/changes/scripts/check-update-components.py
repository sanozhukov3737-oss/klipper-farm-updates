"""Offline fixtures for signed-installer component preparation; no large models needed."""
import contextlib
import hashlib
import importlib.util
import io
import json
import shutil
import tempfile
import unittest
import zipfile
from pathlib import Path

SPEC = importlib.util.spec_from_file_location('update_components', Path(__file__).with_name('prepare-update-components.py'))
components = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(components)


def pin(relative, data):
    return {'path': relative, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


class ComponentPreparationTests(unittest.TestCase):
    def setUp(self):
        self.directory = Path(tempfile.mkdtemp(prefix='update-components-check-'))
        self.root = self.directory / 'app'
        self.speech = self.root / 'src-tauri/speech'
        self.understanding = self.root / 'src-tauri/resources/understanding'
        self.output = self.directory / 'assets'
        (self.root / 'scripts').mkdir(parents=True)
        for base, files in [
            (self.speech, {'silero/tts.py': b'wrapper version one', 'whisper/recognition.args': b'recognition args',
                           'NEURAL-SPEECH-NOTICES.txt': b'third party notice',
                           'silero/python/engine.dll': b'speech engine', 'whisper/ggml.bin': b'speech model'}),
            (self.understanding, {'runtime/completion.exe': b'understanding engine',
                                  'licenses/model-LICENSE.txt': b'model license', 'NOTICE.txt': b'notice',
                                  'model.gguf': b'GGUF miniature model'})]:
            for relative, data in files.items():
                target = base / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(data)
        self.write_manifests()
        model = next(row for row in self.rows(self.understanding) if row['path'] == 'model.gguf')
        model.update(kind='model', url='https://huggingface.co/example/model/resolve/' + 'a' * 40 + '/model.gguf')
        (self.root / 'scripts/voice-understanding-assets.json').write_text(json.dumps({'assets': [model]}), encoding='utf-8')

    def tearDown(self):
        shutil.rmtree(self.directory)

    def rows(self, base):
        return [pin(path.relative_to(base).as_posix(), path.read_bytes()) for path in sorted(base.rglob('*'))
                if path.is_file() and path.name != 'manifest.json']

    def write_manifests(self):
        (self.speech / 'manifest.json').write_text(json.dumps(self.rows(self.speech)), encoding='utf-8')
        (self.understanding / 'manifest.json').write_text(json.dumps({'files': self.rows(self.understanding)}), encoding='utf-8')

    def prepare(self):
        with contextlib.redirect_stdout(io.StringIO()):
            return components.prepare(self.root, self.output)

    def test_repeat_build_is_identical_and_archive_inventory_is_exact(self):
        first = self.prepare()
        archive_bytes = Path(first['assetPath']).read_bytes()
        manifest_path = Path(first['manifestPath'])
        manifest_bytes = manifest_path.read_bytes()
        second = self.prepare()
        self.assertEqual(first, second)
        self.assertEqual(archive_bytes, Path(second['assetPath']).read_bytes())
        self.assertEqual(manifest_bytes, manifest_path.read_bytes())
        manifest = json.loads(manifest_bytes)
        with zipfile.ZipFile(first['assetPath']) as archive:
            expected = {row['path']: row for row in manifest['runtime']['files']}
            self.assertEqual(set(archive.namelist()), set(expected))
            for name in archive.namelist():
                self.assertEqual(pin(name, archive.read(name)), expected[name])
        self.assertNotIn('speech/silero/tts.py', expected)
        self.assertNotIn('speech/manifest.json', expected)
        self.assertNotIn('understanding/model.gguf', expected)
        self.assertEqual(manifest['runtime']['url'], components.RUNTIME_BASE + first['name'])

    def test_empty_python_runtime_file_is_kept_and_hash_pinned(self):
        empty = self.speech / 'silero/python/torch/__init__.py'
        empty.parent.mkdir(parents=True)
        empty.write_bytes(b'')
        self.write_manifests()
        report = self.prepare()
        manifest = json.loads(Path(report['manifestPath']).read_text())
        name = 'speech/silero/python/torch/__init__.py'
        row = next(row for row in manifest['runtime']['files'] if row['path'] == name)
        self.assertEqual(row, pin(name, b''))
        with zipfile.ZipFile(report['assetPath']) as archive:
            self.assertEqual(archive.getinfo(name).file_size, 0)
            self.assertEqual(archive.read(name), b'')

    def test_small_wrapper_change_retains_runtime_and_updates_installer_resource(self):
        first = self.prepare()
        (self.speech / 'silero/tts.py').write_bytes(b'wrapper version two with a pronunciation fix')
        self.write_manifests()
        second = self.prepare()
        self.assertEqual(first['sha256'], second['sha256'])
        copied = self.root / 'src-tauri/resources/update-components/speech/silero/tts.py'
        self.assertEqual(copied.read_bytes(), (self.speech / 'silero/tts.py').read_bytes())
        self.assertEqual((copied.parents[1] / 'manifest.json').read_bytes(), (self.speech / 'manifest.json').read_bytes())

    def test_repinning_an_engine_creates_a_new_immutable_asset(self):
        first = self.prepare()
        original = Path(first['assetPath']).read_bytes()
        (self.speech / 'silero/python/engine.dll').write_bytes(b'updated pinned engine')
        self.write_manifests()
        second = self.prepare()
        self.assertNotEqual(first['sha256'], second['sha256'])
        self.assertNotEqual(first['name'], second['name'])
        self.assertEqual(original, Path(first['assetPath']).read_bytes())
        self.assertTrue(Path(second['assetPath']).is_file())

    def test_tampered_or_missing_prepared_file_cannot_replace_good_manifest(self):
        first = self.prepare()
        manifest = Path(first['manifestPath']).read_bytes()
        engine = self.speech / 'silero/python/engine.dll'
        engine.write_bytes(b'tampered engine')
        with self.assertRaises(ValueError):
            self.prepare()
        self.assertEqual(Path(first['manifestPath']).read_bytes(), manifest)
        engine.unlink()
        with self.assertRaises(ValueError):
            self.prepare()
        self.assertEqual(Path(first['manifestPath']).read_bytes(), manifest)

    def test_unlisted_extra_file_is_rejected(self):
        (self.speech / 'silero/python/extra.dll').write_bytes(b'unlisted')
        with self.assertRaisesRegex(ValueError, 'exact component inventory'):
            self.prepare()

    def test_model_cannot_drift_from_its_source_pin(self):
        (self.understanding / 'model.gguf').write_bytes(b'GGUF changed model')
        self.write_manifests()
        with self.assertRaisesRegex(ValueError, 'immutable model pin'):
            self.prepare()

    def test_model_download_url_must_pin_an_immutable_revision(self):
        pins_path = self.root / 'scripts/voice-understanding-assets.json'
        pins = json.loads(pins_path.read_text())
        pins['assets'][0]['url'] = 'https://huggingface.co/example/model/resolve/main/model.gguf'
        pins_path.write_text(json.dumps(pins), encoding='utf-8')
        with self.assertRaisesRegex(ValueError, 'immutable Hugging Face revision'):
            self.prepare()

    def test_duplicate_case_insensitive_manifest_path_is_rejected(self):
        rows = json.loads((self.speech / 'manifest.json').read_text())
        rows.append(dict(rows[0], path=rows[0]['path'].upper()))
        (self.speech / 'manifest.json').write_text(json.dumps(rows), encoding='utf-8')
        with self.assertRaisesRegex(ValueError, 'duplicate'):
            self.prepare()

    def test_unsafe_windows_and_traversal_paths_are_rejected(self):
        for name in ['', '.', '../escape', '/escape', 'a/../escape', 'a\\escape', 'C:/escape',
                     'file.', 'file ', 'NUL', 'con.txt', 'a/COM1.dll', 'a?b', 'a\0b', 'a|b']:
            with self.subTest(path=name), self.assertRaises(ValueError):
                components.safe_relative(name)

    def test_manifest_traversal_is_rejected_without_reading_an_outside_file(self):
        outside = self.root / 'src-tauri/escape.dll'
        outside.write_bytes(b'outside')
        rows = json.loads((self.speech / 'manifest.json').read_text())
        rows.append(pin('../escape.dll', outside.read_bytes()))
        (self.speech / 'manifest.json').write_text(json.dumps(rows), encoding='utf-8')
        with self.assertRaisesRegex(ValueError, 'Unsafe component path'):
            self.prepare()

    def test_prepared_file_symlink_is_rejected(self):
        engine = self.speech / 'silero/python/engine.dll'
        target = self.directory / 'external-engine.dll'
        target.write_bytes(engine.read_bytes())
        engine.unlink()
        try:
            engine.symlink_to(target)
        except OSError as error:
            self.skipTest('Host cannot create symbolic-link fixture: ' + str(error))
        with self.assertRaisesRegex(ValueError, 'link'):
            self.prepare()


if __name__ == '__main__':
    unittest.main()
