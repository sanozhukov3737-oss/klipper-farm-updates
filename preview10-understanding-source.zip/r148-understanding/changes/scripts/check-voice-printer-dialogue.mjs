import assert from 'node:assert/strict';
import fs from 'node:fs';
import {build} from 'esbuild';

const compiled=await build({stdin:{contents:"export {VoiceAssistant} from './src/lib/voiceAssistant';export {parseVoiceCommand} from './src/lib/voiceCommands';export {profileForPreset} from './src/lib/printerProfile';export {emptyFilamentInventory} from './src/lib/filamentInventory';",resolveDir:process.cwd(),loader:'ts'},bundle:true,write:false,format:'esm',platform:'node'});
const {VoiceAssistant,parseVoiceCommand,profileForPreset,emptyFilamentInventory}=await import('data:text/javascript;base64,'+Buffer.from(compiled.outputFiles[0].text).toString('base64'));
const results=[];
const test=async(name,check)=>{await check();results.push({name,passed:true});console.log('PASS',name)};
const printer=(id,name,preset='creality-k1-max',now=1_700_000)=>({id,name,host:'192.168.1.'+(id==='max'?10:id==='right'?11:12),profile:profileForPreset(preset),status:{state:'printing',connectionState:'online',filename:'детали/держатель.gcode',progress:.5,printDuration:600,nozzle:200,nozzleTarget:200,bed:60,bedTarget:60,jobUpdatedAt:now},webcams:[]});
function fixture({sameModel=false,sameNames=false,interpret}={}){
 const data={clock:1_700_000,role:true,printers:[printer('max',sameNames?'Макс':'Левый Макс'),printer('right',sameNames?'Макс':sameModel?'Правый Макс':'Форж',sameModel||sameNames?'creality-k1-max':'flashforge-ad5m')],calls:[],lists:0,validations:0,uploads:0,starts:0,interpreted:0,camera:[]};
 const clients=new Map(data.printers.map(p=>[p.id,{
  light:async(on,guard)=>{guard?.();data.calls.push([p.id,'light',on]);return{supported:true,on}},
  pause:async guard=>{guard?.();data.calls.push([p.id,'pause']);p.status.state='paused'},
  resume:async guard=>{guard?.();data.calls.push([p.id,'resume']);p.status.state='printing'},
  checkPrintStart:async filename=>({confirmed:filename===p.status.filename&&['printing','paused'].includes(p.status.state),state:p.status.state,filename:p.status.filename}),
 }]));
 const deps={printers:()=>data.printers,client:id=>clients.get(id),canOperate:()=>data.role,now:()=>data.clock,
  list:async()=>{data.lists++;return[{path:'детали/держатель.gcode',size:150}]},inventory:async()=>emptyFilamentInventory(),
  validate:async()=>{data.validations++;return{sha256:'a'.repeat(64),report:{ok:true,issues:[]}}},ready:async()=>{},upload:async()=>{data.uploads++;return'держатель.gcode'},start:async()=>{data.starts++},check:async()=>true,audit:async()=>{},
  hasCamera:()=>true,openCamera:id=>{data.camera.push(id);return true},
 };
 if(interpret)deps.interpret=async input=>{data.interpreted++;return interpret(input,data)};
 const assistant=new VoiceAssistant(deps);
 const noPrint=()=>{assert.equal(data.lists,0);assert.equal(data.validations,0);assert.equal(data.uploads,0);assert.equal(data.starts,0)};
 return{data,deps,clients,assistant,noPrint};
}
await test('a bare known printer answer preserves the pending light action without interpretation',async()=>{
 const f=fixture({interpret:()=>{throw Error('a named pending printer must not call the model')}});
 const ask=await f.assistant.handle('Включи свет');assert.equal(ask.clarification,'printer');assert.equal(ask.printerChoices.length,2);assert.equal(f.data.calls.length,0);
 const result=await f.assistant.handle('Форж');assert.match(result.text,/Подсветка принтера Форж включена/);assert.deepEqual(f.data.calls,[['right','light',true]]);assert.equal(f.data.interpreted,0);f.noPrint();
});
await test('ordinal and UI printer selections preserve pause and resume independently',async()=>{
 for(const action of ['pause','resume'])for(const method of ['ordinal','ui']){
  const f=fixture();if(action==='resume')for(const p of f.data.printers)p.status.state='paused';
  const ask=await f.assistant.handle(action==='pause'?'Пауза':'Продолжи печать');assert.equal(ask.clarification,'printer');assert.equal(f.data.calls.length,0);
  const result=method==='ordinal'?await f.assistant.handle('второй'):await f.assistant.choosePrinter('right');
  assert.match(result.text,action==='pause'?/поставлена на паузу/:/продолжена/);assert.deepEqual(f.data.calls,[['right',action]]);f.noPrint();
 }
});
await test('duplicate model aliases require an explicit current card instead of the first match',async()=>{
 const f=fixture({sameModel:true,interpret:()=>{throw Error('ambiguous alias must not call the model')}});
 const ask=await f.assistant.handle('Включи свет на Максе');assert.equal(ask.clarification,'printer');assert.equal(ask.printerChoices.length,2);
 const ambiguous=await f.assistant.handle('Макс');assert.equal(ambiguous.clarification,'printer');assert.equal(f.data.calls.length,0);
 const result=await f.assistant.handle('Правый Макс');assert.match(result.text,/Правый Макс/);assert.deepEqual(f.data.calls,[['right','light',true]]);assert.equal(f.data.interpreted,0);f.noPrint();
});
await test('a card outside the displayed alias choices cannot receive the pending action',async()=>{
 const f=fixture({sameModel:true});const forge=printer('forge','Форж','flashforge-ad5m',f.data.clock);f.data.printers.push(forge);
 const ask=await f.assistant.handle('Включи свет на Максе');assert.deepEqual(ask.printerChoices.map(p=>p.id),['max','right']);
 const wrong=await f.assistant.handle('Форж');assert.equal(wrong.clarification,'printer');assert.equal(f.data.calls.length,0);
 await f.assistant.choosePrinter('right');assert.deepEqual(f.data.calls,[['right','light',true]]);f.noPrint();
});
await test('a new status topic clears a pending mutation before later printer choices',async()=>{
 const f=fixture();await f.assistant.handle('Включи свет');await f.assistant.handle('Какие принтеры свободны?');
 const reply=await f.assistant.choosePrinter('right');assert.match(reply.text,/Список принтеров устарел/);assert.equal(f.data.calls.length,0);f.noPrint();
});
await test('a new explicit control replaces the old pending action rather than executing both',async()=>{
 const f=fixture();await f.assistant.handle('Включи свет');const reply=await f.assistant.handle('Выключи свет на Форже');
 assert.match(reply.text,/Форж выключена/);assert.deepEqual(f.data.calls,[['right','light',false]]);
 await f.assistant.choosePrinter('max');assert.equal(f.data.calls.length,1);f.noPrint();
});
await test('cancellation and expiry clear pending printer actions',async()=>{
 for(const condition of ['cancel','expire']){
  const f=fixture();await f.assistant.handle('Включи свет');
  if(condition==='cancel')await f.assistant.handle('Отмена');else f.data.clock+=240_001;
  const reply=await f.assistant.choosePrinter('max');assert.match(reply.text,/Список принтеров устарел/);assert.equal(f.data.calls.length,0);f.noPrint();
 }
});
await test('disposing a profile clears pending actions and a fresh assistant cannot inherit them',async()=>{
 const f=fixture();await f.assistant.handle('Включи свет');f.assistant.dispose();assert.equal((await f.assistant.choosePrinter('max')).text,'Помощник закрыт');
 const fresh=new VoiceAssistant(f.deps);const reply=await fresh.choosePrinter('max');assert.match(reply.text,/Список принтеров устарел/);assert.equal(f.data.calls.length,0);f.noPrint();
});
await test('losing the operator role while choosing a printer blocks the pending mutation',async()=>{
 const f=fixture();await f.assistant.handle('Включи свет');f.data.role=false;
 const reply=await f.assistant.choosePrinter('max');assert.match(reply.text,/недоступно управление/);assert.equal(reply.diagnosticOutcome,'error');assert.equal(f.data.calls.length,0);f.noPrint();
});
await test('removing the chosen printer cannot send the old pending command to another card',async()=>{
 const f=fixture();await f.assistant.handle('Включи свет');f.data.printers=f.data.printers.filter(p=>p.id!=='max');
 const reply=await f.assistant.choosePrinter('max');assert.match(reply.text,/Принтер удалён/);assert.equal(f.data.calls.length,0);f.noPrint();
});
await test('a selected pending forecast re-reads the latest printer state without calling a client',async()=>{
 const f=fixture({interpret:()=>{throw Error('known pending printer must stay deterministic')}});
 const ask=await f.assistant.handle('Когда закончится печать?');assert.equal(ask.clarification,'printer');
 f.data.printers[1].status.progress=.75;const result=await f.assistant.handle('Форж');assert.match(result.text,/примерно через 4 мин/);assert.equal(f.data.calls.length,0);assert.equal(f.data.interpreted,0);f.noPrint();
});
await test('forecast printer choices preserve forecast intent for both ordinal and UI paths',async()=>{
 for(const method of ['ordinal','ui']){
  const f=fixture();await f.assistant.handle('Когда закончится печать?');
  const result=method==='ordinal'?await f.assistant.handle('второй'):await f.assistant.choosePrinter('right');
  assert.match(result.text,/Форж: печать закончится примерно через 10 мин/);assert.equal(f.data.calls.length,0);f.noPrint();
 }
});
await test('every named forecast uses the current snapshot and does not invent a stale ETA',async()=>{
 const f=fixture();let reply=await f.assistant.handle('Когда закончит Форж?');assert.match(reply.text,/примерно через 10 мин/);
 f.data.printers[1].status.progress=.75;reply=await f.assistant.handle('Когда закончит Форж?');assert.match(reply.text,/примерно через 4 мин/);
 f.data.printers[1].status.jobUpdatedAt=f.data.clock-20_001;reply=await f.assistant.handle('Когда закончит Форж?');assert.match(reply.text,/свежих данных.*нет/);assert.doesNotMatch(reply.text,/примерно через|около \d{2}:/);assert.equal(f.data.calls.length,0);f.noPrint();
});
await test('fleet forecasts stay global after a named-printer conversation',async()=>{
 const f=fixture();f.data.printers[1].status.progress=.75;
 await f.assistant.handle('Когда закончит Левый Макс?');const first=await f.assistant.handle('Кто освободится первым?');assert.match(first.text,/раньше закончит Форж/);
 f.data.printers[0].status.progress=.1;f.data.printers[0].status.printDuration=1200;
 const after=await f.assistant.handle('Что будет печататься через час?');assert.match(after.text,/ещё будет печатать Левый Макс/);assert.doesNotMatch(after.text,/будет печатать Форж/);assert.equal(f.data.calls.length,0);f.noPrint();
});
await test('paused, offline, absent and future freshness never become a definite forecast',async()=>{
 for(const scenario of ['paused','offline','missing','future']){
  const f=fixture(),status=f.data.printers[0].status;
  if(scenario==='paused')status.state='paused';if(scenario==='offline')status.connectionState='offline';if(scenario==='missing')delete status.jobUpdatedAt;if(scenario==='future')status.jobUpdatedAt=f.data.clock+10_000;
  const reply=await f.assistant.handle('Когда закончит Левый Макс?');assert.doesNotMatch(reply.text,/примерно через|около \d{2}:/,scenario);assert.match(reply.text,/неизвестно|после продолжения/,scenario);assert.equal(f.data.calls.length,0);f.noPrint();
 }
});
await test('read-only forecasts and camera work without the operator role',async()=>{
 const f=fixture();f.data.role=false;
 const forecast=await f.assistant.handle('Кто освободится первым?');assert.match(forecast.text,/прогнозу/);const camera=await f.assistant.handle('Открой камеру на Форже');assert.match(camera.text,/Открыла окно камеры принтера Форж/);assert.deepEqual(f.data.camera,['right']);assert.equal(f.data.calls.length,0);f.noPrint();
});
await test('a forecast or control topic invalidates a previously prepared print confirmation',async()=>{
 for(const text of ['Включи свет на Левом Максе','Когда закончит Левый Макс?']){
  const f=fixture();f.data.printers[0].status.state='ready';f.data.printers[0].status.progress=0;f.data.printers[0].status.printDuration=0;
  const prepared=await f.assistant.handle('Напечатай держатель на Левом Максе');assert(prepared.proposal);
  const next=await f.assistant.handle(text);assert(!next.proposal);const confirm=await f.assistant.handle('Подтверждаю печать');assert.match(confirm.text,/Нет действующего подтверждения/);assert.equal(f.data.uploads,0);assert.equal(f.data.starts,0);
 }
});
await test('cancelling a held pause preflight prevents dispatch through the actual assistant lifecycle',async()=>{
 const f=fixture();let resolve,entered=false;
 f.clients.get('max').checkPrintStart=filename=>{entered=true;return new Promise(done=>{resolve=()=>done({confirmed:true,state:'printing',filename})})};
 const pending=f.assistant.handle('Поставь Левый Макс на паузу');assert.equal(entered,true);
 const cancelled=await f.assistant.handle('Отмена');assert.equal(cancelled.diagnosticOutcome,'cancelled');resolve();
 const result=await pending;assert.match(result.text,/отменено/);assert.equal(f.data.calls.length,0);f.noPrint();
});
await test('cancelling an in-flight semantic request discards its later control result',async()=>{
 let resolve;const f=fixture({interpret:()=>new Promise(done=>{resolve=done})});
 const pending=f.assistant.handle('Можно увидеть изображение с камеры Форжа?');assert.equal(f.data.interpreted,1);
 await f.assistant.handle('Отмена');resolve({kind:'control',action:'camera',printerId:'right'});
 const result=await pending;assert.match(result.text,/отменено/);assert.deepEqual(f.data.camera,[]);assert.equal(f.data.calls.length,0);f.noPrint();
});
await test('semantic duplicate-printer clarification replaces an older pending control',async()=>{
 const f=fixture({sameNames:true,interpret:()=>({kind:'printers',filter:'all',printerId:'max'})});
 const first=await f.assistant.handle('Включи свет');assert.equal(first.clarification,'printer');assert.equal(first.printerChoices.length,2);
 const second=await f.assistant.handle('Не знаю, какие принтеры сейчас заняты');assert.equal(f.data.interpreted,1);assert.equal(second.clarification,'printer',JSON.stringify(second));
 const chosen=await f.assistant.choosePrinter('right');assert.match(chosen.text,/Макс: печатает/);assert.equal(f.data.calls.length,0);f.noPrint();
});
if(process.env.KF_VOICE_PRINTER_DIALOGUE_PROOF)fs.writeFileSync(process.env.KF_VOICE_PRINTER_DIALOGUE_PROOF,JSON.stringify({passed:true,cases:results.length,physicalPrintersTested:false,results},null,2)+'\n');
console.log('Voice printer dialogue:',results.length,'cases passed');
