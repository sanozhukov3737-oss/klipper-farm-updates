# Run on a disposable Windows CI runner, with the local runtime ZIP/model
# adjacent to the installer. Leaves the installed app available for smoke tests.
[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)][string]$InstallerPath,
  [string]$ComponentManifestPath,
  [Parameter(Mandatory=$true)][string]$InstallRoot,
  [string]$ProofPath
)
$ErrorActionPreference = 'Stop'
$InstallerPath = [IO.Path]::GetFullPath($InstallerPath)
$InstallRoot = [IO.Path]::GetFullPath($InstallRoot)
if (-not $ComponentManifestPath) { $ComponentManifestPath = Join-Path (Split-Path -Parent $PSScriptRoot) 'src-tauri/resources/update-components/component-manifest.json' }
if (Test-Path -LiteralPath $InstallRoot) { throw 'CI fresh-install root must not already exist.' }
$manifest = [IO.File]::ReadAllText($ComponentManifestPath, [Text.UTF8Encoding]::new($false, $true)) | ConvertFrom-Json
$directory = Split-Path -Parent $InstallerPath
$statePath = Join-Path $InstallRoot '.klipper-component-state.json'
function Invoke-Installer([switch]$Update) {
  $phase = if ($Update) { 'update-reuse' } else { 'fresh-install' }
  Write-Host ('Installer integration phase: ' + $phase)
  $arguments = '/S /COMPONENTSOFFLINE /COMPONENTSNOPROGRESS '
  if ($Update) { $arguments += '/UPDATE ' }
  $process = Start-Process -FilePath $InstallerPath -ArgumentList ($arguments + '/D=' + $InstallRoot) -Wait -PassThru
  if ($process.ExitCode -ne 0) {
    $detail = 'No retained component error was found.'
    $errorPath = Join-Path $InstallRoot '.klipper-component-install-error.txt'
    if (Test-Path -LiteralPath $errorPath -PathType Leaf) {
      $errorFile = Get-Item -LiteralPath $errorPath -Force
      if (-not ($errorFile.Attributes -band [IO.FileAttributes]::ReparsePoint) -and $errorFile.Length -le 64KB) {
        $detail = [IO.File]::ReadAllText($errorPath)
        $detail = $detail.Substring(0, [Math]::Min(1800, $detail.Length))
      }
    }
    throw ('Installer component integration failed (' + $phase + '): exit ' + $process.ExitCode + '. ' + $detail)
  }
  if (-not (Test-Path -LiteralPath (Join-Path $InstallRoot 'klipper-farm-client.exe'))) { throw 'Desktop executable is missing.' }
  $state = [IO.File]::ReadAllText($statePath) | ConvertFrom-Json
  if ($state.schema -ne 1 -or $state.runtimeSha256 -cne $manifest.runtime.sha256 -or
      $state.modelSha256 -cne $manifest.model.sha256 -or $state.networkDownloadBytes -ne 0) {
    throw 'Installed component report differs from the pinned offline build.'
  }
  return $state
}
function Assert-InstalledFiles {
  $times = @{}
  foreach ($row in @($manifest.runtime.files) + @($manifest.model)) {
    $path = Join-Path $InstallRoot $row.path.Replace('/', '\')
    $item = Get-Item -LiteralPath $path -Force
    if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint -or $item.Length -ne $row.bytes -or
        (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -cne $row.sha256) {
      throw ('Installed component failed integrity verification: ' + $row.path)
    }
    $times[$row.path] = $item.LastWriteTimeUtc.Ticks
  }
  return $times
}
$fresh = Invoke-Installer
if ($fresh.modelReused -or $fresh.runtimeReusedFiles -ne 0 -or $fresh.localCopyBytes -le 0) { throw 'Fresh install did not use verified local fixtures.' }
$before = Assert-InstalledFiles
$hidden = Join-Path $directory ('.component-ci-hidden-' + [Guid]::NewGuid().ToString('N'))
[IO.Directory]::CreateDirectory($hidden) | Out-Null
$moved = @()
try {
  foreach ($name in @($manifest.runtime.name, 'model.gguf')) {
    Move-Item -LiteralPath (Join-Path $directory $name) -Destination (Join-Path $hidden $name)
    $moved += $name
  }
  $reuse = Invoke-Installer -Update
  if (-not $reuse.modelReused -or $reuse.runtimeReusedFiles -ne $reuse.runtimeFiles -or
      $reuse.localCopyBytes -ne 0 -or $reuse.networkDownloadBytes -ne 0) { throw 'Update did not reuse every installed component without download/copy.' }
  $after = Assert-InstalledFiles
  foreach ($name in $before.Keys) { if ($before[$name] -ne $after[$name]) { throw ('Update rewrote a matching component: ' + $name) } }
  if ($ProofPath) {
    $proof = @{schema=1; passed=$true; installer=[IO.Path]::GetFileName($InstallerPath);
      installedFileCount=$before.Count; fresh=$fresh; reuse=$reuse; matchingFileTimestampsRetained=$true}
    [IO.Directory]::CreateDirectory((Split-Path -Parent ([IO.Path]::GetFullPath($ProofPath)))) | Out-Null
    [IO.File]::WriteAllText($ProofPath, ($proof | ConvertTo-Json -Depth 10), [Text.UTF8Encoding]::new($false))
  }
  Write-Output ('PASS: fresh offline install and /UPDATE reuse, zero component downloads; ' + $reuse.runtimeFiles + ' engine files retained.')
} finally {
  foreach ($name in $moved) { Move-Item -LiteralPath (Join-Path $hidden $name) -Destination (Join-Path $directory $name) }
  [IO.Directory]::Delete($hidden, $false)
}
