import assert from 'node:assert/strict';
import {build} from 'esbuild';
import fs from 'node:fs';

const compiled=await build({stdin:{contents:"export * from './src/lib/voiceCommands';",resolveDir:process.cwd(),loader:'ts'},bundle:true,write:false,format:'esm',platform:'node'});
const {parseVoiceCommand,voicePrinterMatches,voiceFileMatches,voiceFileNearMatch}=await import('data:text/javascript;base64,'+Buffer.from(compiled.outputFiles[0].text).toString('base64'));
const printer=(id,name,preset)=>({id,name,profile:{preset}});
const printers=[printer('max','K1 Max','creality-k1-max'),printer('compact','K1C','creality-k1c-2025')];
const report=[],test=(name,run)=>{run();report.push({name,passed:true});console.log('PASS',name)};
const parse=(text,context)=>parseVoiceCommand(text,printers,context);
const print=(query,printerHint='')=>({kind:'print',query,printerHint});

test('missing file and printer remain explicit empty slots',()=>{
 for(const text of ['Хочу напечатать','Напечатай','Можно напечатать?'])assert.deepEqual(parse(text),print(''),text);
 assert.deepEqual(parse('Напечатай на Максе'),print('','максе'));
 assert.deepEqual(parse('Найди'),{kind:'find',query:'',printerHint:''});
 assert.deepEqual(parse('Покажи файл'),{kind:'find',query:'',printerHint:''});
});
test('file and printer may precede the action without changing their identity',()=>{
 for(const text of ['Тестовый куб на K1 Max напечатай','K1 Max тестовый куб напечатай','Хочу тестовый куб напечатать на K1 Max','На K1 Max тестовый куб напечатай'])assert.deepEqual(parse(text),print('тестовый куб','k1 max'),text);
 assert.deepEqual(parse('Крепление на стену найди'),{kind:'find',query:'крепление на стену',printerHint:''});
 assert.deepEqual(parse('Крепление на стену найди на K1 Max'),{kind:'find',query:'крепление на стену',printerHint:'k1 max'});
});
test('bounded polite requests and separated print phrases preserve the file',()=>{
 for(const text of ['Можешь, пожалуйста, напечатать тестовый куб на K1 Max?','Поставь тестовый куб на печать на K1 Max','K1 Max отправь тестовый куб на печать','Давайте напечатать тестовый куб на K1 Max'])assert.deepEqual(parse(text),print('тестовый куб','k1 max'),text);
 assert.deepEqual(parse('Давай этот держатель на Максе'),print('держатель','максе'));
 assert.deepEqual(parse('Давай найдем куб'),{kind:'find',query:'куб',printerHint:''});
 assert.deepEqual(parse('Давай поищем корпус'),{kind:'find',query:'корпус',printerHint:''});
 assert.deepEqual(parse('Давай напечатаем куб'),print('куб'));
 assert.equal(parse('Давай проверь запуск').kind,'help');
 for(const text of ['Давай отменим печать','Давай остановим печать'])assert.equal(parse(text).kind,'help',text);
 assert.deepEqual(parse('Найди тестовый куб и поставь на печать на K1 Max'),print('тестовый куб','k1 max'));
});
test('declined nicknames match only configured names or registered aliases',()=>{
 for(const hint of ['Макс','Максе','Макса','Максу','Максом'])assert.deepEqual(voicePrinterMatches(printers,hint).map(p=>p.id),['max'],hint);
 const named=[printer('left','Левый большой','custom'),printer('ender','Ender','ender3-v3-ke')];
 assert.deepEqual(voicePrinterMatches(named,'Левом большом').map(p=>p.id),['left']);
 assert.deepEqual(voicePrinterMatches(named,'эндере').map(p=>p.id),['ender']);
 assert.deepEqual(voicePrinterMatches(printers,'K1'),[]);assert.deepEqual(voicePrinterMatches(printers,'K2 Max'),[]);
 const exact=[...printers,printer('literal','Максе','custom')];assert.deepEqual(voicePrinterMatches(exact,'Максе').map(p=>p.id),['literal']);
 assert.equal(parseVoiceCommand('Максе напечатай корпус на Макс',exact).kind,'help');
 const duplicate=[...printers,printer('max2','Второй Max','creality-k1-max')];assert.equal(voicePrinterMatches(duplicate,'Максе').length,2);
});
test('target corrections are followups while a standalone no still cancels',()=>{
 assert.deepEqual(parse('А на K1 Max?'),{kind:'followup',printerHint:'k1 max'});
 assert.deepEqual(parse('Нет, лучше на K1C'),{kind:'followup',printerHint:'k1c'});
 assert.deepEqual(parse('На другом принтере'),{kind:'followup',otherPrinter:true});
 assert.deepEqual(parse('На том же принтере'),{kind:'followup',usePreviousPrinter:true});
 assert.deepEqual(parse('Нет'),{kind:'cancel'});
 assert.equal(parse('Нет, лучше напечатай корпус').kind,'help');
});
test('file references never launch or silently become a literal filename',()=>{
 assert.deepEqual(parse('Этот файл'),{kind:'followup',usePreviousFile:true});
 assert.deepEqual(parse('Тот же файл на другом принтере'),{kind:'followup',otherPrinter:true,usePreviousFile:true});
 assert.deepEqual(parse('Напечатай этот файл на K1 Max'),{...print('','k1 max'),usePreviousFile:true});
 assert.deepEqual(parse('Напечатай это на том же принтере'),{...print(''),usePreviousFile:true,usePreviousPrinter:true});
 assert.equal(parse('Не тот файл').kind,'help');
});
test('a named same-print request is a grounded repeat, not a guessed filename or confirmation',()=>{
 for(const text of ['Макс, поставь то же самое на печать','K1 Max поставь тоже самое на печать','Напечатай то же самое на Максе','Ксения, Макс, поставь то же самое на печать','Можешь поставить то же самое на печать на Максе?']){
   const parsed=parse(text);assert.equal(parsed.kind,'repeat',text);assert.deepEqual(voicePrinterMatches(printers,parsed.printerHint).map(p=>p.id),['max'],text);assert.equal(parsed.fromHistory,undefined,text);
 }
 assert.deepEqual(parse('Напечатай то же самое'),{kind:'repeat',printerHint:''});
 assert.deepEqual(parse('Поставь то же самое на печать на другом принтере'),{kind:'repeat',printerHint:'',otherPrinter:true});
 for(const text of ['Повтори последнюю печать на Максе','Макс повтори печать','Ксения Макс повтори предыдущую печать'])assert.deepEqual(parse(text),{kind:'repeat',printerHint:text.includes('Максе')?'максе':'max',fromHistory:true},text);
 assert.deepEqual(parse('Напечатай файл то же самое на K1 Max'),print('то же самое','k1 max'));
 assert.deepEqual(parse('Найди файл то же самое'),{kind:'find',query:'то же самое',printerHint:''});
 for(const text of ['Не ставь то же самое на печать','Макс повтори печать на K1C','Кто-нибудь повтори печать','Повтори печать и подтверди'])assert.equal(parse(text).kind,'help',text);
});
test('bare answers need the matching explicit dialogue slot',()=>{
 assert.equal(parse('Тестовый куб').kind,'help');
 assert.deepEqual(parse('Тестовый куб',{awaiting:'file'}),{kind:'followup',query:'тестовый куб'});
 assert.deepEqual(parse('Файл тестовый куб',{awaiting:'file'}),{kind:'followup',query:'тестовый куб'});
 assert.deepEqual(parse('Тестовый куб на Максе',{awaiting:'file'}),{kind:'followup',query:'тестовый куб',printerHint:'максе'});
 assert.deepEqual(parse('Неизвестный',{awaiting:'printer'}),{kind:'followup',printerHint:'неизвестный'});
 assert.equal(parse('Второй').kind,'help');assert.deepEqual(parse('Второй',{awaiting:'choice'}),{kind:'choose',index:1});
 for(const text of ['Второй','2'])assert.deepEqual(parse(text,{awaiting:'printer'}),{kind:'choose',index:1},text);
 assert.deepEqual(parse('Второй',{awaiting:'file'}),{kind:'followup',query:'второй'});
 assert.deepEqual(parse('42',{awaiting:'file'}),{kind:'followup',query:'42'});
});
test('only explicit filename correction markers can refer back to the failed query',()=>{
 for(const awaiting of ['file','choice'])for(const text of ['Правильно: держатель','Я сказала держатель','Нет, называется держатель','Название — держатель'])assert.deepEqual(parse(text,{awaiting}),{kind:'followup',query:'держатель',correctPreviousQuery:true},text);
 assert.deepEqual(parse('держатель',{awaiting:'file'}),{kind:'followup',query:'держатель'});
 assert.deepEqual(parse('файл держатель',{awaiting:'file'}),{kind:'followup',query:'держатель'});
 for(const text of ['Правильно: держатель','Я сказала держатель','Название — держатель'])assert.equal(parse(text).kind,'help',text);
 assert.equal(parse('Нет, называется держатель').kind,'help');
 assert.deepEqual(parse('Нет, лучше на K1C',{awaiting:'file'}),{kind:'followup',printerHint:'k1c'});
 assert.deepEqual(parse('Нет',{awaiting:'choice'}),{kind:'cancel'});
 assert.equal(parse('Правильно не печатай',{awaiting:'file'}).kind,'help');
 assert.deepEqual(parse('Найди файл название держатель',{awaiting:'file'}),{kind:'find',query:'название держатель',printerHint:''});
});
test('future stock questions keep their text and explicit context flags',()=>{
 for(const text of ['А сколько пластика останется после этой печати?','Сколько пластика останется после этого файла?']){
  const intent=parse(text);assert.equal(intent.kind,'stock');assert.equal(intent.afterPrint,true);assert.equal(intent.usePreviousPrinter,true);assert(intent.query.includes('пластика'));
 }
 assert.deepEqual(parse('Сколько у меня пластика?'),{kind:'stock',query:'сколько у меня пластика'});
 const stock=parse('Сколько пластика на этом принтере?');assert.equal(stock.kind,'stock');assert.equal(stock.usePreviousPrinter,true);assert.equal(stock.afterPrint,undefined);
});
test('implicit future balance asks about the selected print without inventing a file',()=>{
 assert.deepEqual(parse('А сколько пластика останется?'),{kind:'stock',query:'а сколько пластика останется',afterPrint:true});
 assert.deepEqual(parse('А сколько у меня пластика осталось?'),{kind:'stock',query:'а сколько у меня пластика осталось'});
 assert.deepEqual(parse('Найди файл сколько пластика останется'),{kind:'find',query:'сколько пластика останется',printerHint:''});
});
test('filename words, prepositions and trailing verbs do not steal the primary action',()=>{
 for(const query of ['запас пластика','проверь печать','тест напечатай','напечатай куб','поставь куб на печать'])assert.deepEqual(parse('Найди файл '+query),{kind:'find',query,printerHint:''},query);
 assert.deepEqual(parse('Напечатай файл этот корпус на K1 Max'),print('этот корпус','k1 max'));
 assert.deepEqual(parse('Найди файл этот файл'),{kind:'find',query:'этот файл',printerHint:''});
 assert.deepEqual(parse('K1 Max напечатай крепление на стену'),print('крепление на стену','k1 max'));
 assert.deepEqual(parse('Напечатай крепление на стену на K1 Max'),print('крепление на стену','k1 max'));
 assert.deepEqual(parse('Напечатай корпус на принтере Неизвестный'),print('корпус','неизвестный'));
});
test('negative and conflicting commands cannot produce a file action',()=>{
 for(const text of ['Не хочу тестовый куб напечатать','Тестовый куб не печатай','Неизвестный напечатай запасной корпус','Напечатай корпус и не запускай печать','Найди корпус и проверь печать','Напечатай корпус и напечатай куб','K1 Max напечатай корпус на K1C','Нет, напечатай корпус'])assert.equal(parse(text).kind,'help',text);
 for(const text of ['K1 Max напечатай это на том же принтере','K1 Max напечатай это на другом принтере'])assert.equal(parse(text).kind,'help',text);
});
test('confirmation remains an exact independent command in every dialogue slot',()=>{
 for(const context of [{},{awaiting:'file'},{awaiting:'printer'},{awaiting:'choice'}]){
  assert.deepEqual(parse('Подтверждаю печать',context),{kind:'confirm'});
  for(const text of ['Хочу подтвердить печать','Можешь подтвердить печать','На K1 Max подтверждаю печать','Давай подтвердим печать','Напечатай корпус и подтверждаю печать'])assert.equal(parse(text,context).kind,'help',text);
 }
 assert.notEqual(parse('Да').kind,'confirm');assert.deepEqual(parse('Проверь запуск'),{kind:'check'});
});
test('free-only and count queries keep their scope during a file clarification',()=>{
 assert.deepEqual(parse('Какие принтеры свободны?',{awaiting:'file'}),{kind:'printers',filter:'free'});
 assert.deepEqual(parse('Сколько принтеров свободно?'),{kind:'printers',filter:'free',countOnly:true});
 assert.deepEqual(parse('Кто печатает?'),{kind:'printers',filter:'printing'});
 assert.equal(parse('Какие принтеры не свободны?').kind,'help');
});
test('numeric file identifiers remain exact under all spelling suggestions',()=>{
 assert(voiceFileMatches('корпус_A42.gcode','корпус a42'));assert(voiceFileNearMatch('корпус_A42.gcode','кор пусс a42'));
 for(const query of ['корпус a4','корпус a43','кор пусс a43','корпус 42']){assert.equal(voiceFileMatches('корпус_A42.gcode',query),false);assert.equal(voiceFileNearMatch('корпус_A42.gcode',query),false)}
});
if(process.env.KF_VOICE_LANGUAGE_PROOF)fs.writeFileSync(process.env.KF_VOICE_LANGUAGE_PROOF,JSON.stringify({passed:true,cases:report.length,report},null,2)+'\n');
console.log(`Voice language: ${report.length} cases passed`);
