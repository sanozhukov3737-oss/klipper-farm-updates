import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {sha256FileSync, FILE_HASH_BUFFER_BYTES} from './large-file-hash.mjs';

const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'kf-file-hash-'));
try {
  // Exercise zero bytes, an exact buffer boundary, and a final partial buffer.
  for (const size of [0, 1, FILE_HASH_BUFFER_BYTES, FILE_HASH_BUFFER_BYTES + 137]) {
    const file = path.join(directory, 'fixture-' + size);
    const data = Buffer.alloc(size);
    for (let index = 0; index < data.length; index++) data[index] = index % 251;
    fs.writeFileSync(file, data);
    assert.equal(sha256FileSync(file), createHash('sha256').update(data).digest('hex'), 'streamed hash differs at ' + size);
  }
  assert.throws(() => sha256FileSync(path.join(directory, 'missing')), /ENOENT/);
  const fileIndex = process.argv.indexOf('--large-file');
  const shaIndex = process.argv.indexOf('--sha256');
  if (fileIndex >= 0 || shaIndex >= 0) {
    assert(fileIndex >= 0 && shaIndex >= 0, 'Use --large-file PATH --sha256 EXPECTED');
    const file = process.argv[fileIndex + 1], expected = process.argv[shaIndex + 1];
    assert(file && /^[0-9a-f]{64}$/.test(expected), 'Invalid large-file verification arguments');
    const bytes = fs.statSync(file).size;
    assert(bytes > 2 ** 31 - 1, 'Large-file test must exercise the readFileSync limit');
    const actual = sha256FileSync(file);
    assert.equal(actual, expected, 'Actual large model checksum differs');
    const peakResidentBytes = process.resourceUsage().maxRSS * 1024;
    assert(peakResidentBytes > 0 && peakResidentBytes < 192 * 1024 * 1024, 'Large-file hashing exceeded the memory bound');
    console.log(JSON.stringify({passed: true, bytes, sha256: actual, bufferBytes: FILE_HASH_BUFFER_BYTES,
      peakResidentBytes, heapLimitFlag: process.execArgv.find(value => value.startsWith('--max-old-space-size=')) ?? null}));
  }
  console.log('Streaming file hashing passed: empty, one byte, exact block, partial block and missing file');
} finally {
  fs.rmSync(directory, {recursive: true, force: true});
}
