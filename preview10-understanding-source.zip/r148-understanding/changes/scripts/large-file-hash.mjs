import {createHash} from 'node:crypto';
import {openSync, readSync, closeSync} from 'node:fs';

// A model sidecar may exceed Node's readFileSync limit of 2^31 - 1 bytes.
// Reuse one buffer so source manifests still bind every byte without loading
// the model into the JavaScript heap or allocating a file-sized Buffer.
export const FILE_HASH_BUFFER_BYTES = 4 * 1024 * 1024;
export function sha256FileSync(file) {
  const hash = createHash('sha256');
  const buffer = Buffer.allocUnsafe(FILE_HASH_BUFFER_BYTES);
  const descriptor = openSync(file, 'r');
  try {
    for (;;) {
      const bytes = readSync(descriptor, buffer, 0, buffer.length, null);
      if (bytes === 0) break;
      hash.update(buffer.subarray(0, bytes));
    }
  } finally {
    closeSync(descriptor);
  }
  return hash.digest('hex');
}
