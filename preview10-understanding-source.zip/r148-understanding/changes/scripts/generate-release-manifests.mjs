import { readdirSync, statSync, writeFileSync } from 'node:fs';
import { relative, resolve, sep } from 'node:path';
import { sha256FileSync } from './large-file-hash.mjs';

const root=resolve(import.meta.dirname,'..');
const slash=value=>value.split(sep).join('/');
const hash=sha256FileSync;
const walkExcludedPrefixes=['.git/','node_modules/','src-tauri/target/','.klipper-build-cache/','INSTALLER/','src-tauri/binaries/','rv/'];
const excludedNames=new Set(['.DS_Store','Thumbs.db','desktop.ini']);

const walk=directory=>readdirSync(directory,{withFileTypes:true}).flatMap(entry=>{
  const absolute=resolve(directory,entry.name);
  const rel=slash(relative(root,absolute));
  if(walkExcludedPrefixes.some(prefix=>rel===prefix.slice(0,-1)||rel.startsWith(prefix)))return [];
  if(excludedNames.has(entry.name))return [];
  if(entry.isDirectory())return walk(absolute);
  if(entry.isFile())return [absolute];
  return [];
});

const offlineRoots=[
  '.cargo/config.toml',
  'dist',
  'offline-tools/nsis',
  'offline-tools/rust/rust-vendor-v1144.tar.gz',
  'offline-tools/tauri-cli/node_modules',
  'src-tauri/tauri.offline.conf.json',
];
const offlineFiles=offlineRoots.flatMap(item=>{
  const absolute=resolve(root,item);
  return statSync(absolute).isDirectory()?walk(absolute):[absolute];
}).sort((a,b)=>slash(relative(root,a))<slash(relative(root,b))?-1:slash(relative(root,a))>slash(relative(root,b))?1:0);
const offlineBody=offlineFiles.map(file=>`${hash(file)} *${slash(relative(root,file))}`).join('\n');
writeFileSync(resolve(root,'OFFLINE-PAYLOAD-SHA256.txt'),`# Verified fully offline Windows build payload.\n# Format: SHA-256 *relative/path\n${offlineBody}\n`);

const excluded=new Set([
  'MANIFEST-SHA256.txt',
  'tsconfig.tsbuildinfo',
  'éÇåìÄ_æìÇùÇïÇ_ÅÉÄùêÆÇÆ£.txt', // replaced by portable LEGACY-INSTALL-NOTES-v1.1.1.txt
]);
const allFiles=walk(root).filter(file=>{
  const rel=slash(relative(root,file));
  return !excluded.has(rel)
    &&!excludedNames.has(file.split(sep).at(-1))
    &&!rel.startsWith('.git/')
    &&!rel.startsWith('node_modules/')
    &&!rel.startsWith('src-tauri/target/')
    &&!rel.startsWith('.klipper-build-cache/')
    &&!rel.startsWith('INSTALLER/')
    &&!rel.startsWith('src-tauri/binaries/')
    &&!rel.startsWith('rv/');
}).sort((a,b)=>slash(relative(root,a))<slash(relative(root,b))?-1:slash(relative(root,a))>slash(relative(root,b))?1:0);
const manifestBody=allFiles.map(file=>`${hash(file)} *${slash(relative(root,file))}`).join('\n');
writeFileSync(resolve(root,'MANIFEST-SHA256.txt'),`${manifestBody}\n`);

console.log(`Offline payload manifest: ${offlineFiles.length} files`);
console.log(`Release manifest: ${allFiles.length} files`);
