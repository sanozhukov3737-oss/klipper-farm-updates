#!/usr/bin/env node
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

const root=path.resolve(import.meta.dirname,'..');
const required=name=>{
  const value=process.env[name];
  if(!value)throw new Error(`${name} is required`);
  return value;
};
const artifactPath=path.resolve(required('KF_UPDATE_ARTIFACT'));
const keyPath=path.resolve(required('KF_UPDATE_SIGNING_KEY'));
const sequence=Number(required('KF_UPDATE_SEQUENCE'));
const version=required('KF_UPDATE_VERSION');
const channel=process.env.KF_UPDATE_CHANNEL??'stable';
const artifactUrl=required('KF_UPDATE_ARTIFACT_URL');
const releaseNotes=process.env.KF_UPDATE_RELEASE_NOTES??null;
const trustedChannel=JSON.parse(fs.readFileSync(path.join(root,'UPDATE-CHANNEL.json'),'utf8').replace(/^\uFEFF/,''));
if(!/^[0-9a-f]{64}$/.test(trustedChannel.publicKeyHex))throw new Error('Invalid embedded update trust key');
const validIdentifiers=(value,rejectNumericLeadingZero)=>Boolean(value)&&value.split('.').every(identifier=>
  Boolean(identifier)
  &&/^[0-9A-Za-z-]+$/.test(identifier)
  &&!(rejectNumericLeadingZero&&/^\d+$/.test(identifier)&&identifier.length>1&&identifier.startsWith('0'))
);
const validSemver=value=>{
  if(!value||value.length>64||!/^[\x00-\x7F]+$/.test(value))return false;
  const plus=value.indexOf('+');
  const withoutBuild=plus<0?value:value.slice(0,plus);
  const build=plus<0?null:value.slice(plus+1);
  if(build!==null&&(!validIdentifiers(build,false)||build.includes('+')))return false;
  const dash=withoutBuild.indexOf('-');
  const core=dash<0?withoutBuild:withoutBuild.slice(0,dash);
  const prerelease=dash<0?null:withoutBuild.slice(dash+1);
  if(prerelease!==null&&!validIdentifiers(prerelease,true))return false;
  const parts=core.split('.');
  return parts.length===3&&parts.every(part=>/^(0|[1-9]\d*)$/.test(part));
};
if(!Number.isSafeInteger(sequence)||sequence<=0)throw new Error('KF_UPDATE_SEQUENCE must be a positive safe integer');
if(!validSemver(version))throw new Error('KF_UPDATE_VERSION is not strict SemVer');
if(!['stable','beta'].includes(channel))throw new Error('KF_UPDATE_CHANNEL must be stable or beta');
if(artifactUrl.length>2048)throw new Error('Artifact URL is too long');
if(releaseNotes!==null&&(releaseNotes.length>8192||releaseNotes.includes('\0')))throw new Error('Release notes are too large or contain NUL');
const parsedUrl=new URL(artifactUrl);
if(parsedUrl.protocol!=='https:'||parsedUrl.username||parsedUrl.password||parsedUrl.hash)throw new Error('Artifact URL must be credential-free HTTPS');

const keyStat=fs.lstatSync(keyPath);
if(keyStat.isSymbolicLink()||!keyStat.isFile()||keyStat.size<=0||keyStat.size>64*1024)throw new Error('Publisher key must be a regular file no larger than 64 KiB');
const privateKeyBytes=fs.readFileSync(keyPath);
let privateKey;
try{
  privateKey=crypto.createPrivateKey(privateKeyBytes);
}finally{
  privateKeyBytes.fill(0);
}
if(privateKey.asymmetricKeyType!=='ed25519')throw new Error('Publisher key must be Ed25519');
const publicDer=crypto.createPublicKey(privateKey).export({format:'der',type:'spki'});
const publicRaw=publicDer.subarray(publicDer.length-32);
if(publicRaw.length!==32)throw new Error('Could not extract Ed25519 public key');
if(publicRaw.toString('hex')!==trustedChannel.publicKeyHex)throw new Error('Publisher key does not match the existing application trust key');
const signerKeyId=crypto.createHash('sha256').update(publicRaw).digest('hex').slice(0,32);
const artifactStat=fs.lstatSync(artifactPath);
if(artifactStat.isSymbolicLink()||!artifactStat.isFile()||artifactStat.size<=0||artifactStat.size>512*1024*1024||path.extname(artifactPath).toLowerCase()!=='.exe'){
  throw new Error('Update artifact must be a regular .exe between 1 byte and 512 MiB, as required by the installed updater');
}
const artifactHasher=crypto.createHash('sha256');
let artifactBytes=0;
for await(const chunk of fs.createReadStream(artifactPath,{highWaterMark:1024*1024})){
  artifactBytes+=chunk.length;
  if(artifactBytes>artifactStat.size)throw new Error('Update artifact changed while hashing');
  artifactHasher.update(chunk);
}
if(artifactBytes!==artifactStat.size)throw new Error('Update artifact changed while hashing');
const sourceEpoch=Number(process.env.SOURCE_DATE_EPOCH??Math.floor(Date.now()/1000));
if(!Number.isSafeInteger(sourceEpoch)||sourceEpoch<=0||sourceEpoch>Math.floor(Number.MAX_SAFE_INTEGER/1000))throw new Error('SOURCE_DATE_EPOCH must be a positive safe whole second');
const unsigned={
  schemaVersion:1,
  channel,
  sequence,
  version,
  publishedAt:sourceEpoch*1000,
  artifact:{
    url:artifactUrl,
    sha256:artifactHasher.digest('hex'),
    sizeBytes:artifactBytes,
  },
  releaseNotes,
  signerKeyId,
};
const signingBytes=Buffer.concat([Buffer.from('klipper-farm-update-manifest-v1\0'),Buffer.from(JSON.stringify(unsigned))]);
const signatureHex=crypto.sign(null,signingBytes,privateKey).toString('hex');
const manifest={...unsigned,signatureHex};
const output=path.resolve(process.env.KF_UPDATE_MANIFEST??path.join(root,'update-v20.json'));
const samePath=(left,right)=>process.platform==='win32'?left.toLowerCase()===right.toLowerCase():left===right;
if(samePath(output,artifactPath)||samePath(output,keyPath))throw new Error('Update manifest must not overwrite the artifact or publisher key');
if(fs.existsSync(output)){
  const outputStat=fs.lstatSync(output);
  if(outputStat.isSymbolicLink()||!outputStat.isFile())throw new Error('Update manifest output must be a regular file');
}
const manifestBytes=Buffer.from(`${JSON.stringify(manifest,null,2)}\n`);
if(manifestBytes.length>64*1024)throw new Error('Signed update manifest exceeds 64 KiB');
const temporary=`${output}.${process.pid}.${crypto.randomBytes(6).toString('hex')}.tmp`;
try{
  fs.writeFileSync(temporary,manifestBytes,{mode:0o600,flag:'wx'});
  fs.renameSync(temporary,output);
}finally{
  fs.rmSync(temporary,{force:true});
}
process.stdout.write(`Signed V20 manifest ${output}\npublic key (embed at build time): ${publicRaw.toString('hex')}\nkey id: ${signerKeyId}\n`);
