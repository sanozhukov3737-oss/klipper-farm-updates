import assert from 'node:assert/strict';
import fs from 'node:fs';
import {build} from 'esbuild';

const compiled=await build({stdin:{contents:"export {MoonrakerClient} from './src/lib/moonraker';export {executeVoicePrinterControl} from './src/lib/voicePrinterControls';",resolveDir:process.cwd(),loader:'ts'},bundle:true,write:false,format:'esm',platform:'node',target:'node22'});
const {MoonrakerClient,executeVoicePrinterControl}=await import('data:text/javascript;base64,'+Buffer.from(compiled.outputFiles[0].text).toString('base64'));
globalThis.window={setTimeout:callback=>setTimeout(callback,0),clearTimeout};
const results=[];
const test=async(name,check)=>{await check();results.push({name,passed:true});console.log('PASS',name)};
function fixture(target={kind:'pin',name:'case_light',object:'output_pin case_light',scale:1}){
 const client=Object.create(MoonrakerClient.prototype),data={queued:[],rpc:[],creality:[],reads:0,discovery:0,valid:true,guards:0,applied:[],flushes:0,job:{print_stats:{state:'printing',filename:'/usr/data/принтер/держатель.gcode'},virtual_sdcard:{is_active:true}}};
 client.config={id:'max',host:'192.168.1.10'};client.connectionEpoch=1;
 client.lightTarget=target;
 client.runControlRequest=(work,label)=>new Promise((resolve,reject)=>{data.queued.push({label,run:()=>Promise.resolve().then(work).then(resolve,reject)})});
 client.rpc=async(method,args)=>{data.rpc.push({method,args});return method==='printer.objects.query'?{status:data.job}:{result:'ok'}};
 client.applyStatus=status=>{data.applied.push(status)};client.flushStatus=()=>{data.flushes++};
 client.crealityLight=async on=>{data.creality.push(on);return{supported:true,on}};
 client.readLightStatus=async()=>{data.reads++;return{supported:true,on:true}};
 client.authorizationError=()=>false;
 const guard=()=>{data.guards++;if(!data.valid)throw Error('Request no longer applies')};
 const flush=async()=>{const next=data.queued.shift();assert(next,'control must be queued');await next.run()};
 return{client,data,guard,flush};
}
await test('actual pause and resume check applicability inside their deferred control worker',async()=>{
 for(const method of ['pause','resume']){
  const f=fixture(),pending=f.client[method](f.guard),rejected=assert.rejects(pending,/no longer applies/);
  assert.equal(f.data.guards,0);assert.equal(f.data.queued.length,1);assert.equal(f.data.rpc.length,0);
  f.data.valid=false;await f.flush();await rejected;assert.equal(f.data.guards,1);assert.equal(f.data.rpc.length,0);
 }
});
await test('actual pause and resume each dispatch their one exact RPC when the queued guard passes',async()=>{
 for(const method of ['pause','resume']){
  const f=fixture(),pending=f.client[method](f.guard);await f.flush();await pending;
  assert.deepEqual(f.data.rpc,[{method:'printer.print.'+method,args:undefined}]);assert.equal(f.data.guards,1);assert.equal(f.data.queued.length,0);
 }
});
await test('legacy pause and resume callers remain supported without a voice guard',async()=>{
 for(const method of ['pause','resume']){
  const f=fixture(),pending=f.client[method]();await f.flush();await pending;assert.equal(f.data.rpc.length,1);assert.equal(f.data.guards,0);
 }
});
await test('a cancelled light request is rejected before discovery or queueing',async()=>{
 const f=fixture(undefined);f.client.lightTarget=undefined;f.client.lightStatus=async()=>{f.data.discovery++;return{supported:true}};f.data.valid=false;
 await assert.rejects(f.client.light(true,f.guard),/no longer applies/);assert.equal(f.data.discovery,0);assert.equal(f.data.queued.length,0);assert.equal(f.data.rpc.length,0);assert.equal(f.data.creality.length,0);
});
await test('actual light rechecks after asynchronous discovery before scheduling its write',async()=>{
 const f=fixture();f.client.lightTarget=undefined;let discovered;
 f.client.lightStatus=()=>{f.data.discovery++;return new Promise(resolve=>{discovered=()=>{f.client.lightTarget={kind:'pin',name:'case_light',object:'output_pin case_light',scale:1};resolve({supported:true})}})};
 const pending=f.client.light(true,f.guard),rejected=assert.rejects(pending,/no longer applies/);
 assert.equal(f.data.guards,1);assert.equal(f.data.discovery,1);assert.equal(f.data.queued.length,0);
 f.data.valid=false;discovered();await rejected;assert.equal(f.data.guards,2);assert.equal(f.data.queued.length,0);assert.equal(f.data.rpc.length,0);
});
await test('actual G-code light checks its guard again inside the deferred write worker',async()=>{
 for(const target of [{kind:'pin',name:'case_light',object:'output_pin case_light',scale:1},{kind:'macro',onCommand:'LIGHT_ON',offCommand:'LIGHT_OFF'}]){
  const f=fixture(target),pending=f.client.light(true,f.guard),rejected=assert.rejects(pending,/no longer applies/);
  assert.equal(f.data.guards,2);assert.equal(f.data.queued.length,1);f.data.valid=false;
  await f.flush();await rejected;assert.equal(f.data.guards,3);assert.equal(f.data.rpc.length,0);assert.equal(f.data.reads,0);
 }
});
await test('the native Creality light channel has the same deferred pre-dispatch guard',async()=>{
 const f=fixture({kind:'creality'}),pending=f.client.light(false,f.guard),rejected=assert.rejects(pending,/no longer applies/);
 assert.equal(f.data.guards,2);assert.equal(f.data.queued[0].label,'control.light.creality');f.data.valid=false;
 await f.flush();await rejected;assert.equal(f.data.guards,3);assert.deepEqual(f.data.creality,[]);assert.equal(f.data.rpc.length,0);
});
await test('an allowed actual light mutation sends one approved command and returns readback',async()=>{
 const f=fixture(),pending=f.client.light(true,f.guard);await f.flush();const result=await pending;
 assert.equal(result.on,true);assert.equal(f.data.guards,3);assert.equal(f.data.reads,1);assert.deepEqual(f.data.rpc,[{method:'printer.gcode.script',args:{script:'SET_PIN PIN=case_light VALUE=1'}}]);
});
await test('actual light transport failure cannot replay the mutation',async()=>{
 const f=fixture();f.client.rpc=async(method,args)=>{f.data.rpc.push({method,args});throw Error('transport result unknown')};
 const pending=f.client.light(true,f.guard),rejected=assert.rejects(pending,/transport result unknown/);await f.flush();await rejected;
 assert.equal(f.data.rpc.length,1);assert.equal(f.data.queued.length,0);assert.equal(f.data.reads,0);
});
await test('actual light readback retries reads only and rejects an unchanged device state',async()=>{
 const f=fixture();f.client.readLightStatus=async()=>{f.data.reads++;return{supported:true,on:false}};
 const pending=f.client.light(true,f.guard),rejected=assert.rejects(pending,/не подтвердил переключение/);await f.flush();await rejected;
 assert.equal(f.data.rpc.length,1);assert.equal(f.data.reads,3);assert.equal(f.data.queued.length,0);
});
const readJob=async(f,path)=>{const pending=f.client.checkPrintJob(path);await f.flush();return pending};
await test('actual existing-job reads preserve absolute and non-ASCII paths without a filename endpoint',async()=>{
 for(const path of ['/usr/data/принтер/держатель.gcode','C:\\Моя ферма\\детали\\корпус.gcode','детали/держатель%2Fлевый.gcode']){
  const f=fixture();f.data.job.print_stats.filename=path;const result=await readJob(f,path);
  assert.equal(result.confirmed,true,path);assert.equal(result.filename,path);assert.equal(result.state,'printing');
  assert.deepEqual(f.data.rpc,[{method:'printer.objects.query',args:{objects:{print_stats:null,virtual_sdcard:null}}}]);
  assert.equal(f.data.applied.length,1);assert.equal(f.data.flushes,1);assert.equal(f.data.creality.length,0);
 }
});
await test('existing-job identity normalizes separators and Unicode but not directory, case or escapes',async()=>{
 for(const [expected,actual,confirmed] of [
  ['/данные/йога.gcode','\\данные\\и\u0306ога.gcode',true],
  ['/данные/один/держатель.gcode','/данные/два/держатель.gcode',false],
  ['/данные/Держатель.gcode','/данные/держатель.gcode',false],
  ['детали/держатель%2Fлевый.gcode','детали/держатель/левый.gcode',false],
  ['/данные/держатель.gcode','держатель.gcode',false],
 ]){
  const f=fixture();f.data.job.print_stats.filename=actual;const result=await readJob(f,expected);assert.equal(result.confirmed,confirmed,JSON.stringify([expected,actual]));assert.equal(f.data.rpc.length,1);
 }
});
await test('idle, missing-state, mismatched and empty jobs are never confirmed',async()=>{
 for(const job of [
  {print_stats:{state:'standby',filename:'part.gcode'}},
  {print_stats:{state:'complete',filename:'part.gcode'}},
  {print_stats:{filename:'part.gcode'},virtual_sdcard:{is_active:true}},
  {print_stats:{state:'printing',filename:'different.gcode'}},
  {print_stats:{state:'printing',filename:''}},
  {},
 ]){const f=fixture();f.data.job=job;assert.equal((await readJob(f,'part.gcode')).confirmed,false);assert.equal(f.data.rpc.length,1);}
});
await test('a paused job can be confirmed using a supplied virtual-SD full path',async()=>{
 const f=fixture();f.data.job={print_stats:{state:'paused'},virtual_sdcard:{file_path:'/data/держатель.gcode'}};
 const result=await readJob(f,'/data/держатель.gcode');assert.equal(result.confirmed,true);assert.equal(result.state,'paused');assert.equal(f.data.rpc[0].method,'printer.objects.query');
});
await test('invalid existing-job identities are rejected before queueing or querying',async()=>{
 for(const value of ['',null,'  ','part\u0000.gcode','x'.repeat(4097)]){
  const f=fixture();await assert.rejects(f.client.checkPrintJob(value),/корректного имени/);assert.equal(f.data.queued.length,0);assert.equal(f.data.rpc.length,0);
 }
});
await test('a changed printer connection before an existing-job worker starts blocks its query',async()=>{
 for(const changed of ['id','host','epoch']){
  const f=fixture(),pending=f.client.checkPrintJob('/data/part.gcode'),rejected=assert.rejects(pending,/Подключение принтера изменилось/);
  if(changed==='id')f.client.config.id='another';if(changed==='host')f.client.config.host='192.168.1.99';if(changed==='epoch')f.client.connectionEpoch++;
  await f.flush();await rejected;assert.equal(f.data.rpc.length,0);assert.equal(f.data.applied.length,0);
 }
});
await test('a changed connection while awaiting job data cannot apply or confirm the late observation',async()=>{
 for(const changed of ['host','epoch']){
  const f=fixture();let release,entered=false;
  f.client.rpc=async(method,args)=>{f.data.rpc.push({method,args});entered=true;return new Promise(resolve=>{release=()=>resolve({status:f.data.job})})};
  const pending=f.client.checkPrintJob(f.data.job.print_stats.filename),rejected=assert.rejects(pending,/Подключение принтера изменилось/),flushing=f.flush();
  await new Promise(resolve=>setImmediate(resolve));assert.equal(entered,true);
  if(changed==='host')f.client.config.host='192.168.1.99';else f.client.connectionEpoch++;
  release();await flushing;await rejected;assert.equal(f.data.rpc.length,1);assert.equal(f.data.applied.length,0);assert.equal(f.data.flushes,0);
 }
});
await test('a failed existing-job query has no cached-success fallback or write',async()=>{
 const f=fixture();f.client.rpc=async(method,args)=>{f.data.rpc.push({method,args});throw Error('read failed')};
 const pending=f.client.checkPrintJob('/data/part.gcode'),rejected=assert.rejects(pending,/read failed/);await f.flush();await rejected;
 assert.deepEqual(f.data.rpc.map(row=>row.method),['printer.objects.query']);assert.equal(f.data.applied.length,0);
});
await test('absolute-path pause and resume use the actual existing-job reader before and after one write',async()=>{
 for(const action of ['pause','resume']){
  const f=fixture(),path='/usr/data/Клипер ферма/держатель.gcode',p={id:'max',name:'Макс',host:f.client.config.host,profile:{preset:'creality-k1-max'},webcams:[],status:{state:action==='pause'?'printing':'paused',connectionState:'online',filename:path,progress:.5,printDuration:600}};
  f.data.job={print_stats:{state:p.status.state,filename:path},virtual_sdcard:{is_active:true}};
  f.client.runControlRequest=work=>Promise.resolve().then(work);
  f.client.checkPrintStart=()=>{throw Error('relative print-start reader must not be called')};
  f.client.rpc=async(method,args)=>{
   f.data.rpc.push({method,args});
   if(method==='printer.objects.query')return{status:{print_stats:{...f.data.job.print_stats},virtual_sdcard:{is_active:true}}};
   assert.equal(method,'printer.print.'+action);f.data.job.print_stats.state=action==='pause'?'paused':'printing';return{result:'ok'};
  };
  f.client.applyStatus=status=>{f.data.applied.push(status);p.status.state=status.print_stats.state;p.status.filename=status.print_stats.filename};
  const result=await executeVoicePrinterControl(p,action,{printers:()=>[p],client:()=>f.client,canOperate:()=>true,assertActive(){}},new AbortController().signal);
  assert.equal(result.confirmed,true);assert.deepEqual(f.data.rpc.map(row=>row.method),['printer.objects.query','printer.print.'+action,'printer.objects.query']);assert.equal(f.data.applied.length,2);
  assert(f.data.rpc.every(row=>row.method!=='printer.print.start'&&row.method!=='printer.gcode.script'));
 }
});
if(process.env.KF_VOICE_CONTROL_TRANSPORT_PROOF)fs.writeFileSync(process.env.KF_VOICE_CONTROL_TRANSPORT_PROOF,JSON.stringify({passed:true,cases:results.length,actualMoonrakerMethods:true,networkRequests:false,physicalPrintersTested:false,results},null,2)+'\n');
console.log('Voice control transport:',results.length,'cases passed');
