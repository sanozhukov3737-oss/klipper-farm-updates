import assert from 'node:assert/strict';
import {build} from 'esbuild';
import fs from 'node:fs';
const compiled=await build({stdin:{contents:"export {VoiceAssistant} from './src/lib/voiceAssistant';export * from './src/lib/voiceCommands';export {emptyFilamentInventory} from './src/lib/filamentInventory';export {profileForPreset} from './src/lib/printerProfile';export {MoonrakerClient} from './src/lib/moonraker';export {offlineRussianVoice,speakOffline} from './src/lib/offlineSpeech';",resolveDir:process.cwd(),loader:'ts'},bundle:true,write:false,format:'esm',platform:'node'});
globalThis.window=new EventTarget();globalThis.document=new EventTarget();globalThis.localStorage={getItem:()=>null,setItem:()=>{}};
const {VoiceAssistant,parseVoiceCommand,voicePrinterMatches,voiceFileMatches,voiceFileNearMatch,emptyFilamentInventory,profileForPreset,MoonrakerClient,offlineRussianVoice,speakOffline}=await import('data:text/javascript;base64,'+Buffer.from(compiled.outputFiles[0].text).toString('base64'));
const report=[];const test=async(name,fn)=>{await fn();report.push({name,passed:true});console.log('PASS',name)};
const printer=(id='max',name='K1 Max',preset='creality-k1-max')=>({id,name,host:'192.168.1.10',profile:profileForPreset(preset),status:{state:'ready',connectionState:'online'},webcams:[]});
function fixture(){
 const data={printers:[printer()],role:true,clock:1_000_000,upload:0,start:0,checks:0,ready:0,list:0,client:{},audit:0,files:[{path:'корпус/Корпус.gcode',size:150}],inventory:emptyFilamentInventory()};
 const deps={printers:()=>data.printers,canOperate:()=>data.role,client:()=>data.client,now:()=>data.clock,list:async()=>{data.list++;return data.files},inventory:async()=>data.inventory,validate:async()=>({sha256:'a'.repeat(64),report:{ok:true,issues:[]}}),ready:async()=>{data.ready++},upload:async(p,proposal)=>{assert.equal(proposal.sha256,'a'.repeat(64));data.upload++;return proposal.candidate.entry.path},start:async()=>{data.start++},check:async()=>{data.checks++;return true},audit:async()=>{data.audit++}};
 return{data,deps,assistant:new VoiceAssistant(deps)};
}
await test('Russian print phrases and spoken printer aliases',()=>{
 for(const text of ['Напечатай корпус на кей один макс','Найди корпус и поставь на печать на K1 Max','Поставь на печать корпус на K1 Max'])assert.deepEqual(parseVoiceCommand(text),{kind:'print',query:'корпус',printerHint:'k1 max'});
 assert.deepEqual(parseVoiceCommand('найди корпус и поставь на печать'),{kind:'print',query:'корпус',printerHint:''});
 assert.equal(voicePrinterMatches([printer()], 'кей один макс').length,1);assert(voiceFileMatches('details/korpus.gcode','корпус'));
 assert.deepEqual(parseVoiceCommand('напечатать корпус на принтере макс'),{kind:'print',query:'корпус',printerHint:'max'});
 assert.deepEqual(parseVoiceCommand('напечатаю корпус на принтере макс'),{kind:'print',query:'корпус',printerHint:'max'});
 assert.equal(voicePrinterMatches([printer()],'макс').length,1);
 assert.equal(parseVoiceCommand('да').kind,'help');assert.equal(parseVoiceCommand('не подтверждаю печать').kind,'help');
});
await test('explicit file commands win over stock and recovery words in file titles',async()=>{
 assert.deepEqual(parseVoiceCommand('Напечатай запасной корпус на K1 Max'),{kind:'print',query:'запасной корпус',printerHint:'k1 max'});
 for(const query of ['запас пластика','проверь печать']){
  assert.deepEqual(parseVoiceCommand('Найди файл '+query),{kind:'find',query,printerHint:''});
  const f=fixture();f.data.files=[{path:query+'.gcode',size:150}];f.deps.inventory=async()=>{throw new Error('File search must not read stock')};
  const reply=await f.assistant.handle('Найди файл '+query);assert.equal(reply.choices.length,1);assert(!reply.proposal);assert.equal(f.data.start,0);
 }
 const f=fixture();f.data.files=[{path:'запасной корпус.gcode',size:150}];
 const reply=await f.assistant.handle('Найди запасной корпус и поставь на печать на K1 Max');assert(reply.proposal);assert.equal(f.data.upload,0);assert.equal(f.data.start,0);
 await f.assistant.handle('Подтверждаю печать');assert.equal(f.data.start,1);
 for(const text of ['Проверь печать','Проверить запуск'])assert.deepEqual(parseVoiceCommand(text),{kind:'check'});
 assert.equal(parseVoiceCommand('Сколько осталось пластика?').kind,'stock');
});
await test('invalid or contradictory file commands cannot fall back to stock or recovery',async()=>{
 const f=fixture();
 for(const text of ['Не напечатай запасной корпус на K1 Max','Не найди файл запас пластика','Неизвестный напечатай запасной корпус','Напечатай корпус и не запускай печать','Найди корпус и проверь печать','Напечатай корпус и найди куб','Напечатай корпус и напечатай куб','Проверь запуск и напечатай корпус','Найди корпус и подтверждаю печать']){
  assert.equal(parseVoiceCommand(text,f.data.printers).kind,'help',text);await f.assistant.handle(text);
 }
 assert.equal(parseVoiceCommand('Не проверь печать').kind,'help');
 assert.equal(f.data.list,0);assert.equal(f.data.upload,0);assert.equal(f.data.start,0);
});
await test('ordinary filename prepositions are retained unless the tail names a printer',async()=>{
 const f=fixture();f.data.files=[{path:'крепление на стену.gcode',size:150}];
 assert.deepEqual(parseVoiceCommand('K1 Max напечатай крепление на стену',f.data.printers),{kind:'print',query:'крепление на стену',printerHint:'k1 max'});
 assert.deepEqual(parseVoiceCommand('Напечатай крепление на стену'),{kind:'print',query:'крепление на стену',printerHint:''});
 assert.deepEqual(parseVoiceCommand('Напечатай крепление на стену на K1 Max'),{kind:'print',query:'крепление на стену',printerHint:'k1 max'});
 const reply=await f.assistant.handle('K1 Max напечатай крепление на стену');assert(reply.proposal);assert.equal(f.data.upload,0);assert.equal(f.data.start,0);
 assert.deepEqual(parseVoiceCommand('Напечатай крепление на принтере Неизвестный',f.data.printers),{kind:'print',query:'крепление',printerHint:'неизвестный'});
 assert.match((await f.assistant.handle('Напечатай крепление на принтере Неизвестный')).text,/принтер не найден/);
 f.data.printers[0].name='Левый большой';
 assert.deepEqual(parseVoiceCommand('Напечатай крепление на стену на Левый большой',f.data.printers),{kind:'print',query:'крепление на стену',printerHint:'левый большой'});
 assert.deepEqual(parseVoiceCommand('Напечатай крепление на Левый большой'),{kind:'print',query:'крепление на левый большой',printerHint:''});
 assert.equal(f.data.upload,0);assert.equal(f.data.start,0);
});
await test('natural printer status questions retain the requested scope',()=>{
 for(const text of ['Какие принтеры свободны?','Какие принтеры свободные?','Кто сейчас свободен?','Покажи свободные принтеры','Есть свободные?','Есть ли у нас готовые принтеры?','Какие принтеры готовы к печати?','Кто из принтеров сейчас готов?','Подскажи мне, какие у нас сейчас свободные принтеры?','Покажи мне все готовые принтеры, пожалуйста'])assert.deepEqual(parseVoiceCommand(text),{kind:'printers',filter:'free'},text);
 for(const text of ['Какие принтеры печатают?','Кто сейчас печатает?','Покажи печатающие принтеры','Есть ли печатающие принтеры?','Скажи, какие принтеры сейчас печатают'])assert.deepEqual(parseVoiceCommand(text),{kind:'printers',filter:'printing'},text);
 for(const text of ['Покажи все принтеры','Состояние всех принтеров','Статус всех принтеров','Список принтеров','Какие принтеры есть?','Расскажи мне состояние принтеров'])assert.deepEqual(parseVoiceCommand(text),{kind:'printers',filter:'all'},text);
 for(const text of ['Какие принтеры не свободны?','Какие принтеры не печатают?','Есть не готовые принтеры?','Покажи занятые принтеры','Кто свободен и печатает?'])assert.equal(parseVoiceCommand(text).kind,'help',text);
});
await test('status words inside file commands do not replace file intent',()=>{
 for(const query of ['свободный куб','список принтеров','состояние принтера','какие принтеры свободные'])assert.deepEqual(parseVoiceCommand('Покажи файл '+query),{kind:'find',query,printerHint:''});
 assert.deepEqual(parseVoiceCommand('Найди готовый куб'),{kind:'find',query:'готовый куб',printerHint:''});
 assert.deepEqual(parseVoiceCommand('Напечатай файл состояние принтера на K1 Max'),{kind:'print',query:'состояние принтера',printerHint:'k1 max'});
});
await test('bounded status questions accept natural possessive phrases',()=>{
 for(const text of ['Какие у меня сейчас принтеры свободны?','Кто из моих принтеров свободен?','Покажи мои готовые принтеры','Мой принтер свободен?','Какие наши принтеры готовы?','Кто из наших принтеров печатает?']){
  assert.deepEqual(parseVoiceCommand(text),{kind:'printers',filter:text.includes('печатает')?'printing':'free'},text);
 }
 assert.equal(parseVoiceCommand('Какие из моих принтеров не свободны?').kind,'help');
 assert.deepEqual(parseVoiceCommand('Покажи файл мои принтеры'),{kind:'find',query:'мои принтеры',printerHint:''});
});
await test('how many status questions return only the requested count',async()=>{
 const f=fixture();f.data.printers.push(printer('free2','Второй свободный'),{...printer('busy','Занятый'),status:{state:'printing',connectionState:'online'}},{...printer('paused','Пауза'),status:{state:'paused',connectionState:'online'}},{...printer('offline','Нет связи'),status:{state:'ready',connectionState:'offline'}});
 for(const [text,filter,reply] of [['Сколько принтеров свободно?','free','Сейчас свободны 2 принтера.'],['Сколько моих принтеров сейчас печатают?','printing','Сейчас печатает 1 принтер.'],['Скажи сколько у меня всего принтеров?','all','В ферме 5 принтеров.']]){
  assert.deepEqual(parseVoiceCommand(text),{kind:'printers',filter,countOnly:true},text);assert.equal((await f.assistant.handle(text)).text,reply);
 }
 f.data.printers=[];assert.equal((await f.assistant.handle('Сколько принтеров свободно?')).text,'Свободных принтеров сейчас нет.');assert.equal((await f.assistant.handle('Сколько принтеров?')).text,'В ферме пока нет принтеров.');
 assert.equal(f.data.upload,0);assert.equal(f.data.start,0);
});
await test('free and printing replies contain only live printers in the requested state',async()=>{
 const f=fixture(),make=(id,name,state,connectionState='online',remoteControlSuspended=false)=>({...printer(id,name),status:{state,connectionState,remoteControlSuspended}});
 f.data.printers=[make('free','Свободный','ready'),make('busy','Печатающий','printing'),make('paused','Пауза','paused'),make('error','Ошибка','error'),make('offline','Отключенный','ready','offline'),make('stale','Нет связи с печатающим','printing','offline'),make('suspended','Приостановленное управление','ready','online',true),make('degraded','Слабая связь','ready','degraded')];
 assert.equal((await f.assistant.handle('Какие принтеры свободные?')).text,'Сейчас свободен один принтер: Свободный.');
 assert.equal((await f.assistant.handle('Кто печатает?')).text,'Сейчас печатает: Печатающий.');
 const all=await f.assistant.handle('Покажи все принтеры');for(const p of f.data.printers)assert(all.text.includes(p.name),p.name);
 assert.match(all.text,/Пауза — на паузе/);assert.match(all.text,/Ошибка — ошибка/);assert.match(all.text,/Приостановленное управление — управление приостановлено/);
 assert.equal(f.data.list,0);assert.equal(f.data.ready,0);assert.equal(f.data.upload,0);assert.equal(f.data.start,0);
});
await test('empty status selections do not list other states or start a print',async()=>{
 const f=fixture();f.data.printers[0].status.state='paused';
 assert.equal((await f.assistant.handle('Есть готовые принтеры?')).text,'Свободных принтеров сейчас нет.');
 assert.equal((await f.assistant.handle('Кто печатает?')).text,'Сейчас ни один принтер не печатает.');
 for(const text of ['Какие принтеры не свободны?','Какие принтеры не печатают?']){await f.assistant.handle(text);assert.equal(f.data.start,0)}
 f.data.printers=[];for(const text of ['Есть свободные?','Кто печатает?','Покажи все принтеры'])assert.equal((await f.assistant.handle(text)).text,'В ферме пока нет принтеров');
 assert.equal(f.data.upload,0);assert.equal(f.data.start,0);
});
await test('printer-first commands, spoken Max variants and conflicting targets',async()=>{
 for(const name of ['к1 макс','к1 мах','ка один макс','кей один макс','к1мах','к 1 макс','K1MAX']){
  const text='Принтер '+name+' поставь на печать корпус';
  assert.deepEqual(parseVoiceCommand(text),{kind:'print',query:'корпус',printerHint:'k1 max'});
  const f=fixture(),reply=await f.assistant.handle(text);assert(reply.proposal);assert.equal(f.data.start,0);
 }
 assert.deepEqual(parseVoiceCommand('На принтере K1 Max, напечатай файл корпус, пожалуйста'),{kind:'print',query:'корпус',printerHint:'k1 max'});
 for(const text of ['не напечатай корпус','принтер k1 max не поставь на печать корпус','принтер k1 max напечатай корпус на 5m'])assert.equal(parseVoiceCommand(text).kind,'help');
});
await test('bare printer prefixes use current card names and selected model aliases',async()=>{
 for(const name of ['K1 Max','Кей один макс','Креалите K1 Max','Creality K1 Max','Криалити кей один макс']){
  const f=fixture(),text=name+' поставь на печать корпус',intent=parseVoiceCommand(text,f.data.printers);
  assert.equal(intent.kind,'print',text);assert.equal(voicePrinterMatches(f.data.printers,intent.printerHint).length,1,text);
  const reply=await f.assistant.handle(text);assert(reply.proposal,text);assert.equal(f.data.upload,0);assert.equal(f.data.start,0);
 }
 const f=fixture();f.data.printers[0].name='Левый большой';delete f.data.printers[0].profile;
 f.data.printers[0].modelSelection={mode:'manual',selectedPreset:'creality-k1-max'};
 assert.equal(voicePrinterMatches(f.data.printers,'Креалите K1 Max').length,1);
 assert((await f.assistant.handle('Левый большой напечатай корпус')).proposal);
 assert.equal(parseVoiceCommand('Левый большой напечатай корпус').kind,'help');
 f.data.printers.push({...printer('max2','Левый большой'),modelSelection:{mode:'manual',selectedPreset:'creality-k1-max'}});
 const ambiguous=await f.assistant.handle('Левый большой напечатай корпус');assert.equal(ambiguous.choices.length,2);assert(!ambiguous.proposal);
 for(const text of ['Неизвестный напечатай корпус','K1 Max не напечатай корпус','не K1 Max напечатай корпус','K1 Max напечатай корпус на 5m'])assert.equal(parseVoiceCommand(text,f.data.printers).kind,'help',text);
 assert.equal(f.data.upload,0);assert.equal(f.data.start,0);
});
await test('bounded conversational requests preserve explicit confirmation and negation',async()=>{
 for(const prefix of ['Хочу','Я хочу','Можешь','Можешь ли ты','Можете ли вы','Мне нужно','Мне надо'])assert.deepEqual(parseVoiceCommand(prefix+' напечатать корпус на K1 Max'),{kind:'print',query:'корпус',printerHint:'k1 max'});
 assert.deepEqual(parseVoiceCommand('Можешь найти корпус на K1 Max'),{kind:'find',query:'корпус',printerHint:'k1 max'});
 for(const text of ['Не хочу напечатать корпус','Я не хочу напечатать корпус','Можешь не напечатать корпус','Хочу подтвердить печать','Можешь подтвердить печать'])assert.equal(parseVoiceCommand(text).kind,'help',text);
 const f=fixture();const reply=await f.assistant.handle('Хочу напечатать корпус на K1 Max');assert(reply.proposal);assert.equal(f.data.start,0);
 await f.assistant.handle('Хочу подтвердить печать');assert.equal(f.data.start,0);
});
await test('split words and ASR filler produce suggestions while identifiers stay exact',async()=>{
 const path='детали/корпус_A42.gcode';
 for(const query of ['корп ус a42','корпус и a42']){assert.equal(voiceFileMatches(path,query),false,query);assert.equal(voiceFileNearMatch(path,query),true,query)}
 assert.equal(voiceFileMatches('дополнительно/us/корпус_A42.gcode','корп ус a42'),false);
 assert.equal(voiceFileMatches('детали/korpus_A42.gcode','корпус a42'),true);
 assert.equal(voiceFileMatches('тестовый_куб_A42.gcode','тестовыйкуб a42'),false);
 assert.equal(voiceFileNearMatch('тестовый_куб_A42.gcode','тестовыйкуб a42'),true);
 for(const query of ['корпус a4','корпус a43','корпус a420','корпус 42','корп ус a43','корпус и a4']){assert.equal(voiceFileMatches(path,query),false,query);assert.equal(voiceFileNearMatch(path,query),false,query)}
 const f=fixture();f.data.files=[{path,size:150}];
 for(const query of ['корп ус a42','корпус и a42']){
  const reply=await f.assistant.handle('K1 Max напечатай '+query);assert.equal(reply.choices.length,1);assert(!reply.proposal);assert.equal(f.data.upload,0);
  await f.assistant.handle('Подтверждаю печать');assert.equal(f.data.start,0);
 }
 for(const query of ['корпус a4','корпус a43']){const reply=await f.assistant.handle('K1 Max напечатай '+query);assert.equal(reply.choices.length,0);assert(!reply.proposal)}
 assert.equal(f.data.upload,0);assert.equal(f.data.start,0);
});
await test('many dynamically loaded files stay bounded and require a specific choice',async()=>{
 const f=fixture();f.data.files=Array.from({length:65},(_,index)=>({path:`детали/корпус_A42_вариант${index}.gcode`,size:150}));
 for(const query of ['корпус a42','корп ус a42']){
  const reply=await f.assistant.handle('K1 Max напечатай '+query);assert.equal(reply.choices.length,40);assert(!reply.proposal);assert.match(reply.text,/Показаны первые 40/);
  await f.assistant.handle('Подтверждаю печать');assert.equal(f.data.start,0);
 }
 assert.equal(f.data.upload,0);assert.equal(f.data.start,0);
});
await test('split and misspelled letter spans stay suggestions with exact identifiers',async()=>{
 const cases=[{path:'детали/кронштейн_A42.gcode',query:'крон штеин a42'},{path:'детали/корпус_A42.gcode',query:'кор пусс'},{path:'тестовый_куб_A42.gcode',query:'теставыйкуб a42'}];
 for(const {path,query} of cases){
  assert.equal(voiceFileMatches(path,query),false,query);assert.equal(voiceFileNearMatch(path,query),true,query);
  const f=fixture();f.data.files=[{path,size:150}];
  const reply=await f.assistant.handle('K1 Max напечатай '+query);assert.equal(reply.choices.length,1,query);assert(!reply.proposal);assert.equal(f.data.upload,0);
  await f.assistant.handle('Подтверждаю печать');assert.equal(f.data.start,0,query);
 }
 for(const query of ['крон штеин a43','крон штеин a4','крон штеин a420'])assert.equal(voiceFileNearMatch('кронштейн_A42.gcode',query),false,query);
 const f=fixture();f.data.files=[{path:'кронштейн_A42.gcode',size:150}];
 const wrong=await f.assistant.handle('K1 Max напечатай крон штеин a43');assert.equal(wrong.choices.length,0);assert(!wrong.proposal);assert.equal(f.data.start,0);
 assert.equal(voiceFileNearMatch('корпус_A42.gcode','к а р а п у с a42'),false);
});
await test('misheard file names are suggested and never automatically prepared or launched',async()=>{
 assert.equal(voiceFileMatches('детали/кронштейн.gcode','конштейн'),false);
 assert.equal(voiceFileNearMatch('детали/кронштейн.gcode','конштейн'),true);
 assert.equal(voiceFileNearMatch('корпус A12.gcode','корпус A13'),false);
 assert.equal(voiceFileNearMatch('деталь.gcode','дел'),false);
 const f=fixture();f.data.files=[{path:'детали/кронштейн.gcode',size:150}];
 const r=await f.assistant.handle('Принтер К1 Макс поставь на печать конштейн');
 assert.equal(r.choices.length,1);assert(!r.proposal);assert.equal(f.data.upload,0);
 await f.assistant.handle('Подтверждаю печать');assert.equal(f.data.start,0);
 const selected=await f.assistant.handle('Выбери первый');assert(selected.proposal);assert.equal(f.data.start,0);
 await f.assistant.handle('Подтверждаю печать');assert.equal(f.data.start,1);
});
await test('find never uploads; confirmation requires an explicitly selected proposal',async()=>{const f=fixture();const r=await f.assistant.handle('Найди корпус');assert.equal(r.choices.length,1);await f.assistant.handle('подтверждаю печать');assert.equal(f.data.start,0)});
await test('one selected file, separately confirmed, transfers and starts exactly once',async()=>{const f=fixture();const r=await f.assistant.handle('Напечатай корпус на K1 Max');assert(r.proposal);assert.equal(f.data.start,0);const done=await f.assistant.handle('Подтверждаю печать');assert.match(done.text,/подтвердил запуск/);await f.assistant.handle('Подтверждаю печать');assert.equal(f.data.start,1);assert.equal(f.data.upload,1);assert.equal(f.data.ready,2)});
await test('duplicate names and multiple model printers require explicit choice',async()=>{const f=fixture();f.data.printers.push(printer('max2','Второй Max'));const r=await f.assistant.handle('Напечатай корпус');assert.equal(r.choices.length,2);assert(!r.proposal);const chosen=await f.assistant.handle('Выбери второй');assert.equal(chosen.proposal.candidate.printerId,'max2');assert.equal(f.data.start,0)});
await test('different model libraries are searched once each without cross-model dispatch',async()=>{const f=fixture();f.data.printers.push(printer('5m','5M','flashforge-ad5m'));const r=await f.assistant.handle('Напечатай корпус на пять эм');assert.equal(r.proposal.candidate.printerId,'5m');assert.equal(r.proposal.candidate.scopeId,'model:flashforge-ad5m');assert.equal(f.data.list,1)});
for(const state of ['printing','paused','error','offline'])await test('blocked printer '+state,async()=>{const f=fixture();f.data.printers[0].status.state=state;assert(!(await f.assistant.handle('Напечатай корпус на K1 Max')).proposal);assert.equal(f.data.upload,0)});
await test('viewer cannot prepare or launch',async()=>{const f=fixture();f.data.role=false;assert(!(await f.assistant.handle('Напечатай корпус на K1 Max')).proposal);assert.equal(f.data.start,0)});
await test('expiry and cancellation invalidate confirmation',async()=>{for(const cancel of [false,true]){const f=fixture();await f.assistant.handle('Напечатай корпус на K1 Max');if(cancel)await f.assistant.handle('Отмена');else f.data.clock+=90_001;await f.assistant.handle('Подтверждаю печать');assert.equal(f.data.start,0)}});
for(const mutation of ['host','profile','client','role'])await test('change before confirmation '+mutation,async()=>{const f=fixture();await f.assistant.handle('Напечатай корпус на K1 Max');if(mutation==='host')f.data.printers[0].host='192.168.1.11';if(mutation==='profile')f.data.printers[0].profile=profileForPreset('flashforge-ad5m');if(mutation==='client')f.data.client={};if(mutation==='role')f.data.role=false;await f.assistant.handle('Подтверждаю печать');assert.equal(f.data.upload,0);assert.equal(f.data.start,0)});
await test('target changes during upload never launch on the changed printer',async()=>{const f=fixture();f.deps.upload=async()=>{f.data.printers[0].host='192.168.1.12';return 'корпус.gcode'};await f.assistant.handle('Напечатай корпус на K1 Max');await f.assistant.handle('Подтверждаю печать');assert.equal(f.data.start,0)});
await test('fresh readiness failure stops before upload',async()=>{const f=fixture();f.deps.ready=async()=>{throw new Error('busy')};await f.assistant.handle('Напечатай корпус на K1 Max');await f.assistant.handle('Подтверждаю печать');assert.equal(f.data.upload,0)});
await test('changed file hash cannot be uploaded and started',async()=>{const f=fixture();f.deps.upload=async()=>{throw new Error('SHA256 differs')};await f.assistant.handle('Напечатай корпус на K1 Max');const r=await f.assistant.handle('Подтверждаю печать');assert.match(r.text,/SHA256/);assert.equal(f.data.start,0)});
await test('G-code validation errors block confirmation',async()=>{const f=fixture();f.deps.validate=async()=>({sha256:'x',report:{ok:false,issues:[{level:'error',message:'За пределами стола'}]}});const r=await f.assistant.handle('Напечатай корпус на K1 Max');assert.match(r.text,/пределами/);await f.assistant.handle('Подтверждаю печать');assert.equal(f.data.start,0)});
await test('lost start response permits read-only recovery and never repeats a launch',async()=>{const f=fixture();f.deps.start=async()=>{f.data.start++;throw new Error('PRINT_START_UNCONFIRMED')};await f.assistant.handle('Напечатай корпус на K1 Max');assert((await f.assistant.handle('Подтверждаю печать')).unconfirmed);await f.assistant.handle('Подтверждаю печать');await f.assistant.handle('Напечатай корпус на K1 Max');await f.assistant.handle('Подтверждаю печать');assert.equal(f.data.start,1);const r=await f.assistant.handle('Проверь запуск');assert.match(r.text,/подтверждён/);assert.equal(f.data.checks,1);assert.equal(f.data.upload,1)});
await test('stock uses actual loose stock plus spool balance exactly once',async()=>{const f=fixture();f.data.inventory.materials.PLA.looseGrams=500;f.data.inventory.spools=[{id:'s1',name:'PLA',material:'PLA',remainingWeight:750,initialWeight:1000,price:0,currency:'RUB',createdAt:1}];f.data.inventory.printers.max={binding:{spoolId:'s1'}};assert.match((await f.assistant.handle('Сколько осталось пластика?')).text,/1.250/);assert.match((await f.assistant.handle('Сколько пластика на кей один макс?')).text,/750/)});
await test('stock possessives do not become printer hints or hide an explicit printer',async()=>{
 const f=fixture();f.data.inventory.materials.PLA.looseGrams=500;f.data.inventory.materials.PETG.looseGrams=300;
 f.data.inventory.spools=[{id:'s1',name:'PLA',material:'PLA',remainingWeight:750,initialWeight:1000,price:0,currency:'RUB',createdAt:1}];f.data.inventory.printers.max={binding:{spoolId:'s1'}};
 const global=(await f.assistant.handle('Сколько осталось пластика?')).text;assert.match(global,/1.550/);
 for(const text of ['Сколько у меня пластика?','Сколько у нас пластика?','Сколько пластика у меня?','Сколько у меня осталось пластика?','Сколько у нас осталось пластика?'])assert.equal((await f.assistant.handle(text)).text,global,text);
 assert.match((await f.assistant.handle('Сколько у меня пластика PLA?')).text,/^PLA: осталось 1.250/);
 const printer=(await f.assistant.handle('Сколько пластика на K1 Max?')).text;assert.match(printer,/^K1 Max:.*750/);
 for(const text of ['Сколько пластика у K1 Max?','Сколько у меня пластика на принтере K1 Max?','Сколько у нас пластика на K1 Max?','Сколько у меня PLA пластика на K1 Max?'])assert.equal((await f.assistant.handle(text)).text,printer,text);
 assert.equal(f.data.list,0);assert.equal(f.data.upload,0);assert.equal(f.data.start,0);
});
await test('stock read failure is never announced as zero stock',async()=>{const f=fixture();f.deps.inventory=async()=>{throw new Error('SQLITE_BUSY')};assert.match((await f.assistant.handle('Сколько осталось пластика?')).text,/SQLITE_BUSY/)});
await test('concurrent request cannot consume a second print command',async()=>{const f=fixture();let done;f.deps.upload=()=>new Promise(resolve=>{done=resolve});await f.assistant.handle('Напечатай корпус на K1 Max');const first=f.assistant.handle('Подтверждаю печать');await new Promise(resolve=>setTimeout(resolve,0));const second=await f.assistant.handle('Подтверждаю печать');assert.match(second.text,/Повторный запуск/);done('корпус.gcode');await first;assert.equal(f.data.start,1)});
await test('cancel during analysis cannot leave a printable proposal',async()=>{const f=fixture();let done;f.deps.validate=()=>new Promise(resolve=>{done=resolve});const first=f.assistant.handle('Напечатай корпус на K1 Max');await new Promise(resolve=>setTimeout(resolve,0));await f.assistant.handle('Отмена');done({sha256:'a'.repeat(64),report:{ok:true,issues:[]}});await first;await f.assistant.handle('Подтверждаю печать');assert.equal(f.data.start,0)});
for(const state of ['standby','printing','error',''])await test('actual Moonraker read-only preflight '+(state||'missing-state'),async()=>{const methods=[];const fake={runControlRequest:run=>run(),rpc:async method=>{methods.push(method);return method==='printer.info'?{state:'ready'}:{status:{print_stats:{state},virtual_sdcard:{is_active:false}}}}};assert.equal(await MoonrakerClient.prototype.checkIdleReady.call(fake),state==='standby');assert.deepEqual(methods,['printer.info','printer.objects.query'])});
await test('spoken answers select only an installed local Russian voice',()=>{
 let voices=[{lang:'ru-RU',localService:false,name:'Cloud Russian'},{lang:'en-US',localService:true,name:'Local English'}],spoken=[];
 globalThis.speechSynthesis=window.speechSynthesis={getVoices:()=>voices,cancel:()=>{},speak:u=>spoken.push(u)};
 globalThis.SpeechSynthesisUtterance=class{constructor(text){this.text=text}};
 assert.equal(offlineRussianVoice(),undefined);assert.equal(speakOffline('Привет'),false);assert.equal(spoken.length,0);
 voices.push({lang:'ru-RU',localService:true,name:'Installed Russian'});assert.equal(speakOffline('Осталось 500 грамм'),true);assert.equal(spoken.length,1);assert.equal(spoken[0].voice.name,'Installed Russian');
});
if(process.env.KF_VOICE_PROOF)fs.writeFileSync(process.env.KF_VOICE_PROOF,JSON.stringify({passed:true,cases:report.length,report},null,2)+'\n');
console.log('Voice assistant:',report.length,'cases passed');
