import assert from 'node:assert/strict';
import fs from 'node:fs';
import {build} from 'esbuild';

const compiled=await build({stdin:{contents:"export {executeVoicePrinterControl} from './src/lib/voicePrinterControls';",resolveDir:process.cwd(),loader:'ts'},bundle:true,write:false,format:'esm',platform:'node'});
const {executeVoicePrinterControl}=await import('data:text/javascript;base64,'+Buffer.from(compiled.outputFiles[0].text).toString('base64'));
const results=[];
const test=async(name,check)=>{await check();results.push({name,passed:true});console.log('PASS',name)};
const printer=()=>({id:'max',name:'K1 Max',host:'192.168.1.10',profile:{preset:'creality-k1-max',bedX:300,bedY:300,maxZ:300,nozzle:.4,materials:['PLA'],enclosed:true},status:{state:'ready',connectionState:'online',filename:'jobs/держатель.gcode',progress:.5,printDuration:600,nozzle:200,nozzleTarget:200,bed:60,bedTarget:60},webcams:[]});
function fixture(state='ready'){
 const p=printer();p.status.state=state;
 const data={printers:[p],role:true,active:true,remoteState:state,remoteFilename:p.status.filename,remoteLight:false,cameraConfigured:true,lightCalls:0,lightWrites:0,pauseWrites:0,resumeWrites:0,reads:[],camera:[],waits:0};
 const client={
  light:async(on,guard)=>{data.lightCalls++;guard?.();data.lightWrites++;data.remoteLight=on;return{supported:true,on:data.remoteLight}},
  pause:async guard=>{guard?.();data.pauseWrites++;data.remoteState='paused'},
  resume:async guard=>{guard?.();data.resumeWrites++;data.remoteState='printing'},
  checkPrintStart:async filename=>{data.reads.push(filename);return{confirmed:data.remoteFilename===filename&&['printing','paused'].includes(data.remoteState),state:data.remoteState,filename:data.remoteFilename}},
 };
 data.client=client;
 const controller=new AbortController();
 const deps={printers:()=>data.printers,client:()=>data.client,canOperate:()=>data.role,assertActive:()=>{if(!data.active)throw Error('Действие отменено')},hasCamera:()=>data.cameraConfigured,openCamera:id=>{data.camera.push(id);return true},wait:async()=>{data.waits++}};
 const run=action=>executeVoicePrinterControl(p,action,deps,controller.signal);
 const writes=()=>data.lightWrites+data.pauseWrites+data.resumeWrites;
 return{p,data,client,controller,deps,run,writes};
}
await test('both light directions require actual supported matching readback',async()=>{
 for(const action of ['light-on','light-off']){
  const f=fixture();f.data.remoteLight=action==='light-off';const reply=await f.run(action);
  assert.equal(reply.confirmed,true);assert.match(reply.text,action==='light-on'?/включена/:/выключена/);
  assert.equal(f.data.lightCalls,1);assert.equal(f.data.lightWrites,1);assert.equal(f.data.remoteLight,action==='light-on');assert.equal(f.data.pauseWrites+f.data.resumeWrites,0);
 }
});
await test('a successful transport with unsupported, unknown or wrong light state is not success',async()=>{
 for(const response of [{supported:false},{supported:true},{supported:true,on:false}]){
  const f=fixture();f.client.light=async()=>{f.data.lightCalls++;return response};const reply=await f.run('light-on');
  assert.equal(reply.confirmed,false);assert.equal(f.data.lightCalls,1);assert.doesNotMatch(reply.text,/подсветка.*включена/iu);
 }
});
await test('light transport errors never leak diagnostics or retry a write',async()=>{
 const f=fixture();f.client.light=async()=>{f.data.lightCalls++;throw Error('http://private-host/api?key=secret GH_TOKEN=private')};
 const reply=await f.run('light-on');assert.equal(reply.confirmed,false);assert.equal(f.data.lightCalls,1);assert.doesNotMatch(reply.text,/private|secret|TOKEN|http/i);assert.match(reply.text,/Повторную команду не отправляла/);
});
await test('permission, connection, suspension and model conflicts block all writes',async()=>{
 for(const scenario of ['role','offline','suspended','model-conflict','incompatible','missing-client']){
  for(const action of ['light-on','pause','resume']){
   const f=fixture(action==='resume'?'paused':'printing');
   if(scenario==='role')f.data.role=false;
   if(scenario==='offline')f.p.status.connectionState='offline';
   if(scenario==='suspended')f.p.status.remoteControlSuspended=true;
   if(scenario==='model-conflict')f.p.modelSelection={mode:'automatic',selectedPreset:'creality-k1-max',lastDetection:{decision:'conflict'}};
   if(scenario==='incompatible')f.p.capabilities={compatible:false};
   if(scenario==='missing-client')f.data.client=undefined;
   await assert.rejects(f.run(action),undefined,scenario+' '+action);assert.equal(f.writes(),0);assert.equal(f.data.reads.length,0);
  }
 }
});
await test('unsupported runtime actions cannot call arbitrary client methods',async()=>{
 const f=fixture('printing');let escaped=0;f.client.cancel=async()=>{escaped++};
 for(const action of ['cancel','gcode','emergencyStop','__proto__','toString'])await assert.rejects(f.run(action),/недоступно/);
 assert.equal(escaped,0);assert.equal(f.writes(),0);assert.equal(f.data.reads.length,0);
});
await test('missing client methods and explicit pause/resume capability denials block dispatch',async()=>{
 for(const action of ['pause','resume']){
  const f=fixture(action==='pause'?'printing':'paused');delete f.client[action];await assert.rejects(f.run(action),/недоступно/);assert.equal(f.data.reads.length,0);assert.equal(f.writes(),0);
  const g=fixture(action==='pause'?'printing':'paused');g.p.capabilities={[action==='pause'?'canPause':'canResume']:false};await assert.rejects(g.run(action),/не поддерживает/);assert.equal(g.writes(),0);
 }
 const f=fixture();delete f.client.light;await assert.rejects(f.run('light-on'),/недоступно/);assert.equal(f.writes(),0);
});
await test('pause and resume freshly check the exact job and confirm one mutation',async()=>{
 for(const action of ['pause','resume']){
  const f=fixture(action==='pause'?'printing':'paused'),reply=await f.run(action);
  assert.equal(reply.confirmed,true);assert.equal(f.writes(),1);assert.equal(f.data[action==='pause'?'pauseWrites':'resumeWrites'],1);
  assert.deepEqual(f.data.reads,[f.p.status.filename,f.p.status.filename]);assert.match(reply.text,action==='pause'?/поставлена на паузу/:/продолжена/);
 }
});
await test('the full-path existing-job reader is preferred and keeps its client binding',async()=>{
 for(const action of ['pause','resume']){
  const f=fixture(action==='pause'?'printing':'paused');f.p.status.filename='/usr/data/принтер/держатель.gcode';f.data.remoteFilename=f.p.status.filename;
  f.client.checkPrintStart=()=>{throw Error('legacy relative-path reader must not be called')};
  f.client.checkPrintJob=async function(filename){assert.equal(this,f.client);f.data.reads.push(filename);return{confirmed:filename===f.data.remoteFilename,state:f.data.remoteState,filename:f.data.remoteFilename}};
  const result=await f.run(action);assert.equal(result.confirmed,true);assert.equal(f.writes(),1);assert.deepEqual(f.data.reads,[f.p.status.filename,f.p.status.filename]);
 }
});
await test('already paused or already printing states are read-only idempotent replies',async()=>{
 for(const [action,state] of [['pause','paused'],['resume','printing']]){
  const f=fixture(state),reply=await f.run(action);assert.equal(reply.confirmed,true);assert.equal(f.writes(),0);assert.equal(f.data.reads.length,1);assert.match(reply.text,/уже/);
 }
});
await test('an absent or unrelated live job blocks pause/resume before the mutation',async()=>{
 for(const scenario of ['idle','no-name','other-job','complete','read-failure']){
  const f=fixture('printing');
  if(scenario==='idle')f.p.status.state='ready';
  if(scenario==='no-name')f.p.status.filename='';
  if(scenario==='other-job')f.data.remoteFilename='other.gcode';
  if(scenario==='complete')f.data.remoteState='complete';
  if(scenario==='read-failure')f.client.checkPrintStart=async()=>{throw Error('secret private host')};
  await assert.rejects(f.run('pause'),error=>!String(error).includes('secret'),scenario);assert.equal(f.writes(),0);
 }
});
await test('preflight observation state takes priority over an old UI state',async()=>{
 const f=fixture('paused');f.data.remoteState='printing';assert.equal((await f.run('pause')).confirmed,true);assert.equal(f.data.pauseWrites,1);
 const g=fixture('printing');g.data.remoteState='paused';assert.equal((await g.run('resume')).confirmed,true);assert.equal(g.data.resumeWrites,1);
});
await test('readback can recover without repeating the control command',async()=>{
 const f=fixture('printing'),read=f.client.checkPrintStart;let count=0;
 f.client.checkPrintStart=async filename=>{count++;if(count===2)throw Error('temporary read');if(count===3)return{confirmed:true,state:'printing',filename};return read(filename)};
 const reply=await f.run('pause');assert.equal(reply.confirmed,true);assert.equal(f.data.pauseWrites,1);assert.equal(count,4);assert.equal(f.data.waits,2);
});
await test('delayed unchanged state exhausts bounded reads and stays unconfirmed',async()=>{
 const f=fixture('printing');f.client.pause=async guard=>{guard?.();f.data.pauseWrites++};
 const reply=await f.run('pause');assert.equal(reply.confirmed,false);assert.equal(f.data.pauseWrites,1);assert.equal(f.data.reads.length,4);assert.equal(f.data.waits,2);assert.match(reply.text,/пока не подтвердил/);
});
await test('a different job after dispatch ends verification without a second mutation',async()=>{
 const f=fixture('printing');f.client.pause=async guard=>{guard?.();f.data.pauseWrites++;f.data.remoteFilename='new.gcode'};
 const reply=await f.run('pause');assert.equal(reply.confirmed,false);assert.equal(f.data.pauseWrites,1);assert.equal(f.data.reads.length,2);assert.equal(f.data.waits,0);
});
await test('uncertain pause/resume transport results are never replayed',async()=>{
 for(const action of ['pause','resume']){
  const f=fixture(action==='pause'?'printing':'paused');f.client[action]=async guard=>{guard?.();f.data[action==='pause'?'pauseWrites':'resumeWrites']++;throw Error('request timeout private host secret')};
  const reply=await f.run(action);assert.equal(reply.confirmed,false);assert.equal(f.writes(),1);assert.equal(f.data.reads.length,1);assert.doesNotMatch(reply.text,/private|secret|timeout/i);assert.match(reply.text,/Повторную команду не отправляла/);
 }
});
await test('cancellation before or during fresh preflight prevents dispatch',async()=>{
 for(const stage of ['before','read']){
  const f=fixture('printing');if(stage==='before')f.controller.abort();else{const read=f.client.checkPrintStart;f.client.checkPrintStart=async filename=>{const result=await read(filename);f.controller.abort();return result}};
  await assert.rejects(f.run('pause'),/отменено/);assert.equal(f.writes(),0);
 }
});
await test('stale printer, client, role or active job during preflight prevents dispatch',async()=>{
 for(const changed of ['removed','host','client','role','job','completed','same-file-restarted','profile-revision']){
  const f=fixture('printing'),read=f.client.checkPrintStart;
  f.client.checkPrintStart=async filename=>{const result=await read(filename);
   if(changed==='removed')f.data.printers=[];
   if(changed==='host')f.p.host='192.168.1.99';
   if(changed==='client')f.data.client={};
   if(changed==='role')f.data.role=false;
   if(changed==='job')f.p.status.filename='new.gcode';
   if(changed==='completed')f.p.status.state='ready';
   if(changed==='same-file-restarted'){f.p.status.printDuration=1;f.p.status.progress=.001;}
   if(changed==='profile-revision')f.data.active=false;
   return result;
  };
  await assert.rejects(f.run('pause'),undefined,changed);assert.equal(f.writes(),0);
 }
});
await test('dispatch guards stop a control which waited inside its client queue',async()=>{
 for(const action of ['light-on','pause','resume']){
  const f=fixture(action==='resume'?'paused':'printing');
  if(action==='light-on')f.client.light=async(on,guard)=>{f.controller.abort();guard?.();f.data.lightWrites++;return{supported:true,on}};
  else f.client[action]=async guard=>{f.controller.abort();guard?.();f.data[action==='pause'?'pauseWrites':'resumeWrites']++};
  await assert.rejects(f.run(action),/отменено/);assert.equal(f.writes(),0);
 }
});
await test('cancellation after dispatch stops verification and never repeats or undoes a command',async()=>{
 const f=fixture('printing');f.client.pause=async guard=>{guard?.();f.data.pauseWrites++;f.controller.abort()};
 await assert.rejects(f.run('pause'),/отменено/);assert.equal(f.data.pauseWrites,1);assert.equal(f.data.resumeWrites,0);assert.equal(f.data.reads.length,1);
});
await test('client and filename changes after dispatch prevent false confirmation',async()=>{
 for(const changed of ['client','filename']){
  const f=fixture('printing');f.client.pause=async guard=>{guard?.();f.data.pauseWrites++;if(changed==='client')f.data.client={};else f.p.status.filename='new.gcode'};
  await assert.rejects(f.run('pause'));assert.equal(f.data.pauseWrites,1);assert.equal(f.data.reads.length,1);
 }
});
await test('cancellation during readback wait stops all remaining reads',async()=>{
 const f=fixture('printing');f.client.pause=async guard=>{guard?.();f.data.pauseWrites++};f.deps.wait=async()=>{f.data.waits++;f.controller.abort()};
 await assert.rejects(f.run('pause'),/отменено/);assert.equal(f.data.pauseWrites,1);assert.equal(f.data.reads.length,2);assert.equal(f.data.waits,1);
});
await test('camera opens the known printer window for a viewer without a control client',async()=>{
 const f=fixture();f.data.role=false;f.data.client=undefined;f.p.status.connectionState='offline';f.p.status.remoteControlSuspended=true;
 f.deps.client=()=>{throw Error('camera must not request a control client')};
 const reply=await f.run('camera');assert.equal(reply.confirmed,true);assert.match(reply.text,/Открыла окно камеры/);assert.deepEqual(f.data.camera,['max']);assert.equal(f.writes(),0);assert.equal(f.data.reads.length,0);
});
await test('camera policy, callback absence and failed UI opening never claim success',async()=>{
 for(const scenario of ['unavailable','no-callback','refused']){
  const f=fixture();if(scenario==='unavailable')f.data.cameraConfigured=false;if(scenario==='no-callback')delete f.deps.openCamera;if(scenario==='refused')f.deps.openCamera=()=>false;
  await assert.rejects(f.run('camera'));assert.equal(f.writes(),0);assert.deepEqual(f.data.camera,[]);
 }
});
await test('cancelled or removed camera target never opens a stale printer window',async()=>{
 for(const scenario of ['cancelled','removed']){
  const f=fixture();if(scenario==='cancelled')f.controller.abort();else f.data.printers=[];
  await assert.rejects(f.run('camera'));assert.deepEqual(f.data.camera,[]);assert.equal(f.writes(),0);
 }
});
if(process.env.KF_VOICE_CONTROLS_PROOF)fs.writeFileSync(process.env.KF_VOICE_CONTROLS_PROOF,JSON.stringify({passed:true,cases:results.length,physicalPrintersTested:false,results},null,2)+'\n');
console.log('Voice printer controls:',results.length,'cases passed');
