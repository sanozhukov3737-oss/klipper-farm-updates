#!/usr/bin/env node
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';

const releaseRoot=path.resolve(import.meta.dirname,'..');
const buildIdName='RELEASE-BUILD-ID.txt';
const manifestName='MANIFEST-SHA256.txt';
const sentinelName='source-fingerprint-v1.json';
const recipeVersion=2;

const sha256=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const isWithin=(parent,child)=>{
  const relative=path.relative(parent,child);
  return relative!==''&&!relative.startsWith(`..${path.sep}`)&&relative!=='..'&&!path.isAbsolute(relative);
};
const rejectSymlink=(candidate,label)=>{
  if(fs.existsSync(candidate)&&fs.lstatSync(candidate).isSymbolicLink())throw new Error(`${label} must not be a symlink: ${candidate}`);
};
const cacheDirTagContent='Signature: 8a477f597d28d172789f06886806bc55\n# This file is a cache directory tag created by cargo.\n# For information about cache directory tags, see:\n#\thttp://www.brynosaurus.com/cachedir/\n';
const ensureCacheDirTag=targetRoot=>{
  const tagPath=path.join(targetRoot,'CACHEDIR.TAG');
  rejectSymlink(tagPath,'cargo cache directory tag');
  if(!fs.existsSync(tagPath))fs.writeFileSync(tagPath,cacheDirTagContent);
};
const readBuildId=projectRoot=>{
  const value=fs.readFileSync(path.join(projectRoot,buildIdName),'utf8').trim();
  if(!/^[A-Z0-9][A-Z0-9._-]{7,95}$/.test(value))throw new Error(`${buildIdName} is missing or malformed`);
  return value;
};
const readSentinel=file=>{
  try{
    const value=JSON.parse(fs.readFileSync(file,'utf8'));
    if(value?.schema!==2||typeof value.buildId!=='string'||!/^[0-9a-f]{64}$/.test(value.manifestSha256)||!/^[0-9a-f]{64}$/.test(value.recipeSha256)||typeof value.pendingWorkspaceClean!=='boolean')return null;
    return value;
  }catch{
    return null;
  }
};
const writeSentinel=(file,value)=>{
  const temporary=`${file}.${process.pid}.${Date.now()}.tmp`;
  let descriptor;
  try{
    descriptor=fs.openSync(temporary,'wx',0o600);
    fs.writeFileSync(descriptor,`${JSON.stringify(value,null,2)}\n`);
    fs.fsyncSync(descriptor);
    fs.closeSync(descriptor);
    descriptor=undefined;
    fs.rmSync(file,{force:true});
    fs.renameSync(temporary,file);
  }finally{
    if(descriptor!==undefined)fs.closeSync(descriptor);
    fs.rmSync(temporary,{force:true});
  }
};

const command=(program,args,{projectRoot,env=process.env,capture=false})=>{
  const result=spawnSync(program,args,{cwd:projectRoot,env,shell:false,encoding:'utf8',stdio:capture?['ignore','pipe','pipe']:'inherit',maxBuffer:32*1024*1024});
  if(result.error)throw result.error;
  if(result.status!==0)throw new Error(`${program} ${args.join(' ')} failed (${result.status}): ${result.stderr??''}`);
  return capture?result.stdout.trim():'';
};

const recipeFingerprint=({projectRoot,env=process.env,runCommand=command})=>{
  // Cargo fingerprints its own source/dependency graph. This outer recipe only
  // rejects incompatible intermediates; release identity is checked separately.
  const files={};
  const record=(label,file,required=false)=>{
    if(!fs.existsSync(file)){
      if(required)throw new Error(`Missing cache recipe input: ${label}`);
      files[label]=null;
      return;
    }
    rejectSymlink(file,`cache recipe ${label}`);
    files[label]=sha256(file);
  };
  record('Cargo.lock',path.join(projectRoot,'src-tauri','Cargo.lock'),true);
  for(const relative of ['offline-tools/rust/rust-vendor-v1144.tar.gz','offline-tools/nsis/nsis-3.11.zip','offline-tools/nsis/nsis_tauri_utils-0.5.3.dll'])record(relative,path.join(projectRoot,relative));
  for(const relative of ['rust-toolchain','rust-toolchain.toml','src-tauri/rust-toolchain','src-tauri/rust-toolchain.toml','src-tauri/.cargo/config','src-tauri/.cargo/config.toml'])record(relative,path.join(projectRoot,relative));
  // Cargo can inherit configuration from checkout ancestors and CARGO_HOME.
  let directory=projectRoot;
  for(let depth=0;;depth+=1){
    for(const name of ['config','config.toml'])record(`ancestor-${depth}/.cargo/${name}`,path.join(directory,'.cargo',name));
    const parent=path.dirname(directory);
    if(parent===directory)break;
    directory=parent;
  }
  const cargoHome=env.CARGO_HOME??path.join(os.homedir(),'.cargo');
  for(const name of ['config','config.toml'])record(`CARGO_HOME/${name}`,path.join(cargoHome,name));
  const buildEnvironment={};
  for(const name of Object.keys(env).sort()){
    if(/^(RUSTFLAGS|RUSTDOCFLAGS|RUSTC|RUSTC_WRAPPER|RUSTC_WORKSPACE_WRAPPER|RUSTC_BOOTSTRAP|RUSTUP_TOOLCHAIN|CARGO_ENCODED_RUSTFLAGS|CARGO_ENCODED_RUSTDOCFLAGS|CARGO_BUILD_TARGET|CARGO_BUILD_RUSTFLAGS|CARGO_INCREMENTAL|CARGO_PROFILE_.+|CARGO_TARGET_.+_(RUSTFLAGS|LINKER|RUNNER)|CC|CXX|AR|CL|CFLAGS|CXXFLAGS|CPPFLAGS|LDFLAGS|VCToolsVersion|WindowsSDKVersion|UCRTVersion|ImageOS|ImageVersion)$/.test(name))buildEnvironment[name]=env[name];
  }
  const options={projectRoot,env,capture:true};
  const profileLines=[];
  let inProfile=false;
  for(const line of fs.readFileSync(path.join(projectRoot,'src-tauri','Cargo.toml'),'utf8').split(/\r?\n/)){
    if(/^\s*\[/.test(line))inProfile=/^\s*\[profile(?:\.|\])/.test(line);
    if(inProfile)profileLines.push(line);
  }
  const recipe={
    version:recipeVersion,platform:process.platform,arch:process.arch,
    preparerSha256:sha256(import.meta.filename),profiles:profileLines,
    rustc:runCommand(env.RUSTC??'rustc',['-vV'],options),
    cargo:runCommand('cargo',['-Vv'],options),
    files,buildEnvironment,
  };
  return crypto.createHash('sha256').update(JSON.stringify(recipe)).digest('hex');
};

const validateRoots=({projectRoot,cacheRoot,targetRoot})=>{
  projectRoot=path.resolve(projectRoot);
  cacheRoot=path.resolve(cacheRoot);
  targetRoot=path.resolve(targetRoot);
  if(!isWithin(cacheRoot,targetRoot))throw new Error(`CARGO_TARGET_DIR must be strictly inside KF_CACHE_ROOT: ${targetRoot}`);
  rejectSymlink(cacheRoot,'KF_CACHE_ROOT');
  fs.mkdirSync(cacheRoot,{recursive:true});
  rejectSymlink(cacheRoot,'KF_CACHE_ROOT');
  rejectSymlink(targetRoot,'CARGO_TARGET_DIR');
  let existing=targetRoot;
  while(!fs.existsSync(existing))existing=path.dirname(existing);
  const realCache=fs.realpathSync(cacheRoot);
  const realExisting=fs.realpathSync(existing);
  if(realExisting!==realCache&&!isWithin(realCache,realExisting))throw new Error('CARGO_TARGET_DIR resolves outside KF_CACHE_ROOT');
  return {projectRoot,cacheRoot,targetRoot};
};

const sourceIdentity=projectRoot=>({buildId:readBuildId(projectRoot),manifestSha256:sha256(path.join(projectRoot,manifestName))});

const prepare=({projectRoot,cacheRoot,targetRoot,quiet=false,env=process.env,runCommand=command})=>{
  ({projectRoot,cacheRoot,targetRoot}=validateRoots({projectRoot,cacheRoot,targetRoot}));
  const {buildId,manifestSha256}=sourceIdentity(projectRoot);
  const recipeSha256=recipeFingerprint({projectRoot,env,runCommand});
  const sentinelPath=path.join(cacheRoot,sentinelName);
  rejectSymlink(sentinelPath,'cache fingerprint');
  const previous=readSentinel(sentinelPath);
  const changed=!previous||previous.recipeSha256!==recipeSha256;
  const sourceChanged=!previous||previous.buildId!==buildId||previous.manifestSha256!==manifestSha256;
  const pendingWorkspaceClean=!changed&&(sourceChanged||previous.pendingWorkspaceClean);
  if(changed){
    fs.rmSync(targetRoot,{recursive:true,force:true,maxRetries:8,retryDelay:125});
    fs.mkdirSync(targetRoot,{recursive:true});
    if(!quiet)console.log('Build cache reset: compiler, target, dependency or build recipe changed; incompatible Cargo artifacts removed.');
  }else{
    fs.mkdirSync(targetRoot,{recursive:true});
    if(!quiet)console.log(pendingWorkspaceClean?'Build cache reuse: dependency artifacts retained; local workspace rebuild required.':'Build cache reuse: compatible Cargo intermediates retained.');
  }
  // Cargo 1.84+ refuses to clean a target directory without this tag; a reset
  // or a poisoned restored cache can leave the directory empty or untagged.
  ensureCacheDirTag(targetRoot);
  writeSentinel(sentinelPath,{schema:2,buildId,manifestSha256,recipeSha256,pendingWorkspaceClean});
  if(!quiet)console.log(`Release build ID: ${buildId}`);
  return {buildId,manifestSha256,recipeSha256,changed,sourceChanged,pendingWorkspaceClean};
};

const cleanWorkspace=({projectRoot,cacheRoot,targetRoot,quiet=false,env=process.env,runCommand=command})=>{
  ({projectRoot,cacheRoot,targetRoot}=validateRoots({projectRoot,cacheRoot,targetRoot}));
  const sentinelPath=path.join(cacheRoot,sentinelName);
  rejectSymlink(sentinelPath,'cache fingerprint');
  const previous=readSentinel(sentinelPath);
  const identity=sourceIdentity(projectRoot);
  const recipeSha256=recipeFingerprint({projectRoot,env,runCommand});
  if(!previous||previous.buildId!==identity.buildId||previous.manifestSha256!==identity.manifestSha256||previous.recipeSha256!==recipeSha256)throw new Error('Build cache preparation must match the current verified source and compiler before workspace cleanup');
  if(!previous.pendingWorkspaceClean)return [];
  // Release archives have deterministic mtimes. Cargo's fast path must not
  // mistake an older local crate for the current source. Include local path
  // dependencies outside the workspace, preserving registry/git artifacts.
  const manifest=path.join(projectRoot,'src-tauri','Cargo.toml');
  const options={projectRoot,env};
  const metadata=JSON.parse(runCommand('cargo',['metadata','--offline','--locked','--manifest-path',manifest,'--format-version','1'],{...options,capture:true}));
  if(!Array.isArray(metadata.workspace_members)||!metadata.workspace_members.length||!Array.isArray(metadata.packages))throw new Error('Cargo metadata has no local workspace inventory');
  const locals=metadata.packages.filter(item=>item?.source===null);
  const localIds=new Set(locals.map(item=>item.id));
  if(new Set(metadata.workspace_members).size!==metadata.workspace_members.length||metadata.workspace_members.some(id=>!localIds.has(id)))throw new Error('Cargo metadata contains duplicate or non-local workspace packages');
  const packages=locals.map(item=>{
    if(typeof item.id!=='string'||typeof item.manifest_path!=='string'||!isWithin(projectRoot,path.resolve(item.manifest_path))||!isWithin(fs.realpathSync(projectRoot),fs.realpathSync(item.manifest_path))||typeof item.name!=='string'||!/^[A-Za-z0-9_-]+$/.test(item.name)||typeof item.version!=='string'||!/^[0-9A-Za-z.+-]+$/.test(item.version))throw new Error('Cargo metadata contains an invalid or external local package');
    return `${item.name}@${item.version}`;
  });
  if(new Set(packages).size!==packages.length)throw new Error('Cargo metadata contains duplicate workspace packages');
  fs.mkdirSync(targetRoot,{recursive:true});
  ensureCacheDirTag(targetRoot);
  runCommand('cargo',['clean','--offline','--locked','--manifest-path',manifest,'--target-dir',targetRoot,...packages.flatMap(name=>['-p',name])],options);
  // Installers and generated NSIS scripts are release outputs, never reusable
  // compile intermediates. A source change must not collect an older bundle.
  rejectSymlink(path.join(targetRoot,'release'),'release output directory');
  for(const relative of ['release/bundle','release/nsis']){
    const output=path.join(targetRoot,relative);
    rejectSymlink(output,'release packaging output');
    fs.rmSync(output,{recursive:true,force:true,maxRetries:5,retryDelay:100});
  }
  writeSentinel(sentinelPath,{...previous,pendingWorkspaceClean:false});
  if(!quiet)console.log(`Build cache source refresh: rebuilt package state cleared for ${packages.length} local source packages; registry/git dependencies retained.`);
  return packages;
};

const selfTest=()=>{
  const temporaryRoot=fs.mkdtempSync(path.join(os.tmpdir(),'kf-cache-fingerprint-'));
  try{
    const projectRoot=path.join(temporaryRoot,'project');
    const cacheRoot=path.join(temporaryRoot,'cache');
    const targetRoot=path.join(cacheRoot,'target');
    fs.mkdirSync(projectRoot,{recursive:true});
    const cargoRoot=path.join(projectRoot,'src-tauri');
    const libraryRoot=path.join(cargoRoot,'crates','local-library');
    const excludedRoot=path.join(cargoRoot,'excluded-local-dependency');
    fs.mkdirSync(libraryRoot,{recursive:true});
    fs.mkdirSync(excludedRoot,{recursive:true});
    fs.writeFileSync(path.join(cargoRoot,'Cargo.lock'),'version = 4\n');
    fs.writeFileSync(path.join(cargoRoot,'Cargo.toml'),'[package]\nname="fixture-app"\nversion="1.0.0"\n');
    fs.writeFileSync(path.join(libraryRoot,'Cargo.toml'),'[package]\nname="fixture-library"\nversion="1.0.0"\n');
    fs.writeFileSync(path.join(excludedRoot,'Cargo.toml'),'[package]\nname="fixture-excluded"\nversion="1.0.0"\n');
    const source=path.join(libraryRoot,'lib.rs');
    const archivedTime=new Date('2026-09-12T00:00:00Z');
    fs.writeFileSync(source,'pub fn version() -> u8 { 1 }\n');
    fs.utimesSync(source,archivedTime,archivedTime);
    fs.mkdirSync(targetRoot,{recursive:true});
    fs.writeFileSync(path.join(projectRoot,buildIdName),'V20.3-CACHE-SELF-TEST\n');
    const updateManifest=()=>fs.writeFileSync(path.join(projectRoot,manifestName),`${sha256(source)}  src-tauri/crates/local-library/lib.rs\n`);
    updateManifest();
    let compiler='rustc 1.98.0 (fixture)\nhost: x86_64-pc-windows-msvc';
    let failClean=false;
    const cleanCalls=[];
    const metadata={workspace_members:['app','library'],packages:[
      {id:'app',source:null,name:'fixture-app',version:'1.0.0',manifest_path:path.join(cargoRoot,'Cargo.toml')},
      {id:'library',source:null,name:'fixture-library',version:'1.0.0',manifest_path:path.join(libraryRoot,'Cargo.toml')},
      {id:'excluded',source:null,name:'fixture-excluded',version:'1.0.0',manifest_path:path.join(excludedRoot,'Cargo.toml')},
      {id:'registry',source:'registry+https://example.invalid/index',name:'third-party',version:'1.0.0',manifest_path:path.join(temporaryRoot,'registry','Cargo.toml')},
    ]};
    const runCommand=(program,args)=>{
      if(program==='rustc'&&args.join(' ')==='-vV')return compiler;
      if(program==='cargo'&&args.join(' ')==='-Vv')return 'cargo 1.98.0 (fixture)';
      if(program==='cargo'&&args[0]==='metadata')return JSON.stringify(metadata);
      if(program==='cargo'&&args[0]==='clean'){
        cleanCalls.push(args);
        if(failClean)throw new Error('fixture cleanup failed');
        for(const name of ['fixture-app','fixture-library','fixture-excluded'])fs.rmSync(path.join(targetRoot,`${name}.marker`),{force:true});
        return '';
      }
      throw new Error(`Unexpected cache self-test command: ${program} ${args.join(' ')}`);
    };
    const env={CARGO_HOME:path.join(cacheRoot,'cargo'),CARGO_INCREMENTAL:'0',CARGO_PROFILE_RELEASE_DEBUG:'0'};
    const options={projectRoot,cacheRoot,targetRoot,quiet:true,env,runCommand};
    const sentinelPath=path.join(cacheRoot,sentinelName);
    fs.writeFileSync(path.join(targetRoot,'stale.marker'),'stale');
    assert.equal(prepare(options).changed,true);
    assert.equal(fs.existsSync(path.join(targetRoot,'stale.marker')),false,'unknown target state must be purged');
    for(const name of ['third-party','fixture-app','fixture-library','fixture-excluded'])fs.writeFileSync(path.join(targetRoot,`${name}.marker`),'compiled');
    for(const relative of ['release/bundle/nsis/old-setup.exe','release/nsis/old-script.nsi']){
      const output=path.join(targetRoot,relative);
      fs.mkdirSync(path.dirname(output),{recursive:true});
      fs.writeFileSync(output,'stale packaging output');
    }
    assert.equal(prepare(options).changed,false);
    assert.deepEqual(cleanWorkspace(options),[],'identical source must not trigger workspace cleanup');
    assert.equal(cleanCalls.length,0);

    fs.writeFileSync(source,'pub fn version() -> u8 { 2 }\n');
    fs.utimesSync(source,archivedTime,archivedTime);
    assert.equal(fs.statSync(source).mtimeMs,archivedTime.getTime(),'fixture must reproduce equal archive mtimes');
    updateManifest();
    fs.writeFileSync(path.join(projectRoot,buildIdName),'V20.3-CACHE-SELF-TEST-NEXT\n');
    const updated=prepare(options);
    assert.equal(updated.changed,false,'source and release identity must not erase dependency artifacts');
    assert.equal(updated.pendingWorkspaceClean,true);
    assert.equal(fs.existsSync(path.join(targetRoot,'third-party.marker')),true);
    assert.equal(prepare(options).pendingWorkspaceClean,true,'interrupted preparation must keep the cleanup pending');
    failClean=true;
    assert.throws(()=>cleanWorkspace(options),/fixture cleanup failed/);
    assert.equal(readSentinel(sentinelPath).pendingWorkspaceClean,true,'failed cleanup must not acknowledge current local package artifacts');
    failClean=false;
    assert.deepEqual(cleanWorkspace(options),['fixture-app@1.0.0','fixture-library@1.0.0','fixture-excluded@1.0.0']);
    assert.deepEqual(cleanCalls.at(-1).filter((_,index,args)=>args[index-1]==='-p'),['fixture-app@1.0.0','fixture-library@1.0.0','fixture-excluded@1.0.0']);
    assert.equal(fs.existsSync(path.join(targetRoot,'fixture-app.marker')),false);
    assert.equal(fs.existsSync(path.join(targetRoot,'fixture-library.marker')),false);
    assert.equal(fs.existsSync(path.join(targetRoot,'fixture-excluded.marker')),false,'local dependencies outside the workspace must also rebuild');
    assert.equal(fs.existsSync(path.join(targetRoot,'third-party.marker')),true,'source refresh must retain compiled third-party dependencies');
    assert.equal(fs.existsSync(path.join(targetRoot,'release','bundle')),false,'old cached installers must not survive a source change');
    assert.equal(fs.existsSync(path.join(targetRoot,'release','nsis')),false,'old generated packaging scripts must not survive a source change');
    const cleanedCalls=cleanCalls.length;
    cleanWorkspace(options);
    assert.equal(cleanCalls.length,cleanedCalls,'acknowledged source identity must not clean again');
    fs.writeFileSync(path.join(projectRoot,buildIdName),'V20.3-CACHE-SELF-TEST-ID-ONLY\n');
    assert.equal(prepare(options).changed,false,'release ID alone must preserve compatible dependencies');
    assert.equal(fs.existsSync(path.join(targetRoot,'third-party.marker')),true);
    cleanWorkspace(options);

    for(const mutate of [
      ()=>{compiler='rustc 1.99.0 (fixture)\nhost: x86_64-pc-windows-msvc';},
      ()=>{env.RUSTFLAGS='-C target-cpu=x86-64-v2';},
      ()=>{env.CARGO_BUILD_TARGET='aarch64-pc-windows-msvc';},
      ()=>{env.CARGO_PROFILE_RELEASE_LTO='true';},
      ()=>{fs.appendFileSync(path.join(cargoRoot,'Cargo.toml'),'[profile.release]\nlto=true\n');},
      ()=>{fs.appendFileSync(path.join(cargoRoot,'Cargo.lock'),'# changed dependency lock\n');},
      ()=>{fs.mkdirSync(path.join(projectRoot,'.cargo'));fs.writeFileSync(path.join(projectRoot,'.cargo','config.toml'),'[build]\nrustflags=[]\n');},
    ]){
      fs.writeFileSync(path.join(targetRoot,'incompatible.marker'),'old');
      mutate();
      assert.equal(prepare(options).changed,true,'incompatible compiler/dependency/build recipe must reset target');
      assert.equal(fs.existsSync(path.join(targetRoot,'incompatible.marker')),false);
    }
    fs.writeFileSync(sentinelPath,JSON.stringify({schema:1,buildId:updated.buildId,manifestSha256:updated.manifestSha256}));
    assert.equal(prepare(options).changed,true,'old source-only receipts must migrate through one clean reset');
    fs.writeFileSync(sentinelPath,'{broken');
    assert.equal(prepare(options).changed,true,'malformed receipts must not reuse artifacts');
    fs.appendFileSync(path.join(projectRoot,manifestName),'identity changed\n');
    assert.throws(()=>cleanWorkspace(options),/preparation must match/,'cleanup must reject a source identity that was not prepared');
    prepare(options);
    const libraryManifest=metadata.packages[1].manifest_path;
    metadata.packages[1].manifest_path=path.join(temporaryRoot,'foreign-Cargo.toml');
    fs.writeFileSync(metadata.packages[1].manifest_path,'[package]\nname="external"\n');
    assert.throws(()=>cleanWorkspace(options),/invalid or external local package/);
    metadata.packages[1].manifest_path=libraryManifest;
    metadata.workspace_members.push('library');
    assert.throws(()=>cleanWorkspace(options),/duplicate or non-local workspace packages/);
    metadata.workspace_members.pop();
    cleanWorkspace(options);
    assert.throws(()=>prepare({...options,targetRoot:temporaryRoot}),/strictly inside/);
    const outsideLink=path.join(cacheRoot,'outside-link');
    fs.symlinkSync(temporaryRoot,outsideLink,process.platform==='win32'?'junction':'dir');
    assert.throws(()=>prepare({...options,targetRoot:path.join(outsideLink,'escaped-target')}),/resolves outside/);
    console.log('Windows build cache self-test OK: deterministic-mtime source refresh, local-package cleanup/retry, dependency reuse and incompatible-recipe reset verified.');
  }finally{
    fs.rmSync(temporaryRoot,{recursive:true,force:true,maxRetries:5,retryDelay:50});
  }
};

if(process.argv.includes('--self-test')){
  selfTest();
}else{
  const cacheRoot=path.resolve(process.env.KF_CACHE_ROOT??path.join(releaseRoot,'.klipper-build-cache'));
  const targetRoot=path.resolve(process.env.CARGO_TARGET_DIR??path.join(cacheRoot,'target'));
  const options={projectRoot:releaseRoot,cacheRoot,targetRoot};
  if(process.argv.includes('--clean-workspace'))cleanWorkspace(options);
  else prepare(options);
}
