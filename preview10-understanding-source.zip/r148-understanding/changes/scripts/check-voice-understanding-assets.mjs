import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';

const scriptDirectory = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(process.argv[2] || path.join(scriptDirectory, '..'));
const assets = path.join(root, 'src-tauri/resources/understanding');
const pinsBytes = fs.readFileSync(path.join(scriptDirectory, 'voice-understanding-assets.json'));
const pins = JSON.parse(pinsBytes);
const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');
const safe = value => {
  assert.equal(typeof value, 'string');
  assert(value && !value.includes('\\') && !value.includes('\0') && !value.includes(':'));
  const parts = value.split('/');
  assert(parts.every(part => part && part !== '.' && part !== '..' && !/[ .]$/.test(part)));
  return parts;
};
const locate = (directory, name) => {
  const parts = safe(name);
  let current = directory;
  assert(!fs.lstatSync(current).isSymbolicLink(), 'Asset root is a symbolic link');
  for (const part of parts) {
    current = path.join(current, part);
    assert(!fs.lstatSync(current).isSymbolicLink(), 'Symbolic link in asset path: ' + name);
  }
  return current;
};
const digestFile = async file => {
  const value = createHash('sha256');
  for await (const chunk of fs.createReadStream(file, {highWaterMark: 1024 * 1024})) value.update(chunk);
  return value.digest('hex');
};
const verify = async (directory, row) => {
  const file = locate(directory, row.path);
  const info = fs.statSync(file);
  assert(info.isFile() && info.size === row.bytes, 'Asset size differs: ' + row.path);
  assert.equal(await digestFile(file), row.sha256, 'Asset SHA256 differs: ' + row.path);
};
if (!fs.existsSync(path.join(assets, 'manifest.json'))) {
  throw new Error('Offline understanding assets missing. Run python scripts/prepare-voice-understanding.py after speech preparation.');
}
const manifest = JSON.parse(fs.readFileSync(locate(assets, 'manifest.json'), 'utf8'));
assert.equal(manifest.schema, 1);
assert.equal(manifest.pinsSha256, sha256(pinsBytes), 'Understanding asset pins changed after preparation');
assert.deepEqual(manifest.model, pins.model);
assert.deepEqual(manifest.runtime, pins.runtime);
assert(/^[0-9a-f]{40}$/.test(pins.model.revision));
assert(/^[0-9a-f]{40}$/.test(pins.runtime.revision));
const fileRows = new Map();
for (const row of manifest.files) {
  safe(row.path);
  assert(!fileRows.has(row.path.toLowerCase()), 'Duplicate asset manifest path');
  assert(Number.isSafeInteger(row.bytes) && row.bytes > 0 && /^[0-9a-f]{64}$/.test(row.sha256));
  fileRows.set(row.path.toLowerCase(), row);
}
const expectedRuntime = new Set(pins.build.variants.flatMap(row => row.executables.map(item => item.fileName)));
for (const name of fs.readdirSync(path.join(assets, 'runtime'))) {
  assert(expectedRuntime.delete(name), 'Unreviewed understanding runtime binary: ' + name);
}
assert.equal(expectedRuntime.size, 0, 'Understanding runtime dependency missing');
assert(!fs.existsSync(path.join(assets, 'runtime', 'ggml-rpc.dll')));
const modelPin = pins.assets.find(item => item.kind === 'model');
assert.deepEqual(fileRows.get('model.gguf'), {path: 'model.gguf', bytes: modelPin.bytes, sha256: modelPin.sha256});
const packaging = manifest.packaging;
assert(['sidecar', 'bundle'].includes(packaging.modelDelivery));
assert.equal(packaging.preparedModelPath, 'model.gguf');
assert.equal(packaging.installedModelPath, 'understanding/model.gguf');
assert.equal(packaging.modelBytes, modelPin.bytes);
assert.equal(packaging.modelSha256, modelPin.sha256);
assert.equal(packaging.excludeModelFromInstallerResources, packaging.modelDelivery === 'sidecar');
if (modelPin.bytes >= 2 * 1024 ** 3) assert.equal(packaging.modelDelivery, 'sidecar', 'Model exceeds NSIS bundled payload limit');
const build = manifest.runtimeBuild;
assert.equal(build.schema, 1);
assert.deepEqual(build.source, pins.assets.find(item => item.kind === 'runtime-source'));
assert.deepEqual(build.runtime, pins.runtime);
assert.deepEqual(build.build, pins.build);
const canonical = value => Array.isArray(value) ? value.map(canonical) : value && typeof value === 'object'
  ? Object.fromEntries(Object.keys(value).sort().map(key => [key, canonical(value[key])])) : value;
assert.equal(build.recipeSha256, sha256(JSON.stringify(canonical({source: build.source, runtime: pins.runtime, build: pins.build}))));
assert.equal(build.files.length, 4);
assert.deepEqual(build.files.map(row => row.path).sort(), pins.build.variants.flatMap(row => row.executables.map(item => item.fileName)).sort());
const system = new Set(['kernel32.dll','advapi32.dll','shell32.dll','ws2_32.dll','crypt32.dll','psapi.dll','user32.dll','ole32.dll','bcrypt.dll','ntdll.dll','userenv.dll']);
for (const row of build.files) {
  const file = 'runtime/' + row.path;
  assert.deepEqual(fileRows.get(file.toLowerCase()), {path: file, bytes: row.bytes, sha256: row.sha256});
  assert(Array.isArray(row.imports) && row.imports.length > 0);
  for (const name of row.imports) assert(!name.startsWith('api-ms-win-crt-') && (system.has(name) || name.startsWith('api-ms-win-')), 'Non-system runtime import: ' + name);
}
for (const [kind, name] of [['model-license', 'model-LICENSE.txt'], ['runtime-license', 'llama.cpp-MIT.txt']]) {
  const pin = pins.assets.find(item => item.kind === kind);
  const file = 'licenses/' + name;
  assert.deepEqual(fileRows.get(file.toLowerCase()), {path: file, bytes: pin.bytes, sha256: pin.sha256});
}
assert(fileRows.has('notice.txt'), 'Offline understanding notices missing');
assert(fileRows.has('licenses/source-notices/licenses/license-jsonhpp'), 'JSON library license missing');
assert(fileRows.has('licenses/source-notices/vendor/cpp-httplib/license'), 'HTTP helper library license missing');
assert(fileRows.has('licenses/source-notices/vendor/sheredom/subprocess.h'), 'Subprocess header public-domain notice missing');
assert(fileRows.has('licenses/source-notices/vendor/miniaudio/license-from-header.txt'), 'Audio decoder license missing');
assert(fileRows.has('licenses/source-notices/vendor/stb/license-from-header.txt'), 'Image decoder license missing');
const actualFiles = [];
const walk = (directory, prefix = '') => {
  for (const entry of fs.readdirSync(directory, {withFileTypes: true})) {
    const name = prefix + entry.name;
    assert(!entry.isSymbolicLink(), 'Symbolic link in packaged understanding assets');
    if (entry.isDirectory()) walk(path.join(directory, entry.name), name + '/');
    else { assert(entry.isFile(), 'Special file in understanding assets'); actualFiles.push(name); }
  }
};
walk(assets);
assert.deepEqual(actualFiles.sort(), [...manifest.files.map(row => row.path), 'manifest.json'].sort(), 'Unexpected or unmanifested understanding asset');
for (const row of manifest.files) await verify(assets, row);
console.log('Verified offline understanding files:', manifest.files.length);
