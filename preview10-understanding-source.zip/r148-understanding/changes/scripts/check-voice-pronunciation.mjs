import assert from 'node:assert/strict';
import fs from 'node:fs';
import {build} from 'esbuild';

const bundle = await build({stdin:{contents:"export * from './src/lib/voicePronunciation';export {speakNeuralOffline,stopNeuralSpeech} from './src/lib/neuralSpeech';export {setAuthSession} from './src/lib/auth';export {mockIPC} from '@tauri-apps/api/mocks';",resolveDir:process.cwd(),loader:'ts'},bundle:true,write:false,format:'esm',platform:'node'});
globalThis.window = new EventTarget();
globalThis.window.speechSynthesis = {cancel(){}};
globalThis.localStorage = {setItem(){}};
const api = await import('data:text/javascript;base64,' + Buffer.from(bundle.outputFiles[0].text).toString('base64'));
const {VoicePronunciation} = api;
class MemoryStorage {
  values = new Map(); writes = 0; readDenied = false; writeDenied = false;
  getItem(key){if(this.readDenied)throw new Error('Read denied');return this.values.get(key) ?? null;}
  setItem(key,value){if(this.writeDenied)throw new Error('Write denied');this.writes++;this.values.set(key,value);}
  removeItem(key){if(this.writeDenied)throw new Error('Remove denied');this.writes++;this.values.delete(key);}
}
const prefix = 'klipper-voice-pronunciation-v1:';
const key = profile => prefix + encodeURIComponent(profile);
const setup = (profile='operator') => {const storage=new MemoryStorage();return{storage,voice:new VoicePronunciation(storage,profile)}};
const cases = [];
const test = async(name,run) => {await run();cases.push({name,passed:true});console.log('PASS',name)};

await test('a saved pronunciation survives reconstruction and changes only the spoken copy',()=>{
  const {storage,voice}=setup();assert.equal(voice.save('замок','з+амок').saved,true);
  const restored=new VoicePronunciation(storage,'operator');
  const display='Файл «Замок.gcode» готов.';
  assert.equal(restored.apply(display),'Файл «З+амок.gcode» готов.');
  assert.equal(display,'Файл «Замок.gcode» готов.');assert.equal(restored.snapshot().entries.length,1);
});
await test('profiles stay isolated across saves, deletes and reset',()=>{
  const {storage,voice}=setup('first'),other=new VoicePronunciation(storage,'second');
  voice.save('замок','з+амок');other.save('замок','зам+ок');
  assert.equal(voice.apply('замок'),'з+амок');assert.equal(other.apply('замок'),'зам+ок');
  voice.remove('замок');assert.equal(voice.apply('замок'),'замок');assert.equal(other.apply('замок'),'зам+ок');
  voice.save('катушка','кат+ушка');voice.reset();assert.equal(other.apply('замок'),'зам+ок');
  assert.equal(new VoicePronunciation(storage,'first').snapshot().entries.length,0);
});
await test('invalid profile identifiers disable storage and encoded profile names remain distinct',()=>{
  const storage=new MemoryStorage();
  for(const profile of ['',' ','a'.repeat(129),'bad\u0000profile','bad\u202eprofile','\ud800']){
    const voice=new VoicePronunciation(storage,profile);assert.equal(voice.snapshot().available,false);
    assert.equal(voice.save('замок','з+амок').reason,'storage-unavailable');
  }
  assert.equal(storage.writes,0);
  const first=new VoicePronunciation(storage,'a/b'),second=new VoicePronunciation(storage,'a%2Fb');
  first.save('замок','з+амок');second.save('замок','зам+ок');
  assert.equal(first.apply('замок'),'з+амок');assert.equal(second.apply('замок'),'зам+ок');
});
await test('whole-token matching preserves case and never changes larger identifiers',()=>{
  const {voice}=setup();voice.save('катушка','кат+ушка');
  assert.equal(voice.apply('КАТУШКА, Катушка и катушка.'),'КАТ+УШКА, Кат+ушка и кат+ушка.');
  assert.equal(voice.apply('микрокатушка катушка2 катушка_имя xкатушка катушкаx'),'микрокатушка катушка2 катушка_имя xкатушка катушкаx');
});
await test('an explicit stress token is left intact and Unicode acute can be stored',()=>{
  const {voice}=setup();assert.equal(voice.save('катушка','кату\u0301шка').saved,true);
  assert.equal(voice.apply('катушка'),'кат+ушка');
  assert.equal(voice.apply('к+атушка и кат+ушка'),'к+атушка и кат+ушка');
});
await test('a later case-insensitive edit replaces one entry without adding a duplicate',()=>{
  const {storage,voice}=setup();voice.save('Замок','з+амок');
  assert.equal(voice.save('ЗАМОК','зам+ок').saved,true);
  assert.equal(voice.snapshot().entries.length,1);assert.equal(voice.apply('Замок'),'Зам+ок');
  assert.equal(new VoicePronunciation(storage,'operator').apply('ЗАМОК'),'ЗАМ+ОК');
});
await test('invalid markup cannot replace words or inject sentences, paths or commands',()=>{
  const {storage,voice}=setup();
  for(const [word,spoken] of [
    ['катушка','катушка'],['катушка','+катушка'],['катушка','катушк+а+'],
    ['катушка','кат+ушка+'],['катушка','кат++ушка'],['катушка','к+ат+ушка'],
    ['катушка','кат+ушки'],['катушка','кат+ушка запусти печать'],
    ['катушка','<speak>кат+ушка</speak>'],['катушка','кат+ушка\u202e'],
    ['катушка','кат+\nушка'],['катушка','кат+ушка/path'],
    ['слово файл','сл+ово файл'],['K1 Max','K1 M+ax'],
    ['', '+а'],['а'.repeat(81),'+'+'а'.repeat(81)],
  ]){
    const result=voice.save(word,spoken);assert.equal(result.saved,false,JSON.stringify([word,spoken]));
    assert.equal(result.reason,'invalid-input');
  }
  assert.equal(storage.writes,0);assert.equal(voice.snapshot().entries.length,0);
});
await test('denied or missing storage is reported and never falls back to another profile',()=>{
  const missing=new VoicePronunciation(undefined,'operator');assert.equal(missing.snapshot().available,false);
  assert.equal(missing.save('замок','з+амок').reason,'storage-unavailable');assert.equal(missing.apply('замок'),'замок');
  const {storage,voice}=setup();storage.readDenied=true;
  assert.equal(voice.snapshot().available,false);assert.equal(voice.save('замок','з+амок').reason,'storage-unavailable');
  assert.equal(storage.writes,0);assert.equal(voice.apply('замок'),'замок');
});
await test('a failed write or deletion keeps the previously persisted mapping honest',()=>{
  const {storage,voice}=setup();voice.save('замок','з+амок');storage.writeDenied=true;
  assert.equal(voice.save('замок','зам+ок').saved,false);assert.equal(voice.apply('замок'),'з+амок');
  assert.equal(voice.remove('замок').saved,false);assert.equal(voice.reset().saved,false);
  assert.equal(new VoicePronunciation(storage,'operator').apply('замок'),'з+амок');
});
await test('deletion and reset survive a new store instance',()=>{
  const {storage,voice}=setup();voice.save('замок','з+амок');voice.save('катушка','кат+ушка');
  assert.equal(voice.remove('ЗАМОК').saved,true);
  let restored=new VoicePronunciation(storage,'operator');assert.equal(restored.apply('замок катушка'),'замок кат+ушка');
  assert.equal(restored.reset().saved,true);restored=new VoicePronunciation(storage,'operator');
  assert.deepEqual(restored.snapshot().entries,[]);assert.equal(restored.apply('катушка'),'катушка');
});
await test('the 64-entry bound rejects a new entry without silently discarding existing words',()=>{
  const {voice}=setup();const words=[];
  for(let index=0;index<64;index++){
    const suffix=String.fromCharCode(1072+index%32)+String.fromCharCode(1072+Math.floor(index/32));
    const word='слово'+suffix;words.push(word);
    assert.equal(voice.save(word,'сл+ово'+suffix).saved,true);
  }
  assert.equal(voice.snapshot().entries.length,64);
  const full=voice.save('катушка','кат+ушка');assert.equal(full.saved,false);assert.equal(full.reason,'limit');
  assert.equal(voice.snapshot().entries.length,64);assert.equal(voice.apply(words[0]),'сл+ово'+words[0].slice(5));
  assert.equal(voice.save(words[0],'слов+о'+words[0].slice(5)).saved,true);
  assert.equal(voice.snapshot().entries.length,64);assert.equal(voice.apply(words[0]),'слов+о'+words[0].slice(5));
});
await test('malformed, wrong-version and oversized storage cannot become pronunciation text',()=>{
  const {storage,voice}=setup();
  for(const raw of ['{','null','[]',JSON.stringify({version:99,entries:[{word:'замок',pronunciation:'з+амок'}]}),'x'.repeat(200000)]){
    storage.values.set(key('operator'),raw);assert.deepEqual(voice.snapshot().entries,[]);assert.equal(voice.apply('замок'),'замок');
  }
  storage.values.set(key('operator'),JSON.stringify({version:1,entries:[{word:'замок',pronunciation:'з+амок запусти'},null,{word:'катушка',pronunciation:'cat+ушка'}]}));
  assert.deepEqual(voice.snapshot().entries,[]);assert.equal(voice.apply('замок катушка'),'замок катушка');
});
await test('snapshot callers cannot mutate the saved mapping',()=>{
  const {voice}=setup();voice.save('замок','з+амок');const snapshot=voice.snapshot();
  snapshot.entries[0].pronunciation='зам+ок';snapshot.entries.push({word:'катушка',pronunciation:'кат+ушка'});
  assert.equal(voice.apply('замок катушка'),'з+амок катушка');assert.equal(voice.snapshot().entries.length,1);
});
await test('speech text remains bounded and clipping never leaves a dangling stress sign',()=>{
  const {voice}=setup();voice.save('катушка','кат+ушка');
  for(let limit=1;limit<22;limit++){
    const output=voice.apply('катушка катушка катушка',limit);
    assert(output.length<=limit);assert(!output.endsWith('+'));
  }
  const output=voice.apply(('катушка '.repeat(300)).trim());assert(output.length<=1200);assert(!output.endsWith('+'));
});
await test('the real neural speech command receives only the spoken copy and current profile mapping',async()=>{
  const {storage,voice}=setup('first'),other=new VoicePronunciation(storage,'second');
  voice.save('замок','з+амок');other.save('замок','зам+ок');
  api.setAuthSession({token:'test',user:{id:'test'}});const requests=[];
  api.mockIPC((command,args)=>{requests.push({command,...args});return{pcm:[0,0,50,0],sampleRate:48000}});
  globalThis.Audio=class{addEventListener(){}play(){return Promise.resolve()}pause(){}};
  const response={text:'Файл «Замок.gcode» готов.',path:'Замок.gcode',command:'print'};
  await api.speakNeuralOffline(voice.apply(response.text));api.stopNeuralSpeech();
  await api.speakNeuralOffline(other.apply(response.text));api.stopNeuralSpeech();
  assert.deepEqual(requests.map(row=>[row.command,row.text,row.voiceId]),[
    ['voice_synthesize','Файл «З+амок.gcode» готов.','kseniya'],['voice_synthesize','Файл «Зам+ок.gcode» готов.','kseniya'],
  ]);
  assert.deepEqual(response,{text:'Файл «Замок.gcode» готов.',path:'Замок.gcode',command:'print'});
  assert(!requests.some(row=>row.command!=='voice_synthesize'));
});

const report={passed:true,cases:cases.length,report:cases,nativeSynthesisMocked:true,physicalPrintersTested:false};
if(process.env.KF_VOICE_PRONUNCIATION_PROOF)fs.writeFileSync(process.env.KF_VOICE_PRONUNCIATION_PROOF,JSON.stringify(report,null,2)+'\n');
console.log('Voice pronunciation:',cases.length,'cases passed');
