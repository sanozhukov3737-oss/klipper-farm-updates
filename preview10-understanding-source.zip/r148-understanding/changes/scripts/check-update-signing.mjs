import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {spawnSync} from 'node:child_process';

const fixture=fs.mkdtempSync(path.join(os.tmpdir(),'kf-update-signing-'));
try{
  fs.mkdirSync(path.join(fixture,'scripts'));
  fs.copyFileSync(new URL('./sign-v20-update.mjs',import.meta.url),path.join(fixture,'scripts/sign-v20-update.mjs'));
  // These are disposable test keys; production uses the existing embedded key.
  const key=crypto.generateKeyPairSync('ed25519');
  const publicHex=crypto.createPublicKey(key.privateKey).export({format:'der',type:'spki'}).subarray(-32).toString('hex');
  const privatePath=path.join(fixture,'fixture-key.pem');
  fs.writeFileSync(privatePath,key.privateKey.export({format:'pem',type:'pkcs8'}),{mode:0o600});
  fs.writeFileSync(path.join(fixture,'UPDATE-CHANNEL.json'),JSON.stringify({publicKeyHex:publicHex}));
  const artifact=path.join(fixture,'setup.exe');
  fs.writeFileSync(artifact,'fixture installer');
  const output=path.join(fixture,'update-v20.json');
  const env={...process.env,KF_UPDATE_ARTIFACT:artifact,KF_UPDATE_SIGNING_KEY:privatePath,
    KF_UPDATE_SEQUENCE:'145',KF_UPDATE_VERSION:'1.14.5',KF_UPDATE_CHANNEL:'stable',
    KF_UPDATE_ARTIFACT_URL:'https://example.com/releases/setup.exe',KF_UPDATE_MANIFEST:output,
    SOURCE_DATE_EPOCH:'1793404800'};
  const run=()=>spawnSync(process.execPath,[path.join(fixture,'scripts/sign-v20-update.mjs')],{env,encoding:'utf8'});
  let result=run();
  assert.equal(result.status,0,result.stderr);
  const manifest=JSON.parse(fs.readFileSync(output,'utf8'));
  const {signatureHex,...unsigned}=manifest;
  assert.equal(manifest.artifact.sizeBytes,17);
  assert.equal(manifest.artifact.sha256,crypto.createHash('sha256').update(fs.readFileSync(artifact)).digest('hex'));
  assert(crypto.verify(null,Buffer.concat([Buffer.from('klipper-farm-update-manifest-v1\0'),Buffer.from(JSON.stringify(unsigned))]),key.publicKey,Buffer.from(signatureHex,'hex')));
  const validManifest=fs.readFileSync(output);
  fs.writeFileSync(path.join(fixture,'UPDATE-CHANNEL.json'),JSON.stringify({publicKeyHex:'00'.repeat(32)}));
  result=run();
  assert.notEqual(result.status,0);
  assert.match(result.stderr,/does not match the existing application trust key/);
  assert.deepEqual(fs.readFileSync(output),validManifest);
  fs.writeFileSync(path.join(fixture,'UPDATE-CHANNEL.json'),JSON.stringify({publicKeyHex:publicHex}));
  // Sparse file: exercise the installed updater's exact size boundary without hashing it.
  const fd=fs.openSync(artifact,'w');
  fs.ftruncateSync(fd,512*1024*1024+1);
  fs.closeSync(fd);
  result=run();
  assert.notEqual(result.status,0);
  assert.match(result.stderr,/512 MiB/);
  assert.deepEqual(fs.readFileSync(output),validManifest);
  fs.writeFileSync(artifact,'fixture installer');
  env.KF_UPDATE_ARTIFACT=path.join(fixture,'setup.zip');
  fs.copyFileSync(artifact,env.KF_UPDATE_ARTIFACT);
  result=run();
  assert.notEqual(result.status,0);
  assert.match(result.stderr,/regular \.exe/);
  console.log('update signing OK: authentic signature, existing trust key, installer limit and failed-sign preservation');
}finally{
  fs.rmSync(fixture,{recursive:true,force:true});
}
