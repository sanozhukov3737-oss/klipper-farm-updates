"""Small offline build-security checks; no downloaded model or Windows toolchain needed."""
import contextlib
import hashlib
import importlib.util
import io
import json
import shutil
import struct
import subprocess
import tarfile
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

SCRIPT = Path(__file__).with_name('prepare-voice-understanding.py')
SPEC = importlib.util.spec_from_file_location('understanding_assets', SCRIPT)
assets = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(assets)


def fingerprint(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def pe(import_name='KERNEL32.dll'):
    data = bytearray(1024)
    data[:2] = b'MZ'
    struct.pack_into('<I', data, 60, 64)
    data[64:68] = b'PE\0\0'
    struct.pack_into('<HH', data, 68, 0x8664, 1)
    struct.pack_into('<H', data, 84, 240)
    struct.pack_into('<H', data, 88, 0x20b)
    struct.pack_into('<II', data, 88 + 112 + 8, 0x1000, 40)
    struct.pack_into('<IIII', data, 328 + 8, 512, 0x1000, 512, 512)
    struct.pack_into('<IIIII', data, 512, 0, 0, 0, 0x1040, 0)
    encoded = import_name.encode() + b'\0'
    data[576:576 + len(encoded)] = encoded
    return bytes(data)


def source_tar(revision, entries):
    output = io.BytesIO()
    with tarfile.open(fileobj=output, mode='w:gz') as archive:
        for name, data, kind in entries:
            info = tarfile.TarInfo('llama.cpp-' + revision + '/' + name)
            info.type = kind
            if kind == tarfile.SYMTYPE:
                info.linkname = '../../escape'
            else:
                info.size = len(data)
            archive.addfile(info, io.BytesIO(data))
    return output.getvalue()


class PreparationTests(unittest.TestCase):
    def setUp(self):
        self.directory = Path(tempfile.mkdtemp(prefix='understanding-check-'))

    def tearDown(self):
        shutil.rmtree(self.directory)

    def test_paths(self):
        for name in ['', '.', '../escape', '/escape', 'a\\escape', 'C:/escape', 'x/../escape', 'name.', 'name ', 'a\0b']:
            with self.subTest(name=name), self.assertRaises(ValueError):
                assets.safe_path(name)

    def test_tar_rejects_links_traversal_and_case_collisions(self):
        revision = 'a' * 40
        cases = [[('link', b'', tarfile.SYMTYPE)], [('../escape', b'x', tarfile.REGTYPE)],
                 [('A', b'x', tarfile.REGTYPE), ('a', b'y', tarfile.REGTYPE)]]
        for index, entries in enumerate(cases):
            archive = self.directory / ('source-' + str(index) + '.tar.gz')
            archive.write_bytes(source_tar(revision, entries))
            destination = self.directory / ('out-' + str(index))
            destination.mkdir()
            with self.assertRaises(ValueError):
                assets.extract_source(archive, destination, revision)
            self.assertEqual(list(destination.iterdir()), [])

    def test_pe_rejects_external_crt_and_private_dlls(self):
        binary = self.directory / 'completion.exe'
        binary.write_bytes(pe())
        self.assertEqual(assets.verify_standalone(binary), ['kernel32.dll'])
        for name in ['MSVCP140.dll', 'VCRUNTIME140.dll', 'libomp.dll', 'llama.dll', 'api-ms-win-crt-runtime-l1-1-0.dll']:
            binary.write_bytes(pe(name))
            with self.subTest(name=name), self.assertRaises(ValueError):
                assets.verify_standalone(binary)

    def test_download_stops_after_expected_size_and_cleans_partial(self):
        class Response(io.BytesIO):
            url = 'https://example.invalid/asset'
            headers = {}
        pin = {'name': 'asset.bin', 'url': Response.url, **fingerprint(b'good')}
        with patch.object(assets.urllib.request, 'urlopen', return_value=Response(b'wrong and oversized')):
            with self.assertRaises(ValueError):
                assets.download(pin, self.directory, False)
        self.assertFalse((self.directory / 'asset.bin.part').exists())
        self.assertFalse((self.directory / 'asset.bin').exists())

    def test_offline_cache_requires_both_size_and_sha(self):
        pin = {'name': 'asset.bin', 'url': 'https://example.invalid/asset', **fingerprint(b'good')}
        (self.directory / 'asset.bin').write_bytes(b'evil')
        with self.assertRaises(ValueError):
            assets.download(pin, self.directory, True)
        (self.directory / 'asset.bin').write_bytes(b'good')
        self.assertEqual(assets.download(pin, self.directory, True), self.directory / 'asset.bin')

    def test_download_stream_accepts_model_above_two_gib_without_large_buffers(self):
        expected = 2497281120
        class Response:
            url = 'https://example.invalid/model.gguf'
            headers = {'Content-Length': str(expected)}
            remaining = expected
            chunk = b'x' * assets.CHUNK
            largest = 0
            def __enter__(self): return self
            def __exit__(self, *unused): pass
            def read(self, limit):
                self.largest = max(self.largest, limit)
                count = min(limit, self.remaining)
                self.remaining -= count
                return self.chunk if count == len(self.chunk) else self.chunk[:count]
        class Sink:
            count = 0
            def __enter__(self): return self
            def __exit__(self, *unused): pass
            def write(self, data): self.count += len(data)
        class Hash:
            count = 0
            def update(self, data): self.count += len(data)
            def hexdigest(self): return 'a' * 64
        response, sink, hashed = Response(), Sink(), Hash()
        pin = {'name': 'large-model.gguf', 'url': response.url, 'bytes': expected, 'sha256': 'a' * 64}
        with patch.object(assets.urllib.request, 'urlopen', return_value=response), \
                patch.object(assets.hashlib, 'sha256', return_value=hashed), \
                patch.object(Path, 'open', return_value=sink), \
                patch.object(Path, 'replace'), patch.object(Path, 'unlink'):
            result = assets.download(pin, self.directory, False)
        self.assertEqual(result.name, pin['name'])
        self.assertEqual(sink.count, expected)
        self.assertEqual(hashed.count, expected)
        self.assertLessEqual(response.largest, assets.CHUNK)

    @unittest.skipUnless(shutil.which('node'), 'Node is required for the packaging verification fixture')
    def test_complete_package_and_node_verifier_reject_stale_extra_file(self):
        pins = json.loads(SCRIPT.with_name('voice-understanding-assets.json').read_text())
        root = self.directory / 'app'
        scripts, cache = root / 'scripts', self.directory / 'cache'
        scripts.mkdir(parents=True)
        cache.mkdir()
        runtime = self.directory / 'runtime'
        runtime.mkdir()
        source = source_tar(pins['runtime']['revision'], [
            ('LICENSE', b'MIT fixture', tarfile.REGTYPE),
            ('licenses/LICENSE-jsonhpp', b'JSON fixture', tarfile.REGTYPE),
            ('vendor/cpp-httplib/LICENSE', b'HTTP fixture', tarfile.REGTYPE),
            ('vendor/sheredom/subprocess.h', b'Public domain fixture', tarfile.REGTYPE),
            ('vendor/miniaudio/miniaudio.h', b'header\n/* ALTERNATIVE MIT LICENSE THE SOFTWARE fixture */', tarfile.REGTYPE),
            ('vendor/stb/stb_image.h', b'header\n/* ALTERNATIVE MIT LICENSE THE SOFTWARE fixture */', tarfile.REGTYPE)])
        fixture = {'model': b'GGUF model fixture', 'runtime-source': source,
                   'model-license': b'Apache fixture', 'runtime-license': b'MIT fixture'}
        for row in pins['assets']:
            row.update(fingerprint(fixture[row['kind']]))
            (cache / row['name']).write_bytes(fixture[row['kind']])
        pins_path = scripts / 'voice-understanding-assets.json'
        pins_path.write_text(json.dumps(pins, indent=2) + '\n')
        report = {'schema': 1, 'source': next(row for row in pins['assets'] if row['kind'] == 'runtime-source'),
                  'runtime': pins['runtime'], 'build': pins['build'], 'files': []}
        report['recipeSha256'] = hashlib.sha256(json.dumps({key: report[key] for key in ['source', 'runtime', 'build']},
            sort_keys=True, separators=(',', ':')).encode()).hexdigest()
        for variant in pins['build']['variants']:
            for item in variant['executables']:
                (runtime / item['fileName']).write_bytes(pe())
                report['files'].append({'path': item['fileName'], **fingerprint(pe()), 'imports': ['kernel32.dll']})
        with patch.object(assets, 'build_runtimes', return_value=(runtime, report)), contextlib.redirect_stdout(io.StringIO()):
            report = assets.prepare(root, cache, True, pins_path, model_sidecar=True)
        self.assertEqual(report['packaging']['modelDelivery'], 'sidecar')
        self.assertTrue(report['packaging']['excludeModelFromInstallerResources'])
        notice = (root / 'src-tauri/resources/understanding/NOTICE.txt').read_text()
        self.assertIn('Unsloth', notice)
        self.assertIn('Qwen/Qwen3-4B-Instruct-2507', notice)
        self.assertIn('installer reuses verified components', notice)
        self.assertIn('Inference uses --offline and installed local files', notice)
        checker = scripts / 'check-voice-understanding-assets.mjs'
        shutil.copyfile(SCRIPT.with_name(checker.name), checker)
        subprocess.run(['node', str(checker), str(root)], check=True, capture_output=True)
        destination = root / 'src-tauri/resources/understanding'
        (destination / 'runtime' / 'ggml-rpc-server.exe').write_bytes(pe())
        failed = subprocess.run(['node', str(checker), str(root)], capture_output=True)
        self.assertNotEqual(failed.returncode, 0)


if __name__ == '__main__':
    unittest.main()
