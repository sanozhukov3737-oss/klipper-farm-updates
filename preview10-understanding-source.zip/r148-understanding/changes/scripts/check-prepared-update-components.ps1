# Windows CI preflight using the real prepared runtime and model before Rust.
# Hard links are read-only aliases here: only their owned directory entries are
# removed. The original prepared assets are never copied over or deleted.
[CmdletBinding()]
param(
  [string]$ComponentBuildReportPath,
  [string]$ProofPath
)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$appRoot = Split-Path -Parent $PSScriptRoot
if (-not $ComponentBuildReportPath) { $ComponentBuildReportPath = Join-Path $appRoot '.update-components/component-build-report.json' }
$ComponentBuildReportPath = [IO.Path]::GetFullPath($ComponentBuildReportPath)
if (-not $ProofPath) { $ProofPath = Join-Path (Split-Path -Parent $ComponentBuildReportPath) 'prepared-component-proof.json' }
$ProofPath = [IO.Path]::GetFullPath($ProofPath)
$helper = Join-Path $PSScriptRoot 'install-update-components.ps1'
$ownedRoot = $null
$ownerToken = [Guid]::NewGuid().ToString('N')
$currentCase = 'inputs'
$failure = $null
$canWriteProof = $false
$proof = @{schema=1; passed=$false; directPreparedComponents=$true; networkAllowed=$false}

function Assert-NoReparsePoint([string]$Path) {
  $current = [IO.Path]::GetFullPath($Path)
  while ($current) {
    if (Test-Path -LiteralPath $current) {
      $item = Get-Item -LiteralPath $current -Force
      if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw ('Preflight path is a link: ' + $current) }
    }
    $parent = [IO.Directory]::GetParent($current)
    $current = if ($parent) { $parent.FullName } else { $null }
  }
}

function Assert-OwnedTree([string]$Directory) {
  if (-not $ownedRoot -or [IO.Path]::GetFullPath($Directory) -cne $ownedRoot) { throw 'Refusing cleanup outside the owned preflight root.' }
  Assert-NoReparsePoint $Directory
  $marker = Join-Path $Directory '.preflight-owner'
  Assert-NoReparsePoint $marker
  if (-not (Test-Path -LiteralPath $marker -PathType Leaf) -or [IO.File]::ReadAllText($marker) -cne $ownerToken) { throw 'Preflight cleanup ownership marker differs.' }
  Assert-TreeNoLinks $Directory
}

function Assert-TreeNoLinks([string]$Directory) {
  foreach ($item in Get-ChildItem -LiteralPath $Directory -Force) {
    if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw ('Refusing cleanup through a link: ' + $item.FullName) }
    if ($item.PSIsContainer) { Assert-TreeNoLinks $item.FullName }
  }
}

function Read-BoundedText([string]$Path, [int]$Maximum = 4000) {
  if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return '' }
  Assert-NoReparsePoint $Path
  $item = Get-Item -LiteralPath $Path -Force
  if ($item.Length -le 64KB) {
    $text = [IO.File]::ReadAllText($Path)
  } else {
    $stream = [IO.File]::OpenRead($Path)
    try {
      $count = [int][Math]::Min(8192, $stream.Length)
      [void]$stream.Seek(-$count, [IO.SeekOrigin]::End)
      $buffer = New-Object byte[] $count
      $read = $stream.Read($buffer, 0, $count)
      $text = [Text.Encoding]::UTF8.GetString($buffer, 0, $read)
    } finally { $stream.Dispose() }
  }
  if ($text.Length -gt $Maximum) { return $text.Substring($text.Length - $Maximum) }
  return $text
}

function New-AssetAlias([string]$Original, [string]$Alias) {
  Assert-NoReparsePoint $Original
  Assert-NoReparsePoint $Alias
  if (-not (Test-Path -LiteralPath $Original -PathType Leaf)) { throw 'Prepared asset is not a regular file.' }
  if (-not [string]::Equals([IO.Path]::GetPathRoot($Original), [IO.Path]::GetPathRoot($Alias), [StringComparison]::OrdinalIgnoreCase)) {
    throw 'Prepared preflight requires RUNNER_TEMP on the prepared asset volume for hard links.'
  }
  New-Item -ItemType HardLink -Path $Alias -Target $Original | Out-Null
  Assert-NoReparsePoint $Alias
}

function Invoke-PreparedCase([string]$Name) {
  $resultPath = Join-Path $ownedRoot ($Name + '-result.txt')
  $stdoutPath = Join-Path $ownedRoot ($Name + '-stdout.log')
  $stderrPath = Join-Path $ownedRoot ($Name + '-stderr.log')
  $quoted = @('-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass',
    '-File',('"' + $helper + '"'),'-InstallRoot',('"' + $installRoot + '"'),
    '-ManifestPath',('"' + $report.manifestPath + '"'),'-LocalSource',('"' + $sourceRoot + '"'),
    '-ResultPath',('"' + $resultPath + '"'),'-Offline','-NoProgressWindow')
  $process = Start-Process -FilePath (Join-Path $PSHOME 'powershell.exe') -ArgumentList $quoted -Wait -PassThru -WindowStyle Hidden -RedirectStandardOutput $stdoutPath -RedirectStandardError $stderrPath
  if ($process.ExitCode -ne 0) {
    $details = Read-BoundedText $resultPath
    if (-not $details) { $details = Read-BoundedText $stderrPath }
    if (-not $details) { $details = 'No component result or standard error was written.' }
    $proof.componentResult = $details
    $proof.stdoutTail = Read-BoundedText $stdoutPath
    $proof.stderrTail = Read-BoundedText $stderrPath
    throw ('Prepared component ' + $Name + ' failed: exit ' + $process.ExitCode + '. ' + $details)
  }
  $statePath = Join-Path $installRoot '.klipper-component-state.json'
  Assert-NoReparsePoint $statePath
  $state = [IO.File]::ReadAllText($statePath) | ConvertFrom-Json
  if ($state.schema -ne 1 -or $state.runtimeSha256 -cne $manifest.runtime.sha256 -or
      $state.modelSha256 -cne $manifest.model.sha256 -or $state.runtimeFiles -ne @($manifest.runtime.files).Count -or
      $state.networkDownloadBytes -ne 0) { throw ('Prepared component ' + $Name + ' report differs from the pinned inputs.') }
  return $state
}

try {
  foreach ($path in @($ComponentBuildReportPath, $helper, $ProofPath)) { Assert-NoReparsePoint $path }
  $report = [IO.File]::ReadAllText($ComponentBuildReportPath, [Text.UTF8Encoding]::new($false, $true)) | ConvertFrom-Json
  foreach ($path in @($report.assetPath, $report.modelPath, $report.manifestPath)) {
    if (-not ($path -is [string]) -or -not [IO.Path]::IsPathRooted($path)) { throw 'Prepared component report contains an invalid input path.' }
    Assert-NoReparsePoint $path
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw 'Prepared component input is missing.' }
  }
  foreach ($inputPath in @($ComponentBuildReportPath, $helper, $report.assetPath, $report.modelPath, $report.manifestPath)) {
    if ([string]::Equals($ProofPath, [IO.Path]::GetFullPath($inputPath), [StringComparison]::OrdinalIgnoreCase)) { throw 'Proof output must not overwrite a prepared input.' }
  }
  $canWriteProof = $true
  $manifest = [IO.File]::ReadAllText($report.manifestPath, [Text.UTF8Encoding]::new($false, $true)) | ConvertFrom-Json
  if ($report.schema -ne 1 -or $manifest.schema -ne 1 -or $report.name -cnotmatch '^klipper-farm-runtime-[0-9a-f]{64}\.zip$' -or
      $report.name -cne $manifest.runtime.name -or $report.sha256 -cne $manifest.runtime.sha256 -or
      $report.bytes -ne $manifest.runtime.bytes -or $report.runtimeFileCount -ne @($manifest.runtime.files).Count) { throw 'Prepared report and embedded component manifest differ.' }
  $tempRoot = if ($env:RUNNER_TEMP) { [IO.Path]::GetFullPath($env:RUNNER_TEMP) } else { [IO.Path]::GetTempPath() }
  Assert-NoReparsePoint $tempRoot
  $candidateRoot = [IO.Path]::GetFullPath((Join-Path $tempRoot ('kfcp-' + $ownerToken.Substring(0,12))))
  if (Test-Path -LiteralPath $candidateRoot) { throw 'Preflight temporary root already exists.' }
  [IO.Directory]::CreateDirectory($candidateRoot) | Out-Null
  $ownedRoot = $candidateRoot
  [IO.File]::WriteAllText((Join-Path $ownedRoot '.preflight-owner'), $ownerToken, [Text.UTF8Encoding]::new($false))
  $sourceRoot = Join-Path $ownedRoot 'source'
  $installRoot = Join-Path $ownedRoot 'app'
  [IO.Directory]::CreateDirectory($sourceRoot) | Out-Null
  New-AssetAlias ([IO.Path]::GetFullPath($report.assetPath)) (Join-Path $sourceRoot $report.name)
  New-AssetAlias ([IO.Path]::GetFullPath($report.modelPath)) (Join-Path $sourceRoot 'model.gguf')
  $proof.runtimeFiles = @($manifest.runtime.files).Count
  $proof.emptyRuntimeFiles = @($manifest.runtime.files | Where-Object { $_.bytes -eq 0 }).Count
  $proof.runtimeSha256 = $manifest.runtime.sha256
  $proof.modelSha256 = $manifest.model.sha256
  $currentCase = 'fresh'
  $fresh = Invoke-PreparedCase 'fresh'
  if ($fresh.modelReused -or $fresh.runtimeReusedFiles -ne 0 -or $fresh.localCopyBytes -le 0) { throw 'Prepared fresh case did not install the verified local assets.' }
  $proof.fresh = $fresh
  Assert-OwnedTree $ownedRoot
  # Remove only the aliases. The second real helper run must work with no
  # adjacent archive/model and with all network access prohibited.
  [IO.Directory]::Delete($sourceRoot, $true)
  [IO.Directory]::CreateDirectory($sourceRoot) | Out-Null
  $currentCase = 'reuse'
  $reuse = Invoke-PreparedCase 'reuse'
  if (-not $reuse.modelReused -or $reuse.runtimeReusedFiles -ne $reuse.runtimeFiles -or
      $reuse.localCopyBytes -ne 0 -or $reuse.networkDownloadBytes -ne 0) { throw 'Prepared reuse case downloaded or copied a component.' }
  if (-not (Test-Path -LiteralPath $report.assetPath -PathType Leaf) -or -not (Test-Path -LiteralPath $report.modelPath -PathType Leaf)) { throw 'Prepared source assets were not retained.' }
  $proof.reuse = $reuse
  $proof.originalAssetsRetained = $true
  $proof.passed = $true
} catch {
  $failure = $_.Exception.Message
  $proof.failedCase = $currentCase
  $proof.error = $failure.Substring(0, [Math]::Min(4000, $failure.Length))
} finally {
  if ($ownedRoot) {
    try {
      Assert-OwnedTree $ownedRoot
      [IO.Directory]::Delete($ownedRoot, $true)
      $proof.ownedTemporaryFilesRemoved = $true
    } catch {
      $proof.passed = $false
      $proof.cleanupError = $_.Exception.Message
      if (-not $failure) { $failure = $_.Exception.Message }
    }
  }
  if ($canWriteProof) {
    Assert-NoReparsePoint $ProofPath
    [IO.Directory]::CreateDirectory((Split-Path -Parent $ProofPath)) | Out-Null
    [IO.File]::WriteAllText($ProofPath, ($proof | ConvertTo-Json -Depth 12), [Text.UTF8Encoding]::new($false))
  }
}
if ($failure) { Write-Error $failure -ErrorAction Continue; exit 2 }
Write-Output ('PASS: real prepared components installed and reused offline; ' + $proof.runtimeFiles + ' runtime files, including ' + $proof.emptyRuntimeFiles + ' empty files.')
