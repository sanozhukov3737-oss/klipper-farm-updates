import {useState} from 'react';
import {VoicePronunciation} from '../lib/voicePronunciation';
import './VoicePronunciationSettings.css';

type Props={store:VoicePronunciation;disabled:boolean;onPreview:(text:string)=>void};
export function VoicePronunciationSettings({store,disabled,onPreview}:Props){
  const [snapshot,setSnapshot]=useState(()=>store.snapshot()),[word,setWord]=useState(''),[marked,setMarked]=useState(''),[error,setError]=useState('');
  const update=(result:ReturnType<VoicePronunciation['save']>)=>{
    setSnapshot(store.snapshot());
    setError(result.saved?'':result.reason==='invalid-input'?'Введите то же слово и один знак + перед ударной гласной. Например: катушка → кат+ушка.':result.reason==='limit'?'Можно сохранить до 64 слов. Удалите лишнее или исправьте существующее.':'Не удалось сохранить произношение на этом компьютере.');
    return result.saved;
  };
  return <details className="kfVoiceLearning kfVoicePronunciation">
    <summary>Произношение · {snapshot.entries.length}</summary>
    <p>Если Ксения ошибается, укажите ударение: катушка → кат+ушка. Исправление действует только в озвучке вашего профиля.</p>
    <form onSubmit={event=>{event.preventDefault();if(update(store.save(word,marked))){setWord('');setMarked('')}}}>
      <label>Слово<input aria-label="Слово для произношения" maxLength={80} value={word} disabled={disabled||!snapshot.available} onChange={event=>setWord(event.target.value)} placeholder="катушка"/></label>
      <label>С ударением<input aria-label="Слово с ударением" maxLength={160} value={marked} disabled={disabled||!snapshot.available} onChange={event=>setMarked(event.target.value)} placeholder="кат+ушка"/></label>
      <button type="submit" disabled={disabled||!snapshot.available||!word.trim()||!marked.trim()}>Сохранить произношение</button>
    </form>
    {snapshot.entries.map(row=><div key={row.word}><span><b>{row.word}</b><small>{row.pronunciation}</small></span><button type="button" disabled={disabled} aria-label={'Послушать произношение '+row.word} onClick={()=>onPreview(row.word)}>Послушать</button><button type="button" disabled={disabled} aria-label={'Удалить произношение '+row.word} onClick={()=>update(store.remove(row.word))}>Удалить</button></div>)}
    {!!snapshot.entries.length&&<button type="button" disabled={disabled} onClick={()=>update(store.reset())}>Сбросить произношение</button>}
    {(!snapshot.available||error)&&<p role="status">{error||'Настройки произношения сейчас недоступны для этого профиля.'}</p>}
  </details>;
}
