import type { PrinterModel } from '../types';
import { finishDuration, finishTime, printerFinish } from './printerFinish';
import { jobFreshness } from './printerTelemetry';

export type VoicePrinterForecastRequest={mode:'finish'|'first'|'after';minutes?:number};
type Observation={name:string;kind:'free'|'known'|'unknown';finishAt?:number;remainingSeconds?:number;reason?:string};
const printerName=(value:string)=>value.replace(/[\p{Cc}\p{Cf}]/gu,' ').replace(/\s+/gu,' ').trim().slice(0,160)||'Принтер';

function observe(printer:PrinterModel,now:number):Observation{
  const status=printer.status,name=printerName(printer.name);
  const unknown=(reason:string):Observation=>({name,kind:'unknown',reason});
  if(status.remoteControlSuspended)return unknown('управление приостановлено, время окончания неизвестно');
  if(status.connectionState==='offline'||status.state==='offline')return unknown('нет подтверждённой связи, время окончания неизвестно');
  if(status.connectionState!=='online')return unknown('связь ещё не подтверждена, время окончания неизвестно');
  if(!Number.isFinite(status.jobUpdatedAt)||status.jobUpdatedAt!>now+1000||jobFreshness(status,now)!=='live')return unknown('свежих данных о задании нет, время окончания неизвестно');
  if(status.state==='error')return unknown('ошибка печати, время окончания неизвестно');
  if(status.state==='paused')return unknown('печать на паузе, время окончания станет известно после продолжения');
  const forecast=printerFinish(status,now);
  if(status.state==='ready'&&!forecast.active)return{name,kind:'free'};
  if(forecast.active&&forecast.finishAt!==undefined&&forecast.remainingSeconds!==undefined)return{name,kind:'known',finishAt:forecast.finishAt,remainingSeconds:forecast.remainingSeconds};
  return unknown('время окончания пока рассчитывается');
}

const names=(items:Observation[])=>items.map(item=>item.name).join(', ');
const freeReply=(items:Observation[])=>items.length===1?`${items[0].name} уже свободен.`:`Уже свободны: ${names(items)}.`;
const unknownReply=(items:Observation[])=>items.map(item=>`${item.name}: ${item.reason}.`).join(' ');
const clockReply=(at:number,now:number)=>{
  const time=finishTime(at,now);
  return time.startsWith('завтра, ')?`завтра около ${time.slice('завтра, '.length)}`:/^\d{2}:\d{2}$/u.test(time)?`около ${time}`:`ориентировочно ${time}`;
};
const finishReply=(item:Observation,now:number)=>`${item.name}: печать закончится примерно через ${finishDuration(item.remainingSeconds!)}, ${clockReply(item.finishAt!,now)}.`;

/** Read-only projections of the current jobs. No printer action or queue is scheduled. */
export function voicePrinterForecast(printers:readonly PrinterModel[],request:VoicePrinterForecastRequest,now=Date.now()):string{
  if(!Number.isFinite(now)||Math.abs(now)>8.63e15)return'Сейчас не могу надёжно рассчитать время окончания.';
  if(!request||!['finish','first','after'].includes(request.mode))return'Уточни, нужно время окончания печати или список принтеров, которые освободятся раньше.';
  if(request.mode==='after'&&(!Number.isInteger(request.minutes)||request.minutes!<1||request.minutes!>10080))return'Через сколько минут посмотреть? Назови время от 1 минуты до 7 суток.';
  if(!printers.length)return'В ферме пока нет принтеров.';
  const observations=printers.map(printer=>observe(printer,now));
  const free=observations.filter(item=>item.kind==='free'),unknown=observations.filter(item=>item.kind==='unknown');
  const known=observations.filter(item=>item.kind==='known');
  if(request.mode==='finish')return observations.map(item=>item.kind==='free'?freeReply([item]):item.kind==='known'?finishReply(item,now):unknownReply([item])).join(' ');
  if(request.mode==='first'){
    const replies:string[]=free.length?[freeReply(free)]:[];
    if(known.length){
      const ordered=known.slice().sort((a,b)=>a.finishAt!-b.finishAt!),earliest=ordered[0];
      const tied=ordered.filter(item=>Math.abs(item.finishAt!-earliest.finishAt!)<1000);
      const scope=unknown.length?'Среди принтеров с известным прогнозом':free.length?'Из занятых принтеров':'По текущему прогнозу';
      replies.push(tied.length===1?`${scope} раньше закончит ${earliest.name}: примерно через ${finishDuration(earliest.remainingSeconds!)}, ${clockReply(earliest.finishAt!,now)}.`:`${scope} примерно одновременно закончат: ${names(tied)}. Осталось около ${finishDuration(earliest.remainingSeconds!)}.`);
    }else if(!free.length)replies.push('Пока не могу определить, кто освободится первым.');
    if(unknown.length)replies.push(unknownReply(unknown));
    return replies.join(' ');
  }
  const horizon=now+request.minutes!*60_000,continuing=known.filter(item=>item.finishAt!>horizon);
  const replies=[continuing.length?`По текущему прогнозу через ${finishDuration(request.minutes!*60)} ещё ${continuing.length===1?'будет печатать '+continuing[0].name:'будут печатать: '+names(continuing)}.`:known.length?'По текущему прогнозу текущие задания с известным временем закончатся к этому моменту.':free.length===observations.length?'Сейчас все принтеры свободны.':'Пока нет надёжного прогноза текущих печатей.'];
  if(unknown.length)replies.push(unknownReply(unknown));
  replies.push('Новые задания в этот прогноз не входят.');
  return replies.join(' ');
}
