import {secureInvoke} from './auth';
import type {VoiceSemanticInput} from './voiceSemantic';

let serial=0;
/** Model output is data, subsequently validated by voiceSemantic before dispatch. */
export async function interpretVoiceSemantic(input:VoiceSemanticInput,signal:AbortSignal):Promise<unknown>{
  if(signal.aborted)throw new DOMException('Действие отменено','AbortError');
  const requestId=`voice-${Date.now()}-${++serial}-${crypto.randomUUID()}`;
  const cancel=()=>{void secureInvoke('voice_semantic_cancel',{requestId}).catch(()=>{})};
  signal.addEventListener('abort',cancel,{once:true});
  try{
    if(signal.aborted){cancel();throw new DOMException('Действие отменено','AbortError')}
    const result=await secureInvoke<unknown>('voice_semantic_interpret',{requestId,request:input});
    if(signal.aborted)throw new DOMException('Действие отменено','AbortError');
    return result;
  }finally{signal.removeEventListener('abort',cancel)}
}

export function voiceUnderstandingStatus(){
  return secureInvoke<{available:boolean}>('voice_semantic_status');
}

export function prepareVoiceUnderstanding(){
  return secureInvoke<void>('voice_semantic_prepare');
}
