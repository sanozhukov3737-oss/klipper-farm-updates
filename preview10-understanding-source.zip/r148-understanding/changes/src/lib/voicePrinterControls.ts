import type {PrinterModel} from '../types';
import {assertModelDependentOperationAllowed} from './modelSafety';

export type VoicePrinterControlAction='light-on'|'light-off'|'pause'|'resume'|'camera';
type PrintObservation={confirmed:boolean;state:string;filename?:string};
type LightObservation={supported:boolean;on?:boolean};
export type VoicePrinterControlClient={
  light?:(on:boolean,assertApplicable?:()=>void)=>Promise<LightObservation>;
  pause?:(assertApplicable?:()=>void)=>Promise<unknown>;
  resume?:(assertApplicable?:()=>void)=>Promise<unknown>;
  checkPrintStart?:(filename:string)=>Promise<PrintObservation>;
  checkPrintJob?:(filename:string)=>Promise<PrintObservation>;
};
export type VoicePrinterControlDependencies={
  printers:()=>PrinterModel[];
  client:(id:string)=>unknown;
  canOperate:()=>boolean;
  assertActive:()=>void;
  openCamera?:(id:string)=>boolean|void;
  hasCamera?:(printer:PrinterModel)=>boolean;
  wait?:(milliseconds:number,signal:AbortSignal)=>Promise<void>;
};
export type VoicePrinterControlResult={text:string;confirmed:boolean};
const actions=new Set<VoicePrinterControlAction>(['light-on','light-off','pause','resume','camera']);
const fingerprint=(p:PrinterModel)=>JSON.stringify([p.id,p.host,p.profile,p.modelSelection?.mode,p.modelSelection?.selectedPreset,p.modelSelection?.confirmationRequired,p.modelSelection?.pendingPreset]);
const cancelled=()=>{const error=new Error('Действие отменено');error.name='AbortError';return error};
const pause=async(milliseconds:number,signal:AbortSignal)=>{
  if(signal.aborted)throw cancelled();
  await new Promise<void>((resolve,reject)=>{
    const abort=()=>{clearTimeout(timer);signal.removeEventListener('abort',abort);reject(cancelled())};
    const timer=setTimeout(()=>{signal.removeEventListener('abort',abort);resolve()},milliseconds);
    signal.addEventListener('abort',abort,{once:true});
    if(signal.aborted)abort();
  });
};

/** Typed controls only. A successful transport response is never proof that a
 * light or print state changed; mutations are dispatched once and read back. */
export async function executeVoicePrinterControl(printer:PrinterModel,action:VoicePrinterControlAction,deps:VoicePrinterControlDependencies,signal:AbortSignal):Promise<VoicePrinterControlResult>{
  if(!actions.has(action))throw new Error('Такое действие недоступно в голосовом управлении.');
  const initialFingerprint=fingerprint(printer),job=printer.status.filename,jobDuration=printer.status.printDuration,jobProgress=printer.status.progress,initialClient=action==='camera'?undefined:deps.client(printer.id);
  const current=(write=true,checkJob=false)=>{
    if(signal.aborted)throw cancelled();deps.assertActive();
    const p=deps.printers().find(value=>value.id===printer.id);
    if(!p||fingerprint(p)!==initialFingerprint)throw new Error('Принтер или его настройки изменились. Повторите команду.');
    if(write){
      if(!deps.canOperate())throw new Error('Вашей учётной записи недоступно управление принтерами.');
      if(p.status.connectionState!=='online'||p.status.state==='offline'||p.status.remoteControlSuspended)throw new Error('Управление принтером сейчас недоступно. Проверьте связь и его карточку.');
      assertModelDependentOperationAllowed(p);
      if(p.capabilities?.compatible===false)throw new Error('Принтер ещё не подтвердил совместимость управления. Проверьте его настройки.');
      if(!initialClient||deps.client(p.id)!==initialClient)throw new Error('Соединение с принтером изменилось. Повторите команду.');
      if(checkJob&&(p.status.filename!==job||!['printing','paused'].includes(p.status.state)
        ||Number.isFinite(jobDuration)&&Number.isFinite(jobProgress)&&p.status.printDuration+30<jobDuration&&p.status.progress+.05<jobProgress))throw new Error('На принтере уже другое задание или печать завершилась. Повторите команду для текущей печати.');
    }
    return p;
  };
  if(action==='camera'){
    const p=current(false);
    if(!deps.hasCamera?.(p))throw new Error('У этого принтера камера не настроена. Добавьте её в настройках принтера.');
    if(!deps.openCamera)throw new Error('Окно камеры сейчас недоступно. Откройте камеру в карточке принтера.');
    current(false);
    if(deps.openCamera(p.id)===false)throw new Error('Не удалось открыть окно камеры. Откройте её в карточке принтера.');
    return{text:`Открыла окно камеры принтера ${p.name}.`,confirmed:true};
  }
  const p=current(),client=initialClient as VoicePrinterControlClient;
  const activeJob=action==='pause'||action==='resume';
  const assertApplicable=()=>{current(true,activeJob)};
  if(action==='light-on'||action==='light-off'){
    if(typeof client.light!=='function')throw new Error('Голосовое управление подсветкой этого принтера сейчас недоступно.');
    const on=action==='light-on';let state:LightObservation;
    try{current();state=await client.light(on,assertApplicable)}catch{
      current();return{text:`Не удалось подтвердить ${on?'включение':'выключение'} подсветки принтера ${p.name}. Проверьте её состояние в карточке. Повторную команду не отправляла.`,confirmed:false};
    }
    current();
    if(state?.supported!==true)return{text:`На принтере ${p.name} управляемая подсветка недоступна.`,confirmed:false};
    if(state.on!==on)return{text:`Принтер ${p.name} не подтвердил ${on?'включение':'выключение'} подсветки. Проверьте её состояние в карточке. Повторную команду не отправляла.`,confirmed:false};
    return{text:`Подсветка принтера ${p.name} ${on?'включена':'выключена'}.`,confirmed:true};
  }
  const expected=action==='pause'?'paused':'printing',from=action==='pause'?'printing':'paused';
  const checkPrintJob=client.checkPrintJob?.bind(client)??client.checkPrintStart?.bind(client);
  if(!checkPrintJob||typeof client[action]!=='function')throw new Error('Голосовое управление печатью этого принтера сейчас недоступно.');
  if(p.capabilities?.[action==='pause'?'canPause':'canResume']===false)throw new Error(`Принтер не поддерживает ${action==='pause'?'паузу':'продолжение печати'}.`);
  if(!job?.trim()||!['printing','paused'].includes(p.status.state))throw new Error('На этом принтере нет подтверждённой активной печати.');
  let before:PrintObservation;
  try{before=await checkPrintJob(job)}catch{current(true,true);throw new Error('Не удалось проверить текущее задание принтера. Команду не отправляла.');}
  current(true,true);
  // The live job reader compares the printer-reported identity directly;
  // a new print is never prepared or sent during this read-only preflight.
  if(before?.confirmed!==true||![from,expected].includes(before.state))throw new Error('Принтер не подтвердил текущее задание. Команду не отправляла.');
  if(before.state===expected)return{text:action==='pause'?`Печать на принтере ${p.name} уже на паузе.`:`Принтер ${p.name} уже печатает.`,confirmed:true};
  current(true,true);
  try{await client[action]!(assertApplicable)}catch{
    current(true,true);return{text:`Не удалось подтвердить ${action==='pause'?'паузу':'продолжение печати'} на принтере ${p.name}. Проверьте его карточку. Повторную команду не отправляла.`,confirmed:false};
  }
  for(let attempt=0;attempt<3;attempt++){
    current(true,true);
    if(attempt)await(deps.wait??pause)(250,signal);
    current(true,true);
    let observed:PrintObservation|undefined;
    try{observed=await checkPrintJob(job)}catch{/* Reads may recover; the control command is never repeated. */}
    current(true,true);
    if(observed?.confirmed===true&&observed.state===expected)return{text:action==='pause'?`Печать на принтере ${p.name} поставлена на паузу.`:`Печать на принтере ${p.name} продолжена.`,confirmed:true};
    if(observed&&observed.confirmed!==true)break;
  }
  return{text:`Принтер ${p.name} пока не подтвердил ${action==='pause'?'паузу':'продолжение печати'}. Проверьте его карточку. Повторную команду не отправляла.`,confirmed:false};
}
