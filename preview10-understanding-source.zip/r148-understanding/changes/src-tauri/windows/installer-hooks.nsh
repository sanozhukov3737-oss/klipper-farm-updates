!macro KF_STOP_RUNNING_COMPONENTS
  nsExec::ExecToStack '"$SYSDIR\taskkill.exe" /F /T /IM "klipper-farmd.exe"'
  Pop $0
  Pop $1
  nsExec::ExecToStack '"$SYSDIR\taskkill.exe" /F /T /IM "klipper-farmd-x86_64-pc-windows-msvc.exe"'
  Pop $0
  Pop $1
  nsExec::ExecToStack '"$SYSDIR\taskkill.exe" /F /T /IM "klipper-farmd-x86_64-pc-windows-gnu.exe"'
  Pop $0
  Pop $1
  nsExec::ExecToStack '"$SYSDIR\taskkill.exe" /F /T /IM "klipper-farm-client.exe"'
  Pop $0
  Pop $1
  Sleep 500
!macroend

!macro NSIS_HOOK_PREINSTALL
  ; The GGUF sidecar is kept outside the NSIS archive (its size exceeds 2 GiB).
  ; Delivery is one ZIP containing the installer and this adjacent model file.
  ${IfNot} ${FileExists} "$EXEDIR\model.gguf"
    MessageBox MB_ICONSTOP "Распакуйте весь архив обновления в одну папку. Рядом с установщиком нужен файл model.gguf." /SD IDOK
    SetErrorLevel 2
    Abort
  ${EndIf}
  FileOpen $0 "$EXEDIR\model.gguf" r
  FileRead $0 $1 4
  FileClose $0
  ${If} $1 != "GGUF"
    MessageBox MB_ICONSTOP "Файл model.gguf повреждён. Распакуйте архив обновления заново." /SD IDOK
    SetErrorLevel 2
    Abort
  ${EndIf}
  !insertmacro KF_STOP_RUNNING_COMPONENTS
  ; V20.3 could persist the daemon as MainBinaryName. Correct the migration
  ; value before Tauri's template decides which old executable to delete, or
  ; it can delete the freshly copied klipper-farmd sidecar during the repair.
  WriteRegStr SHCTX "${UNINSTKEY}" "MainBinaryName" "${MAINBINARYNAME}.exe"
!macroend

!macro NSIS_HOOK_POSTINSTALL
  CreateDirectory "$INSTDIR\understanding"
  ClearErrors
  CopyFiles /SILENT "$EXEDIR\model.gguf" "$INSTDIR\understanding\model.gguf"
  ${If} ${Errors}
    MessageBox MB_ICONSTOP "Не удалось установить модуль понимания речи. Проверьте свободное место и повторите установку." /SD IDOK
    SetErrorLevel 3
    Abort
  ${EndIf}
  ; Always recreate the Start menu entry with the verified desktop target.
  ; Preserve the user's desktop-shortcut choice, but repair it when it exists.
  Delete "$SMPROGRAMS\${PRODUCTNAME}.lnk"
  CreateShortcut "$SMPROGRAMS\${PRODUCTNAME}.lnk" "$INSTDIR\${MAINBINARYNAME}.exe"
  !insertmacro SetLnkAppUserModelId "$SMPROGRAMS\${PRODUCTNAME}.lnk"
  !insertmacro IsShortcutTarget "$SMPROGRAMS\${PRODUCTNAME}.lnk" "$INSTDIR\${MAINBINARYNAME}.exe"
  Pop $0
  ${If} $0 != 1
    Abort "Klipper Farm could not verify the Start menu shortcut target."
  ${EndIf}
  ${If} ${FileExists} "$DESKTOP\${PRODUCTNAME}.lnk"
    Delete "$DESKTOP\${PRODUCTNAME}.lnk"
    CreateShortcut "$DESKTOP\${PRODUCTNAME}.lnk" "$INSTDIR\${MAINBINARYNAME}.exe"
    !insertmacro SetLnkAppUserModelId "$DESKTOP\${PRODUCTNAME}.lnk"
    !insertmacro IsShortcutTarget "$DESKTOP\${PRODUCTNAME}.lnk" "$INSTDIR\${MAINBINARYNAME}.exe"
    Pop $0
    ${If} $0 != 1
      Abort "Klipper Farm could not verify the desktop shortcut target."
    ${EndIf}
  ${EndIf}
!macroend

!macro NSIS_HOOK_PREUNINSTALL
  !insertmacro KF_STOP_RUNNING_COMPONENTS
  Delete "$INSTDIR\understanding\model.gguf"
!macroend
