import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import http from 'node:http';
import {createHash} from 'node:crypto';
import {build} from 'vite';

// Exercise production FarmApp -> PrinterSettings -> updateConfig -> config
// store -> authenticated native IPC -> existing MoonrakerClient, then restart.
// Only the native host/database/credential provider is emulated by the fixture.
const root=path.resolve(import.meta.dirname,'..');
const output=fs.mkdtempSync(path.join(os.tmpdir(),'kf-r126-profile-app-'));
const proof=process.env.KF_R126_APP_PROOF,shots=process.env.KF_UI_SCREENSHOTS;
const state=page=>page.evaluate(()=>window.__farmStartup.state());
const target=page=>page.locator('[data-testid^="live-printer-"]').nth(6);
const geometry=profile=>[profile.bedX,profile.bedY,profile.maxZ,profile.xMin,profile.xMax,profile.yMin,profile.yMax];
const expectedGeometry=[220,220,220,-110,110,-110,110];
const selectedScenarios=process.env.KF_R126_APP_SCENARIOS?.split(','),wanted=scenario=>!selectedScenarios||selectedScenarios.includes(scenario);
const results=[];
let server,browser,lastPage,lastScenario;
try{
 await build({root,logLevel:'warn',build:{outDir:output,emptyOutDir:true,rollupOptions:{input:path.join(root,'ui-tests/farm-startup-r125.html')}}});
 if(process.argv.includes('--build-only')){console.log('R126 full FarmApp profile fixture build passed');process.exit(0)}
 const {chromium}=await import(process.env.PLAYWRIGHT_MODULE_PATH??'playwright');
 server=http.createServer((req,res)=>{
  const file=path.resolve(output,new URL(req.url,'http://localhost').pathname.slice(1));
  if(!file.startsWith(output+path.sep)||!fs.existsSync(file)||!fs.statSync(file).isFile()){res.writeHead(404).end();return}
  res.setHeader('Content-Type',({'.js':'text/javascript','.css':'text/css','.html':'text/html','.svg':'image/svg+xml','.png':'image/png','.webp':'image/webp'})[path.extname(file)]??'application/octet-stream');
  res.end(fs.readFileSync(file));
 });
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 const origin=`http://127.0.0.1:${server.address().port}`;
 browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_EXECUTABLE,args:['--no-sandbox','--disable-dev-shm-usage']});
 if(shots)fs.mkdirSync(shots,{recursive:true});
 for(const scenario of ['select-custom','select-custom-alias','select-automatic','repair','geometry','driver','cancel','held-save','save-failure'].filter(wanted)){
  const context=await browser.newContext({viewport:{width:1366,height:1000},locale:'ru-RU'});
  const page=await context.newPage(),errors=[],network=[];
  lastPage=page;lastScenario=scenario;
  page.on('pageerror',error=>errors.push(error.message));
  await page.route('**/*',route=>{
   if(route.request().url().startsWith(origin+'/'))return route.continue();
   network.push(route.request().url());return route.abort();
  });
  const open=async()=>{await target(page).getByRole('button',{name:'Настройки',exact:true}).click();await page.locator('.printerSetup').waitFor()};
  const waitForFarm=async()=>{
   await page.locator('.kfSidebar nav').getByRole('button',{name:'Принтеры',exact:true}).click();
   await page.waitForFunction(()=>{
    const s=window.__farmStartup.state();
    return document.querySelectorAll('[data-testid^="live-printer-"]').length===7&&s.productionHeld.length>=3&&new Set(s.calls.filter(c=>c.command==='printer_actor_upsert').map(c=>c.args.config.printerId)).size===7;
   });
   await page.evaluate(()=>window.__farmStartup.releaseFresh());
  };
  await page.goto(`${origin}/ui-tests/farm-startup-r125.html?r126=${scenario}`);
  await waitForFarm();
  const initial=await state(page),before=initial.database['printers.config'];
  assert.equal(before.length,7);assert.equal(initial.pending,null);
  await open();
  if(scenario.startsWith('select')){
   await page.locator('.printerSetup summary').first().click();
   await page.getByRole('searchbox',{name:'Поиск модели',exact:true}).fill('Adventurer 5M');
   await page.getByRole('button',{name:'Выбрать Flashforge Adventurer 5M',exact:true}).click();
  }else{
   await page.getByText('Модель и рабочий профиль отличаются',{exact:true}).waitFor();
   await page.getByRole('button',{name:'Применить профиль',exact:true}).click();
  }
  assert.equal(await page.locator('.catalogProfileMismatch').count(),0);
  assert.match(await page.locator('.printerSetupPreview').innerText(),/220 × 220 × 220/);
  assert.equal(await page.locator('.modelDetectionControls select').inputValue(),'flashforge-ad5m');
  assert.deepEqual((await state(page)).database['printers.config'],before,'profile selection must remain an unsaved draft');
  if(scenario==='cancel'){
   await page.locator('.printerSetup .panelHead > button').click();
   await page.locator('.printerSetup').waitFor({state:'hidden'});
   assert.deepEqual((await state(page)).database['printers.config'],before);
   assert.equal((await state(page)).pending,null);
   await open();await page.getByText('Модель и рабочий профиль отличаются',{exact:true}).waitFor();
   await page.getByRole('button',{name:'Применить профиль',exact:true}).click();
  }
  const startsBefore=(await state(page)).calls.filter(call=>call.command==='printer_actor_upsert').length;
  if(scenario==='held-save')await page.evaluate(()=>window.__farmStartup.holdNextConfigWrite());
  if(scenario==='save-failure')await page.evaluate(()=>window.__farmStartup.failNextConfigWrite());
  await page.getByRole('button',{name:'Сохранить настройки',exact:true}).click();
  if(scenario==='held-save'){
   await page.waitForFunction(()=>!!window.__farmStartup.state().heldConfigWrite);
   const held=await state(page);
   assert.deepEqual(held.database['printers.config'],before,'settings cannot acknowledge an uncommitted database write');
   assert.deepEqual(geometry(JSON.parse(held.pending).configs[6].profile),expectedGeometry);
   assert.equal(await page.locator('.printerSetup').isVisible(),true);
   assert.equal(await page.getByRole('button',{name:'Сохранение…',exact:true}).isDisabled(),true);
   assert.equal(held.calls.filter(c=>c.command==='printer_actor_upsert').length,startsBefore,'driver changes only after durable acknowledgement');
   await page.evaluate(()=>window.__farmStartup.releaseAutomaticWrite());
  }
  if(scenario==='save-failure'){
   await page.locator('.printerSetupError').filter({hasText:'forced R126 save failure'}).waitFor();
   const failed=await state(page);
   assert.deepEqual(failed.database['printers.config'],before);assert.ok(failed.pending);
   assert.equal(failed.calls.filter(c=>c.command==='printer_actor_upsert').length,startsBefore);
   assert.equal(await page.locator('.printerSetup').isVisible(),true);
   await page.getByRole('button',{name:'Сохранить настройки',exact:true}).click();
  }
  await page.locator('.printerSetup').waitFor({state:'hidden'});
  await page.waitForFunction(()=>window.__farmStartup.state().calls.some(c=>c.command==='printer_actor_upsert'&&c.args.config.printerId==='printer-7'&&c.args.config.modelId==='flashforge-ad5m'));
  const committed=await state(page),saved=committed.database['printers.config'],printer=saved[6];
  assert.equal(printer.catalogModelId,'flashforge-adventurer-5m');
  assert.equal(printer.profile.preset,'flashforge-ad5m');assert.deepEqual(geometry(printer.profile),expectedGeometry);
  assert.equal(printer.modelSelection.selectedPreset,'flashforge-ad5m');assert.equal(printer.modelSelection.mode,'manual');
  assert.equal(printer.name,scenario==='select-automatic'?'Flashforge Adventurer 5M 07':before[6].name);
  assert.equal(printer.nameSource,scenario==='select-automatic'?'automatic':'custom');
  for(const key of ['id','host','apiKeyStored','deviceIdentity','configSnapshot','accent','tags'])assert.deepEqual(printer[key],before[6][key],`${key} was changed by the profile choice`);
  if(scenario==='geometry'||scenario==='driver')for(const key of ['nozzle','priority','materials'])assert.deepEqual(printer.profile[key],before[6].profile[key]);
  assert.deepEqual(saved.slice(0,6),before.slice(0,6),'other six printers must be byte-for-byte equivalent as JSON');
  assert.deepEqual(committed.credentials,initial.credentials,'stored API keys and their printer associations survive');
  assert.equal(committed.pending,null);assert.deepEqual(committed.cache,saved);
  const changedActors=committed.calls.filter(c=>c.command==='printer_actor_upsert').slice(startsBefore);
  if(scenario!=='geometry')assert.deepEqual(changedActors.map(c=>[c.args.config.printerId,c.args.config.modelId]),[['printer-7','flashforge-ad5m']]);
  else assert.equal(changedActors.length,0,'correct driver does not need a reconnect when only local geometry changes');
  assert.ok(committed.calls.every(c=>!/^secret_(?:set|delete)$/.test(c.command)),'a model change must not rewrite credentials');
  assert.ok(committed.calls.every(c=>c.args?.method!=='printer.gcode.script'&&c.args?.method!=='printer.print.start'),'settings must not issue device commands');
  await open();
  assert.equal(await page.locator('.catalogProfileMismatch').count(),0);
  assert.equal(await page.locator('.modelDetectionControls select').inputValue(),'flashforge-ad5m');
  if(shots&&['repair','geometry','driver'].includes(scenario))await page.screenshot({path:path.join(shots,`r126-full-app-${scenario}.png`)});
  await page.locator('.printerSetup .panelHead > button').click();
  // Remove the fast cache. Reloading now proves hydration from the durable
  // native DB boundary instead of simply retaining React or cached form state.
  await page.evaluate(()=>localStorage.removeItem('printers'));
  await page.reload();await waitForFarm();await open();
  const restarted=await state(page);
  assert.deepEqual(restarted.database['printers.config'],saved);assert.deepEqual(restarted.credentials,initial.credentials);
  assert.equal(await page.locator('.catalogProfileMismatch').count(),0);
  assert.equal(await page.locator('.modelDetectionControls select').inputValue(),'flashforge-ad5m');
  assert.match(await page.locator('.printerSetupPreview').innerText(),/220 × 220 × 220/);
  const restartedActor=restarted.calls.find(c=>c.command==='printer_actor_upsert'&&c.args.config.printerId==='printer-7');
  assert.equal(restartedActor.args.config.modelId,'flashforge-ad5m');assert.equal(restartedActor.args.config.host,before[6].host);
  const gcode=`; generated by OrcaSlicer\n; printer_model = Flashforge Adventurer 5M\n; nozzle_diameter = ${printer.profile.nozzle}\n; filament_type = PLA\nG90\nM82\nM104 S220\nM140 S60\nG1 X-80 Y-70 Z0.2 F1200\nG1 X80 Y70 E1\n`;
  const reports=await page.evaluate(text=>{
   const validate=window.__farmStartup.validate;
   return {ordinary:validate(text),edge:validate(text+'G1 X-110 Y110\nG1 X110 Y-110\n'),invalid:[...['X110.1','X-110.1','Y110.1','Y-110.1'].map(move=>validate(text+`G1 ${move}\n`)),validate(text+'CX_PRINT_START\n'),validate(text+'M112\n'),validate(text.replace('Flashforge Adventurer 5M','Creality K1 Max'))]};
  },gcode);
  assert.equal(reports.ordinary.ok,true,JSON.stringify(reports.ordinary.issues));assert.equal(reports.edge.ok,true);
  for(const report of reports.invalid)assert.equal(report.ok,false,JSON.stringify(report.issues));
  assert.deepEqual(restarted.unexpected,[]);assert.deepEqual(errors,[]);assert.deepEqual(network,[]);
  results.push({scenario,passed:true,reopened:true,restartedFromNativeDatabase:true,operationalActor:'flashforge-ad5m',geometry:expectedGeometry,otherPrintersPreserved:6,credentialsPreserved:true,gcodeChecks:9});
  console.log('PASS R126 full FarmApp profile '+scenario);await context.close();
 }
 for(const scenario of ['wizard','discovery'].filter(wanted)){
  const context=await browser.newContext({viewport:{width:1366,height:1000},locale:'ru-RU'}),page=await context.newPage(),errors=[],network=[];
  lastPage=page;lastScenario=scenario;
  page.setDefaultTimeout(10000);
  page.on('pageerror',error=>{errors.push(error.message);console.error('UI error '+scenario+': '+error.stack)});
  await page.route('**/*',route=>{if(route.request().url().startsWith(origin+'/'))return route.continue();network.push(route.request().url());return route.abort()});
  await page.goto(`${origin}/ui-tests/farm-startup-r125.html?r126=${scenario}`);
  let before;
  if(scenario==='wizard'){
   await page.locator('.wizardNext').click();
   await page.getByRole('searchbox',{name:'Поиск модели',exact:true}).fill('Adventurer 5M');
   await page.getByRole('button',{name:'Выбрать Flashforge Adventurer 5M',exact:true}).click();
   await page.getByLabel('Название принтера',{exact:true}).fill('Новый Flashforge');
   await page.getByLabel('Адрес Moonraker',{exact:true}).fill('192.168.77.108:7125');
   await page.getByRole('button',{name:'Проверить подключение',exact:true}).click();
   await page.getByText('Подключение работает',{exact:true}).waitFor();
   assert.match(await page.locator('.wizardCheck.ok').innerText(),/Ender-3 V3 KE/,'fixture must exercise actual conflicting detection');
   before=(await state(page)).database['printers.config'];assert.equal(before.length,0);
   await page.getByRole('button',{name:'Добавить принтер',exact:true}).click();
  }else{
   await page.locator('.kfSidebar nav').getByRole('button',{name:'Принтеры',exact:true}).click();
   await page.waitForFunction(()=>window.__farmStartup.state().productionHeld.length>=3);
   before=(await state(page)).database['printers.config'];
   await page.locator('.kfSidebar nav').getByRole('button',{name:'Инструменты',exact:true}).click();
   await page.getByRole('button',{name:/Найти принтеры/}).click();
   await page.getByRole('button',{name:'Выбрать модель для 192.168.77.108',exact:true}).click();
   await page.getByRole('searchbox',{name:'Поиск модели',exact:true}).fill('Adventurer 5M');
   await page.getByRole('button',{name:'Выбрать Flashforge Adventurer 5M',exact:true}).click();
   await page.getByRole('button',{name:'Добавить',exact:true}).click();
  }
  await page.waitForFunction(expected=>window.__farmStartup.state().database['printers.config'].length===expected,before.length+1);
  const committed=await state(page),saved=committed.database['printers.config'],printer=saved.at(-1);
  assert.equal(printer.profile.preset,'flashforge-ad5m');assert.deepEqual(geometry(printer.profile),expectedGeometry);
  assert.equal(printer.modelSelection.selectedPreset,'flashforge-ad5m');assert.equal(printer.modelSelection.mode,'manual');
  assert.equal(printer.modelSelection.lastDetection.model,'ender3-v3-ke');assert.equal(printer.modelSelection.lastDetection.decision,'confirmed');
  assert.equal(printer.catalogModelId,'flashforge-adventurer-5m');assert.equal(printer.host,'192.168.77.108:7125');
  if(scenario==='wizard')assert.equal(printer.name,'Новый Flashforge');
  assert.deepEqual(saved.slice(0,before.length),before);assert.equal(committed.pending,null);
  await page.evaluate(()=>localStorage.removeItem('printers'));await page.reload();
  await page.locator('.kfSidebar nav').getByRole('button',{name:'Принтеры',exact:true}).click();
  await page.waitForFunction(id=>window.__farmStartup.state().calls.some(c=>c.command==='printer_actor_upsert'&&c.args.config.printerId===id&&c.args.config.modelId==='flashforge-ad5m'),printer.id);
  await page.locator('[data-testid^="live-printer-"]').last().getByRole('button',{name:'Настройки',exact:true}).click();
  assert.equal(await page.locator('.catalogProfileMismatch').count(),0);assert.equal(await page.locator('.modelDetectionControls select').inputValue(),'flashforge-ad5m');
  const restarted=await state(page);assert.deepEqual(restarted.database['printers.config'],saved);assert.deepEqual(restarted.unexpected,[]);assert.deepEqual(errors,[]);assert.deepEqual(network,[]);
  results.push({scenario,passed:true,restartedFromNativeDatabase:true,explicitCatalogOverridesDetection:true,detectedPreset:'ender3-v3-ke',operationalActor:'flashforge-ad5m',otherPrintersPreserved:before.length});
  console.log('PASS R126 full FarmApp profile '+scenario);await context.close();
 }
 const sourceFiles=['src/App.tsx','src/components/PrinterSettings.tsx','src/components/SetupWizard.tsx','src/components/DiscoveryPanel.tsx','src/lib/printerCatalogSelection.ts','src/lib/printerProfile.ts','src/lib/printerName.ts','src/lib/printerConfigStore.ts','src/lib/db.ts','src/lib/moonraker.ts','src/lib/gcodeValidation.ts','src/lib/gcodeAnalysis.ts','ui-tests/farm-startup-r125.tsx','ui-tests/r126-profile-app.mjs'];
 const report={release:'R126',stage:'model-profile',passed:true,caseCount:results.length,cases:results,nativeBoundary:'Emulated authenticated native database, credentials and printer IPC; production React/settings/store/client/validator modules',physicalPrinterTested:false,windowsNativeExecutableTested:false,productionSources:Object.fromEntries(sourceFiles.map(file=>[file,createHash('sha256').update(fs.readFileSync(path.join(root,file))).digest('hex')]))};
 if(proof){fs.mkdirSync(path.dirname(proof),{recursive:true});fs.writeFileSync(proof,JSON.stringify(report,null,2)+'\n')}
 console.log('R126 full FarmApp profile: '+results.length+' cases passed');
}catch(error){
 if(shots&&lastPage)await lastPage.screenshot({path:path.join(shots,`r126-full-app-failure-${lastScenario}.png`),fullPage:true}).catch(()=>{});
 throw error;
}finally{await browser?.close();if(server)await new Promise(resolve=>server.close(resolve));fs.rmSync(output,{recursive:true,force:true})}
