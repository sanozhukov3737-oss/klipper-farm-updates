import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import http from 'node:http';
import {createHash} from 'node:crypto';
import {build} from 'vite';

const root=path.resolve(import.meta.dirname,'..'),output=fs.mkdtempSync(path.join(os.tmpdir(),'kf-r126-ui-stage-'));
const proof=process.env.KF_R126_UI_PROOF,shots=process.env.KF_UI_SCREENSHOTS,cases=[];
const assets={k1c:'src/assets/creality-k1c-clean-v1144.png',flashforge:'src/assets/flashforge-ad5m-clean-v1144.png'};
const hashes=Object.fromEntries(Object.entries(assets).map(([model,file])=>[model,createHash('sha256').update(fs.readFileSync(path.join(root,file))).digest('hex')]));
const probes={k1c:{transparent:[[.02,.02],[.15,.96],[.5,.99],[.66,.99]],solid:[[.44,.16]]},flashforge:{transparent:[[.02,.02],[.5,.99],[.66,.99],[.28,.54],[.61,.13]],solid:[[.48,.37]]}};
const state=page=>page.evaluate(()=>window.__farmStartup.state());
const reachable=async(page,locator)=>{
 await locator.scrollIntoViewIfNeeded();
 const result=await locator.evaluate(el=>{
  const r=el.getBoundingClientRect(),view={left:0,top:0,right:innerWidth,bottom:innerHeight};let visible={...view};
  for(let parent=el.parentElement;parent;parent=parent.parentElement){
   if(parent===document.scrollingElement)continue;
   const s=getComputedStyle(parent),box=parent.getBoundingClientRect();
   if(/auto|scroll|hidden|clip/.test(s.overflowY)){visible.top=Math.max(visible.top,box.top+parent.clientTop);visible.bottom=Math.min(visible.bottom,box.top+parent.clientTop+parent.clientHeight)}
   if(/auto|scroll|hidden|clip/.test(s.overflowX)){visible.left=Math.max(visible.left,box.left+parent.clientLeft);visible.right=Math.min(visible.right,box.left+parent.clientLeft+parent.clientWidth)}
  }
  const hit=document.elementFromPoint((r.left+r.right)/2,(r.top+r.bottom)/2);
  return {text:el.textContent?.trim().slice(0,60),box:r.toJSON(),visible,covered:!hit||!el.contains(hit),contained:r.top>=visible.top-.5&&r.bottom<=visible.bottom+.5&&r.left>=visible.left-.5&&r.right<=visible.right+.5};
 });
 assert.ok(result.contained&&!result.covered,'inaccessible control '+JSON.stringify(result));
};
const noOverflow=async(page,selector)=>{
 const failures=await page.locator(selector).evaluateAll(elements=>elements.filter(el=>el.getClientRects().length).flatMap(el=>{const r=el.getBoundingClientRect();return r.left<-.5||r.right>innerWidth+.5||el.scrollWidth>el.clientWidth+2?[{className:el.className,box:r.toJSON(),scrollWidth:el.scrollWidth,clientWidth:el.clientWidth}]:[]}));
 assert.deepEqual(failures,[],'horizontal overflow');
};
const checkImage=async(page,locator,model)=>{
 await locator.waitFor();const url=await locator.getAttribute('src');assert.ok(new URL(url,page.url()).origin===new URL(page.url()).origin);
 const response=await page.request.get(new URL(url,page.url()).href);assert.equal(response.status(),200);
 assert.equal(createHash('sha256').update(await response.body()).digest('hex'),hashes[model],'UI loaded a different file than the reviewed source asset');
 const pixels=await locator.evaluate(async(img,points)=>{
  await img.decode();const canvas=document.createElement('canvas');canvas.width=img.naturalWidth;canvas.height=img.naturalHeight;const context=canvas.getContext('2d');context.drawImage(img,0,0);
  const at=([x,y])=>Array.from(context.getImageData(Math.round(x*canvas.width),Math.round(y*canvas.height),1,1).data);
  return {width:canvas.width,height:canvas.height,transparent:points.transparent.map(at),solid:points.solid.map(at)};
 },probes[model]);
 for(const color of pixels.transparent)assert.equal(color[3],0,model+' background must contain genuine alpha zero');
 for(const color of pixels.solid){assert.ok(color[3]>=245,model+' light printer part was erased');assert.ok(Math.min(...color.slice(0,3))>=170,model+' white/silver detail changed')}
 return {asset:assets[model],sha256:hashes[model],pixels};
};
let server,browser,lastPage,lastCase;
try{
 await build({root,logLevel:'warn',build:{outDir:output,emptyOutDir:true,rollupOptions:{input:path.join(root,'ui-tests/farm-startup-r125.html')}}});
 const {chromium}=await import(process.env.PLAYWRIGHT_MODULE_PATH??'playwright');
 server=http.createServer((req,res)=>{const file=path.resolve(output,new URL(req.url,'http://localhost').pathname.slice(1));if(!file.startsWith(output+path.sep)||!fs.existsSync(file)||!fs.statSync(file).isFile()){res.writeHead(404).end();return}res.setHeader('Content-Type',({'.js':'text/javascript','.css':'text/css','.html':'text/html','.png':'image/png','.webp':'image/webp','.svg':'image/svg+xml'})[path.extname(file)]??'application/octet-stream');res.end(fs.readFileSync(file))});
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const origin=`http://127.0.0.1:${server.address().port}`;
 browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_EXECUTABLE,args:['--no-sandbox','--disable-dev-shm-usage']});if(shots)fs.mkdirSync(shots,{recursive:true});
 for(const theme of ['dark','light'])for(const [width,height,windowsScale] of [[1366,768,1],[1093,614,1.25],[910,512,1.5],[683,384,2],[390,844,1]]){
  const context=await browser.newContext({viewport:{width:1366,height:768},deviceScaleFactor:windowsScale,locale:'ru-RU'}),page=await context.newPage(),errors=[],network=[];lastPage=page;lastCase={theme,width,height,windowsScale};page.setDefaultTimeout(10000);
  page.on('pageerror',error=>{errors.push(error.message);console.error('UI:',error.stack)});
  await page.route('**/*',route=>{if(route.request().url().startsWith(origin+'/'))return route.continue();network.push(route.request().url());return route.abort()});
  await page.goto(`${origin}/ui-tests/farm-startup-r125.html?r126=files&files=wrong-model`);
  await page.locator('.kfSidebar nav').getByRole('button',{name:'Принтеры',exact:true}).click();
  await page.waitForFunction(()=>document.querySelectorAll('[data-testid^="live-printer-"] [data-testid="printer-telemetry"][data-freshness="live"]').length===6);
  await page.getByRole('button',{name:theme==='light'?'Светлая тема':'Тёмная тема',exact:true}).click();
  await page.setViewportSize({width,height});
  const before=await state(page),cards=page.locator('[data-testid^="live-printer-"]');
  const cardImages={k1c:await checkImage(page,cards.nth(4).locator('[data-testid="printer-artwork"]'),'k1c'),flashforge:await checkImage(page,cards.nth(6).locator('[data-testid="printer-artwork"]'),'flashforge')};
  await cards.nth(6).getByRole('button',{name:/^Моя флешка:/}).click();
  await page.waitForFunction(()=>window.__farmStartup.state().database['production.printerFiles.printer-7'].validations[window.__filesFixture.state().nested]?.report?.ok===false);
  await page.locator('.printerFileCard').getByRole('button',{name:'Печать',exact:true}).click();await page.locator('.printerFileDialog.blocked').waitFor();
  await noOverflow(page,'.printerFileDialog,.printerFileDialog>header,.printerFileDialog>footer,.printerFileIssueList');
  assert.equal(await page.locator('.printerFileDialog>footer').getByRole('button',{name:/Запустить на/}).count(),0);
  const settingsButton=page.getByRole('button',{name:'Настройки принтера',exact:true});await reachable(page,settingsButton);await settingsButton.click();
  await page.locator('.printerSetup').waitFor();assert.equal(await page.locator('.printerFilesPanel').count(),0);assert.equal(await page.locator('.printerFileDialog').count(),0);
  assert.equal(await page.getByLabel('Название в Klipper Farm',{exact:true}).inputValue(),before.database['printers.config'][6].name);
  assert.equal(await page.getByLabel('IP и порт Moonraker',{exact:true}).inputValue(),before.database['printers.config'][6].host);
  assert.equal(await page.locator('.modelDetectionControls select').inputValue(),'flashforge-ad5m');
  const preview=await checkImage(page,page.locator('.printerSetupPreview img'),'flashforge');
  await noOverflow(page,'.printerSetup,.printerSetup .panelHead,.printerSetupLayout,.printerSetupActions,.printerSetup .field');
  await reachable(page,page.getByLabel('Материалы',{exact:true}));
  for(const name of ['Отмена','Сохранить настройки'])await reachable(page,page.locator('.printerSetupActions').getByRole('button',{name,exact:true}));
  const save=page.getByRole('button',{name:'Сохранить настройки',exact:true});await save.focus();await page.keyboard.press('Tab');assert.ok(await page.locator('.printerSetup .panelHead > button').evaluate(el=>document.activeElement===el),'keyboard focus escaped settings');
  if(shots&&width===1366){await page.locator('.printerSetupLayout').evaluate(el=>el.scrollTop=0);await page.screenshot({path:path.join(shots,`r126-settings-flashforge-${theme}.png`)})}
  await page.locator('.printerSetupActions').getByRole('button',{name:'Отмена',exact:true}).click();await page.locator('.printerSetup').waitFor({state:'hidden'});
  if(width===1366){
   await cards.nth(4).getByRole('button',{name:'Настройки',exact:true}).click();await page.locator('.printerSetup').waitFor();await checkImage(page,page.locator('.printerSetupPreview img'),'k1c');
   if(shots)await page.screenshot({path:path.join(shots,`r126-settings-k1c-${theme}.png`)});
   await page.locator('.printerSetupActions').getByRole('button',{name:'Отмена',exact:true}).click();
  }
  const after=await state(page);assert.deepEqual(after.database['printers.config'],before.database['printers.config']);assert.deepEqual(after.credentials,before.credentials);
  assert.ok(after.calls.every(c=>c.args?.method!=='printer.print.start'&&c.args?.method!=='printer.gcode.script'));assert.deepEqual(after.unexpected,[]);assert.deepEqual(errors,[]);assert.deepEqual(network,[]);
  cases.push({...lastCase,passed:true,settingsTarget:'printer-7',cardImages,preview,configurationPreserved:true});console.log(`PASS R126 UI ${theme} ${width}x${height} ${windowsScale*100}%`);await context.close();
 }
 const files=['src/styles.css','src/App.tsx','src/components/PrinterFilesPanel.tsx','src/components/PrinterSettings.tsx','src/lib/printerArtwork.ts','src/lib/printerCatalog.ts','ui-tests/r126-ui.mjs'];
 const report={release:'R126',stage:'ui-artwork',passed:true,caseCount:cases.length,cases,assets:hashes,windowsScaling:'Effective CSS viewport plus deviceScaleFactor; Windows EXE not run',physicalPrinterTested:false,nativeIpcEmulated:true,productionSources:Object.fromEntries(files.map(file=>[file,createHash('sha256').update(fs.readFileSync(path.join(root,file))).digest('hex')]))};
 if(proof){fs.mkdirSync(path.dirname(proof),{recursive:true});fs.writeFileSync(proof,JSON.stringify(report,null,2)+'\n')}
 console.log('R126 UI/artwork: '+cases.length+' cases passed');
}catch(error){
 console.error('Failed UI case:',lastCase);if(lastPage&&shots)await lastPage.screenshot({path:path.join(shots,'r126-ui-failure.png')}).catch(()=>{});throw error;
}finally{await browser?.close();if(server)await new Promise(resolve=>server.close(resolve));fs.rmSync(output,{recursive:true,force:true})}
