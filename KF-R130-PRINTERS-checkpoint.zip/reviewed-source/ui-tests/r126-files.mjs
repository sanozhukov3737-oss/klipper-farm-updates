import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import http from 'node:http';
import {createHash} from 'node:crypto';
import {build} from 'vite';

const root=path.resolve(import.meta.dirname,'..'),output=fs.mkdtempSync(path.join(os.tmpdir(),'kf-r126-files-'));
const cacheKey='production.printerFiles.printer-7',cases=[],proof=process.env.KF_R126_FILE_UI_PROOF;
const state=page=>page.evaluate(()=>({app:window.__farmStartup.state(),files:window.__filesFixture.state()}));
const scenarios=['rpc-array','rpc-envelope','fallback-404','fallback-405','fallback-method','list-401','list-403','list-timeout','list-500','list-501','partial-array','partial-envelope','malformed-list','partial-directory','child-500','directory-401','directory-403','directory-timeout','directory-500','both-unavailable','db-read-error','db-write-error','empty','metadata-401','metadata-500','metadata-timeout','metadata-404','download-401','download-500','download-timeout','download-404','outside','incompatible','dangerous','wrong-model','recover-after-500'];
const selected=process.env.KF_R126_FILE_SCENARIOS?.split(',');
let server,browser,lastPage,lastScenario;
try{
 await build({root,logLevel:'warn',build:{outDir:output,emptyOutDir:true,rollupOptions:{input:path.join(root,'ui-tests/farm-startup-r125.html')}}});
 const {chromium}=await import(process.env.PLAYWRIGHT_MODULE_PATH??'playwright');
 server=http.createServer((req,res)=>{
  const file=path.resolve(output,new URL(req.url,'http://localhost').pathname.slice(1));
  if(!file.startsWith(output+path.sep)||!fs.existsSync(file)||!fs.statSync(file).isFile()){res.writeHead(404).end();return}
  res.setHeader('Content-Type',({'.js':'text/javascript','.css':'text/css','.html':'text/html','.svg':'image/svg+xml','.png':'image/png','.webp':'image/webp'})[path.extname(file)]??'application/octet-stream');res.end(fs.readFileSync(file));
 });
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 const origin=`http://127.0.0.1:${server.address().port}`;
 browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_EXECUTABLE,args:['--no-sandbox','--disable-dev-shm-usage']});
 for(const scenario of scenarios.filter(value=>!selected||selected.includes(value))){
  const context=await browser.newContext({viewport:{width:1366,height:1000},locale:'ru-RU'}),page=await context.newPage(),errors=[],network=[];
  lastPage=page;lastScenario=scenario;page.setDefaultTimeout(10000);
  page.on('pageerror',error=>{errors.push(error.message);console.error('UI '+scenario+': '+error.stack)});
  await page.route('**/*',route=>{if(route.request().url().startsWith(origin+'/'))return route.continue();network.push(route.request().url());return route.abort()});
  await page.goto(`${origin}/ui-tests/farm-startup-r125.html?r126=files&files=${scenario==='recover-after-500'?'list-500':scenario}`);
  await page.locator('.kfSidebar nav').getByRole('button',{name:'Принтеры',exact:true}).click();
  await page.waitForFunction(()=>document.querySelectorAll('[data-testid^="live-printer-"]').length===7&&document.querySelectorAll('[data-testid^="live-printer-"] [data-testid="printer-telemetry"][data-freshness="live"]').length===6);
  const before=await state(page),initialCache=before.app.database[cacheKey];
  assert.deepEqual(initialCache,before.files.originalCache);
  await page.locator('[data-testid^="live-printer-"]').nth(6).getByRole('button',{name:/^Моя флешка:/}).click();
  await page.locator('.printerFilesPanel').waitFor();
  const failure=/^(?:list-|directory-|partial-|malformed-|child-|both-|db-)/.test(scenario)||scenario==='recover-after-500';
  if(failure){
   await page.locator('.printerFilesError').waitFor();
   const failed=await state(page),message=await page.locator('.printerFilesError').innerText();
   assert.deepEqual(failed.app.database[cacheKey],initialCache,'failed/incomplete sync must preserve every cached file, project, hash and validation');
   assert.equal(failed.app.calls.filter(c=>c.command==='db_set_json'&&c.args.key===cacheKey&&!scenario.startsWith('db-write-')).length,0);
   if(scenario!=='db-read-error'){
    assert.equal(await page.locator('.printerFileCard').count(),1);assert.match(await page.locator('.printerFileCard').innerText(),/прежний\.gcode/);assert.match(message,/кеш файлов/);
   }
   const code=scenario.match(/-(401|403|500|501)$/)?.[1];if(code)assert.match(message,new RegExp('HTTP '+code));
   if(scenario.includes('timeout'))assert.match(message,/timeout/);
   if(scenario==='both-unavailable')assert.match(message,/file_manager/);
   if(scenario.startsWith('db-'))assert.match(message,/SQLITE_BUSY/);
   if(scenario==='recover-after-500'){
    await page.evaluate(()=>window.__filesFixture.setMode('rpc-array'));
    await page.getByRole('button',{name:'Обновить',exact:true}).click();
    await page.waitForFunction(key=>window.__farmStartup.state().database[key].files.length===2,cacheKey);
    assert.equal(await page.locator('.printerFilesError').count(),0);
   }
   if(scenario==='partial-array'){
    await page.reload();await page.locator('.kfSidebar nav').getByRole('button',{name:'Принтеры',exact:true}).click();
    await page.waitForFunction(()=>document.querySelectorAll('[data-testid^="live-printer-"] [data-testid="printer-telemetry"][data-freshness="live"]').length===6);
    await page.locator('[data-testid^="live-printer-"]').nth(6).getByRole('button',{name:/^Моя флешка:/}).click();await page.locator('.printerFilesError').waitFor();
    assert.deepEqual((await state(page)).app.database[cacheKey],initialCache);assert.equal(await page.locator('.printerFileCard').count(),1);
   }
  }else if(scenario==='empty'){
   await page.waitForFunction(key=>window.__farmStartup.state().database[key].files.length===0,cacheKey);
   assert.equal(await page.locator('.printerFileCard').count(),0);assert.equal(await page.locator('.printerFilesError').count(),0);
  }else{
   await page.waitForFunction(key=>{
    const index=window.__farmStartup.state().database[key],expected=window.__filesFixture.state().expectedEntries;
    return index.files.length===expected.length&&expected.every(file=>index.validations[file.path]?.report);
   },cacheKey);
   const synced=await state(page),cache=synced.app.database[cacheKey];
   assert.deepEqual(cache.files.map(({path,size,modified})=>({path,size,modified})),synced.files.expectedEntries);
   assert.deepEqual(cache.projects,initialCache.projects);assert.deepEqual(cache.hashes,initialCache.hashes);assert.deepEqual(cache.folders,initialCache.folders);
   const listCalls=synced.app.calls.filter(c=>c.command==='printer_actor_rpc'&&c.args.method==='server.files.list');
   assert.equal(listCalls.length,1);assert.deepEqual(listCalls[0].args.params,{root:'gcodes'});assert.equal(listCalls[0].args.timeoutMs,6000);assert.equal(listCalls[0].args.preferRest,false);
   assert.ok(synced.app.calls.every(c=>!(c.command==='moonraker_http'&&c.args.path.startsWith('/server/files/list?'))),'client must request the RPC method instead of repeating the failing REST list endpoint');
   if(scenario.startsWith('fallback-')){
    const directories=synced.app.calls.filter(c=>c.command==='moonraker_http'&&c.args.path.startsWith('/server/files/directory?')).map(c=>new URL(c.args.path,'http://fixture').searchParams.get('path'));
    assert.deepEqual(directories,['gcodes','gcodes/Детали','gcodes/Детали/Серия №1']);
   }
   if(scenario.startsWith('metadata-')&&scenario!=='metadata-404')assert.ok((await page.locator('.printerFilesError').innerText()).includes(scenario.endsWith('timeout')?'timeout':'HTTP '+scenario.split('-')[1]));
   const card=page.locator('.printerFileCard').filter({has:page.locator('b[title="'+synced.files.nested+'"]')});
   await card.getByRole('button',{name:'Печать',exact:true}).click();
   await page.locator('.printerFileDialog').waitFor();
   const blocked=scenario.startsWith('download-')||['outside','incompatible','dangerous','wrong-model'].includes(scenario);
   assert.equal(await page.locator('.printerFileDialog>header b').innerText(),blocked?'Запуск заблокирован':'Файл готов к печати');
   if(scenario.startsWith('metadata-')&&scenario!=='metadata-404'){
    const message=scenario.endsWith('timeout')?'timeout':'HTTP '+scenario.split('-')[1];
    assert.ok((await page.locator('.printerFileIssueList').innerText()).includes(message));
   }
   if(scenario.startsWith('download-'))assert.ok((await page.locator('.printerFileIssueList').innerText()).includes(scenario.endsWith('timeout')?'timeout':'HTTP '+scenario.split('-')[1]));
   if(blocked){
    assert.equal(await page.locator('.printerFileDialog>footer').getByRole('button',{name:/Запустить на/}).count(),0);assert.deepEqual((await state(page)).files.printed,[]);
   }else{
    const callsBefore=(await state(page)).app.calls;
    assert.ok(callsBefore.some(c=>c.command==='moonraker_http'&&c.args.path===('/server/files/gcodes/'+synced.files.nested.split('/').map(encodeURIComponent).join('/'))),'actual download must encode every Unicode path segment');
    await page.locator('.printerFileDialog>footer').getByRole('button',{name:/Запустить на/}).click();
    await page.locator('.printerFilesPanel').waitFor({state:'hidden'});
    const launched=await state(page);assert.deepEqual(launched.files.printed,[synced.files.nested]);
    assert.equal(launched.app.calls.filter(c=>c.command==='printer_actor_rpc'&&c.args.method==='printer.print.start').length,1);
    assert.ok(launched.app.calls.every(c=>c.args?.method!=='printer.gcode.script'),'launch must use the existing Moonraker print endpoint');
   }
  }
  const after=await state(page);assert.deepEqual(after.app.database['printers.config'],before.app.database['printers.config']);assert.deepEqual(after.app.credentials,before.app.credentials);
  assert.deepEqual(after.app.unexpected,[]);assert.deepEqual(errors,[]);assert.deepEqual(network,[]);
  cases.push({scenario,passed:true,cachePreservedOnFailure:failure,printCalls:after.files.printed.length});console.log('PASS R126 real file flow '+scenario);await context.close();
 }
 const files=['src/lib/moonrakerFiles.ts','src/lib/moonraker.ts','src/components/PrinterFilesPanel.tsx','src/lib/gcodeValidation.ts','src/lib/gcodeAnalysis.ts','src/lib/gcodeCompatibility.ts','src/lib/db.ts','ui-tests/r126-files-native.ts','ui-tests/farm-startup-r125.tsx','ui-tests/r126-files.mjs'];
 const report={release:'R126',stage:'file-sync',passed:true,caseCount:cases.length,cases,nativeBoundary:'Actual FarmApp, PrinterFilesPanel, MoonrakerClient, cache, validator and start; only authenticated native IPC and printer responses emulated',physicalPrinterTested:false,windowsExeTested:false,productionSources:Object.fromEntries(files.map(file=>[file,createHash('sha256').update(fs.readFileSync(path.join(root,file))).digest('hex')]))};
 if(proof){fs.mkdirSync(path.dirname(proof),{recursive:true});fs.writeFileSync(proof,JSON.stringify(report,null,2)+'\n')}
 console.log('R126 real file flow: '+cases.length+' cases passed');
}catch(error){
 if(lastPage)console.error('Failed scenario:',lastScenario,'UI:',(await lastPage.locator('body').innerText()).slice(-5000));
 throw error;
}finally{await browser?.close();if(server)await new Promise(resolve=>server.close(resolve));fs.rmSync(output,{recursive:true,force:true})}
