import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import http from 'node:http';
import {build} from 'vite';

const root=path.resolve(import.meta.dirname,'..');
const output=fs.mkdtempSync(path.join(os.tmpdir(),'kf-farm-startup-r125-'));
const {chromium}=await import(process.env.PLAYWRIGHT_MODULE_PATH??'playwright');
const screenshots=process.env.KF_UI_SCREENSHOTS;
const report=[];
let server,browser,lastPage,lastMode;
const state=page=>page.evaluate(()=>window.__farmStartup.state());
const cards=page=>page.locator('[data-testid^="live-printer-"]');
const names=page=>cards(page).getByTestId('printer-name').allTextContents();
const assertNoEmptyConfigWrite=rows=>{
 for(const row of rows.filter(value=>value.command==='db_set_json'&&value.args.key==='printers.config')){
  assert.equal(JSON.parse(row.args.value).length,7,'startup never replaces a read failure with []');
 }
};
try{
 await build({root,logLevel:'warn',build:{outDir:output,emptyOutDir:true,rollupOptions:{input:path.join(root,'ui-tests/farm-startup-r125.html')}}});
 server=http.createServer((req,res)=>{
  const file=path.resolve(output,new URL(req.url,'http://localhost').pathname.slice(1));
  if(!file.startsWith(output+path.sep)||!fs.existsSync(file)||!fs.statSync(file).isFile()){res.writeHead(404).end();return}
  res.setHeader('Content-Type',({'.js':'text/javascript','.css':'text/css','.html':'text/html','.png':'image/png','.svg':'image/svg+xml'})[path.extname(file)]??'application/octet-stream');
  res.end(fs.readFileSync(file));
 });
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 const origin=`http://127.0.0.1:${server.address().port}`;
 browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_EXECUTABLE,args:['--no-sandbox','--disable-dev-shm-usage']});
 if(screenshots)fs.mkdirSync(screenshots,{recursive:true});
 for(const mode of ['normal','read-failure','automatic-refresh']){
  const context=await browser.newContext({viewport:{width:1920,height:1200},locale:'ru-RU'});
  const page=await context.newPage(),errors=[],network=[];
  lastPage=page;lastMode=mode;
  page.on('pageerror',error=>errors.push(error.message));
  await page.route('**/*',route=>{
   if(route.request().url().startsWith(origin+'/'))return route.continue();
   network.push(route.request().url());return route.abort();
  });
  await page.addInitScript(()=>{
   window.__poisonVisible=[];
   new MutationObserver(()=>{
    const poison=Array.from(document.querySelectorAll('[data-testid^="live-printer-"]')).map(card=>card.textContent??'').filter(text=>/poison-|cache-is-not-live|\b(?:399|400)\s*°/.test(text));
    if(poison.length)window.__poisonVisible.push({at:performance.now(),poison});
   }).observe(document,{subtree:true,childList:true,characterData:true});
  });
  await page.goto(`${origin}/ui-tests/farm-startup-r125.html?mode=${mode}`);
  await page.locator('.kfSidebar nav').getByRole('button',{name:'Принтеры',exact:true}).click();
  await page.waitForFunction(()=>document.querySelectorAll('[data-testid^="live-printer-"]').length===7,{},{timeout:3000});
  const visibleAt=await page.evaluate(()=>performance.now());
  await page.waitForFunction(()=>{
   const data=window.__farmStartup.state();
   return new Set(data.calls.filter(call=>call.command==='printer_actor_upsert').map(call=>call.args.config.printerId)).size===7&&data.calls.some(call=>call.command==='printer_actor_snapshots'&&call.args.targets.length===7);
  },{},{timeout:3500});
  // Let real compatibility timers start while both production preferences and
  // the offline printer remain unresolved. Nothing here replaces client code.
  await page.waitForFunction(()=>window.__farmStartup.state().calls.some(call=>call.command==='printer_actor_rpc'&&call.args.method==='server.info'),{},{timeout:2500});
  const started=await state(page);
  const upserts=started.calls.filter(call=>call.command==='printer_actor_upsert');
  assert.equal(new Set(upserts.map(row=>row.args.config.printerId)).size,7);
  assert.equal(started.calls.filter(row=>row.command==='plugin:event|listen'&&row.args.event==='printer-actor-event').length,7,'every real client subscribes independently');
  for(const key of ['production.schedule','production.cost','dispatch.smartJobs'])assert.ok(started.productionHeld.some(row=>row.key===key),`${key} remains pending during all seven actor starts`);
  const startTimes=upserts.map(row=>row.at);
  assert.ok(Math.max(...startTimes)-Math.min(...startTimes)<1500,'one offline printer never serializes the other starts');
  assert.equal(await page.locator('[data-testid^="live-printer-"] [data-testid="printer-telemetry"][data-freshness="live"]').count(),0,'neither legacy cache nor old native snapshot is live telemetry');
  const initialNames=await names(page);
  assert.equal(initialNames.length,7);
  assert.match(initialNames[6],/Flashforge Adventurer 5M/i,'saved explicit Flashforge catalogue identity repairs the old generated KE name');
  assert.doesNotMatch(initialNames[6],/Ender|\bKE\b/i);
  assert.equal(started.database['printers.config'].length,7);
  assertNoEmptyConfigWrite(started.calls);
  if(mode==='read-failure'){
   await page.getByRole('alert').filter({hasText:'Настройки принтеров требуют внимания'}).waitFor({state:'visible'});
   assert.equal(started.calls.filter(row=>row.command==='db_set_json'&&row.args.key==='printers.config').length,0,'failed strict DB read cannot trigger any configuration write');
   assert.equal(started.cache.length,7,'all cached configurations remain recoverable');
   if(screenshots)await page.screenshot({path:path.join(screenshots,'farm-startup-r125-read-failure-seven.png'),fullPage:true});
  }
  const freshReleasedAt=await page.evaluate(()=>{const at=performance.now();window.__farmStartup.releaseFresh();return at});
  await page.waitForFunction(()=>document.querySelectorAll('[data-testid^="live-printer-"] [data-testid="printer-telemetry"][data-freshness="live"]').length===6,{},{timeout:4000});
  assert.equal(await cards(page).first().locator('[data-testid="printer-telemetry"][data-freshness="live"]').count(),0,'the offline printer stays separate from the six fresh cards');
  for(let index=1;index<7;index++)assert.match(await cards(page).nth(index).innerText(),/220\s*°/,'fresh native temperatures reach the actual printer cards');
  const freshVisibleAt=await page.evaluate(()=>performance.now());
  const fresh=await state(page);
  assert.ok(fresh.calls.some(row=>row.command==='printer_actor_events_pending'),'actual client consumes the persisted native outbox');
  assert.ok(fresh.calls.some(row=>row.command==='printer_actor_events_ack'&&row.args.throughEventId>=48),'obsolete outbox entries are acknowledged');
  const rpcs=fresh.calls.filter(row=>row.command==='printer_actor_rpc');
  assert.ok(rpcs.length>0);
  assert.ok(rpcs.every(row=>row.args.expectedSessionEpoch===49),'old outbox epoch 48 cannot poison real native RPC expectations');
  assert.deepEqual(await page.evaluate(()=>window.__poisonVisible),[]);
  assert.equal(fresh.productionHeld.length>=3,true,'unrelated production reads are still pending when six cards are live');
  if(screenshots)await page.screenshot({path:path.join(screenshots,`farm-startup-r125-${mode}-six-fresh.png`),fullPage:true});
  await page.evaluate(()=>window.__farmStartup.advanceEpoch());
  await page.waitForFunction(()=>Array.from(document.querySelectorAll('[data-testid^="live-printer-"]')).slice(1).every(card=>/235\s*°/.test(card.textContent??'')),{},{timeout:4000});
  await page.evaluate(()=>{window.__farmStartup.emitOldEvent();window.__farmStartup.regressOneSnapshotPoll()});
  await page.waitForFunction(()=>window.__farmStartup.state().regressionPolls===1,{},{timeout:3500});
  assert.ok((await cards(page).allTextContents()).slice(1).every(text=>/235\s*°/.test(text)),'an older snapshot cannot overwrite epoch 50');
  assert.deepEqual(await page.evaluate(()=>window.__poisonVisible),[],'epoch 48 outbox and later epoch 49 event/snapshot never appear in the UI');
  if(mode==='read-failure'){
   await page.evaluate(()=>window.__farmStartup.recoverDatabase());
   await page.getByRole('alert').filter({hasText:'Настройки принтеров требуют внимания'}).waitFor({state:'hidden',timeout:7500});
   assert.equal(await cards(page).count(),7,'automatic retry restores DB hydration without dropping cached printers');
  }
  // Exercise the real settings -> awaited configuration commit -> existing
  // MoonrakerClient path. Changing only one operational preset must update its
  // native actor now, without restarting or reconnecting the other six.
  let concurrentSave;
  const actorStartsBeforeEdit=mode==='automatic-refresh'?7:(await state(page)).calls.filter(row=>row.command==='printer_actor_upsert').length;
  if(mode==='automatic-refresh'){
   assert.equal(upserts.find(row=>row.args.config.printerId==='printer-2').args.config.modelId,'custom','automatic detection begins with the saved generic operational profile');
   // The automatic model refresh owns a durable full-array write A. While its
   // native SQLite commit is held, save a different printer's real settings B.
   // B must be rejected before staging, then succeed against A's committed refs.
   await page.waitForFunction(()=>!!window.__farmStartup.state().heldConfigWrite,{},{timeout:8500});
   const held=await state(page),heldPending=JSON.parse(held.pending);
   const configWriteCount=held.calls.filter(row=>row.command==='db_set_json'&&row.args.key==='printers.config').length;
   assert.equal(held.database['printers.config'][1].profile.preset,'custom','A is still uncommitted in the native database');
   assert.equal(held.heldConfigWrite.configs[1].profile.preset,'ender3-v3-se');
   assert.equal(heldPending.configs[1].profile.preset,'ender3-v3-se','A is recoverable in the actual pending journal');
   const renamedPrinter='Мастерская — принтер 3';
   await cards(page).nth(2).getByRole('button',{name:'Настройки',exact:true}).click();
   await page.locator('.printerSetup').waitFor({state:'visible'});
   await page.getByLabel('Название в Klipper Farm',{exact:true}).fill(renamedPrinter);
   await page.getByRole('button',{name:'Сохранить настройки',exact:true}).click();
   await page.locator('.printerSetupError').filter({hasText:'Настройки принтеров уже сохраняются. Дождитесь завершения и повторите сохранение.'}).waitFor({state:'visible',timeout:2000});
   assert.equal(await page.locator('.printerSetup').isVisible(),true,'B remains editable for retry');
   const rejected=await state(page);
   assert.equal(rejected.calls.filter(row=>row.command==='db_set_json'&&row.args.key==='printers.config').length,configWriteCount,'busy B is rejected before a second native configuration write');
   assert.deepEqual(JSON.parse(rejected.pending),heldPending,'busy B cannot replace A in the pending journal');
   assert.deepEqual(rejected.database['printers.config'],held.database['printers.config'],'neither uncommitted A nor rejected B modifies durable configuration');
   assert.equal(JSON.parse(rejected.pending).configs[2].name,held.database['printers.config'][2].name,'B was not staged behind the held full-array write');
   if(screenshots)await page.screenshot({path:path.join(screenshots,'farm-startup-r125-concurrent-save-busy.png'),fullPage:true});
   await page.evaluate(()=>window.__farmStartup.releaseAutomaticWrite());
   await page.waitForFunction(()=>{
    const data=window.__farmStartup.state(),printer=data.database['printers.config'][1];
    return printer.profile.preset==='ender3-v3-se'&&printer.modelSelection.lastDetection?.decision==='confirmed'&&data.calls.some(row=>row.command==='printer_actor_upsert'&&row.args.config.printerId==='printer-2'&&row.args.config.modelId==='ender3-v3-se');
   },{},{timeout:8500});
   assert.equal(await page.getByLabel('Название в Klipper Farm',{exact:true}).inputValue(),renamedPrinter,'A completion preserves B\'s unsaved form draft');
   await page.getByRole('button',{name:'Сохранить настройки',exact:true}).click();
   await page.locator('.printerSetup').waitFor({state:'hidden',timeout:3000});
   const retried=await state(page),finalConfigs=retried.database['printers.config'];
   assert.equal(finalConfigs[1].profile.preset,'ender3-v3-se','retry B preserves A\'s committed operational change');
   assert.equal(finalConfigs[2].name,renamedPrinter,'retry B commits its own name change');
   assert.equal(finalConfigs[2].nameSource,'custom');
   assert.equal(retried.calls.filter(row=>row.command==='db_set_json'&&row.args.key==='printers.config').length,configWriteCount+1,'only the successful B retry reaches native persistence');
   for(const index of [0,3,4,5,6])assert.deepEqual(finalConfigs[index],held.database['printers.config'][index],'concurrent settings preserve untouched printer '+(index+1));
   assert.equal(retried.pending,null,'both successful commits clear the pending journal');
   concurrentSave={rejectedBeforeStaging:true,retryPreservedBoth:true,blockedAdditionalNativeWrites:0,pendingJournalPreserved:true,renamedPrinterId:'printer-3',renamedPrinterName:renamedPrinter,unchangedOtherPrinters:5};
  }else{
   await cards(page).nth(1).getByRole('button',{name:'Настройки',exact:true}).click();
   await page.locator('.printerSetup').waitFor({state:'visible'});
   await page.locator('.printerSetup').getByText('Профиль управления',{exact:true}).click();
   await page.locator('.printerSetup .modelDetectionControls select').selectOption('ender3-v3-se');
   await page.getByRole('button',{name:'Сохранить настройки',exact:true}).click();
   await page.locator('.printerSetup').waitFor({state:'hidden'});
   await page.waitForFunction(before=>window.__farmStartup.state().calls.filter(row=>row.command==='printer_actor_upsert').length>before,actorStartsBeforeEdit,{timeout:3000});
  }
  await page.waitForTimeout(150);
  const afterEdit=await state(page);
  const changedActors=afterEdit.calls.filter(row=>row.command==='printer_actor_upsert').slice(actorStartsBeforeEdit);
  assert.equal(changedActors.length,1,'one saved operational edit produces exactly one native actor update');
  assert.equal(changedActors[0].args.config.printerId,'printer-2');
  assert.equal(changedActors[0].args.config.modelId,'ender3-v3-se');
  assert.equal(afterEdit.database['printers.config'][1].profile.preset,'ender3-v3-se');
  if(mode==='automatic-refresh'){
   const detected=afterEdit.database['printers.config'][1];
   assert.equal(detected.modelSelection.mode,'automatic');
   assert.equal(detected.modelSelection.selectedPreset,'ender3-v3-se');
   assert.equal(detected.modelSelection.lastDetection.model,'ender3-v3-se');
   assert.equal(detected.modelSelection.lastDetection.decision,'confirmed');
   assert.equal(detected.configSnapshot.probeCoverage.successful,6);
   assert.equal(detected.configSnapshot.probeCoverage.total,6);
   for(const method of ['server.info','printer.info','machine.system_info','printer.objects.list'])assert.ok(afterEdit.calls.some(row=>row.command==='printer_actor_rpc'&&row.args.printerId==='printer-2'&&row.args.method===method),`actual automatic detector performs ${method}`);
   assert.ok(afterEdit.calls.some(row=>row.command==='printer_actor_rpc'&&row.args.printerId==='printer-2'&&row.args.method==='printer.objects.query'&&row.args.params.objects.configfile));
   assert.ok(afterEdit.calls.some(row=>row.command==='printer_actor_rpc'&&row.args.printerId==='printer-2'&&row.args.method==='printer.objects.query'&&row.args.params.objects.toolhead));
   assert.match(await cards(page).nth(1).locator('[data-testid="printer-address"]').innerText(),/^SE\s*·/,'confirmed automatic profile reaches the visible model badge');
   if(screenshots)await page.screenshot({path:path.join(screenshots,'farm-startup-r125-automatic-confirmed-profile.png'),fullPage:true});
  }
  const beforeReload=await state(page);
  const expectedNames=await names(page);
  assertNoEmptyConfigWrite(beforeReload.calls);
  assert.equal(beforeReload.database['printers.config'].length,7);
  assert.equal(beforeReload.cache.length,7);
  assert.equal(beforeReload.unexpected.length,0,JSON.stringify(beforeReload.unexpected));
  // A real navigation destroys all React/client state. Only saved native DB and
  // the actual application configuration cache survive it.
  await page.reload();
  await page.locator('.kfSidebar nav').getByRole('button',{name:'Принтеры',exact:true}).click();
  await page.waitForFunction(()=>document.querySelectorAll('[data-testid^="live-printer-"]').length===7,{},{timeout:3000});
  assert.deepEqual(await names(page),expectedNames,'restart keeps all seven names and selected catalogue identity');
  assert.equal(await page.locator('[data-testid^="live-printer-"] [data-testid="printer-telemetry"][data-freshness="live"]').count(),0,'restart never reuses previous runtime telemetry as live');
  const restarted=await state(page);
  assert.equal(restarted.database['printers.config'][6].catalogModelId,'flashforge-adventurer-5m');
  if(concurrentSave){assert.equal(restarted.database['printers.config'][1].profile.preset,'ender3-v3-se');assert.equal(restarted.database['printers.config'][2].name,concurrentSave.renamedPrinterName)}
  assertNoEmptyConfigWrite(restarted.calls);
  assert.deepEqual(network,[],'real MoonrakerClient communicates only through the native authenticated boundary');
  assert.deepEqual(errors,[]);
  report.push({mode,printers:7,independentActorStarts:upserts.map(row=>({printerId:row.args.config.printerId,atMs:row.at-started.mountAt})),sevenCardsVisibleMs:visibleAt-started.mountAt,startSpreadMs:Math.max(...startTimes)-Math.min(...startTimes),sixFreshAfterReleaseMs:freshVisibleAt-freshReleasedAt,pendingProductionKeys:[...new Set(fresh.productionHeld.map(row=>row.key))],freshCards:6,offlineCards:1,oldOutboxEpoch:48,firstNativeEpoch:49,nextNativeEpoch:50,operationalEdit:{kind:mode==='automatic-refresh'?'automatic-confirmed':'manual',printerId:changedActors[0].args.config.printerId,modelId:changedActors[0].args.config.modelId,nativeUpdates:changedActors.length,probeCoverage:afterEdit.database['printers.config'][1].configSnapshot?.probeCoverage},concurrentSave,configurationWrites:beforeReload.calls.filter(row=>row.command==='db_set_json'&&row.args.key==='printers.config').map(row=>({count:JSON.parse(row.args.value).length,atMs:row.at})),namesAfterRestart:await names(page),passed:true});
  await context.close();
  lastPage=undefined;
 }
 const result={passed:report.length===3,cases:report,notes:'Actual FarmApp, actual MoonrakerClient, actual configuration store. Only authenticated native IPC is emulated; this measures local UI scheduling, not physical-printer network latency. Three production migrations and the offline actor RPC remain pending. The automatic case uses the real six-probe detector, fact parser, classifier and five-second App refresh timer.'};
 if(screenshots)fs.writeFileSync(path.join(screenshots,'farm-startup-r125-report.json'),JSON.stringify(result,null,2));
 console.log(JSON.stringify(result,null,2));
}catch(error){
 if(screenshots&&lastPage){
  await lastPage.screenshot({path:path.join(screenshots,'farm-startup-r125-failure.png'),fullPage:true}).catch(()=>{});
  const actual=await state(lastPage).catch(()=>undefined);
  fs.writeFileSync(path.join(screenshots,'farm-startup-r125-failure.json'),JSON.stringify({passed:false,mode:lastMode,error:String(error),actual},null,2));
 }
 throw error;
}finally{
 await browser?.close();
 if(server)await new Promise(resolve=>server.close(resolve));
 fs.rmSync(output,{recursive:true,force:true});
}
