import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import ts from './typescript-runtime.mjs';
const root = path.resolve(import.meta.dirname, '..');
const compile = (file, imports = {}) => {
  let code = ts.transpileModule(fs.readFileSync(path.join(root, file), 'utf8'), { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ES2022 } }).outputText;
  for (const [name, url] of Object.entries(imports)) code = code.replaceAll(`from '${name}'`, `from '${url}'`);
  return `data:text/javascript;base64,${Buffer.from(code).toString('base64')}`;
};
const { printerFinish, finishTime, printerLayerLabel } = await import(compile('src/lib/printerFinish.ts', {
  './printerJob': compile('src/lib/printerJob.ts'), './printerTelemetry': compile('src/lib/printerTelemetry.ts'),
}));
const now = new Date(2026, 9, 20, 23, 50).getTime();
const live = { state: 'printing', connectionState: 'online', filename: 'calibration.gcode', progress: .5, printDuration: 1800, jobUpdatedAt: now, currentLayer: 50, totalLayers: 100 };
const cases = [];
function test(name, run) { run(); cases.push({ name, passed: true }); }
test('estimate-remains-anchored-to-sample-while-countdown-decreases', () => {
  const first = printerFinish(live, now), later = printerFinish(live, now + 10_000);
  assert.equal(first.finishAt, now + 1800_000); assert.equal(later.finishAt, first.finishAt);
  assert.equal(later.remainingSeconds, 1790); assert.equal(later.progress, .5);
});
test('fresh-progress-and-duration-revise-the-forecast', () => {
  const next = printerFinish({ ...live, progress: .75, printDuration: 3600, jobUpdatedAt: now + 10_000 }, now + 10_000);
  assert.equal(next.finishAt, now + 1210_000);
});
test('pause-offline-errors-autonomous-and-degraded-never-get-a-finish-time', () => {
  for (const patch of [{ state: 'paused' }, { state: 'error' }, { state: 'offline' }, { connectionState: 'offline' }, { connectionState: 'degraded' }, { connectionState: 'connecting' }, { remoteControlSuspended: true }]) {
    assert.equal(printerFinish({ ...live, ...patch }, now).finishAt, undefined, JSON.stringify(patch));
  }
});
test('stale-expired-and-missing-job-samples-suspend-projections', () => {
  for (const jobUpdatedAt of [now - 20_001, now - 120_001, undefined, now + 60_000]) assert.equal(printerFinish({ ...live, jobUpdatedAt }, now).finishAt, undefined);
});
test('warmup-invalid-and-extreme-values-never-create-misleading-forecasts', () => {
  for (const patch of [{ progress: 0 }, { progress: .01 }, { progress: 1 }, { progress: NaN }, { printDuration: NaN }, { printDuration: -1 }, { printDuration: 0 }, { printDuration: 29 }, { printDuration: 8 * 86400 }]) {
    assert.equal(printerFinish({ ...live, ...patch }, now).finishAt, undefined, JSON.stringify(patch));
  }
});
test('complete-idle-and-ready-printers-do-not-become-fake-active-jobs', () => {
  assert.equal(printerFinish({ ...live, state: 'ready', progress: 1 }, now).active, false);
  assert.equal(printerFinish({ ...live, state: 'ready', filename: '', progress: 0, printDuration: 0 }, now).active, false);
});
test('midnight-and-farther-dates-include-the-day', () => {
  assert.match(finishTime(now + 1800_000, now), /^завтра, /);
  assert.doesNotMatch(finishTime(now - 60_000, now), /завтра/);
  assert.match(finishTime(now + 3 * 86400_000, now), /23/);
});
test('layer-labels-reject-missing-corrupt-and-expired-data', () => {
  assert.equal(printerLayerLabel(live, now), 'Слой 50 / 100');
  for (const patch of [{ currentLayer: 101 }, { currentLayer: -1 }, { totalLayers: 0 }, { currentLayer: 1.2 }, { totalLayers: undefined }, { jobUpdatedAt: now - 120_001 }]) assert.equal(printerLayerLabel({ ...live, ...patch }, now), undefined);
});
const report = { timezone: Intl.DateTimeFormat().resolvedOptions().timeZone, cases };
if (process.env.KF_R128_FINISH_PROOF) fs.writeFileSync(process.env.KF_R128_FINISH_PROOF, JSON.stringify(report, null, 2) + '\n');
console.log(`R128 finish forecast: ${cases.length} cases passed`);
