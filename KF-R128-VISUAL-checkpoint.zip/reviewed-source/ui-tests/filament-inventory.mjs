import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import http from 'node:http';
import {build} from 'vite';

const root=path.resolve(import.meta.dirname,'..');
const out=fs.mkdtempSync(path.join(os.tmpdir(),'kf-filament-r123-'));
const shots=process.env.KF_UI_SCREENSHOTS,report=[],runtimeErrors=[];
let browser,server,currentPage,currentCase='fixture-build';
const record=(name,proof={})=>report.push({case:name,passed:true,...proof});
try{
 await build({root,logLevel:'warn',build:{outDir:out,emptyOutDir:true,rollupOptions:{input:path.join(root,'ui-tests/filament-inventory.html')}}});
 if(process.argv.includes('--build-only')){console.log('R123 filament fixture build passed: actual production tab, inventory forms, reducer and strict persistence store');process.exit(0)}
 const {chromium}=await import(process.env.PLAYWRIGHT_MODULE_PATH??'playwright');
 server=http.createServer((req,res)=>{
  const file=path.resolve(out,new URL(req.url,'http://localhost').pathname.slice(1));
  if(!file.startsWith(out+path.sep)||!fs.existsSync(file)||!fs.statSync(file).isFile()){res.writeHead(404).end();return}
  res.setHeader('Content-Type',({'.js':'text/javascript','.css':'text/css','.html':'text/html','.svg':'image/svg+xml','.png':'image/png','.webp':'image/webp'})[path.extname(file)]??'application/octet-stream');res.end(fs.readFileSync(file));
 });
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 const origin=`http://127.0.0.1:${server.address().port}`;
 browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_EXECUTABLE,args:['--no-sandbox','--disable-dev-shm-usage']});
 if(shots)fs.mkdirSync(shots,{recursive:true});
 async function pageFor(query='',theme='light',width=1536,height=1000){
  const page=await browser.newPage({viewport:{width,height},locale:'ru-RU'});currentPage=page;
  page.on('pageerror',error=>runtimeErrors.push(error.message));
  await page.route('**/*',route=>route.request().url().startsWith(origin+'/')?route.continue():route.abort());
  await page.goto(`${origin}/ui-tests/filament-inventory.html?theme=${theme}&${query}`);
  return page;
 }
 const panel=page=>page.getByRole('region',{name:'Запас и расход пластика',exact:true});
 const form=page=>panel(page).locator('form');
 async function field(page,label){
  // Playwright's label text includes nested <option> text and optional hints.
  // Match the visible label prefix, then require exactly one real form control.
  const escaped=label.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
  const control=form(page).getByLabel(new RegExp('^'+escaped));
  await control.waitFor();assert.equal(await control.count(),1,'Ambiguous inventory field: '+label);return control;
 }
 const material=(page,name)=>page.getByTestId('filament-material-'+name);
 const printer=(page,id)=>page.getByTestId('filament-printer-'+id);
 async function loaded(page){await panel(page).getByRole('button',{name:'Добавить пластик',exact:true}).waitFor()}
 async function state(page){return await page.evaluate(()=>window.__inventory())}
 async function db(page){return await page.evaluate(()=>window.__database())}
 async function notices(page){return await page.evaluate(()=>window.__notices())}
 async function commits(page){return await page.evaluate(()=>window.__calls.filter(call=>call.command==='filament_inventory_commit').length)}
 async function total(page,name){const value=await state(page);return (value.materials[name]?.looseGrams??0)+value.spools.filter(spool=>spool.material===name).reduce((sum,spool)=>sum+spool.remainingWeight,0)}
 async function save(page,label='Сохранить'){await form(page).getByRole('button',{name:label,exact:true}).click();await form(page).waitFor({state:'detached'})}
 async function addStock(page,name,quantity,reserve){
  await panel(page).getByRole('button',{name:'Добавить пластик',exact:true}).click();
  await (await field(page,'Материал')).selectOption(name);
  await (await field(page,'Добавить на склад, кг')).fill(quantity);
  if(reserve!==undefined)await (await field(page,'Резерв, кг')).fill(reserve);
  await save(page);
 }
 async function writeoff(page,id,name,quantity){
  await printer(page,id).getByRole('button',{name:'Расход вручную',exact:true}).click();
  await (await field(page,'Материал')).selectOption(name);
  await (await field(page,'Откуда списывать')).selectOption('');
  await (await field(page,'Расход, кг')).fill(quantity);
  await save(page,'Записать расход');
 }
 async function shot(page,name){if(shots)await page.screenshot({path:path.join(shots,'filament-'+name+'.png')})}
 async function noOverflow(page){
  const value=await page.evaluate(()=>({width:innerWidth,document:document.documentElement.scrollWidth,body:document.body.scrollWidth}));
  assert.ok(value.document<=value.width+1&&value.body<=value.width+1,'Filament UI overflows horizontally: '+JSON.stringify(value));
  const fields=await form(page).locator('input,select,button').evaluateAll(elements=>elements.filter(element=>{const s=getComputedStyle(element);return s.display!=='none'&&s.visibility!=='hidden'}).map(element=>{const b=element.getBoundingClientRect();return {left:b.left,right:b.right,label:element.getAttribute('aria-label')||element.textContent||element.tagName}}));
  for(const field of fields)assert.ok(field.left>=-.5&&field.right<=value.width+.5,'Unreachable inventory form control: '+JSON.stringify(field));
 }
 async function actualProductionParent(page){
  const classes=await panel(page).evaluate(element=>element.closest('.productionPanel.panel')?.className??'');
  assert.ok(classes.split(/\s+/).includes('productionPanel')&&classes.split(/\s+/).includes('panel'),'Field regression must run inside the actual production modal');return classes;
 }
 async function themedFields(page,kind){
  await actualProductionParent(page);
  await form(page).evaluate(element=>{if(element.contains(document.activeElement))document.activeElement.blur()});
  const proof=await form(page).evaluate((element,formKind)=>{
   const probe=document.createElement('span');probe.style.cssText='position:fixed;left:-10000px;top:0;background:var(--ui-surface);color:var(--ui-text);border:1px solid var(--ui-border-strong);outline:2px solid var(--ui-accent)';element.append(probe);
   const canonical=getComputedStyle(probe),expected={surface:canonical.backgroundColor,text:canonical.color,borderStrong:canonical.borderTopColor,accent:canonical.outlineColor,subtle:''};
   probe.style.color='var(--ui-subtle)';expected.subtle=getComputedStyle(probe).color;probe.remove();
   const fields=[...element.querySelectorAll('input,select')].map(control=>{
    const style=getComputedStyle(control),placeholder=control instanceof HTMLInputElement?control.placeholder:'';
    const row={tag:control.tagName.toLowerCase(),id:control.id,value:control.value,placeholder,background:style.backgroundColor,text:style.color,border:[style.borderTopColor,style.borderRightColor,style.borderBottomColor,style.borderLeftColor]};
    if(placeholder){const pseudo=getComputedStyle(control,'::placeholder');row.placeholderColor=pseudo.color;row.placeholderOpacity=pseudo.opacity;}
    return row;
   });
   return {form:formKind,parentClasses:element.closest('.productionPanel.panel')?.className??'',expected,fields};
  },kind);
  assert.ok(proof.fields.length>=3,'The actual production form has no fields');
  assert.ok(proof.expected.surface!=='rgba(0, 0, 0, 0)'&&proof.expected.text!==proof.expected.surface,'Theme tokens did not resolve to a readable surface');
  for(const input of proof.fields){
   assert.equal(input.background,proof.expected.surface,`${kind} ${input.id}: legacy production input background won over the theme`);
   assert.equal(input.text,proof.expected.text,`${kind} ${input.id}: input text differs from the theme`);
   for(const color of input.border)assert.equal(color,proof.expected.borderStrong,`${kind} ${input.id}: input border differs from the theme`);
   if(input.placeholder){assert.equal(input.placeholderColor,proof.expected.subtle,`${kind} ${input.id}: placeholder differs from the theme`);assert.equal(input.placeholderOpacity,'1',`${kind} ${input.id}: placeholder is faded`);}
  }
  assert.ok(proof.fields.some(input=>input.tag==='input')&&proof.fields.some(input=>input.tag==='select'),'Both input and select must be exercised inside production');
  return proof;
 }
 async function keyboardFieldEntry(page,kind,label,value,expectedAccent){
  const material=await field(page,'Материал'),target=await field(page,label);
  await material.focus();await page.keyboard.press('Tab');
  assert.equal(await target.evaluate(element=>element===document.activeElement),true,'Keyboard Tab must reach the quantity field');
  await page.keyboard.press('Control+A');await page.keyboard.type(value);
  assert.equal(await target.inputValue(),value,'Keyboard entry did not retain its value');
  const proof=await target.evaluate((element,formKind)=>{const style=getComputedStyle(element);return {form:formKind,tag:element.tagName.toLowerCase(),id:element.id,value:element.value,active:element===document.activeElement,focusVisible:element.matches(':focus-visible'),outlineStyle:style.outlineStyle,outlineWidth:parseFloat(style.outlineWidth),outlineColor:style.outlineColor,borderColor:style.borderTopColor}},kind);
  proof.expectedAccent=expectedAccent;
  assert.equal(proof.active,true);assert.equal(proof.focusVisible,true,'Keyboard focus must be visibly identified');
  assert.equal(proof.outlineStyle,'solid');assert.ok(proof.outlineWidth>=2,'Keyboard focus outline is missing or too thin');
  assert.equal(proof.outlineColor,expectedAccent,'Production focus outline lost the accent color');assert.equal(proof.borderColor,expectedAccent,'Production focus border lost the accent color');
  return proof;
 }
 async function saveReachable(page,kind){
  const button=form(page).getByRole('button',{name:'Сохранить',exact:true});await button.scrollIntoViewIfNeeded();
  const proof=await button.evaluate((element,formKind)=>{const box=element.getBoundingClientRect(),hit=(x,y)=>{const target=document.elementFromPoint(x,y);return target===element||element.contains(target)};return {form:formKind,visible:getComputedStyle(element).visibility!=='hidden'&&getComputedStyle(element).display!=='none',insideViewport:box.x>=0&&box.y>=0&&box.right<=innerWidth+1&&box.bottom<=innerHeight+1,unobscured:[.25,.5,.75].every(x=>[.25,.5,.75].every(y=>hit(box.x+box.width*x,box.y+box.height*y))),box:{x:box.x,y:box.y,width:box.width,height:box.height}}},kind);
  assert.equal(proof.visible,true);assert.equal(proof.insideViewport,true,'The production form save button cannot be scrolled into view');assert.equal(proof.unobscured,true,'The production form save button is obscured');
  return proof;
 }
 async function nativeBoundariesOnly(page){
  const calls=await page.evaluate(()=>window.__calls);
  for(const call of calls){
   assert.ok(['db_get_json','db_set_json','filament_inventory_commit','native_notify','notification_list','audit_add'].includes(call.command),'Inventory interaction attempted printer control: '+call.command);
   if(call.command==='db_set_json')assert.ok(!['production.filamentInventory','production.spools'].includes(call.args.key),'Inventory bypassed atomic persistence');
  }
 }

 {
  currentCase='production-discoverability';const page=await pageFor('view=production','dark');
  await page.getByRole('button',{name:'Пластик',exact:true}).click();await loaded(page);
  await page.getByText('Начните с общего запаса',{exact:true}).waitFor();
  await shot(page,'production-tab-dark');await nativeBoundariesOnly(page);
  record(currentCase,{actualProductionPanel:true,actualInventoryPanel:true});await page.close();
 }

 {
  const page=await pageFor();await loaded(page);
  currentCase='material-stock-and-reserve';
  await panel(page).getByRole('button',{name:'Добавить пластик',exact:true}).click();
  for(const invalid of ['0','-1','NaN','1e309']){
   const before=await commits(page);await (await field(page,'Добавить на склад, кг')).fill(invalid);
   await form(page).getByRole('button',{name:'Сохранить',exact:true}).click();await form(page).getByRole('alert').waitFor();
   assert.equal(await commits(page),before,'Invalid quantity reached persistence');
  }
  await (await field(page,'Добавить на склад, кг')).fill('15');
  await (await field(page,'Резерв, кг')).fill('5');await save(page);
  assert.equal(await total(page,'PLA'),15000);assert.equal((await state(page)).materials.PLA.reserveGrams,5000);
  assert.match(await material(page,'PLA').innerText(),/15 кг/);assert.match(await material(page,'PLA').innerText(),/10 кг/);
  record(currentCase,{stockGrams:15000,reserveGrams:5000,invalidValuesBlocked:true});

  currentCase='spool-transfer-and-purchase';
  await panel(page).getByRole('button',{name:'Добавить катушки',exact:true}).click();
  await (await field(page,'Вес пластика в одной катушке, кг')).fill('1');
  await (await field(page,'Число катушек')).fill('2');
  await (await field(page,'Название')).fill('PLA рабочая');
  await (await field(page,'Откуда пластик')).selectOption('existing-stock');await save(page);
  assert.equal(await total(page,'PLA'),15000,'A spool transfer counted stock twice');
  assert.equal((await state(page)).materials.PLA.looseGrams,13000);
  assert.equal((await state(page)).spools.length,2);
  await panel(page).getByRole('button',{name:'Добавить катушки',exact:true}).click();
  await (await field(page,'Вес пластика в одной катушке, кг')).fill('0,5');
  await (await field(page,'Название')).fill('PLA покупка');
  await (await field(page,'Откуда пластик')).selectOption('purchase');await save(page);
  assert.equal(await total(page,'PLA'),15500);assert.equal((await state(page)).spools.length,3);
  record(currentCase,{existingStockZeroNet:true,purchaseAddedGrams:500,commaDecimals:true});

  currentCase='printer-binding-and-material-writeoff';
  await printer(page,'printer-one').getByRole('button',{name:'Выбрать пластик',exact:true}).click();await save(page);
  assert.equal((await state(page)).printers['printer-one'].binding.material,'PLA');
  await writeoff(page,'printer-one','PLA','1');
  await page.locator('.appToastStack').getByText('K1 Max: израсходовано 1 кг пластика',{exact:true}).waitFor();
  await addStock(page,'PETG','3,5');
  await printer(page,'printer-two').getByRole('button',{name:'Выбрать пластик',exact:true}).click();
  await (await field(page,'Материал')).selectOption('PETG');await save(page);
  await writeoff(page,'printer-two','PETG','0,25');
  let value=await state(page);
  assert.equal(value.printers['printer-one'].usedGrams,1000);assert.equal(value.printers['printer-two'].usedGrams,250);
  assert.equal(value.printers['printer-one'].manualGrams,1000);assert.equal(value.printers['printer-one'].calculatedGrams,0);
  assert.equal(await total(page,'PLA'),14500);assert.equal(await total(page,'PETG'),3250);
  record(currentCase,{perPrinterSeparated:true,perMaterialSeparated:true,manualLabeled:true});

  currentCase='milestone-and-reserve-notices';
  assert.equal((await notices(page)).filter(row=>row.action==='filament.milestone').length,1);
  await writeoff(page,'printer-one','PLA','9,5');assert.equal(await total(page,'PLA'),5000);
  await page.locator('.appToastStack').getByText('PLA: достигнут резерв пластика',{exact:true}).waitFor();
  await material(page,'PLA').getByText('Достигнут резерв',{exact:true}).waitFor();
  let noticeRows=await notices(page);
  assert.equal(noticeRows.filter(row=>row.action==='filament.milestone').length,2,'Bulk use must combine crossed kilogram milestones into one notice');
  assert.equal(noticeRows.filter(row=>row.action==='filament.reserve').length,1);
  await writeoff(page,'printer-one','PLA','0,1');
  assert.equal((await notices(page)).filter(row=>row.action==='filament.reserve').length,1,'Low-stock warning repeated below the same threshold');
  const beforeReload=await notices(page);await page.reload();await loaded(page);assert.deepEqual(await notices(page),beforeReload,'Reopening duplicated durable notices');
  await addStock(page,'PLA','0,2');assert.equal(await total(page,'PLA'),5100);
  await writeoff(page,'printer-one','PLA','0,2');assert.equal(await total(page,'PLA'),4900);
  noticeRows=await notices(page);
  assert.equal(noticeRows.filter(row=>row.action==='filament.reserve').length,2,'Reserve must rearm only after replenishment above it');
  assert.equal(noticeRows.filter(row=>row.action==='filament.milestone').length,2);
  await page.getByRole('button',{name:/^Уведомления(?::|$)/}).click();
  const drawer=page.getByRole('dialog',{name:'Центр уведомлений',exact:true});
  await drawer.getByText('Пластик достиг резерва',{exact:true}).first().waitFor();await drawer.getByText('Расход пластика',{exact:true}).first().waitFor();
  assert.equal(await drawer.getByText('Пластик достиг резерва',{exact:true}).count(),2);assert.equal(await drawer.getByText('Расход пластика',{exact:true}).count(),2);
  await shot(page,'actual-notifications');await drawer.getByRole('button',{name:'Закрыть уведомления',exact:true}).click();
  record(currentCase,{perPrinterMilestone:true,bulkNoticeCombined:true,reserveCrossing:true,reserveDeduplicated:true,rearmedAfterReplenishment:true,reopenDoesNotNotify:true,actualToastHost:true,actualNotificationCenter:true});

  currentCase='save-failure-preserves-form';
  await panel(page).getByRole('button',{name:'Добавить пластик',exact:true}).click();
  await (await field(page,'Материал')).selectOption('PETG');
  await (await field(page,'Добавить на склад, кг')).fill('1,25');await (await field(page,'Резерв, кг')).fill('2');
  const beforeFailure=await db(page),beforeFailureNotices=await notices(page),beforeFailureToasts=await page.evaluate(()=>window.__toasts);
  await page.evaluate(()=>window.__fault.commit=true);await form(page).getByRole('button',{name:'Сохранить',exact:true}).click();
  await form(page).getByRole('alert').filter({hasText:'Проверочный сбой сохранения SQLite'}).waitFor();
  assert.equal(await (await field(page,'Добавить на склад, кг')).inputValue(),'1,25');
  assert.equal(await (await field(page,'Резерв, кг')).inputValue(),'2');
  assert.equal(await (await field(page,'Материал')).inputValue(),'PETG');
  assert.deepEqual(await db(page),beforeFailure);assert.deepEqual(await notices(page),beforeFailureNotices);
  assert.deepEqual(await page.evaluate(()=>window.__toasts),beforeFailureToasts,'A failed transaction displayed a desktop notice');
  await shot(page,'save-failure-preserved');await page.evaluate(()=>window.__fault.commit=false);await save(page);
  assert.equal(await total(page,'PETG'),4500);
  record(currentCase,{failedSavePreserved:true,formValuesPreserved:true,noStateOrNoticeWrite:true,retrySaved:true});

  currentCase='reopen-persistence';
  const durable=await db(page),durableNotices=await notices(page);await page.reload();await loaded(page);
  assert.deepEqual(await db(page),durable);assert.deepEqual(await notices(page),durableNotices);
  value=await state(page);assert.equal(value.printers['printer-one'].usedGrams,10800);assert.equal(value.printers['printer-two'].usedGrams,250);
  assert.equal(await commits(page),0,'A read-only reopen rewrote migrated stock');
  await shot(page,'saved-inventory-light');await nativeBoundariesOnly(page);
  record(currentCase,{stockAndPrinterCountersRestored:true,noticesUnchanged:true,noReadOnlyCommit:true});await page.close();
 }

 {
  currentCase='legacy-migration';const page=await pageFor('seed=legacy','dark');await loaded(page);
  assert.equal(await commits(page),0,'Previewing legacy stock must remain read-only');
  await panel(page).getByTestId('filament-spool-legacy-exact-id').click();
  await panel(page).getByRole('region',{name:'Выбранная катушка',exact:true}).getByText('Старая PETG',{exact:true}).waitFor();
  await panel(page).getByRole('button',{name:'QR',exact:true}).click();
  const qr=panel(page).getByRole('img',{name:'QR klipper-spool://legacy-exact-id',exact:true});await qr.waitFor();assert.ok(await qr.evaluate(async image=>{await image.decode();return image.naturalWidth>0}),'Migrated spool QR did not decode');
  await addStock(page,'PLA','1');
  let value=await state(page),legacy=await page.evaluate(()=>window.__legacy);
  assert.deepEqual(value.spools.find(row=>row.id===legacy.id),legacy,'Migration changed original spool fields');
  assert.equal(await total(page,'PETG'),625);assert.equal(value.printers['printer-two'].binding.spoolId,legacy.id);
  const originalLegacyRaw=(await db(page))['production.spools'];assert.equal(originalLegacyRaw,JSON.stringify([legacy]));
  await page.reload();await loaded(page);value=await state(page);assert.deepEqual(value.spools.find(row=>row.id===legacy.id),legacy);
  await nativeBoundariesOnly(page);record(currentCase,{migrationPreserved:true,originalLegacyKeyUnchanged:true,legacyAssignmentPreserved:true,reopenPreserved:true});await page.close();
 }

 {
  currentCase='read-failure-no-overwrite';const page=await pageFor('seed=legacy&fault=read');
  await panel(page).getByRole('alert').filter({hasText:'Проверочный сбой чтения SQLite'}).waitFor();
  const before=await db(page);assert.equal(await commits(page),0);assert.equal(await panel(page).getByRole('button',{name:'Добавить пластик',exact:true}).count(),0);
  await panel(page).getByRole('button',{name:'Повторить',exact:true}).click();await panel(page).getByRole('alert').waitFor();assert.deepEqual(await db(page),before);
  await page.evaluate(()=>window.__fault.read=false);await panel(page).getByRole('button',{name:'Повторить',exact:true}).click();await loaded(page);
  assert.deepEqual(await db(page),before);assert.equal(await commits(page),0);
  assert.match(await material(page,'PETG').innerText(),/0,625 кг/);
  record(currentCase,{noOverwrite:true,noCommit:true,explicitRetryRetainsLegacy:true});await page.close();
 }

 {
  currentCase='malformed-state-no-overwrite';const page=await pageFor('seed=malformed');
  await panel(page).getByRole('alert').filter({hasText:'повреждены'}).waitFor();
  assert.equal((await db(page))['production.filamentInventory'],'{broken JSON');assert.equal(await commits(page),0);
  assert.equal(await panel(page).getByRole('button',{name:'Добавить пластик',exact:true}).count(),0);
  record(currentCase,{malformedStateRetained:true,noCommit:true});await page.close();
 }

 {
  currentCase='viewer-read-only';const page=await pageFor('role=viewer&seed=legacy','dark');await loaded(page);
  await page.getByText('Доступен просмотр. Менять запасы может оператор или администратор.',{exact:true}).waitFor();
  assert.equal(await panel(page).getByRole('button',{name:'Добавить пластик',exact:true}).isDisabled(),true);
  assert.equal(await panel(page).getByRole('button',{name:'Добавить катушки',exact:true}).isDisabled(),true);
  for(const button of await printer(page,'printer-two').getByRole('button').all())assert.equal(await button.isDisabled(),true);
  assert.equal(await commits(page),0);assert.equal((await db(page))['production.filamentInventory'],undefined);
  await nativeBoundariesOnly(page);record(currentCase,{viewerBlocked:true,readOnlyMigration:true});await page.close();
 }

 for(const theme of ['light','dark'])for(const width of [390,910,1536]){
  currentCase=`responsive-layout-${theme}-${width}`;const page=await pageFor('view=production',theme,width,width===390?844:1000);
  await page.getByRole('button',{name:'Пластик',exact:true}).click();await loaded(page);await actualProductionParent(page);
  const computedFields=[],keyboardFocus=[],formSaveReachability=[];
  await panel(page).getByRole('button',{name:'Добавить пластик',exact:true}).click();
  const stockColors=await themedFields(page,'stock');computedFields.push(stockColors);
  keyboardFocus.push(await keyboardFieldEntry(page,'stock','Добавить на склад, кг','15',stockColors.expected.accent));
  await (await field(page,'Резерв, кг')).fill('5');await noOverflow(page);formSaveReachability.push(await saveReachable(page,'stock'));await shot(page,`stock-form-${theme}-${width}`);
  await save(page);assert.equal(await total(page,'PLA'),15000);assert.equal((await state(page)).materials.PLA.reserveGrams,5000);
  await noOverflow(page);await page.locator('.productionPanel.panel').evaluate(element=>{element.scrollTop=0});await shot(page,`overview-${theme}-${width}`);
  await panel(page).getByRole('button',{name:'Добавить катушки',exact:true}).click();
  const spoolColors=await themedFields(page,'spools');computedFields.push(spoolColors);
  keyboardFocus.push(await keyboardFieldEntry(page,'spools','Вес пластика в одной катушке, кг','0,75',spoolColors.expected.accent));
  await (await field(page,'Название')).fill('Рабочая PLA чёрная');await (await field(page,'Откуда пластик')).selectOption('existing-stock');
  await noOverflow(page);formSaveReachability.push(await saveReachable(page,'spools'));await shot(page,`form-${theme}-${width}`);
  await save(page);assert.equal(await total(page,'PLA'),15000,'Production spool form counted existing stock twice');assert.equal((await state(page)).materials.PLA.looseGrams,14250);assert.equal((await state(page)).spools.length,1);
  await nativeBoundariesOnly(page);
  record('responsive-layout',{theme,width,noHorizontalOverflow:true,formControlsReachable:true,actualProductionParentVerified:true,themedFieldsVerified:true,stockAndSpoolFormsVerified:true,focusVisibleVerified:true,computedFields,keyboardFocus,formSaveReachability});await page.close();
 }
 assert.deepEqual(runtimeErrors,[],'Filament UI browser runtime errors');
 const result={passed:report.length,report,runtimeErrors,themes:['light','dark'],viewports:[390,910,1536],nativeBoundaryOnly:true,migrationPreserved:true,failedSavePreserved:true,notes:'Actual ProductionPanel/FilamentInventoryPanel, reducer and serialized persistence store. SQLite/desktop native boundary is deterministic; Rust tests validate the real atomic transaction. No physical printer consumption claim.'};
 if(shots)fs.writeFileSync(path.join(shots,'filament-inventory-r123-report.json'),JSON.stringify(result,null,2));
 console.log(JSON.stringify(result,null,2));
}catch(error){
 if(shots){fs.mkdirSync(shots,{recursive:true});try{if(currentPage&&!currentPage.isClosed())await currentPage.screenshot({path:path.join(shots,'filament-failure.png')})}catch{}
  fs.writeFileSync(path.join(shots,'filament-inventory-r123-failure.json'),JSON.stringify({case:currentCase,error:String(error.stack??error),report,runtimeErrors},null,2));}
 throw error;
}finally{await browser?.close();await new Promise(resolve=>server?server.close(resolve):resolve());fs.rmSync(out,{recursive:true,force:true})}
