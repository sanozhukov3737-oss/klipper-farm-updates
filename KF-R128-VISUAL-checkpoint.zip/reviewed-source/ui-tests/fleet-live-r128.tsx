// Actual production dashboard; all printers and stored data are synthetic.
import { useState } from 'react';
import { createRoot } from 'react-dom/client';
import { FleetDashboard } from '../src/components/FleetDashboard';
import { I18nProvider } from '../src/i18n';
import { setAuthSession } from '../src/lib/auth';
import { emptyFilamentInventory, reduceFilamentInventory, type FilamentCommand } from '../src/lib/filamentInventory';
import { updateFilamentInventory } from '../src/lib/filamentInventoryStore';
import type { PrinterModel, PrinterStatus, PrinterPreset } from '../src/types';
import '../src/styles.css';
const w = window as any, now = Date.now(), params = new URLSearchParams(location.search);
document.documentElement.dataset.theme = params.get('theme') || 'dark';
setAuthSession({ token: 'r128-fleet-fixture', user: { id: 'fixture', name: 'Оператор', role: 'admin', enabled: true, createdAt: 0 } });
const presets: PrinterPreset[] = ['ender3-v3-ke', 'ender3-v3-ke', 'ender3-v3-ke', 'ender3-v3-ke', 'creality-k1c-2025', 'creality-k1-max', 'flashforge-ad5m'];
const names = ['Ender-3 V3 KE · 01', 'Ender-3 V3 KE · 02', 'Ender-3 V3 KE · 03', 'Ender-3 V3 KE · 04', 'Creality K1C 2025', 'Creality K1 Max', 'Flashforge 5M'];
const initial: PrinterModel[] = presets.map((preset, index) => ({ id: `printer-${index + 1}`, name: names[index], nameSource: 'custom', host: `192.0.2.${index + 10}:7125`, webcams: [], profile: { preset, bedX: 220, bedY: 220, maxZ: 250, nozzle: .4, materials: ['PLA'] }, status: { state: 'printing', connectionState: 'online', filename: `calibration_${index + 1}.gcode`, progress: [.7, .1, .45, 0, .4, .9, .3][index], printDuration: 3600, nozzle: 215, nozzleTarget: 215, bed: 60, bedTarget: 60, currentLayer: 70, totalLayers: 100, telemetryUpdatedAt: now, jobUpdatedAt: now, lastSeen: now } }));
Object.assign(initial[2].status, { state: 'paused' });
Object.assign(initial[3].status, { state: 'ready', filename: '', printDuration: 0, nozzle: 26, bed: 25 });
Object.assign(initial[4].status, { state: 'error', message: 'Проверочный сбой печати' });
Object.assign(initial[5].status, { jobUpdatedAt: now - 40_000, telemetryUpdatedAt: now - 40_000 });
Object.assign(initial[6].status, { connectionState: 'offline', jobUpdatedAt: now - 180_000, telemetryUpdatedAt: now - 180_000, lastSeen: now - 180_000 });
let inventory = emptyFilamentInventory(now - 86400_000);
const apply = (command: FilamentCommand) => { inventory = reduceFilamentInventory(inventory, command, now).state; };
for (const [index, color, weight] of [[0, '#e7963b', 720], [1, '#60b5a7', 430], [5, '#bf7baa', 180]] as const) {
  apply({ type: 'add-spools', material: 'PLA', count: 1, weightGrams: 1000, color, source: 'purchase' });
  const spool = inventory.spools[inventory.spools.length - 1];
  apply({ type: 'edit-spool', spoolId: spool.id, remainingGrams: weight });
  apply({ type: 'bind-printer', printerId: initial[index].id, material: 'PLA', spoolId: spool.id });
}
const memory = new Map([['production.filamentInventory', JSON.stringify(inventory)]]);
w.__calls = []; w.__opened = [];
w.__TAURI_INTERNALS__ = { invoke: async (command: string, args: any) => {
  w.__calls.push({ command, key: args?.key });
  if (args.sessionToken !== 'r128-fleet-fixture') throw new Error('Unexpected fixture session');
  if (command === 'db_get_json') return memory.get(args.key) ?? null;
  if (command === 'filament_inventory_commit') { memory.set('production.filamentInventory', args.value); return null; }
  throw new Error('Unexpected fixture IPC: ' + command);
} };
w.__changeSpool = async () => updateFilamentInventory({ type: 'edit-spool', spoolId: inventory.spools[0].id, remainingGrams: 310, color: '#d34d6b' });
const clients = new Map();
function Fixture() {
  const [printers, setPrinters] = useState(initial);
  w.__patchPrinter = (id: string, patch: Partial<PrinterStatus>) => setPrinters(current => current.map(printer => printer.id === id ? { ...printer, status: { ...printer.status, ...patch } } : printer));
  w.__idleAll = () => setPrinters(current => current.map(printer => ({ ...printer, status: { ...printer.status, state: 'ready', connectionState: 'online', progress: 0, filename: '', printDuration: 0, jobUpdatedAt: Date.now(), telemetryUpdatedAt: Date.now() } })));
  return <div className="kfShell dashboardShell"><aside className="kfSidebar"><div className="kfBrand">KLIPPER FARM</div><nav>{['Панель', 'Принтеры', 'Инструменты', 'Очередь', 'Файлы', 'История', 'Настройки'].map((name, index) => <button key={name} className={index ? '' : 'active'}>{name}</button>)}</nav></aside><main className="kfMain dashboardMain"><header className="kfTopbar"><div className="kfPageIdentity"><h1>Панель фермы</h1><p>Семь принтеров · одна рабочая панель</p></div></header><FleetDashboard printers={printers} clients={clients} onOpen={id => w.__opened.push(id)} onPrinters={() => {}} onScan={() => {}} onReports={() => {}}/></main></div>;
}
createRoot(document.getElementById('root')!).render(<I18nProvider><Fixture/></I18nProvider>);
