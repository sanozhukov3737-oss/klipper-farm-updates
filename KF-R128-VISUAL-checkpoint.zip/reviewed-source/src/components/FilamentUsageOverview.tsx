import { useEffect, useId, useMemo, useState } from 'react';
import { BarChart3, CalendarDays } from 'lucide-react';
import type { FilamentInventory } from '../lib/filamentInventory';
import { filamentAnalytics, filamentUsageInPeriod } from '../lib/filamentAnalytics';
import type { PrinterModel } from '../types';
import styles from './FilamentInventoryPanel.module.css';

const weight = (grams: number) => grams >= 1000
  ? `${(grams / 1000).toLocaleString('ru-RU', { maximumFractionDigits: 2 })} кг`
  : `${grams.toLocaleString('ru-RU', { maximumFractionDigits: 1 })} г`;
const dateLabel = (at: number) => new Date(at).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' });
function sparkline(values: number[]) {
  const maximum = Math.max(1, ...values);
  return values.map((value, index) => `${index ? 'L' : 'M'}${4 + index / Math.max(1, values.length - 1) * 102},${40 - value / maximum * 32}`).join(' ');
}

export function FilamentUsageOverview({ inventory, printers }: { inventory: FilamentInventory; printers: PrinterModel[] }) {
  const [period, setPeriod] = useState<7 | 30>(7);
  const [now, setNow] = useState(Date.now());
  const [selectedDay, setSelectedDay] = useState('');
  const id = useId();
  useEffect(() => {
    const update = () => setNow(Date.now());
    const timer = window.setInterval(update, 60_000);
    window.addEventListener('focus', update);
    return () => { clearInterval(timer); window.removeEventListener('focus', update); };
  }, []);
  const analytics = useMemo(() => filamentAnalytics(inventory, now), [inventory, now]);
  const days = analytics.days.slice(-period);
  const maximum = Math.max(1, ...days.map(day => day.grams));
  const active = days.find(day => day.key === selectedDay) ?? days[days.length - 1];
  const printerUsage = filamentUsageInPeriod(inventory, days[0].key, days[days.length - 1].key);
  const ranked = Object.entries(printerUsage).filter(([, amount]) => amount > 0).sort((a, b) => b[1] - a[1]);
  const maxPrinter = Math.max(1, ...ranked.map(([, amount]) => amount));
  const dayMaterials = Object.entries((inventory.usageHistory?.days ?? []).filter(row => row.day === active.key).reduce<Record<string, number>>((sum, row) => {
    sum[row.material] = (sum[row.material] ?? 0) + row.manualGrams + row.calculatedGrams;
    return sum;
  }, {})).filter(([, amount]) => amount > 0);
  return <section className={styles.usageOverview} aria-label="Расход по дням">
    <div className={styles.usageStats}>
      {[['Сегодня', analytics.today, 7], ['За 7 дней', analytics.week, 7], ['За 30 дней', analytics.month, 30]].map(([name, grams, count]) => <div className={styles.usageStat} key={name}>
        <span><CalendarDays/>{name}</span><strong>{analytics.hasHistory ? weight(grams as number) : '—'}</strong>
        {analytics.hasHistory ? <svg className={styles.usageSparkline} viewBox="0 0 110 48" role="img" aria-label={`Динамика расхода за ${count} дней`}><path d={sparkline(analytics.days.slice(-(count as number)).map(day => day.grams))} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg> : <small>История появится после списания</small>}
      </div>)}
    </div>
    <div className={styles.usageLayout}>
      <div className={styles.dailyPanel}>
        <div className={styles.chartHeading}><h4><BarChart3/>Расход по дням</h4><div className={styles.periodButtons} role="group" aria-label="Период расхода">{([7, 30] as const).map(value => <button type="button" key={value} aria-pressed={period === value} onClick={() => setPeriod(value)}>{value} дней</button>)}</div></div>
        <div className={styles.chartScale}><span>граммы</span><span>{weight(maximum === 1 && days.every(day => !day.grams) ? 0 : maximum)}</span></div>
        <div className={styles.dayBars} style={{ gridTemplateColumns: `repeat(${period}, minmax(0, 1fr))` }} role="group" aria-label={`Списания за ${period} дней`}>
          {days.map(day => <button type="button" key={day.key} className={`${styles.dayButton} ${active.key === day.key ? styles.selectedDay : ''}`} aria-pressed={active.key === day.key} aria-describedby={`${id}-day`} aria-label={`${dateLabel(day.date)}: ${day.known ? weight(day.grams) : 'нет истории'}`} onClick={() => setSelectedDay(day.key)} onFocus={() => setSelectedDay(day.key)} onPointerEnter={event => { if (event.pointerType === 'mouse') setSelectedDay(day.key); }}>
            <span className={styles.barTrack}>{period === 7 && day.grams > 0 && <span className={styles.barValue}>{Math.round(day.grams)}</span>}<span className={styles.dayBar} style={{ height: `${day.grams / maximum * 100}%` }}/>{!day.known && <span className={styles.unknownDay}>·</span>}</span>
            {(period === 7 || day === days[0] || day === days[days.length - 1] || new Date(day.date).getDate() % 5 === 0) && <span className={styles.dayLabel}>{new Date(day.date).getDate()}</span>}
          </button>)}
        </div>
        <p className={styles.dayDetail} id={`${id}-day`} aria-live="polite">{dateLabel(active.date)} · {active.known ? weight(active.grams) : 'нет истории за этот день'}</p>
        {dayMaterials.length > 0 && <div className={styles.dayMaterials} aria-label="Материалы за выбранный день">{dayMaterials.map(([material, amount]) => <span key={material}>{material}<b>{weight(amount)}</b></span>)}</div>}
      </div>
      <div className={styles.rankingPanel}><h4>По принтерам · {period} дней</h4>{ranked.length ? ranked.map(([printerId, amount]) => <div className={styles.rankingRow} key={printerId}><div><span>{printers.find(printer => printer.id === printerId)?.name ?? 'Удалённый принтер'}</span><strong>{weight(amount)}</strong></div><div className={styles.usageTrack}><span style={{ width: `${amount / maxPrinter * 100}%` }}/></div></div>) : <p className={styles.hint}>За выбранный период списаний пока нет.</p>}</div>
    </div>
    <details className={styles.historyNote}><summary>Как считается расход</summary><p>{analytics.hasHistory ? 'Автоматический расход — на дату завершения печати, ручной — на дату записи. Текущая печать попадёт в расход после завершения.' : 'Разбивка по дням появится с первого нового списания.'}{analytics.legacyGrams > 0.001 && <> Ранее учтено без дневного журнала: {weight(analytics.legacyGrams)}; эта сумма сохранена в общих итогах.</>}</p></details>
  </section>;
}
