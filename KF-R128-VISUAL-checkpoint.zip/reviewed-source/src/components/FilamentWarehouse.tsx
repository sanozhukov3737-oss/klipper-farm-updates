import { useMemo, useState, type CSSProperties } from 'react';
import { ArrowUpRight, Check, PackagePlus, Pencil, Printer, QrCode, Search, Trash2, X } from 'lucide-react';
import type { PrinterModel, Spool } from '../types';
import type { FilamentInventory } from '../lib/filamentInventory';
import { normalizeFilamentMaterial } from '../lib/filamentInventory';
import { FilamentSpoolVisual } from './FilamentSpoolVisual';
import { SpoolQr } from './SpoolQr';
import styles from './FilamentWarehouse.module.css';

const weight = (grams: number) => grams >= 1000 ? `${(grams / 1000).toLocaleString('ru-RU', { maximumFractionDigits: 3 })} кг` : `${grams.toLocaleString('ru-RU', { maximumFractionDigits: 1 })} г`;
const fraction = (spool: Spool) => spool.remainingWeight / Math.max(spool.initialWeight, spool.remainingWeight, 1);
const colorStyle = (color?: string) => ({ '--filament-color': color && /^#[\da-f]{3}(?:[\da-f]{3})?$/i.test(color) ? color : '#9299a4' } as CSSProperties);
type Props = {
  inventory: FilamentInventory; printers: PrinterModel[]; canOperate: boolean; busy: boolean;
  onAdd: () => void; onEdit: (spool: Spool) => void; onAssign: (spool: Spool) => void; onRemove: (spool: Spool) => void;
};

export function FilamentWarehouse({ inventory, printers, canOperate, busy, onAdd, onEdit, onAssign, onRemove }: Props) {
  const [query, setQuery] = useState('');
  const [material, setMaterial] = useState('');
  const [location, setLocation] = useState('active');
  const [selectedId, setSelectedId] = useState('');
  const [qrId, setQrId] = useState('');
  const materials = [...new Set(inventory.spools.map(spool => normalizeFilamentMaterial(spool.material)))];
  const visible = useMemo(() => inventory.spools.filter(spool => {
    const term = query.trim().toLocaleLowerCase('ru-RU');
    const name = printers.find(printer => printer.id === spool.printerId)?.name ?? '';
    return (!material || normalizeFilamentMaterial(spool.material) === material)
      && (!term || `${spool.name} ${spool.material} ${spool.color ?? ''} ${name}`.toLocaleLowerCase('ru-RU').includes(term))
      && (location === 'all' || location === 'active' && spool.remainingWeight > 0 || location === 'shelf' && !spool.printerId && spool.remainingWeight > 0 || location === 'printer' && !!spool.printerId && spool.remainingWeight > 0 || location === 'low' && spool.remainingWeight > 0 && fraction(spool) <= .2 || location === 'empty' && spool.remainingWeight === 0);
  }), [inventory.spools, material, location, query, printers]);
  const selected = visible.find(spool => spool.id === selectedId) ?? visible[0];
  const activeCount = inventory.spools.filter(spool => spool.remainingWeight > 0).length;
  const reset = () => { setQuery(''); setMaterial(''); setLocation('active'); };
  return <section className={styles.warehouse} aria-label="Визуальный склад катушек">
    <div className={styles.boardHeading}><div><span className={styles.eyebrow}>ВАШ ПЛАСТИК</span><h4>Катушки <span>{activeCount}</span></h4></div><div className={styles.boardLegend}><span/><span>На принтере</span><i/>Нажмите на катушку</div></div>
    <div className={styles.filters}>
      <label className={styles.search}><Search aria-hidden="true"/><input aria-label="Найти катушку" placeholder="Название, цвет или принтер" value={query} onChange={event => setQuery(event.target.value)}/>{query && <button type="button" aria-label="Очистить поиск" onClick={() => setQuery('')}><X aria-hidden="true"/></button>}</label>
      <div className={styles.materialFilters} role="group" aria-label="Материал катушек">{['', ...materials].map(value => <button type="button" key={value} aria-pressed={material === value} onClick={() => setMaterial(value)}>{value || 'Все'}</button>)}</div>
      <select aria-label="Расположение катушек" value={location} onChange={event => setLocation(event.target.value)}><option value="active">С пластиком</option><option value="shelf">На складе</option><option value="printer">На принтерах</option><option value="low">Осталось ≤ 20%</option><option value="empty">Пустые</option><option value="all">Все катушки</option></select>
    </div>
    <div className={`${styles.workbench} ${!selected ? styles.noSelection : ''}`}>
      <div className={styles.shelf}>
        <div className={styles.spoolGrid} aria-label="Катушки на складе">
          {visible.map(spool => <button type="button" key={spool.id} className={styles.spoolCard} style={colorStyle(spool.color)} aria-pressed={selected?.id === spool.id} aria-controls="filament-selected-spool" aria-label={`Выбрать катушку ${spool.name}, ${spool.color || 'цвет не указан'}, ${weight(spool.remainingWeight)}`} data-testid={`filament-spool-${spool.id}`} onClick={() => setSelectedId(spool.id)}>
            <span className={styles.cardTop}><span className={spool.printerId ? styles.onPrinter : styles.onShelf}>{spool.printerId ? <><Printer aria-hidden="true"/>{printers.find(printer => printer.id === spool.printerId)?.name ?? 'На принтере'}</> : spool.material}</span><span className={styles.percentage}>{Math.round(fraction(spool) * 100)}%</span></span>
            <div className={styles.spoolStage}><FilamentSpoolVisual color={spool.color} fraction={fraction(spool)} label={`Катушка ${spool.name}`}/></div>
            <span className={styles.cardName}><i title={spool.color || 'Цвет не указан'}/><b>{spool.name}</b>{selected?.id === spool.id && <Check aria-hidden="true"/>}</span>
            <span className={styles.cardBottom}><strong>{weight(spool.remainingWeight)}</strong><span>из {weight(spool.initialWeight)}</span></span>
            <span className={styles.fillTrack}><span style={{ width: `${fraction(spool) * 100}%` }}/></span>
          </button>)}
          {!query && !material && location === 'active' && <button type="button" className={styles.addCard} onClick={onAdd} disabled={!canOperate || busy} aria-label="Новая катушка"><PackagePlus aria-hidden="true"/><b>Новая катушка</b><span>Цвет, вес и материал</span></button>}
        </div>
        {!visible.length && inventory.spools.length > 0 && <div className={styles.noResults}><Search aria-hidden="true"/><b>Катушки не найдены</b><p>Попробуйте другой цвет, материал или расположение.</p><button type="button" onClick={reset}>Сбросить фильтры</button></div>}
        {!inventory.spools.length && <p className={styles.emptyHint}>Добавьте катушки из уже учтённого запаса или оформите новую покупку.</p>}
        <div className={styles.shelfFooter}><span>Показано {visible.length} из {inventory.spools.length}</span><span>{weight(visible.reduce((sum, spool) => sum + spool.remainingWeight, 0))} на катушках</span></div>
      </div>
      {selected && <section id="filament-selected-spool" className={styles.inspector} style={colorStyle(selected.color)} aria-label="Выбранная катушка">
        <div className={styles.inspectorLabel}><span>ВЫБРАНА КАТУШКА</span><ArrowUpRight aria-hidden="true"/></div>
        <div className={styles.inspectorStage}><FilamentSpoolVisual color={selected.color} fraction={fraction(selected)} label={`Выбранная катушка ${selected.name}`}/></div>
        <div className={styles.inspectorName}><span>{selected.material}<i/>{selected.color ? selected.color.toUpperCase() : 'Цвет не указан'}</span><h4>{selected.name}</h4></div>
        <div className={styles.remaining}><strong>{weight(selected.remainingWeight)}</strong><span>осталось из {weight(selected.initialWeight)}</span></div>
        <div className={styles.inspectorMeter}><span style={{ width: `${fraction(selected) * 100}%` }}/></div>
        <div className={styles.inspectorMeta}><span>{selected.printerId ? <Printer aria-hidden="true"/> : <PackagePlus aria-hidden="true"/>}{selected.printerId ? printers.find(printer => printer.id === selected.printerId)?.name ?? 'Назначена принтеру' : 'На складе'}</span><b>{Math.round(fraction(selected) * 100)}%</b></div>
        {selected.remainingWeight === 0 && <p className={styles.emptyWarning}>Катушка закончилась</p>}
        {selected.price > 0 && <span className={styles.price}>Цена катушки · {selected.price.toLocaleString('ru-RU')} {selected.currency}</span>}
        <div className={styles.inspectorActions}>
          <button type="button" className={styles.editButton} disabled={!canOperate || busy} onClick={() => onEdit(selected)}><Pencil aria-hidden="true"/>Остаток и цвет</button>
          <button type="button" disabled={!canOperate || busy} onClick={() => onAssign(selected)}><Printer aria-hidden="true"/>{selected.printerId ? 'Сменить пластик' : 'Назначить принтеру'}</button>
          <div><button type="button" aria-expanded={qrId === selected.id} onClick={() => setQrId(qrId === selected.id ? '' : selected.id)}><QrCode aria-hidden="true"/>QR</button><button type="button" className={styles.deleteButton} aria-label={`Удалить катушку ${selected.name}`} disabled={!canOperate || busy} onClick={() => onRemove(selected)}><Trash2 aria-hidden="true"/></button></div>
        </div>
        {qrId === selected.id && <div className={styles.qr}><SpoolQr value={`klipper-spool://${selected.id}`} size={150}/><small>QR этой катушки</small></div>}
      </section>}
    </div>
  </section>;
}
