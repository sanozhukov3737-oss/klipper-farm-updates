import { useId, useMemo, useState } from 'react';
import { ArrowUpRight, Clock3, Printer } from 'lucide-react';
import type { PrinterModel } from '../types';
import { printerDisplayName } from '../lib/printerName';
import { finishDuration, finishTime, printerFinish } from '../lib/printerFinish';
import styles from './FarmFinishTimeline.module.css';

const colors = ['#5ca5fa', '#a08af7', '#42bbab', '#e8a44f', '#e37fa1', '#6bb4cd', '#b3bc62'];
export function FarmFinishTimeline({ printers, now, onOpen }: { printers: PrinterModel[]; now: number; onOpen: (id: string) => void }) {
  const [hours, setHours] = useState<4 | 12 | 24>(4);
  const titleId = useId();
  const rows = useMemo(() => printers.map((printer, index) => ({ printer, index, ...printerFinish(printer.status, now) })).filter(row => row.active).sort((a, b) => (a.finishAt ?? Infinity) - (b.finishAt ?? Infinity) || a.index - b.index), [printers, now]);
  const timed = rows.filter(row => row.finishAt !== undefined);
  const next = timed[0];
  const horizon = hours * 3600_000;
  return <section className={styles.timeline} aria-labelledby={titleId} data-testid="farm-finish-timeline">
    <header className={styles.header}><div><span className={styles.eyebrow}><Clock3 aria-hidden="true"/>ПЕЧАТЬ ВО ВРЕМЕНИ</span><h2 id={titleId}>Когда освободятся принтеры</h2></div><div className={styles.range} role="group" aria-label="Период шкалы окончания печати">{([4, 12, 24] as const).map(value => <button key={value} aria-pressed={hours === value} onClick={() => setHours(value)}>{value} ч</button>)}</div></header>
    {next && <div className={styles.next}><span className={styles.liveDot}/><span>Ближайшее окончание <b>{printerDisplayName(next.printer, next.index)}</b></span><strong>≈ {finishTime(next.finishAt!, now)}</strong></div>}
    {rows.length ? <>
      <div className={styles.axis} aria-hidden="true"><span>Сейчас</span><span>+{hours / 4} ч</span><span>+{hours / 2} ч</span><span>+{hours * .75} ч</span><span>+{hours} ч</span></div>
      <div className={styles.rows}>{rows.map(row => {
        const ratio = row.finishAt === undefined ? undefined : Math.max(0, Math.min(1, (row.finishAt - now) / horizon));
        const beyond = row.finishAt !== undefined && row.finishAt - now > horizon;
        const color = colors[row.index % colors.length];
        return <button key={row.printer.id} className={styles.row} data-testid={`finish-row-${row.printer.id}`} data-forecast={row.finishAt === undefined ? 'unavailable' : 'estimated'} aria-label={`Открыть ${printerDisplayName(row.printer, row.index)}: ${row.finishAt ? `окончание примерно ${finishTime(row.finishAt, now)}` : row.label}`} onClick={() => onOpen(row.printer.id)}>
          <span className={styles.printer}><i style={{ background: color }}/><b>{printerDisplayName(row.printer, row.index)}</b></span>
          <span className={styles.track} aria-hidden="true">{ratio === undefined ? <span className={styles.unknown}/> : <span className={styles.bar} style={{ width: `${Math.max(1.5, ratio * 100)}%`, background: color }}>{beyond ? <ArrowUpRight aria-hidden="true"/> : <i/>}</span>}</span>
          <span className={styles.ending}>{row.finishAt ? <><b>≈ {finishTime(row.finishAt, now)}</b><small>{beyond ? `за шкалой · ${finishDuration(row.remainingSeconds!)}` : `ещё ${finishDuration(row.remainingSeconds!)}`}</small></> : <b>{row.label}</b>}</span>
        </button>;
      })}</div>
      <p className={styles.note}>Примерное время по текущему темпу печати. Пауза и потеря свежих данных приостанавливают прогноз.</p>
    </> : <div className={styles.empty}><Printer aria-hidden="true"/><div><strong>Сейчас нет активных заданий</strong><span>Здесь появятся текущие задания и время их окончания.</span></div></div>}
  </section>;
}
