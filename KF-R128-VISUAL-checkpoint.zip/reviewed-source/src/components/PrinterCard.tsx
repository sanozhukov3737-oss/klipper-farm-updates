import { memo } from 'react';
import { Camera, ChevronRight, Clock3, FileCode2, Pause, RefreshCw, Settings2, Thermometer, Usb } from 'lucide-react';
import type { PrinterModel } from '../types';
import { printerDisplayName } from '../lib/printerName';
import { fallbackPrinterArtwork, printerArtwork } from '../lib/printerArtwork';
import { printerPresentationPreset } from '../lib/printerPresentation';
import { hasPrinterCamera } from './PrinterCamera';
import { printerConnectionReasonLabel, printerIsConnecting, printerIsReachable, printerWorkingChannel } from '../lib/printerHealth';
import { printerHasActiveJob } from '../lib/printerJob';
import { printerHostDisplay } from '../lib/printerEndpoint';
import { confirmedTemperature, jobFreshness, lastResponseLabel, telemetryFreshness, telemetryLabel } from '../lib/printerTelemetry';
import { useLiveNow } from '../lib/liveClock';
import { finishDuration, finishTime, printerFinish } from '../lib/printerFinish';

function PrinterCardView({p,index,onAction,onOpen,onCamera,onFiles,onSettings}:{p:PrinterModel;index:number;onAction:(id:string,a:string)=>void;onOpen:(id:string)=>void;onCamera:(id:string)=>void;onFiles:(id:string)=>void;onSettings?:(id:string)=>void}){
  const now=useLiveNow();
  const progress=Math.max(0,Math.min(100,Math.round((p.status.progress||0)*100)));
  const displayName=printerDisplayName(p,index-1);
  const remoteSuspended=!!p.status.remoteControlSuspended;
  const online=printerIsReachable(p.status),connecting=printerIsConnecting(p.status);
  const jobState=jobFreshness(p.status,now),jobConfirmed=jobState==='live'||jobState==='stale';
  const activeJob=jobConfirmed&&printerHasActiveJob(p.status),paused=jobConfirmed&&p.status.state==='paused';
  const telemetryState=telemetryFreshness(p.status,now);
  const finish=printerFinish(p.status,now);
  const tone=p.status.connectionState==='offline'||p.status.state==='error'?'danger':p.status.connectionState==='degraded'||connecting||paused?'warning':activeJob?'printing':'ready';
  const stateLabel=remoteSuspended?'Автономная печать':connecting?'Подключение':p.status.connectionState==='degraded'?printerConnectionReasonLabel(p.status):p.status.connectionState==='offline'?'Нет связи':p.status.state==='error'?printerConnectionReasonLabel(p.status):paused?'Пауза':activeJob?'Печатает':online?'Готов':'Нет связи';
  const connectionKind=remoteSuspended?'ЛОКАЛЬНО':'СВЯЗЬ';
  const channel=printerWorkingChannel(p.status);
  const presentationPreset=printerPresentationPreset(p);
  const modelShort=presentationPreset==='ender3-v3-ke'?'KE':presentationPreset==='ender3-v3-se'?'SE':presentationPreset==='creality-k1c-2025'?'K1C':presentationPreset==='creality-k1-max'?'K1 MAX':presentationPreset==='flashforge-ad5m'?'5M':'KLIPPER';
  return <article className={`printerManagerCard tone-${tone}`} onClick={()=>onOpen(p.id)}>
    <header className="printerManagerHead">
      <img src={printerArtwork(p)} alt={displayName} onError={event=>{event.currentTarget.src=fallbackPrinterArtwork}}/>
      <div className="printerManagerIdentity">
        <span>{modelShort} · {printerHostDisplay(p.host)}{channel&&<em className="printerManagerChannel">{channel}</em>}</span>
        <h2>{displayName}</h2>
        <small>{connectionKind} · {printerConnectionReasonLabel(p.status)} · {lastResponseLabel(p.status.lastSeen,now)}</small>
      </div>
      <span className={`printerManagerState ${tone}`}><i/>{stateLabel}</span>
    </header>

    <div className="printerManagerJob">
      <FileCode2/>
      <div><span>Текущее задание</span><b title={p.status.filename}>{remoteSuspended?'Печать выполняется принтером':!jobConfirmed?'Данные задания недоступны':p.status.filename||(online?'Нет активной печати':'Данные задания недоступны')}</b></div>
      <strong>{activeJob?`${progress}%`:'—'}</strong>
    </div>
    <div className="printerManagerProgress"><i style={{width:`${jobConfirmed?progress:0}%`}}/></div>

    <div className="printerManagerFacts">
      <span className={`telemetryAge ${telemetryState}`} title={finish.finishAt?`Окончание примерно ${finishTime(finish.finishAt,now)}`:finish.label}><Clock3/>{telemetryState==='live'?(activeJob?(finish.remainingSeconds!==undefined?`Осталось ≈ ${finishDuration(finish.remainingSeconds)}`:finish.label):'Живые данные'):telemetryLabel(p.status,now)}</span>
      <span><Thermometer/>Сопло <b>{confirmedTemperature(p.status.nozzle,p.status,now)}</b></span>
      <span><Thermometer/>Стол <b>{confirmedTemperature(p.status.bed,p.status,now)}</b></span>
    </div>

    <footer className="printerManagerActions">
      <button className="kfTelemetryFiles" title="Моя флешка — файлы G-code" aria-label={`Моя флешка: ${displayName}`} onClick={event=>{event.stopPropagation();onFiles(p.id)}}><Usb/><span>Моя флешка</span></button>
      {onSettings&&<button title="Настройки" onClick={event=>{event.stopPropagation();onSettings(p.id)}}><Settings2/><span>Настройки</span></button>}
      {hasPrinterCamera(p)&&<button title="Камера" onClick={event=>{event.stopPropagation();onCamera(p.id)}}><Camera/><span>Камера</span></button>}
      {activeJob&&!remoteSuspended&&<button title={paused?'Продолжить':'Пауза'} onClick={event=>{event.stopPropagation();onAction(p.id,paused?'resume':'pause')}}><Pause/><span>{paused?'Продолжить':'Пауза'}</span></button>}
      {!online&&!connecting&&!remoteSuspended&&<button title="Повторить подключение" onClick={event=>{event.stopPropagation();onAction(p.id,'reconnect')}}><RefreshCw/><span>Повторить</span></button>}
      <button className="primary" onClick={event=>{event.stopPropagation();onOpen(p.id)}}><span>Открыть</span><ChevronRight/></button>
    </footer>
  </article>;
}

export const PrinterCard=memo(PrinterCardView,(current,next)=>current.p===next.p&&current.index===next.index);
