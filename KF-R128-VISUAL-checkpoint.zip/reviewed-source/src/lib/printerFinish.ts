import type { PrinterStatus } from '../types';
import { printerHasActiveJob } from './printerJob';
import { jobFreshness } from './printerTelemetry';

export type PrinterFinish = { active: boolean; progress?: number; finishAt?: number; remainingSeconds?: number; label: string };

/** A projection from one confirmed sample, anchored to that sample's timestamp. */
export function printerFinish(status: PrinterStatus, now = Date.now()): PrinterFinish {
  const freshness = jobFreshness(status, now);
  const confirmed = freshness === 'live' || freshness === 'stale';
  const active = printerHasActiveJob(status);
  const progress = confirmed && Number.isFinite(status.progress) ? Math.max(0, Math.min(1, status.progress)) : undefined;
  const base = { active, progress };
  if (status.remoteControlSuspended) return { ...base, label: 'Автономная печать' };
  if (status.connectionState === 'offline' || status.state === 'offline') return { ...base, label: 'Нет связи' };
  if (status.connectionState === 'connecting') return { ...base, label: 'Подключение' };
  if (status.state === 'error') return { ...base, label: 'Ошибка печати' };
  if (status.connectionState === 'degraded') return { ...base, label: 'Проверяем связь' };
  if (freshness !== 'live') return { ...base, label: confirmed ? 'Данные устарели' : 'Ожидаем данные' };
  if (status.state === 'paused') return { ...base, label: 'Пауза · время уточнится' };
  if (!active) return { ...base, label: 'Готов к печати' };
  // Small percentages and warm-up time produce unstable extrapolations.
  if (status.connectionState !== 'online' || progress === undefined || progress < .02 || progress >= 1 || !Number.isFinite(status.printDuration) || status.printDuration < 30) {
    return { ...base, label: 'Рассчитываем время' };
  }
  const seconds = status.printDuration * (1 - progress) / progress;
  const sampleAt = status.jobUpdatedAt!;
  const finishAt = sampleAt + seconds * 1000;
  if (!Number.isFinite(finishAt) || sampleAt > now + 1000 || seconds > 7 * 86400 || finishAt <= now) return { ...base, label: 'Уточняем время' };
  return { ...base, finishAt, remainingSeconds: (finishAt - now) / 1000, label: 'Прогноз по текущему темпу' };
}

export function finishDuration(seconds: number) {
  const minutes = Math.max(1, Math.ceil(seconds / 60));
  return minutes >= 60 ? `${Math.floor(minutes / 60)} ч${minutes % 60 ? ` ${minutes % 60} мин` : ''}` : `${minutes} мин`;
}

export function finishTime(at: number, now = Date.now()) {
  const date = new Date(at), today = new Date(now), tomorrow = new Date(now);
  tomorrow.setDate(tomorrow.getDate() + 1);
  const sameDay = (a: Date, b: Date) => a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
  const time = date.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
  return sameDay(date, today) ? time : sameDay(date, tomorrow) ? `завтра, ${time}` : `${date.toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' })}, ${time}`;
}

export function printerLayerLabel(status: PrinterStatus, now = Date.now()) {
  if (!['live', 'stale'].includes(jobFreshness(status, now))) return undefined;
  const { currentLayer, totalLayers } = status;
  return Number.isInteger(currentLayer) && Number.isInteger(totalLayers) && currentLayer! >= 0 && totalLayers! > 0 && currentLayer! <= totalLayers!
    ? `Слой ${currentLayer} / ${totalLayers}` : undefined;
}
