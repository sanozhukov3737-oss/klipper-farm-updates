import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import http from 'node:http';
import crypto from 'node:crypto';
import {build} from './source/Klipper-Farm-R134/node_modules/vite/dist/node/index.js';

const work=import.meta.dirname,root=path.join(work,'source/Klipper-Farm-R134'),proof=path.join(work,'ui-proof');
const out=fs.mkdtempSync(path.join(os.tmpdir(),'kf-reference-frames-')),errors=[],report=[];
const reference=Object.fromEntries(['FilamentInventoryPanel.tsx','FilamentInventoryPanel.module.css','FilamentWarehouse.tsx','FilamentWarehouse.module.css'].map(n=>[path.join(root,'src/components',n),fs.readFileSync(path.join(work,'screenshot-reference',n),'utf8')]));
let browser,server;
try{
 for(const stage of ['reference','framed']){
  await build({root,base:`/${stage}/`,logLevel:'error',plugins:[{name:'reference-and-five-material-fixture',enforce:'pre',load(id){
   if(stage==='reference'&&reference[id])return reference[id];
   if(id===path.join(root,'ui-tests/filament-inventory-fixture.tsx')){
    let fixture=fs.readFileSync(id,'utf8');
    const anchor="  const spoolColors=['#ef9e32'";
    assert.ok(fixture.includes(anchor));
    fixture=fixture.replace(anchor,"  for(const [material,grams] of [['ASA',4000],['TPU',2000]] as const){apply({type:'add-stock',material,grams});apply({type:'add-spools',material,count:1,weightGrams:1000,color:'#33363b',source:'existing-stock'});}\n"+anchor);
    return fixture.replace("color:spoolColors[index]},now)","color:index===0?'#33363b':spoolColors[index]??'#33363b'},now)").replace('remainingGrams:spoolWeights[index]','remainingGrams:spoolWeights[index]??1000');
   }
  }}],build:{outDir:path.join(out,stage),emptyOutDir:true,rollupOptions:{input:path.join(root,'ui-tests/filament-inventory.html')}}});
 }
 server=http.createServer((req,res)=>{
  const file=path.resolve(out,new URL(req.url,'http://localhost').pathname.slice(1));
  if(!file.startsWith(out+path.sep)||!fs.existsSync(file)||!fs.statSync(file).isFile()){res.writeHead(404).end();return;}
  res.setHeader('Content-Type',({'.js':'text/javascript','.css':'text/css','.html':'text/html','.svg':'image/svg+xml','.webp':'image/webp','.png':'image/png'})[path.extname(file)]??'application/octet-stream');res.end(fs.readFileSync(file));
 });
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 const {chromium}=await import(process.env.PLAYWRIGHT_MODULE_PATH);
 browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_EXECUTABLE,args:['--no-sandbox','--disable-dev-shm-usage','--enable-unsafe-swiftshader']});
 for(const theme of ['dark','light']){
  let before;
  for(const stage of ['reference','framed']){
   const page=await browser.newPage({viewport:{width:1536,height:960},deviceScaleFactor:1.25,locale:'ru-RU'});
   page.on('pageerror',e=>errors.push(e.message));
   await page.goto(`http://127.0.0.1:${server.address().port}/${stage}/ui-tests/filament-inventory.html?seed=warehouse&view=production-page&theme=${theme}`);
   await page.waitForFunction(()=>document.querySelector('[data-testid="filament-3d-viewer"]')?.dataset.ready==='true',null,{timeout:60000});
   const geometry=await page.evaluate(()=>{
    const panel=document.querySelector('[aria-label="Запас и расход пластика"]'),selected=document.querySelector('[aria-label="Выбранная катушка"]'),viewer=document.querySelector('[data-testid="filament-3d-viewer"]');
    const rect=e=>{const r=e.getBoundingClientRect();return{x:r.x,y:r.y,width:r.width,height:r.height};};
    return {dpr:devicePixelRatio,panel:rect(panel),selected:rect(selected),viewer:rect(viewer),details:rect(selected.querySelector('h4').parentElement.parentElement),sidebar:rect(document.querySelector('.kfSidebar')),cards:[...document.querySelectorAll('[data-testid^="filament-material-"]')].map(rect),stockHeading:rect([...panel.querySelectorAll('h4')].find(e=>e.textContent==='Запас и резерв')),overflow:document.body.scrollWidth>innerWidth};
   });
   assert.equal(geometry.dpr,1.25);assert.equal(geometry.panel.width*geometry.dpr,1400);assert.equal(geometry.sidebar.width*geometry.dpr,255);assert.equal(geometry.overflow,false);assert.equal(geometry.cards.length,5);
   assert.ok(Math.abs(geometry.panel.x*geometry.dpr-387.5)<1);
   assert.ok(geometry.cards.slice(0,4).every(c=>c.y===geometry.cards[0].y));assert.ok(geometry.cards[4].y>geometry.cards[0].y);
   if(stage==='reference')before=geometry;
   else{
    assert.deepEqual({...geometry,panel:{...geometry.panel,height:0}},{...before,panel:{...before.panel,height:0}},'Frames must preserve exact original geometry at the user screenshot scale');
    assert.ok(geometry.panel.height<before.panel.height,'Removing the manual accounting block should shorten only the bottom of the page');
    const selected=page.getByRole('region',{name:'Выбранная катушка',exact:true}),stock=page.getByTestId('filament-stock-block');
    const top=await selected.evaluate(e=>{const s=getComputedStyle(e);return{border:s.borderTopStyle,radius:parseFloat(s.borderRadius),background:s.backgroundColor};});
    const lower=await stock.evaluate(e=>{const s=getComputedStyle(e);return{outline:s.outlineStyle,radius:parseFloat(s.borderRadius),background:s.backgroundColor};});
    assert.equal(top.border,'solid');assert.ok(top.radius>=14);assert.equal(lower.outline,'solid');assert.ok(lower.radius>=14);assert.equal(top.background,'rgba(0, 0, 0, 0)');assert.equal(lower.background,'rgba(0, 0, 0, 0)');
    assert.equal(await page.getByText('Расход по принтерам',{exact:true}).count(),0);
    assert.equal(await page.getByRole('button',{name:/Подтвердить расход|Расход вручную|Пропустить списание/}).count(),0);
    assert.equal(await page.evaluate(()=>window.__calls.filter(c=>c.command==='filament_inventory_commit').length),0);
   }
   await page.locator('main.kfMain').evaluate(e=>{e.scrollTop=50;});
   await page.screenshot({path:path.join(proof,stage==='framed'?`r135-plastic-${theme}.png`:`r134-reference-scale-${theme}.png`)});
   report.push({stage,theme,geometry,passed:true});console.log(`PASS ${stage} ${theme}: 1400px physical width, five materials, original geometry`);
   await page.close();
  }
 }
 assert.deepEqual(errors,[]);
 const result={passed:report.length,referenceArchive:'KF-R134-FULL.zip',referenceFiles:Object.fromEntries(Object.entries(reference).map(([n,s])=>[path.basename(n),crypto.createHash('sha256').update(s).digest('hex')])),sourceDimensionsChanged:false,viewport:{width:1536,height:960},deviceScaleFactor:1.25,pngSize:{width:1920,height:1200},syntheticInventory:true,manualConfirmationRemoved:true,report,runtimeErrors:errors};
 fs.writeFileSync(path.join(proof,'screenshot-scale-report.json'),JSON.stringify(result,null,2)+'\n');
 console.log(JSON.stringify({passed:report.length,runtimeErrors:errors,originalGeometryPreserved:true}));
}finally{
 await browser?.close();if(server){server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}fs.rmSync(out,{recursive:true,force:true});
}
