import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import {createHash} from 'node:crypto';
import {build} from './klipper-farm-r142-source/node_modules/vite/dist/node/index.js';
import {chromium} from '/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';

const root=path.resolve('klipper-farm-r142-source'),proof=path.resolve('r142-preview');
const baselineCss=fs.readFileSync(path.join(proof,'r141-styles.css'),'utf8');
const entries=['ui-tests/files-contrast-r139.html','ui-tests/r141-performance-app.html','ui-tests/r141-performance-tv.html'];
const builds={},errors=[],requests=[],visual=[];
let server,browser;
try {
  for(const version of ['r141','r142']) {
    const directory=path.join(proof,'builds',version);builds[version]=directory;
    await build({root,base:'./',logLevel:'error',publicDir:false,plugins:version==='r141'?[{name:'published-r141-css',enforce:'pre',transform(code,id){return path.normalize(id.split('?')[0])===path.join(root,'src/styles.css')?baselineCss:undefined;}}]:[],build:{outDir:directory,emptyOutDir:true,rollupOptions:{input:entries.map(name=>path.join(root,name))}}});
  }
  server=http.createServer((req,res)=>{
    const segments=new URL(req.url,'http://localhost').pathname.split('/').filter(Boolean);
    const directory=builds[segments[0]];
    let file=directory?path.resolve(directory,...segments.slice(1)):undefined;
    if(!file||!file.startsWith(directory+path.sep)||!fs.existsSync(file)||!fs.statSync(file).isFile()) {
      file=path.resolve(root,'public',...segments.slice(directory?1:0));
      if(!file.startsWith(path.join(root,'public')+path.sep)||!fs.existsSync(file)||!fs.statSync(file).isFile()) {res.writeHead(404).end();return;}
    }
    res.setHeader('Content-Type',({'.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png','.jpg':'image/jpeg','.svg':'image/svg+xml','.webp':'image/webp','.wasm':'application/wasm'})[path.extname(file)]||'application/octet-stream');
    res.end(fs.readFileSync(file));
  });
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const origin='http://127.0.0.1:'+server.address().port;
  browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_EXECUTABLE,args:['--no-sandbox','--disable-dev-shm-usage','--enable-unsafe-swiftshader']});
  const pageFor=async(viewport)=>{
    const context=await browser.newContext({viewport,locale:'ru-RU',reducedMotion:'reduce'}),page=await context.newPage();
    page.setDefaultTimeout(15000);page.on('pageerror',error=>errors.push(error.message));
    await page.route('**/*',route=>{
      const url=route.request().url();
      if(url.startsWith(origin+'/'))return route.continue();
      requests.push(url);return route.abort();
    });
    return {page,context};
  };
  const inspect=page=>page.evaluate(()=>{
    const selectors=['.printerFilesPanel','.printerFilesHead','.printerFilesSourceTabs','.printerFilesList','.printerFileCard','.printerFileThumb','.printerFileControls','.localLibraryHero','.localLibraryImport','.localLibraryToolbar','.localFolderCard','.localFileCard','.localFileThumb'];
    const geometry=selectors.flatMap(selector=>Array.from(document.querySelectorAll(selector)).map((el,index)=>{
      const r=el.getBoundingClientRect();return {selector,index,x:r.x,y:r.y,width:r.width,height:r.height,scrollWidth:el.scrollWidth,clientWidth:el.clientWidth};
    }));
    const sample=selector=>{const el=document.querySelector(selector);if(!el)return null;const s=getComputedStyle(el);return {background:s.backgroundColor,color:s.color,border:s.borderColor};};
    return {geometry,surfaces:{panel:sample('.printerFilesPanel'),header:sample('.printerFilesHead'),hero:sample('.localLibraryHero'),folder:sample('.localFolderCard'),file:sample('.localFileCard,.printerFileCard')},controls:Array.from(document.querySelectorAll('.printerFilesPanel button,.printerFilesPanel label.button')).map(el=>({text:el.textContent.trim(),disabled:el.disabled===true||el.getAttribute('aria-disabled')==='true'})),nativeCalls:window.__fileStyleFixture.calls};
  });
  for(const theme of ['dark','light'])for(const [width,height] of [[1920,1200],[910,640],[390,844]])for(const scenario of ['local','remote-cache']) {
    const pair={};
    for(const version of ['r141','r142']) {
      const {page,context}=await pageFor({width,height});
      await page.goto(origin+'/'+version+'/ui-tests/files-contrast-r139.html?theme='+theme+'&scenario='+scenario);
      await page.locator('.printerFileCard').first().waitFor();
      if(scenario==='local') {await page.getByRole('tab',{name:/Моя флешка/}).click();await page.locator('.localFileCard').first().waitFor();}
      await page.evaluate(()=>document.fonts.ready);
      await page.waitForFunction(()=>document.getAnimations().every(a=>a.constructor.name!=='CSSTransition'||a.playState!=='running'));
      pair[version]=await inspect(page);
      if((width===1920&&scenario==='local')||(version==='r142'&&theme==='dark'))await page.screenshot({path:path.join(proof,version+'-'+theme+'-'+scenario+'-'+width+'.png')});
      await context.close();
    }
    const deltas=pair.r141.geometry.flatMap((before,index)=>{
      const after=pair.r142.geometry[index];
      return !after?[{index,missing:true}]:['x','y','width','height'].flatMap(key=>Math.abs(before[key]-after[key])>1?[{selector:before.selector,index,key,before:before[key],after:after[key]}]:[]);
    });
    const overflow=pair.r142.geometry.filter(r=>r.x<-.5||r.x+r.width>width+.5||r.scrollWidth>r.clientWidth+2);
    visual.push({theme,width,height,scenario,geometryDeltas:deltas,overflow,controlsUnchanged:JSON.stringify(pair.r141.controls)===JSON.stringify(pair.r142.controls),before:pair.r141.surfaces,after:pair.r142.surfaces});
    console.log('Visual review '+theme+' '+width+' '+scenario+': '+deltas.length+' geometry changes, '+overflow.length+' overflow');
  }
  fs.writeFileSync(path.join(proof,'visual-review.json'),JSON.stringify({baseline:'published R141',baselineCssSha256:createHash('sha256').update(baselineCss).digest('hex'),cases:visual,runtimeErrors:errors,externalRequests:requests},null,2)+'\n');
  console.log('Visual review saved. Starting short resource measurements with synthetic printers.');
  const resource=[];
  for(const mode of ['app','tv']) {
    const {page,context}=await pageFor({width:1366,height:900});
    await page.goto(origin+'/r142/ui-tests/r141-performance-'+mode+'.html');
    if(mode==='app') {
      await page.locator('.infoPrinterGrid [data-testid^="live-printer-"]').nth(6).waitFor();
      await page.evaluate(()=>window.__farmStartup.releaseFresh());
    } else await page.locator('.tvSpotlightCamera[data-ready="true"] img').waitFor();
    const cdp=await context.newCDPSession(page);await cdp.send('Performance.enable');
    const samples=[];
    for(let i=0;i<=6;i++) {
      if(i)await new Promise(resolve=>setTimeout(resolve,15000));
      const values=Object.fromEntries((await cdp.send('Performance.getMetrics')).metrics.map(({name,value})=>[name,value]));
      samples.push({elapsedSeconds:i*15,jsHeapUsedBytes:values.JSHeapUsedSize,jsHeapTotalBytes:values.JSHeapTotalSize,taskDurationSeconds:values.TaskDuration,nodes:values.Nodes,documents:values.Documents,layoutCount:values.LayoutCount});
      if(i%2===0)console.log('Resource review '+mode+' '+i*15+'s: JS heap '+Math.round(values.JSHeapUsedSize/1024/1024)+' MiB');
    }
    const state=await page.evaluate(mode=>mode==='app'?{configuredPrinters:window.__farmStartup.state().database['printers.config'].length,unexpectedNativeCalls:window.__farmStartup.state().unexpected}: {cameraReady:document.querySelector('.tvSpotlightCamera')?.getAttribute('data-ready'),cardCount:document.querySelectorAll('.tvPrinter').length},mode);
    resource.push({mode,seconds:90,samples,state});await context.close();
  }
  fs.writeFileSync(path.join(proof,'resource-review.json'),JSON.stringify({scope:'Short headless Linux renderer measurement, 7 synthetic printers and a static local camera image. Not a long-duration Windows or physical-printer test. JS heap is not whole-process RAM. Synthetic fixture logging is included.',browser:browser.version(),resource,runtimeErrors:errors,externalRequests:requests,physicalPrintersTested:false,installedWindowsTested:false},null,2)+'\n');
  console.log('Resource review saved.');
} finally {await browser?.close();if(server)await new Promise(resolve=>server.close(resolve));}
