import type { PrinterModel } from '../types';

export const normalizeVoice=(value:string)=>value.normalize('NFKC').toLowerCase().replace(/ё/g,'е')
  .replace(/(?:кей|кэй|ка|к)\s*(?:один|1)\s*(?:си|с|c)/gu,'k1c')
  .replace(/(?:кей|кэй|ка|к)\s*(?:один|1)/gu,'k1')
  .replace(/(?:пять|5)\s*(?:эм|м|m)/gu,'5m')
  .replace(/макс(?:имум)?/gu,'max').replace(/к1с|к1c|k1с/gu,'k1c').replace(/к1/gu,'k1')
  .replace(/\.gcode$/u,'').replace(/[^\p{L}\p{N}]+/gu,' ').trim().replace(/\s+/g,' ');
export type VoiceIntent={kind:'confirm'|'cancel'|'help'|'printers'|'check'}|{kind:'choose';index:number}|{kind:'stock';query:string}|{kind:'find'|'print';query:string;printerHint:string};
export function parseVoiceCommand(value:string):VoiceIntent{
  const text=normalizeVoice(value).replace(/^(?:пожалуйста|помощник)\s+/u,'');
  const choice=text.match(/^(?:выбери|выбрать|вариант)\s+(?:вариант\s+)?(первый|второй|третий|четвертый|пятый|один|два|три|четыре|пять|\d+)$/u);
  if(choice){const numbers:Record<string,number>={первый:1,второй:2,третий:3,четвертый:4,пятый:5,один:1,два:2,три:3,четыре:4,пять:5};return{kind:'choose',index:(numbers[choice[1]]??Number(choice[1]))-1};}
  if(/^(?:подтверждаю печать|подтвердить печать|запускай печать)$/u.test(text))return{kind:'confirm'};
  if(/^(?:отмена|отмени|отменить|не печатай|нет)$/u.test(text))return{kind:'cancel'};
  if(/(?:проверь|проверить) (?:запуск|печать)/u.test(text))return{kind:'check'};
  if(/(?:пластик|филамент|катушк|запас)/u.test(text)&&/(?:сколько|остат|остал|запас)/u.test(text))return{kind:'stock',query:text};
  if(/(?:какие|кто|покажи|список|состояние).*(?:принтер|свобод|печата)/u.test(text))return{kind:'printers'};
  if(/^(?:найди|найти|поищи|покажи файл|напечатай|напечатать|напечатаю|распечатай|распечатать|распечатаю|печатай|печатать|поставь на печать|отправь на печать)\s/u.test(text)){
    const print=/(?:напечатай|напечатать|напечатаю|распечатай|распечатать|распечатаю|печатай|печатать|поставь на печать|отправь на печать|поставь.*печать)/u.test(text);
    const body=text.replace(/^(?:найди|найти|поищи|покажи файл|напечатай|напечатать|напечатаю|распечатай|распечатать|распечатаю|печатай|печатать|поставь на печать|отправь на печать)\s+/u,'').replace(/^файл\s+/u,'')
      .replace(/\s+(?:и\s+)?(?:поставь|отправь)\s+(?:его\s+)?на\s+печать/u,'')
      .replace(/\s+(?:и\s+)?(?:запусти|напечатай|печатай)(?:\s+его)?/u,'').trim();
    const tail=body.match(/\s+(?:на|для)\s+(?:принтер(?:е|а)?\s+)?(.+)$/u);
    const query=(tail?body.slice(0,tail.index):body).trim();
    return{kind:print?'print':'find',query,printerHint:tail?.[1]??''};
  }
  return{kind:'help'};
}
const aliases:Record<string,string[]>={
  'creality-k1-max':['k1 max','креалити k1 max','макс'],
  'creality-k1c-2025':['k1c','k1c 2025','креалити k1c'],
  'flashforge-ad5m':['5m','форж','флэшфордж','флешфордж','адвентурер 5m'],
  'ender3-v3-ke':['ке','эндер','эндер ке','эндер три ке'],
};
export function voicePrinterMatches(printers:PrinterModel[],hint:string){
  const query=normalizeVoice(hint);if(!query)return printers;
  return printers.filter(p=>[p.name,...(aliases[p.profile?.preset??'']??[])].some(name=>normalizeVoice(name)===query));
}
const transliteration:Record<string,string>={а:'a',б:'b',в:'v',г:'g',д:'d',е:'e',ж:'zh',з:'z',и:'i',й:'y',к:'k',л:'l',м:'m',н:'n',о:'o',п:'p',р:'r',с:'s',т:'t',у:'u',ф:'f',х:'h',ц:'ts',ч:'ch',ш:'sh',щ:'sch',ъ:'',ы:'y',ь:'',э:'e',ю:'yu',я:'ya'};
const searchable=(value:string)=>[...normalizeVoice(value)].map(c=>transliteration[c]??c).join('');
export function voiceFileMatches(path:string,query:string){
  const tokens=searchable(query).split(' ').filter(Boolean),name=searchable(path);
  return tokens.length>0&&tokens.every(token=>name.includes(token));
}
