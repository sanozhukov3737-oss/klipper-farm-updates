import type { Model,KaldiRecognizer } from 'vosk-browser';
export type ListeningState='idle'|'loading'|'listening'|'finishing';
export class OfflineSpeechInput{
  private model?:Model;
  private loading?:Promise<void>;
  private recognizer?:KaldiRecognizer;
  private stream?:MediaStream;
  private audio?:AudioContext;
  private capture?:AudioWorkletNode;
  private source?:MediaStreamAudioSourceNode;
  private timer?:ReturnType<typeof setTimeout>;
  private idleTimer?:ReturnType<typeof setTimeout>;
  private epoch=0;
  private delivered=false;
  private active=false;
  private disposed=false;
  constructor(private callbacks:{state:(state:ListeningState)=>void;partial:(text:string)=>void;text:(text:string,confidence:number)=>void;error:(text:string)=>void}){}
  async start(grammar?:string[]){
    if(this.disposed||this.active)return;
    const epoch=++this.epoch;this.active=true;this.delivered=false;
    clearTimeout(this.idleTimer);speechSynthesis.cancel();this.callbacks.partial('');this.callbacks.state('loading');
    try{
      if(!navigator.mediaDevices?.getUserMedia||!window.AudioWorkletNode)throw new Error('В этой среде недоступен микрофон. Откройте установленное приложение');
      this.audio=new AudioContext();await this.audio.resume();
      if(this.loading)await this.loading;
      if(!this.model){
        await import(/* @vite-ignore */ new URL('/voice/vosk-csp.js',location.href).href);
        const {Model}=(globalThis as typeof globalThis&{Vosk:typeof import('vosk-browser')}).Vosk;
        if(epoch!==this.epoch)return;
        const model=new Model(new URL('/voice/ru-small.tar.gz',location.href).href,-1);this.model=model;
        this.loading=new Promise<void>((resolve,reject)=>{
          const timer=setTimeout(()=>reject(new Error('Не удалось загрузить локальную речевую модель. Проверьте установку приложения')),60_000);
          model.on('load',message=>{clearTimeout(timer);if('result' in message&&message.result)resolve();else reject(new Error('Локальная речевая модель не загрузилась'))});
          model.on('error',message=>{clearTimeout(timer);reject(new Error('error' in message?message.error:'Ошибка локальной речевой модели'))});
        }).catch(error=>{model.terminate();if(this.model===model)this.model=undefined;throw error}).finally(()=>{this.loading=undefined});
        await this.loading;
      }
      if(epoch!==this.epoch||!this.audio)return;
      const stream=await navigator.mediaDevices.getUserMedia({video:false,audio:{echoCancellation:true,noiseSuppression:true,channelCount:1}});
      if(epoch!==this.epoch){stream.getTracks().forEach(t=>t.stop());return;}this.stream=stream;
      await this.audio.audioWorklet.addModule(new URL('/voice/capture.js',location.href).href);
      if(epoch!==this.epoch||!this.audio)return;
      const recognizer=new this.model!.KaldiRecognizer(this.audio.sampleRate,grammar?JSON.stringify([...grammar,'[unk]']):undefined);this.recognizer=recognizer;recognizer.setWords(true);
      recognizer.on('result',message=>{
        if(epoch!==this.epoch||!('result' in message)||!('text' in message.result))return;
        const text=message.result.text.trim();if(!text||this.delivered)return;
        this.delivered=true;
        const words=message.result.result??[],confidence=words.length?words.reduce((s,w)=>s+w.conf,0)/words.length:0;
        this.cleanup();this.callbacks.state('idle');this.callbacks.text(text,confidence);
      });
      recognizer.on('partialresult',message=>{if(epoch===this.epoch&&'result' in message&&'partial' in message.result)this.callbacks.partial(message.result.partial)});
      recognizer.on('error',message=>{if(epoch===this.epoch){this.cleanup();this.callbacks.state('idle');this.callbacks.error('error' in message?message.error:'Речь не распознана')}});
      this.source=this.audio.createMediaStreamSource(stream);this.capture=new AudioWorkletNode(this.audio,'farm-voice-capture');
      this.capture.port.onmessage=event=>{if(epoch===this.epoch&&this.recognizer&&this.audio)this.recognizer.acceptWaveformFloat(event.data,this.audio.sampleRate)};
      this.source.connect(this.capture);this.capture.connect(this.audio.destination);
      this.callbacks.state('listening');this.timer=setTimeout(()=>this.finish(),20_000);
    }catch(error){if(epoch===this.epoch){this.cleanup();this.callbacks.state('idle');const denied=error instanceof DOMException&&error.name==='NotAllowedError';this.callbacks.error(denied?'Нет доступа к микрофону. Разрешите его в настройках конфиденциальности Windows.':error instanceof Error?error.message:String(error))}}
  }
  finish(){
    if(!this.active)return;
    if(!this.recognizer){this.cancel();return;}
    clearTimeout(this.timer);this.callbacks.state('finishing');this.stream?.getTracks().forEach(t=>t.stop());this.recognizer.retrieveFinalResult();
    this.timer=setTimeout(()=>{if(!this.delivered){this.cancel();this.callbacks.error('Речь не распознана. Нажмите микрофон и повторите команду')}},2000);
  }
  cancel(){this.epoch++;this.cleanup();this.callbacks.state('idle');}
  private cleanup(){
    clearTimeout(this.timer);this.capture?.disconnect();this.source?.disconnect();this.stream?.getTracks().forEach(t=>t.stop());
    this.capture=undefined;this.source=undefined;this.stream=undefined;
    this.recognizer?.remove();this.recognizer=undefined;
    if(this.audio)void this.audio.close().catch(()=>{});this.audio=undefined;this.active=false;
    clearTimeout(this.idleTimer);this.idleTimer=setTimeout(()=>{this.model?.terminate();this.model=undefined},30_000);
  }
  dispose(){this.disposed=true;this.cancel();clearTimeout(this.idleTimer);this.model?.terminate();this.model=undefined;}
}
export function offlineRussianVoice(){return window.speechSynthesis?.getVoices().find(voice=>voice.localService&&/^ru(?:-|_)/i.test(voice.lang));}
export function speakOffline(text:string){
  const voice=offlineRussianVoice();if(!voice)return false;
  speechSynthesis.cancel();const utterance=new SpeechSynthesisUtterance(text);utterance.voice=voice;utterance.lang=voice.lang;utterance.rate=1;
  speechSynthesis.speak(utterance);return true;
}
