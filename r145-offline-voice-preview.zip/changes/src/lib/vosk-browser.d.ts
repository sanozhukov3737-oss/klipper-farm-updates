declare module 'vosk-browser' {
  export { Model, createModel, type KaldiRecognizer } from 'vosk-browser/dist/model';
}
