import { analyzeGCodeByteChunks } from './gcodeAnalysis';
import { localLibraryReadBegin, localLibraryReadChunk, localLibraryReadAbort } from './native';
const ensureActive=(signal?:AbortSignal)=>{if(signal?.aborted)throw new DOMException('Операция отменена','AbortError')};

export const analyzeLocalFile=async(printerId:string,relativePath:string,signal?:AbortSignal)=>{
  ensureActive(signal);
  const started=await localLibraryReadBegin(printerId,relativePath);
  let offset=0,finished=false,sha256='';
  const chunks=async function*(){
    while(!finished){
      ensureActive(signal);
      const chunk=await localLibraryReadChunk(started.readId,offset);
      if(chunk.nextOffset<=offset||chunk.nextOffset>started.size)throw new Error('Нарушен порядок чтения локального G-code');
      offset=chunk.nextOffset;
      if(chunk.data.length)yield Uint8Array.from(chunk.data);
      if(chunk.done){
        if(offset!==started.size||!chunk.sha256)throw new Error('Локальный G-code прочитан не полностью');
        sha256=chunk.sha256;
        finished=true;
      }
    }
  };
  try{
    const analysis=await analyzeGCodeByteChunks(chunks(),signal);
    if(!finished||!sha256)throw new Error('Проверка локального G-code не завершена');
    return{analysis,sha256};
  }finally{if(!finished)await localLibraryReadAbort(started.readId).catch(()=>false)}
};
