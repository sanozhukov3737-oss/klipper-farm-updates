import { useCallback, useEffect, useMemo, useRef, useState, type ChangeEvent } from 'react';
import {
  CheckCircle2,
  ChevronRight,
  Clock3,
  Database,
  FileCode2,
  Folder,
  FolderOpen,
  HardDrive,
  Home,
  ListPlus,
  Play,
  RefreshCw,
  Search,
  ShieldAlert,
  ShieldCheck,
  Trash2,
  Upload,
  Usb,
  X,
} from 'lucide-react';
import type { MoonrakerClient } from '../lib/moonraker';
import type { PrinterModel } from '../types';
import { printStartOptionsFromValidation, validateGCodeAnalysis, type GCodeValidation } from '../lib/gcodeValidation';
import { analyzeLocalFile } from '../lib/localGCodeAnalysis';
import {
  localLibraryDelete,
  localLibraryDeleteDirectory,
  localLibraryAdoptLegacy,
  localLibraryImportAbort,
  localLibraryImportBegin,
  localLibraryImportChunk,
  localLibraryImportFinish,
  localLibraryList,
  localLibraryMergeScopes,
  type LocalLibraryEntry,
} from '../lib/native';
import { audit } from '../lib/db';
import { uncertainPrintStart } from '../lib/printStartConfirmation';
import { diagnosticWarning } from '../lib/diagnosticLog';
import { useModalAccessibility } from '../lib/modalAccessibility';
import { useLiveNow } from '../lib/liveClock';
import type { LocalTransferProgress } from '../lib/localLibraryTransfer';
import { assertModelDependentOperationAllowed, modelDependentOperationsBlocked } from '../lib/modelSafety';
import { printerDisplayName } from '../lib/printerName';
import { LocalGCodeThumbnail } from './LocalGCodeThumbnail';
import { fileNameCollator, ListPagination, usePagedRows } from './ListPagination';

type LocalAction={kind:'start'|'queue'|'blocked'|'delete';entry:LocalLibraryEntry;report?:GCodeValidation;sha256?:string;targetKey?:string};
type ImportProgress={done:number;total:number;stored:number;skipped:number;current:string};
type FolderDelete={path:string;name:string;files:number;size:number};
type PendingLocalLaunch={path:string;scopeId:string;printerId:string;host:string;targetKey:string};

// Refreshing detection evidence does not change a validated print target.
// Keep the operational profile and model safety decisions in the guard.
const targetKey=(printer:PrinterModel)=>JSON.stringify([printer.id,printer.host,printer.profile,{
  mode:printer.modelSelection?.mode,
  selectedPreset:printer.modelSelection?.selectedPreset,
  confirmationRequired:printer.modelSelection?.confirmationRequired,
  pendingPreset:printer.modelSelection?.pendingPreset,
  blocked:modelDependentOperationsBlocked(printer),
}]);
const MAX_IMPORT_FILES=5_000;
const MAX_FILE_SIZE=100*1024*1024;
const leafName=(path:string)=>path.split('/').filter(Boolean).at(-1)??path;
const parentPath=(path:string)=>path.split('/').slice(0,-1).join('/');
const filesLabel=(value:number)=>{
  const lastTwo=value%100,last=value%10;
  return lastTwo>=11&&lastTwo<=14?'файлов':last===1?'файл':last>=2&&last<=4?'файла':'файлов';
};
const bytes=(value:number)=>{
  if(value<1024)return `${value} Б`;
  if(value<1024*1024)return `${(value/1024).toFixed(1)} КБ`;
  if(value<1024*1024*1024)return `${(value/1024/1024).toFixed(1)} МБ`;
  return `${(value/1024/1024/1024).toFixed(2)} ГБ`;
};
const date=(value?:number)=>value?new Date(value).toLocaleString('ru-RU'):'дата не указана';

const abortError=(message='Операция отменена')=>{const error=new Error(message);error.name='AbortError';return error};
const ensureActive=(signal?:AbortSignal)=>{if(signal?.aborted)throw abortError()};

const importLocalFile=async(printerId:string,relativePath:string,file:File,overwrite:boolean,signal?:AbortSignal)=>{
  ensureActive(signal);
  const started=await localLibraryImportBegin(printerId,relativePath,file.size,overwrite);
  if(started.result)return started.result;
  if(!started.importId)throw new Error('Локальный импорт не создал сессию передачи');
  const chunkSize=Math.max(64*1024,Math.min(512*1024,Math.trunc(started.chunkSize)||512*1024));
  let offset=0,finished=false;
  try{
    while(offset<file.size){
      ensureActive(signal);
      const end=Math.min(file.size,offset+chunkSize);
      const data=Array.from(new Uint8Array(await file.slice(offset,end).arrayBuffer()));
      ensureActive(signal);
      const received=await localLibraryImportChunk(started.importId,offset,data);
      if(received!==end)throw new Error('Локальное хранилище подтвердило неверный размер блока');
      offset=end;
    }
    const result=await localLibraryImportFinish(started.importId);
    finished=true;
    return result;
  }finally{if(!finished)await localLibraryImportAbort(started.importId).catch(()=>false)}
};


function LocalTransferStatus({transfer,launching,cancelRequested,queue,cancel}:{transfer:LocalTransferProgress&{startedAt:number};launching:boolean;cancelRequested:boolean;queue:boolean;cancel:()=>void}){
  const now=useLiveNow();
  return <div className="printerFileTransfer" role="status" aria-live="polite">
    <div><RefreshCw className="spin"/><strong>{cancelRequested?'Действие отменено. Ожидаем завершения передачи…':launching?(queue?'Добавляем в очередь…':'Ожидаем подтверждения запуска…'):transfer.phase==='preparing'?'Подготавливаем файл…':'Передаём проверенный файл на принтер…'}</strong><span>{Math.max(0,Math.floor((now-transfer.startedAt)/1000))} с</span></div>
    {!cancelRequested&&!launching&&transfer.phase==='preparing'&&<><progress max={transfer.total} value={transfer.done}/><small>{bytes(transfer.done)} / {bytes(transfer.total)}</small></>}
    {!launching&&transfer.phase==='sending'&&<small>Передачу файла нельзя прервать. Отмена запретит {queue?'добавление в очередь':'запуск печати'} после её завершения.</small>}
    {!launching&&<button type="button" disabled={cancelRequested} onClick={cancel}><X/>{cancelRequested?'Отмена запрошена':'Отменить действие'}</button>}
  </div>;
}

export function LocalLibraryPanel({
  printer,
  libraryScopeId,
  libraryScopeLabel,
  librarySharedByModel,
  sourcePrinterIds,
  client,
  canOperate,
  canSync,
  onPrinted,
}:{
  printer:PrinterModel;
  libraryScopeId:string;
  libraryScopeLabel:string;
  librarySharedByModel:boolean;
  sourcePrinterIds:string[];
  client?:MoonrakerClient;
  canOperate:boolean;
  canSync:boolean;
  onPrinted:()=>void;
}){
  const printerRef=useRef(printer);printerRef.current=printer;
  const printTargetKey=targetKey(printer);
  const permissionsRef=useRef({canOperate,canSync});permissionsRef.current={canOperate,canSync};
  const [transfer,setTransfer]=useState<(LocalTransferProgress&{startedAt:number})|undefined>();
  const [launching,setLaunching]=useState(false);
  const [cancelRequested,setCancelRequested]=useState(false);
  const [launchUnconfirmed,setLaunchUnconfirmed]=useState(false);
  const [pendingLaunch,setPendingLaunch]=useState<PendingLocalLaunch>();
  const pendingLaunchRef=useRef<PendingLocalLaunch>();
  const launchQueryRef=useRef<object>();
  const launchEpoch=useRef(0);
  const clientRef=useRef(client);clientRef.current=client;
  const [recoveringLaunch,setRecoveringLaunch]=useState(false);
  const [checkingLaunch,setCheckingLaunch]=useState(false);
  const cancelTransfer=()=>{if(launching||!operationAbort.current)return;setCancelRequested(true);operationAbort.current.abort('Передача отменена пользователем')};
  const [entries,setEntries]=useState<LocalLibraryEntry[]>([]);
  const [legacy,setLegacy]=useState({files:0,size:0});
  const [folder,setFolder]=useState('');
  const [query,setQuery]=useState('');
  const [busy,setBusy]=useState(false);
  const [error,setError]=useState('');
  const [notice,setNotice]=useState('');
  const [overwrite,setOverwrite]=useState(false);
  const [importProgress,setImportProgress]=useState<ImportProgress>();
  const [action,setAction]=useState<LocalAction>();
  const [folderDelete,setFolderDelete]=useState<FolderDelete>();
  const [operation,setOperation]=useState<'import'|'analysis'|'upload'>();
  const operationAbort=useRef<AbortController>();
  const refreshRequest=useRef(0);
  const libraryRef=useRef<HTMLDivElement>(null);
  const scopeIdRef=useRef(libraryScopeId);
  scopeIdRef.current=libraryScopeId;
  const sourceScopeKey=sourcePrinterIds.join('|');
  useModalAccessibility(()=>{if(busy){if(operation==='upload')cancelTransfer();return}closeAction();setFolderDelete(undefined)},'.localLibrary .printerFileDialog','Действие с локальным файлом',!!action||!!folderDelete);

  const loadScope=useCallback(async(migrate=false)=>{
    const scopeId=libraryScopeId;
    const request=++refreshRequest.current;
    setBusy(true);
    setError('');
    let migrationError='';
    try{
      if(migrate&&canOperate&&librarySharedByModel){
        try{
          const sourceIds=sourcePrinterIds.filter(id=>id!==scopeId);
          if(sourceIds.length){
            const merged=await localLibraryMergeScopes(sourceIds,scopeId);
            if(request!==refreshRequest.current||scopeId!==scopeIdRef.current)return;
            if(merged.moved||merged.duplicates){
              const renamed=merged.renamed?` Из-за совпадающих имён ${merged.renamed} ${filesLabel(merged.renamed)} помещено в папку «Объединено из другого принтера».`:'';
              setNotice(`Старые библиотеки принтеров ${libraryScopeLabel} объединены: ${merged.moved} перенесено, ${merged.duplicates} дублей убрано.${renamed}`);
            }
            if(merged.conflicts)migrationError=`Не удалось безопасно объединить ${merged.conflicts} ${filesLabel(merged.conflicts)}. Они оставлены в прежних каталогах без удаления.`;
          }
        }catch(value){migrationError=`Общая библиотека открыта, но перенос старых файлов не завершён: ${String(value instanceof Error?value.message:value)}`}
      }
      const result=await localLibraryList(scopeId);
      if(request!==refreshRequest.current||scopeId!==scopeIdRef.current)return;
      setEntries(result.files);
      setLegacy({files:result.legacyFiles,size:result.legacySize});
      if(migrationError)setError(migrationError);
    }
    catch(value){if(request===refreshRequest.current&&scopeId===scopeIdRef.current)setError(String(value instanceof Error?value.message:value))}
    finally{if(request===refreshRequest.current&&scopeId===scopeIdRef.current)setBusy(false)}
  },[libraryScopeId,libraryScopeLabel,librarySharedByModel,sourceScopeKey,canOperate]);

  const refresh=useCallback(()=>loadScope(false),[loadScope]);

  useEffect(()=>{
    launchEpoch.current++;pendingLaunchRef.current=undefined;launchQueryRef.current=undefined;
    operationAbort.current?.abort('Смена локальной библиотеки');
    refreshRequest.current++;
    setEntries([]);setLegacy({files:0,size:0});setFolder('');setQuery('');setBusy(false);setError('');setNotice('');setAction(undefined);setFolderDelete(undefined);setImportProgress(undefined);setTransfer(undefined);setLaunching(false);setCancelRequested(false);setLaunchUnconfirmed(false);setPendingLaunch(undefined);setRecoveringLaunch(false);setCheckingLaunch(false);
    return()=>{launchEpoch.current++;operationAbort.current?.abort('Локальная библиотека закрыта');refreshRequest.current++};
  },[libraryScopeId,printer.id,printer.host,client]);
  useEffect(()=>{void loadScope(true)},[loadScope]);

  const folderRows=useMemo(()=>{
    if(query.trim())return [];
    const prefix=folder?`${folder}/`:'';
    const map=new Map<string,{path:string;name:string;files:number;size:number}>();
    for(const entry of entries){
      if(!entry.path.startsWith(prefix))continue;
      const rest=entry.path.slice(prefix.length),separator=rest.indexOf('/');
      if(separator<0)continue;
      const name=rest.slice(0,separator),path=prefix+name,current=map.get(path)??{path,name,files:0,size:0};
      current.files++;current.size+=entry.size;map.set(path,current);
    }
    return [...map.values()].sort((left,right)=>fileNameCollator.compare(left.name,right.name));
  },[entries,folder,query]);

  const visibleFiles=useMemo(()=>{
    const search=query.trim().toLowerCase(),prefix=folder?`${folder}/`:'';
    return entries.filter(entry=>{
      if(search)return entry.path.toLowerCase().includes(search);
      if(!entry.path.startsWith(prefix))return false;
      return !entry.path.slice(prefix.length).includes('/');
    }).sort((left,right)=>fileNameCollator.compare(leafName(left.path),leafName(right.path)));
  },[entries,folder,query]);
  const browserRows=useMemo(()=>[
    ...folderRows.map(folder=>({kind:'folder' as const,folder})),
    ...visibleFiles.map(file=>({kind:'file' as const,file})),
  ],[folderRows,visibleFiles]);
  const browserPage=usePagedRows(browserRows,JSON.stringify([libraryScopeId,folder,query]));

  const breadcrumbs=useMemo(()=>{
    const output:Array<{name:string;path:string}>=[];
    let current='';
    for(const segment of folder.split('/').filter(Boolean)){
      current=current?`${current}/${segment}`:segment;
      output.push({name:segment,path:current});
    }
    return output;
  },[folder]);

  const totalSize=useMemo(()=>entries.reduce((sum,entry)=>sum+entry.size,0),[entries]);
  const totalFolders=useMemo(()=>new Set(entries.flatMap(entry=>{
    const parts=entry.path.split('/').slice(0,-1),paths:string[]=[];
    for(let index=1;index<=parts.length;index++)paths.push(parts.slice(0,index).join('/'));
    return paths;
  })).size,[entries]);

  const importSelection=async(files:File[],mode:'folder'|'file')=>{
    if(!canOperate||busy)return;
    const scopeId=libraryScopeId;
    const accepted=files.filter(file=>/\.(?:gcode|gco)$/i.test(file.name));
    const oversized=accepted.filter(file=>file.size===0||file.size>MAX_FILE_SIZE);
    if(accepted.length>MAX_IMPORT_FILES){setError(`В одной операции можно импортировать не более ${MAX_IMPORT_FILES} G-code файлов.`);return}
    if(oversized.length){setError(`${oversized.length} файлов пустые или превышают лимит 100 MiB. Импорт отменён — исправьте набор и повторите.`);return}
    if(!accepted.length){setError(mode==='folder'?'В выбранной папке нет файлов .gcode или .gco.':'Выберите один файл .gcode или .gco.');return}
    setBusy(true);setError('');setNotice('');
    const controller=new AbortController();operationAbort.current=controller;setOperation('import');
    let stored=0,skipped=0,done=0;
    setImportProgress({done,total:accepted.length,stored,skipped,current:''});
    try{
      for(const file of accepted){
        if(scopeId!==scopeIdRef.current)return;
        const relativePath=mode==='file'?(folder?`${folder}/${file.name}`:file.name):(file.webkitRelativePath||file.name);
        setImportProgress({done,total:accepted.length,stored,skipped,current:relativePath});
        const result=await importLocalFile(scopeId,relativePath,file,overwrite,controller.signal);
        if(scopeId!==scopeIdRef.current)return;
        if(result.status==='skipped')skipped++;else stored++;
        done++;
        setImportProgress({done,total:accepted.length,stored,skipped,current:relativePath});
      }
      await audit(mode==='folder'?'local_library.folder_import':'local_library.file_import',`${printer.name} · ${stored} сохранено · ${skipped} пропущено`);
      if(scopeId!==scopeIdRef.current)return;
      await refresh();
      if(scopeId!==scopeIdRef.current)return;
      setNotice(mode==='folder'
        ?`Импорт завершён: ${stored} сохранено, ${skipped} совпадений пропущено. Структура папок сохранена и доступна офлайн.`
        :`${stored?'Файл сохранён':'Совпадающий файл пропущен'} в «${folder||'Моя флешка'}» для ${libraryScopeLabel}.`);
    }catch(value){if(scopeId===scopeIdRef.current)setError(value instanceof Error&&value.name==='AbortError'?`Импорт отменён после ${done} из ${accepted.length}.`:`Импорт остановлен после ${done} из ${accepted.length}: ${String(value instanceof Error?value.message:value)}`)}
    finally{if(operationAbort.current===controller)operationAbort.current=undefined;if(scopeId===scopeIdRef.current){setOperation(undefined);setBusy(false);window.setTimeout(()=>setImportProgress(undefined),1200)}}
  };

  const chooseFolder=(event:ChangeEvent<HTMLInputElement>)=>{
    const selected=Array.from(event.currentTarget.files??[]);
    event.currentTarget.value='';
    void importSelection(selected,'folder');
  };

  const chooseFile=(event:ChangeEvent<HTMLInputElement>)=>{
    const selected=Array.from(event.currentTarget.files??[]).slice(0,1);
    event.currentTarget.value='';
    void importSelection(selected,'file');
  };

  const prepare=async(entry:LocalLibraryEntry,kind:'start'|'queue')=>{
    if(!canOperate||!client||!canSync||busy||operationAbort.current)return;
    const scopeId=libraryScopeId;
    setBusy(true);setError('');setNotice('');
    const controller=new AbortController();operationAbort.current=controller;setOperation('analysis');
    try{
      const {analysis,sha256}=await analyzeLocalFile(scopeId,entry.path,controller.signal);
      if(scopeId!==scopeIdRef.current)return;
      const report=validateGCodeAnalysis(printer,entry.path,analysis);
      if(!report.ok)await audit('local_library.preflight_blocked',`${entry.path} → ${printer.name}`);
      if(scopeId!==scopeIdRef.current)return;
      ensureActive(controller.signal);
      setLaunchUnconfirmed(false);
      pendingLaunchRef.current=undefined;
      setPendingLaunch(undefined);
      setAction({kind:report.ok?kind:'blocked',entry,report,sha256,targetKey:targetKey(printer)});
    }catch(value){if(scopeId===scopeIdRef.current)setError(value instanceof Error&&value.name==='AbortError'?'Проверка G-code отменена пользователем.':`Полная проверка не выполнена: ${String(value instanceof Error?value.message:value)}`)}
    finally{if(operationAbort.current===controller)operationAbort.current=undefined;if(scopeId===scopeIdRef.current){setOperation(undefined);setBusy(false)}}
  };

  const confirmAction=async()=>{
    const current=action;
    if(!current||current.kind==='blocked'||!canOperate||busy||operationAbort.current||launchUnconfirmed)return;
    const scopeId=libraryScopeId;
    setBusy(true);setError('');setCancelRequested(false);setLaunching(false);
    const controller=new AbortController();operationAbort.current=controller;
    const epoch=launchEpoch.current,printerId=printer.id,host=printer.host;
    const stillCurrent=()=>launchEpoch.current===epoch&&operationAbort.current===controller&&scopeId===scopeIdRef.current&&clientRef.current===client&&printerRef.current.id===printerId&&printerRef.current.host===host;
    let commandSent=false;
    const ensureTarget=()=>{
      ensureActive(controller.signal);
      if(scopeId!==scopeIdRef.current||current.targetKey!==targetKey(printerRef.current))throw new Error('Принтер или его настройки изменились. Проверьте файл заново');
      if(!permissionsRef.current.canOperate||!permissionsRef.current.canSync)throw new Error('Связь с принтером потеряна. Файл остаётся в библиотеке');
      if(current.kind==='start'&&(printerRef.current.status.state!=='ready'||printerRef.current.status.connectionState!=='online'))throw new Error('Принтер больше не готов к запуску. Файл остаётся в библиотеке');
      assertModelDependentOperationAllowed(printerRef.current);
    };
    try{
      if(current.kind==='delete'){
        await localLibraryDelete(scopeId,current.entry.path);
        ensureActive(controller.signal);
        if(scopeId!==scopeIdRef.current)return;
        setEntries(items=>items.filter(item=>item.path!==current.entry.path));
        setAction(undefined);setNotice(`${current.entry.path} удалён из локальной библиотеки.`);return;
      }
      if(!client||!current.report?.ok||!current.sha256)throw new Error('Проверка файла не завершена. Файл остаётся в библиотеке');
      ensureTarget();
      setOperation('upload');
      const startedAt=Date.now();setTransfer({phase:'preparing',done:0,total:current.entry.size,startedAt});
      const remotePath=await client.uploadLocalLibrary(current.entry.path,current.sha256,scopeId,progress=>{
        if(!controller.signal.aborted&&operationAbort.current===controller)setTransfer({...progress,startedAt});
      },controller.signal);
      ensureTarget();
      setLaunching(true);commandSent=true;
      if(current.kind==='queue'){
        await client.enqueue([remotePath]);
        if(!stillCurrent())return;
        setAction(undefined);setNotice(`${current.entry.path} проверен, скопирован на ${printerDisplayName(printer)} и добавлен в очередь.`);
        void audit('print.queue_add',`${current.entry.path} → ${remotePath} → ${printer.name}`).catch(()=>{});return;
      }
      const pending={path:remotePath,scopeId,printerId:printer.id,host:printer.host,targetKey:current.targetKey!};
      pendingLaunchRef.current=pending;setPendingLaunch(pending);
      await client.start(remotePath,printStartOptionsFromValidation(current.report));
      if(!stillCurrent())return;
      pendingLaunchRef.current=undefined;setPendingLaunch(undefined);setAction(undefined);onPrinted();
      void audit('print.validated_start',`${current.entry.path} → ${remotePath} → ${printer.name}`).catch(()=>{});
    }catch(value){
      if(stillCurrent()){
        if(commandSent&&(current.kind==='queue'||uncertainPrintStart(value))){setLaunchUnconfirmed(true);setError(current.kind==='queue'?'Добавление в очередь не подтверждено. Проверьте очередь перед повтором.':'');diagnosticWarning('print.local_start_unconfirmed',value,{printerId:printer.id,operation:'control.print_start'})}
        else {pendingLaunchRef.current=undefined;setPendingLaunch(undefined);setError(value instanceof Error&&value.name==='AbortError'?'Действие отменено; команда запуска или добавления в очередь не отправлялась. Файл мог остаться на принтере.':String(value instanceof Error?value.message:value));}
      }
    }finally{
      if(operationAbort.current===controller){const active=stillCurrent();operationAbort.current=undefined;if(active){setOperation(undefined);setTransfer(undefined);setLaunching(false);setCancelRequested(false);setBusy(false)}}
    }
  };

  const recheckLaunch=async(automatic=false)=>{
    const pending=pendingLaunchRef.current;
    if(!client||!pending||pending.scopeId!==libraryScopeId||pending.printerId!==printer.id||pending.host!==printer.host||busy||launchQueryRef.current)return 'pending';
    const epoch=launchEpoch.current;
    const stillCurrent=()=>launchEpoch.current===epoch&&pendingLaunchRef.current===pending&&clientRef.current===client&&pending.scopeId===scopeIdRef.current&&pending.printerId===printerRef.current.id&&pending.host===printerRef.current.host&&pending.targetKey===targetKey(printerRef.current);
    if(!stillCurrent())return 'stopped';
    const query={};launchQueryRef.current=query;setCheckingLaunch(true);
    try{
      const observed=await client.checkPrintStart(pending.path);
      if(!stillCurrent())return 'stopped';
      if(observed.confirmed){launchQueryRef.current=undefined;setCheckingLaunch(false);pendingLaunchRef.current=undefined;setLaunchUnconfirmed(false);setRecoveringLaunch(false);setAction(undefined);setError('');setPendingLaunch(undefined);onPrinted();void audit('print.start_recovered',`${pending.path} → ${printer.name}`).catch(()=>{});return 'confirmed';}
      if(observed.state==='error'||((observed.state==='printing'||observed.state==='paused')&&observed.filename)){
        setError(observed.state==='error'?`Принтер сообщил ошибку: ${observed.message||'проверьте экран принтера'}`:'Принтер выполняет другое задание. Повторная команда не отправлялась.');setRecoveringLaunch(false);return 'stopped';
      }
      if(!automatic)setError('Запуск пока не подтверждён. Повторная команда не отправлялась.');
      return 'pending';
    }catch(value){
      diagnosticWarning('print.local_recheck',value,{printerId:pending.printerId});
      if(!stillCurrent())return 'stopped';
      if(!automatic)setError('Не удалось получить состояние принтера. Повторная команда не отправлялась.');
      return 'pending';
    }finally{if(launchQueryRef.current===query){const current=stillCurrent();launchQueryRef.current=undefined;if(current)setCheckingLaunch(false)}}
  };
  // A missing command reply starts read-only recovery, never another upload or launch.
  useEffect(()=>{
    if(!launchUnconfirmed||action?.kind!=='start'||!pendingLaunch||!client)return;
    if(pendingLaunch.targetKey!==printTargetKey){launchQueryRef.current=undefined;setCheckingLaunch(false);setRecoveringLaunch(false);setError('Настройки принтера изменились. Автоматическая проверка этого запуска остановлена.');return;}
    let stopped=false,timer:number|undefined;
    const deadline=Date.now()+90_000;
    const active=()=>!stopped&&pendingLaunchRef.current===pendingLaunch&&clientRef.current===client&&pendingLaunch.scopeId===scopeIdRef.current&&printerRef.current.id===pendingLaunch.printerId&&printerRef.current.host===pendingLaunch.host&&pendingLaunch.targetKey===targetKey(printerRef.current);
    setRecoveringLaunch(true);
    const check=async()=>{
      if(!active())return;
      if(Date.now()>=deadline){setRecoveringLaunch(false);setError('Принтер не подтвердил запуск за время автоматической проверки. Повторная команда не отправлялась.');return;}
      const result=await recheckLaunch(true);
      if(!active())return;
      if(result==='stopped'||result==='confirmed'){setRecoveringLaunch(false);return;}
      timer=window.setTimeout(()=>void check(),Math.min(2_000,Math.max(0,deadline-Date.now())));
    };
    timer=window.setTimeout(()=>void check(),0);
    return()=>{stopped=true;if(timer!==undefined)window.clearTimeout(timer)};
  },[launchUnconfirmed,pendingLaunch,action?.kind,client,libraryScopeId,printer.id,printer.host,printTargetKey]);
  const closeAction=()=>{
    if(busy)return;
    launchEpoch.current++;pendingLaunchRef.current=undefined;launchQueryRef.current=undefined;
    setPendingLaunch(undefined);setAction(undefined);setError('');setLaunchUnconfirmed(false);setRecoveringLaunch(false);setCheckingLaunch(false);
  };

  const confirmFolderDelete=async()=>{
    const current=folderDelete;
    if(!current||!canOperate)return;
    const scopeId=libraryScopeId;
    setBusy(true);setError('');setNotice('');
    try{
      const result=await localLibraryDeleteDirectory(scopeId,current.path);
      if(scopeId!==scopeIdRef.current)return;
      const prefix=`${current.path}/`;
      setEntries(items=>items.filter(item=>item.path!==current.path&&!item.path.startsWith(prefix)));
      if(folder===current.path||folder.startsWith(prefix))setFolder(parentPath(current.path));
      setFolderDelete(undefined);
      setNotice(`Папка «${current.name}» удалена из библиотеки ${libraryScopeLabel}: ${result.files} ${filesLabel(result.files)}, ${bytes(result.size)}.`);
    }catch(value){if(scopeId===scopeIdRef.current)setError(`Папка не удалена: ${String(value instanceof Error?value.message:value)}`)}
    finally{if(scopeId===scopeIdRef.current)setBusy(false)}
  };

  const canPrint=canOperate&&canSync&&!!client&&printer.status.state==='ready'&&printer.status.connectionState==='online';
  const canQueue=canOperate&&canSync&&!!client;

  const adoptLegacy=async()=>{
    if(!canOperate||busy||!legacy.files)return;
    const scopeId=libraryScopeId;
    setBusy(true);setError('');setNotice('');
    try{
      const result=await localLibraryAdoptLegacy(scopeId);
      if(scopeId!==scopeIdRef.current)return;
      await refresh();
      if(scopeId!==scopeIdRef.current)return;
      setNotice(`Старые общие файлы закреплены за ${libraryScopeLabel}: ${result.moved} перенесено${result.skipped?`, ${result.skipped} оставлено без изменений`:''}.`);
    }catch(value){if(scopeId===scopeIdRef.current)setError(`Не удалось перенести старые файлы: ${String(value instanceof Error?value.message:value)}`)}
    finally{if(scopeId===scopeIdRef.current)setBusy(false)}
  };

  return <div className="localLibrary" ref={libraryRef}>
    <div className="localLibraryHero">
      <div><i><HardDrive/></i><span><small>{librarySharedByModel?'ОБЩАЯ БИБЛИОТЕКА МОДЕЛИ':'ЛОКАЛЬНОЕ ХРАНИЛИЩЕ'} · {libraryScopeLabel}</small><b>Моя флешка</b><em>{librarySharedByModel?`Одинаковые принтеры ${libraryScopeLabel} используют одни файлы. Другие модели сюда не попадают.`:'Это отдельная библиотека данного пользовательского принтера.'}</em></span></div>
      <div className="localLibraryStats">
        <span><Database/><b>{entries.length}</b><small>файлов</small></span>
        <span><Folder/><b>{totalFolders}</b><small>папок</small></span>
        <span><HardDrive/><b>{bytes(totalSize)}</b><small>занято</small></span>
      </div>
    </div>

    {legacy.files>0&&<div className="localLibraryLegacy"><ShieldAlert/><span><b>Найдены старые общие файлы: {legacy.files}</b><small>{bytes(legacy.size)} пока не относятся ни к одной модели. Перенесите их только если они подготовлены для {libraryScopeLabel}.</small></span><button type="button" disabled={!canOperate||busy} onClick={adoptLegacy}>{librarySharedByModel?'Закрепить за этой моделью':'Закрепить за этим принтером'}</button></div>}

    <div className="localLibraryImport">
      <div><i><Usb/></i><span><small>ИМПОРТ С USB И ДИСКА</small><b>Добавить папку или один G-code</b><em>Один файл попадёт в открытую папку; импорт папки сохранит всю вложенную структуру.</em></span></div>
      <label className="localLibraryOverwrite"><input type="checkbox" checked={overwrite} disabled={!canOperate||busy} onChange={event=>setOverwrite(event.target.checked)}/> Заменять совпадающие файлы</label>
      <label className={`button localLibrarySingleFile ${!canOperate||busy?'disabled':''}`} aria-disabled={!canOperate||busy}><FileCode2/>Добавить файл<input hidden disabled={!canOperate||busy} type="file" accept=".gcode,.gco" onChange={chooseFile}/></label>
      <label className={`button primary ${!canOperate||busy?'disabled':''}`} aria-disabled={!canOperate||busy}><Upload/>Выбрать папку<input hidden disabled={!canOperate||busy} type="file" multiple accept=".gcode,.gco" {...({webkitdirectory:'',directory:''} as object)} onChange={chooseFolder}/></label>
      {importProgress&&<div className="localLibraryImportProgress"><progress max={importProgress.total} value={importProgress.done}/><span>{importProgress.done}/{importProgress.total} · сохранено {importProgress.stored} · пропущено {importProgress.skipped}</span><small title={importProgress.current}>{importProgress.current}</small>{operation==='import'&&<button type="button" onClick={()=>operationAbort.current?.abort('Импорт отменён пользователем')}><X/>Отменить</button>}</div>}
    </div>

    <div className="localLibraryToolbar">
      <nav aria-label="Папка локальной библиотеки"><button type="button" className={!folder?'active':''} onClick={()=>{setFolder('');setQuery('')}}><Home/>Моя флешка</button>{breadcrumbs.map(item=><span key={item.path}><ChevronRight/><button type="button" className={item.path===folder?'active':''} onClick={()=>{setFolder(item.path);setQuery('')}}>{item.name}</button></span>)}</nav>
      <label><Search/><input value={query} onChange={event=>setQuery(event.target.value)} placeholder="Поиск во всех папках…" aria-label="Поиск в локальной библиотеке"/></label>
      <button type="button" disabled={busy} onClick={refresh} title="Обновить локальную библиотеку"><RefreshCw className={busy?'spin':''}/></button>
      {(operation==='analysis'||operation==='upload')&&!action&&<button type="button" className="danger" onClick={()=>operation==='upload'?cancelTransfer():operationAbort.current?.abort('Операция отменена пользователем')}><X/>{operation==='analysis'?'Отменить проверку':'Отменить действие'}</button>}
    </div>

    {!canSync&&<div className="localLibraryOffline"><ShieldCheck/><span><b>Офлайн-библиотека работает</b><small>Папки можно просматривать без интернета. Печать станет доступна, когда компьютер снова увидит этот принтер в локальной сети.</small></span></div>}
    {notice&&<div className="printerFilesNotice"><CheckCircle2/><span>{notice}</span><button type="button" onClick={()=>setNotice('')} aria-label="Закрыть сообщение"><X/></button></div>}
    {error&&!action&&<div className="printerFilesError"><ShieldAlert/>{error}</div>}

    <div className="localLibraryBrowser">
      {browserPage.rows.filter(row=>row.kind==='folder').map(row=>{const item=row.folder;return <article className="localFolderCard" key={item.path}>
        <button type="button" className="localFolderOpen" onClick={()=>setFolder(item.path)} title={`Открыть папку ${item.name}`}><i><FolderOpen/></i><span><b>{item.name}</b><small>{item.files} {filesLabel(item.files)} · {bytes(item.size)}</small></span><ChevronRight/></button>
        <button type="button" className="localFolderDelete" disabled={!canOperate||busy} onClick={()=>setFolderDelete(item)} title={`Удалить папку ${item.name} и все файлы внутри`} aria-label={`Удалить папку ${item.name}`}><Trash2/><span>Удалить</span></button>
      </article>})}
      {browserPage.rows.filter(row=>row.kind==='file').map(row=>{const entry=row.file;return <article className="localFileCard" key={entry.path}>
        <div className="localFileThumb"><LocalGCodeThumbnail printerId={libraryScopeId} entry={entry} fallback={<FileCode2/>} alt={`Предпросмотр ${leafName(entry.path)}`}/><span>G-CODE</span></div>
        <div className="localFileInfo"><b title={entry.path}>{leafName(entry.path)}</b>{(query||parentPath(entry.path)!==folder)&&<small title={entry.path}>{parentPath(entry.path)||'Моя флешка'}</small>}<div><span><Database/>{bytes(entry.size)}</span><span><Clock3/>{date(entry.modified)}</span></div></div>
        <div className="localFileActions"><button type="button" className="primary" disabled={!canPrint||busy} title={canPrint?'Полная проверка и запуск':'Нужен готовый принтер в локальной сети'} onClick={()=>prepare(entry,'start')}><Play/>Печать</button><button type="button" disabled={!canQueue||busy} title={canQueue?'Полная проверка и добавление в очередь':'Нужна локальная связь с Moonraker'} onClick={()=>prepare(entry,'queue')}><ListPlus/>В очередь</button><button type="button" className="danger" disabled={!canOperate||busy} title="Удалить из локальной библиотеки" onClick={()=>setAction({kind:'delete',entry})}><Trash2/></button></div>
      </article>})}
      {!busy&&!folderRows.length&&!visibleFiles.length&&<div className="printerFilesEmpty"><HardDrive/><b>{entries.length?'Ничего не найдено':'Локальная флешка пока пустая'}</b><span>{entries.length?'Измените запрос или вернитесь в корневую папку.':'Нажмите «Добавить файл» для одного G-code или «Выбрать папку» для всей флешки.'}</span></div>}
      {busy&&!entries.length&&!importProgress&&<div className="printerFilesEmpty loading"><RefreshCw className="spin"/><b>Открываем локальную библиотеку…</b><span>Интернет для этого не нужен.</span></div>}
    </div>
    <ListPagination count={browserRows.length} page={browserPage.page} onPageChange={page=>{browserPage.setPage(page);libraryRef.current?.scrollTo({top:0})}} label="Страницы локальной библиотеки"/>

    {action&&<div className="printerFileDialogBackdrop" onMouseDown={event=>{if(event.target===event.currentTarget&&!busy)closeAction()}}>
      <section className={`printerFileDialog ${action.kind}`} role="dialog" aria-modal="true" aria-labelledby="local-library-dialog-title">
        <header><i>{action.kind==='start'?<Play/>:action.kind==='queue'?<ListPlus/>:<ShieldAlert/>}</i><span><small>{action.kind==='delete'?'LOCAL STORAGE':'G-CODE PREFLIGHT'}</small><b id="local-library-dialog-title">{launchUnconfirmed?(recoveringLaunch?'Ожидаем запуск принтера':'Запуск не подтверждён'):error&&(action.kind==='start'||action.kind==='queue')?'Отправка не завершена':action.kind==='start'?'Проверка G-code пройдена':action.kind==='queue'?'Проверка G-code пройдена':action.kind==='delete'?'Удалить файл из «Моей флешки»?':'Запуск заблокирован'}</b><em>{action.entry.path}</em></span><button type="button" disabled={busy} onClick={closeAction}><X/></button></header>
        {action.kind==='delete'?<p>Удалится только эта локальная копия. Файлы на физической флешке и на принтерах не изменятся.</p>:<div className="printerFileIssueList">{action.report?.issues.map(issue=><div className={issue.level} key={`${issue.code}:${issue.message}`}><i>{issue.level==='error'?<ShieldAlert/>:<CheckCircle2/>}</i><span>{issue.message}</span></div>)}</div>}
        {recoveringLaunch&&<div className="printerFileLaunchRecovery" role="status" aria-live="polite"><RefreshCw className="spin"/><span>Файл передан. Автоматически проверяем запуск на принтере. Повторная команда не отправляется.</span></div>}
        {error&&!recoveringLaunch&&<div className="printerFileOperationError" role="alert"><ShieldAlert/><span>{error}</span></div>}
        {transfer&&<LocalTransferStatus transfer={transfer} launching={launching} cancelRequested={cancelRequested} queue={action.kind==='queue'} cancel={cancelTransfer}/> }
        <footer><button type="button" disabled={busy} onClick={closeAction}>{launchUnconfirmed?'Закрыть':'Отмена'}</button>{launchUnconfirmed&&action.kind==='start'&&pendingLaunch?.printerId===printer.id&&<button type="button" className="primary" disabled={busy||checkingLaunch||recoveringLaunch} onClick={()=>void recheckLaunch()}><RefreshCw className={checkingLaunch||recoveringLaunch?'spin':''}/>{recoveringLaunch?'Проверяем автоматически…':checkingLaunch?'Проверяем состояние…':'Проверить состояние'}</button>}{action.kind!=='blocked'&&!launchUnconfirmed &&<button type="button" className={action.kind==='delete'?'danger':'primary'} disabled={busy||launchUnconfirmed} onClick={confirmAction}>{busy?<RefreshCw className="spin"/>:action.kind==='start'?<Play/>:action.kind==='queue'?<ListPlus/>:<Trash2/>}{busy?(action.kind==='delete'?'Удаление…':launching?'Подтверждаем команду…':'Передача файла…'):action.kind==='start'?`Отправить и запустить на ${printerDisplayName(printer)}`:action.kind==='queue'?`Отправить в очередь ${printerDisplayName(printer)}`:'Удалить локальную копию'}</button>}{action.kind==='blocked'&&<button type="button" className="primary" onClick={()=>setAction(undefined)}>Понятно</button>}</footer>
      </section>
    </div>}

    {folderDelete&&<div className="printerFileDialogBackdrop" onMouseDown={event=>{if(event.target===event.currentTarget&&!busy)setFolderDelete(undefined)}}>
      <section className="printerFileDialog delete" role="dialog" aria-modal="true" aria-labelledby="local-folder-delete-title">
        <header><i><Trash2/></i><span><small>LOCAL STORAGE · ПАПКА</small><b id="local-folder-delete-title">Удалить папку из «Моей флешки»?</b><em>{folderDelete.path}</em></span><button type="button" disabled={busy} onClick={()=>setFolderDelete(undefined)} aria-label="Закрыть окно"><X/></button></header>
        <p>Будет удалена папка «{folderDelete.name}» и вложенные G-code — {folderDelete.files} {filesLabel(folderDelete.files)} ({bytes(folderDelete.size)}) — из библиотеки <b>{libraryScopeLabel}</b>. {librarySharedByModel?'Папка исчезнет у всех принтеров этой модели. ':''}Физическая USB-флешка, библиотеки других моделей и файлы в Moonraker не изменятся.</p>
        <footer><button type="button" disabled={busy} onClick={()=>setFolderDelete(undefined)}>Отмена</button><button type="button" className="danger" disabled={busy||!canOperate} onClick={confirmFolderDelete}>{busy?<RefreshCw className="spin"/>:<Trash2/>}Удалить папку и файлы</button></footer>
      </section>
    </div>}
  </div>;
}
