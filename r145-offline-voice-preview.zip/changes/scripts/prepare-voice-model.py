from pathlib import Path
import zipfile,tarfile,io,gzip,hashlib,json,sys
r=Path(__file__).resolve().parent.parent
if len(sys.argv)!=2:raise SystemExit('Usage: python scripts/prepare-voice-model.py OFFICIAL_MODEL_ZIP')
source=Path(sys.argv[1]);out=r/'public/voice';out.mkdir(parents=True,exist_ok=True)
with source.open('rb') as f:original=hashlib.file_digest(f,'sha256').hexdigest()
assert original=='961d5ff98a17f4aa6de69864d0aa71fa5bac682301d2b5d17a3f24c5c99a46d4','Reviewed official Russian model bytes differ'
with zipfile.ZipFile(source) as z,(out/'ru-small.tar.gz').open('wb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as t:
 directories={'model'}
 for entry in z.infolist():
  parts=Path(entry.filename).parts[1:]
  for i in range(1,len(parts)):directories.add('model/'+'/'.join(parts[:i]))
 for name in sorted(directories):
  info=tarfile.TarInfo(name+'/');info.type=tarfile.DIRTYPE;info.mode=0o755;info.mtime=0;t.addfile(info)
 for entry in sorted(z.infolist(),key=lambda e:e.filename):
  if entry.is_dir():continue
  parts=Path(entry.filename).parts;assert parts[0]=='vosk-model-small-ru-0.22' and '..' not in parts
  data=z.read(entry);info=tarfile.TarInfo('model/'+'/'.join(parts[1:]));info.size=len(data);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(data))
with (out/'ru-small.tar.gz').open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
(out/'NOTICE.txt').write_text('Russian offline speech recognition: vosk-model-small-ru-0.22\nSource: https://alphacephei.com/vosk/models/vosk-model-small-ru-0.22.zip\nLicense: Apache-2.0\nOriginal archive SHA256: '+original+'\nPackaged model SHA256: '+digest+'\nModel archive repackaged with unchanged file contents for vosk-browser.\nVosk-Browser 0.0.8, Ciaran O’Reilly, Apache-2.0.\n')
(out/'model.json').write_text(json.dumps({'model':'vosk-model-small-ru-0.22','file':'ru-small.tar.gz','sha256':digest,'bytes':(out/'ru-small.tar.gz').stat().st_size,'sourceSha256':original,'license':'Apache-2.0'},indent=2)+'\n')
print('Bundled Russian offline model',digest,(out/'ru-small.tar.gz').stat().st_size)
