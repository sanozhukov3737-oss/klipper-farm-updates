// Reproducible adaptation of Vosk-Browser 0.0.8 for the app's CSP.
// Emscripten's generated name/invoker wrappers use static closures here;
// no JavaScript string evaluation is enabled in the application.
import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const sha=value=>crypto.createHash('sha256').update(value).digest('hex');
const source=fs.readFileSync('node_modules/vosk-browser/dist/vosk.js','utf8');
assert.equal(sha(source),'29504515526e974f4cb053cf08811c4de5fb2a74007c0a5a957db50eaa8d5d0c','Upstream Vosk runtime bytes changed');
assert.equal(JSON.parse(fs.readFileSync('node_modules/vosk-browser/package.json')).version,'0.0.8');
const encoded=/createBase64WorkerFactory\(['"]([A-Za-z0-9+/=]+)['"]/.exec(source);assert.ok(encoded);
let worker=Buffer.from(encoded[1],'base64').toString('utf8');
const originalWorkerSha256=sha(worker);
function replaceFunction(name,replacement){
 const start=worker.indexOf('function '+name+'(');assert.ok(start>=0,name);
 // Parse the upstream syntax: function boundaries must not depend on braces in strings.
 return import('typescript').then(({default:ts})=>{
  const tree=ts.createSourceFile('worker.js',worker,ts.ScriptTarget.ESNext,true,ts.ScriptKind.JS);let found;
  const visit=node=>{if(ts.isFunctionDeclaration(node)&&node.name?.text===name&&node.getStart(tree)===start)found=node;ts.forEachChild(node,visit)};visit(tree);assert.ok(found,name);
  worker=worker.slice(0,start)+replacement+worker.slice(found.end);
 });
}
await replaceFunction('createNamedFunction',`function createNamedFunction(name,body){var wrapper=function(){return body.apply(this,arguments)};Object.defineProperty(wrapper,'name',{value:makeLegalFunctionName(name),configurable:true});return wrapper}`);
await replaceFunction('craftInvokerFunction',`function craftInvokerFunction(humanName,argTypes,classType,cppInvokerFunc,cppTargetFunc){
 if(argTypes.length<2)throwBindingError('argTypes array size mismatch');
 var count=argTypes.length-2,isClass=argTypes[1]!==null&&classType!==null;
 var needsStack=argTypes.slice(1).some(function(t){return t!==null&&t.destructorFunction===undefined});
 return createNamedFunction(humanName,function(){
  if(arguments.length!==count)throwBindingError('function '+humanName+' called with '+arguments.length+' arguments, expected '+count+' args');
  var stack=needsStack?[]:null,wired=[],result;
  if(isClass)wired.push(argTypes[1].toWireType(stack,this));
  for(var i=0;i<count;i++)wired.push(argTypes[i+2].toWireType(stack,arguments[i]));
  result=cppInvokerFunc.apply(null,[cppTargetFunc].concat(wired));
  if(needsStack)runDestructors(stack);
  else {var offset=0;if(isClass){if(argTypes[1].destructorFunction!==null)argTypes[1].destructorFunction(wired[0]);offset=1;}
   for(var i=0;i<count;i++)if(argTypes[i+2].destructorFunction!==null)argTypes[i+2].destructorFunction(wired[i+offset]);}
  if(argTypes[0].name!=='void')return argTypes[0].fromWireType(result);
 });
}`);
await replaceFunction('__emval_get_method_caller',`function __emval_get_method_caller(argCount,argTypes){
 var types=__emval_lookupTypes(argCount,argTypes),retType=types[0];
 return __emval_addMethodCaller(function(handle,name,destructors,args){
  var values=[],offset=0;
  for(var i=1;i<argCount;i++){values.push(types[i].readValueFromPointer(args+offset));offset+=types[i].argPackAdvance;}
  var rv=handle[name].apply(handle,values);
  for(var i=1;i<argCount;i++)if(types[i].deleteObject)types[i].deleteObject(values[i-1]);
  if(!retType.isVoid)return retType.toWireType(destructors,rv);
 });
}`);
assert.ok(!/\bnew Function\s*\(|new_\(Function|\beval\s*\(/.test(worker),'Remaining dynamic JavaScript execution');
// The model ships with the installer: a second IndexedDB copy is unnecessary.
assert.ok(worker.includes('this.Vosk.FS.mount(this.Vosk.IDBFS, {}, storagePath);'));
worker=worker.replace('this.Vosk.FS.mount(this.Vosk.IDBFS, {}, storagePath);','/* Packaged local model: transient MEMFS only. */')
 .replace('return this.Vosk.syncFilesystem(true);','return Promise.resolve();')
 .replace('return this.Vosk.syncFilesystem(false);','return Promise.resolve();');
const patched=source.replace(encoded[1],Buffer.from(worker).toString('base64'));
fs.writeFileSync('public/voice/vosk-csp.js','// Adapted for static CSP wrappers by Klipper Farm. Original: Vosk-Browser 0.0.8, Apache-2.0.\n'+patched);
fs.writeFileSync('public/voice/runtime.json',JSON.stringify({package:'vosk-browser',version:'0.0.8',license:'Apache-2.0',upstreamJsSha256:sha(source),originalWorkerSha256,workerSha256:sha(worker),file:'vosk-csp.js',sha256:sha(fs.readFileSync('public/voice/vosk-csp.js')),modifications:['Static createNamedFunction closure','Static craftInvokerFunction closure','Static __emval_get_method_caller closure','Read packaged model into transient MEMFS without IndexedDB duplication'],cspUnsafeEvalRequired:false},null,2)+'\n');
console.log('Prepared local Vosk runtime with static CSP-compatible wrappers');
