import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const metadata=JSON.parse(fs.readFileSync('public/voice/model.json','utf8'));
const model=fs.readFileSync('public/voice/'+metadata.file);
assert.equal(metadata.model,'vosk-model-small-ru-0.22');assert.equal(metadata.license,'Apache-2.0');assert.equal(model.length,metadata.bytes);
assert.equal(crypto.createHash('sha256').update(model).digest('hex'),metadata.sha256);
assert.ok(fs.readFileSync('public/voice/NOTICE.txt','utf8').includes(metadata.sourceSha256));
assert.ok(fs.readFileSync('public/voice/capture.js','utf8').includes("registerProcessor('farm-voice-capture'"));
assert.ok(fs.existsSync('public/voice/LICENSE'));
console.log('Offline Russian speech assets verified:',metadata.bytes,'bytes; no runtime download');

const runtime=JSON.parse(fs.readFileSync('public/voice/runtime.json','utf8'));
assert.equal(runtime.cspUnsafeEvalRequired,false);
assert.equal(crypto.createHash('sha256').update(fs.readFileSync('public/voice/'+runtime.file)).digest('hex'),runtime.sha256);
const config=JSON.parse(fs.readFileSync('src-tauri/tauri.conf.json','utf8'));
assert.ok(!config.app.security.csp.includes("'unsafe-eval'"));
console.log('Local speech runtime hash and application CSP verified');
