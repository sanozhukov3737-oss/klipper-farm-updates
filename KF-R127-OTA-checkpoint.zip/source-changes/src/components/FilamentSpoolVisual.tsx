import { useId } from 'react';
import styles from './FilamentInventoryPanel.module.css';

export function FilamentSpoolVisual({ color, fraction = 1, label }: { color?: string; fraction?: number; label: string }) {
  const id = useId().replace(/:/g, '');
  const amount = Math.max(0, Math.min(1, fraction));
  const fill = color && /^#[\da-f]{3}(?:[\da-f]{3})?$/i.test(color) ? color : 'var(--ui-accent)';
  return <svg className={styles.spoolVisual} viewBox="0 0 116 108" role="img" aria-label={label}>
    <defs>
      <linearGradient id={id} x1="0" y1="0" x2="1" y2="1"><stop stopColor="var(--ui-surface-3)"/><stop offset="1" stopColor="var(--ui-border-strong)"/></linearGradient>
    </defs>
    <ellipse cx="64" cy="99" rx="40" ry="5" fill="var(--ui-text)" opacity=".08"/>
    <circle cx="65" cy="49" r="44" fill="var(--ui-border-strong)"/>
    <path d="M54 6h11v88H54Z" fill="var(--ui-border-strong)"/>
    <circle cx="54" cy="49" r="44" fill={`url(#${id})`} stroke="var(--ui-border-strong)"/>
    <circle cx="54" cy="49" r="30" fill="var(--ui-surface-2)"/>
    <circle cx="54" cy="49" r="27" fill="none" stroke={fill} strokeWidth={amount > 0 ? 11 + amount * 15 : 0} opacity=".95"/>
    {[22, 26, 30, 34].filter(radius => radius <= 27 + amount * 13 && radius >= 27 - amount * 8).map(radius => <circle key={radius} cx="54" cy="49" r={radius} fill="none" stroke="var(--ui-text)" opacity=".15"/>)}
    <circle cx="54" cy="49" r="16" fill={`url(#${id})`} stroke="var(--ui-border-strong)"/>
    <circle cx="54" cy="49" r="8" fill="var(--ui-surface-2)" stroke="var(--ui-border-strong)"/>
    {[0, 120, 240].map(angle => <rect key={angle} x="50" y="10" width="8" height="5" rx="2.5" fill="var(--ui-surface-2)" transform={`rotate(${angle} 54 49)`}/>)}
  </svg>;
}
