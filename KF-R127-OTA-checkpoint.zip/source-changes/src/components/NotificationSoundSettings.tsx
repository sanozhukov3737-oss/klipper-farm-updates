import { useEffect, useId, useState } from 'react';
import { Volume2 } from 'lucide-react';
import { NOTIFICATION_SOUND_CHANGED, notificationSoundPreferences, playNotificationSound, saveNotificationSoundPreferences, type NotificationSoundEvent, type NotificationSoundPreferences } from '../lib/notificationSound';
import styles from './NotificationSoundSettings.module.css';

const labels: Record<NotificationSoundEvent, string> = { complete: 'Печать завершена', error: 'Ошибка печати', runout: 'Закончился пластик', offline: 'Потеря связи с принтером' };
export function NotificationSoundSettings() {
  const volumeId=useId();
  const [settings, setSettings] = useState(notificationSoundPreferences), [message, setMessage] = useState(''), [failed, setFailed] = useState(false);
  useEffect(() => {
    const update = () => setSettings(notificationSoundPreferences());
    window.addEventListener(NOTIFICATION_SOUND_CHANGED, update); window.addEventListener('storage', update);
    return () => { window.removeEventListener(NOTIFICATION_SOUND_CHANGED, update); window.removeEventListener('storage', update); };
  }, []);
  const save = (next: NotificationSoundPreferences) => {
    try { setSettings(saveNotificationSoundPreferences(next)); setFailed(false); setMessage('Настройки звука сохранены.'); }
    catch { setFailed(true); setMessage('Не удалось сохранить настройки звука. Повторите изменение.'); }
  };
  const test = async (event: NotificationSoundEvent) => {
    const played = await playNotificationSound(event, undefined, true);
    setFailed(!played); setMessage(played ? `Проверка: «${labels[event]}».` : 'Звук недоступен. Проверьте громкость приложения в микшере Windows.');
  };
  return <section className={styles.root} aria-label="Звуки событий печати">
    <div className={styles.heading}><h3><Volume2/>Звук уведомлений</h3><label className={styles.enabled}><input type="checkbox" checked={settings.enabled} onChange={event => save({ ...settings, enabled: event.target.checked })}/>Включён</label></div>
    <label className={styles.volume} htmlFor={volumeId}>Громкость <output>{Math.round(settings.volume * 100)}%</output><input id={volumeId} type="range" min="0" max="100" step="5" value={Math.round(settings.volume * 100)} disabled={!settings.enabled} onChange={event => save({ ...settings, volume: Number(event.target.value) / 100 })}/></label>
    <div className={styles.events}>{(Object.keys(labels) as NotificationSoundEvent[]).map(event => <label key={event}><input type="checkbox" disabled={!settings.enabled} checked={settings.events[event]} onChange={value => save({ ...settings, events: { ...settings.events, [event]: value.target.checked } })}/>{labels[event]}</label>)}</div>
    <div className={styles.actions}><button type="button" disabled={!settings.enabled || settings.volume === 0} onClick={() => void test('complete')}>Послушать завершение</button><button type="button" disabled={!settings.enabled || settings.volume === 0} onClick={() => void test('error')}>Послушать ошибку</button></div>
    <p>Громкость также зависит от микшера Windows. Уведомления на экране сохраняются при выключенном звуке.</p>
    {message && <p role={failed ? 'alert' : 'status'}>{message}</p>}
  </section>;
}
