import {useEffect,useRef,useState} from 'react';
import {Bell} from 'lucide-react';
import {nativeNotify} from '../lib/native';
import {recordNotification,showAppNotification} from '../lib/appNotifications';
import {playNotificationSound} from '../lib/notificationSound';

export type NotificationTestResult={message:string;failed:boolean};
export function NotificationTest({compact=false,onResult}:{compact?:boolean;onResult?:(result:NotificationTestResult)=>void}={}){
  const [busy,setBusy]=useState(false),[result,setResult]=useState(''),[failed,setFailed]=useState(false);
  useEffect(()=>{onResult?.({message:result,failed})},[result,failed,onResult]);
  const lock=useRef(false),mounted=useRef(true);
  useEffect(()=>{mounted.current=true;return()=>{mounted.current=false}},[]);
  const test=async()=>{
    if(lock.current)return;
    lock.current=true;setBusy(true);setFailed(false);setResult('Проверяем уведомления…');
    showAppNotification('Проверка уведомлений','Сообщения внутри Klipper Farm работают. Проверяем уведомление Windows.','success');
    void playNotificationSound('complete',undefined,true);
    let saved=true;
    try{await recordNotification('notification.test','Проверка: уведомления внутри программы работают.')}catch{saved=false}
    let timer:number|undefined;
    try{
      await Promise.race([nativeNotify('Klipper Farm','Проверка системного уведомления. Сообщение внутри программы уже показано.'),new Promise<never>((_,reject)=>{timer=window.setTimeout(()=>reject(new Error('Система не ответила за 10 секунд')),10_000)})]);
      if(mounted.current)setResult(compact?`Уведомление в программе показано. Запрос Windows отправлен.${saved?'':' Не удалось сохранить запись в журнале.'}`:`Уведомление показано внутри программы${saved?' и сохранено в центре уведомлений':''}. Запрос Windows отправлен. Если баннера нет, проверьте «Не беспокоить» и разрешения уведомлений Windows.${saved?'':' Не удалось сохранить запись в журнале.'}`);
    }catch(error){
      const message=`Внутри программы уведомления работают. Windows: ${String(error instanceof Error?error.message:error)}`;
      showAppNotification('Системное уведомление недоступно',message,'danger');
      if(mounted.current){setFailed(true);setResult(message)}
    }finally{window.clearTimeout(timer);lock.current=false;if(mounted.current)setBusy(false)}
  };
  return <div className={`notificationTest${compact?' compact':''}`}><button type="button" disabled={busy} onClick={()=>void test()}>{!compact&&<Bell/>}{busy?'Проверяем…':compact?'Проверить':'Проверить уведомления'}</button>{!compact&&result&&<p role={failed?'alert':'status'}>{result}</p>}</div>;
}
