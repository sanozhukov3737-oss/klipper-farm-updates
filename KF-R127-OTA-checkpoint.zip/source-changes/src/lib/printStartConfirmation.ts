export const PRINT_START_CONFIRMATION_MS = 30_000;

export function uncertainPrintStart(error: unknown) {
  if (error instanceof Error && error.name === 'AbortError') return true;
  const message = error instanceof Error ? error.message : String(error);
  return /PRINT_START_UNCONFIRMED|RESULT_UNKNOWN|OPERATION_DEADLINE_EXCEEDED|\btimeout\b|\btimed out\b|тайм.?аут/i.test(message);
}

/** Keep the whole path: equal basenames in different folders are different jobs. */
export function matchingPrintFilename(actual: unknown, expected: string) {
  const clean = (value: string) => value.replace(/\\/g, '/').replace(/^\.\//, '').replace(/^\/+/, '').replace(/^gcodes\//, '').normalize('NFC');
  return typeof actual === 'string' && !!actual && clean(actual) === clean(expected);
}

export function printStartObservation(status: any, filename: string) {
  const stats = status?.print_stats;
  const state = String(stats?.state ?? 'unknown').trim().toLowerCase();
  return { confirmed: (state === 'printing' || state === 'paused') && matchingPrintFilename(stats?.filename, filename), state,
    filename: typeof stats?.filename === 'string' ? stats.filename : '', message: String(stats?.message ?? '') };
}
