import { filamentDayKey, type FilamentInventory } from './filamentInventory';

export function filamentAnalytics(inventory: FilamentInventory, now = Date.now()) {
  const today = new Date(now);
  today.setHours(0, 0, 0, 0);
  const history = inventory.usageHistory;
  const recorded = history?.days ?? [];
  const days = Array.from({ length: 30 }, (_, index) => {
    const date = new Date(today);
    // Calendar arithmetic preserves local days across daylight saving changes.
    date.setDate(date.getDate() - 29 + index);
    const key = filamentDayKey(date.getTime());
    const entries = recorded.filter(row => row.day === key);
    return {
      key, date: date.getTime(),
      grams: entries.reduce((sum, row) => sum + row.calculatedGrams + row.manualGrams, 0),
      known: !!history && (key >= filamentDayKey(history.startedAt) || entries.length > 0),
    };
  });
  const totalUsed = Object.values(inventory.materials).reduce((sum, row) => sum + row.usedGrams, 0);
  const dated = recorded.reduce((sum, row) => sum + row.calculatedGrams + row.manualGrams, 0);
  const sum = (count: number) => days.slice(-count).reduce((value, day) => value + day.grams, 0);
  return { days, today: sum(1), week: sum(7), month: sum(30), hasHistory: !!history,
    legacyGrams: Math.max(0, totalUsed - dated), totalUsed };
}

export function filamentUsageInPeriod(inventory: FilamentInventory, from: string, to: string) {
  const byPrinter: Record<string, number> = {};
  for (const row of inventory.usageHistory?.days ?? []) {
    if (row.day >= from && row.day <= to) byPrinter[row.printerId] = (byPrinter[row.printerId] ?? 0) + row.calculatedGrams + row.manualGrams;
  }
  return byPrinter;
}
