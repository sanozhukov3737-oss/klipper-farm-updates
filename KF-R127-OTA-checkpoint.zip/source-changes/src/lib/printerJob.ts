import type { PrinterStatus } from '../types';

export function printerCompletionNotificationAllowed(status: PrinterStatus) {
  return status.state === 'ready' && status.connectionState === 'online' && !status.remoteControlSuspended
    && !['cancelled', 'canceled', 'error', 'failed', 'interrupted', 'klippy_shutdown', 'klippy_disconnect', 'server_exit'].includes(status.printStatsState ?? '');
}

export function printerHasActiveJob(status:PrinterStatus){
  if(status.remoteControlSuspended)return true;
  if(status.state==='printing'||status.state==='paused')return true;
  if(status.connectionState==='offline'||!status.filename?.trim())return false;
  const progress=Number.isFinite(status.progress)?status.progress:0;
  const elapsed=Number.isFinite(status.printDuration)?status.printDuration:0;
  // Some vendor Moonraker builds briefly omit print_stats.state while still
  // publishing the same filename/progress used by the detailed view. Keep all
  // screens on that shared live job instead of hiding it only on the dashboard.
  return progress>0&&progress<0.999||elapsed>0&&progress<0.999;
}
