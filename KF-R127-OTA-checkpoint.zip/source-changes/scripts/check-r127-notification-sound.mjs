import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {build} from 'esbuild';
const root=path.resolve(import.meta.dirname,'..'),report=[],memory=new Map(),oscillators=[],contexts=[];
const {outputFiles}=await build({stdin:{contents:"export * from './src/lib/notificationSound';export {printerCompletionNotificationAllowed} from './src/lib/printerJob';",resolveDir:root,loader:'ts'},bundle:true,write:false,format:'esm',platform:'node',target:'node22'});
let now=Date.now();const realNow=Date.now;Date.now=()=>now;
globalThis.localStorage={getItem:key=>memory.get(key)??null,setItem:(key,value)=>memory.set(key,value)};
globalThis.document=new EventTarget();globalThis.window=new EventTarget();
window.setTimeout=setTimeout;window.clearTimeout=clearTimeout;
class Audio {
 state='running';currentTime=0;destination={};
 constructor(){contexts.push(this);}
 resume(){this.state='running';return Promise.resolve();}
 createOscillator(){const node={frequency:{setValueAtTime:(value,at)=>{node.frequencyValue=value;node.frequencyAt=at}},connect:()=>{},disconnect:()=>{},start:at=>{node.startAt=at},stop:at=>{node.stopAt=at;node.stopped=true},onended:undefined};oscillators.push(node);return node;}
 createGain(){return {gain:{setValueAtTime:()=>{},linearRampToValueAtTime:()=>{},exponentialRampToValueAtTime:()=>{}},connect:()=>{},disconnect:()=>{}};}
}
window.AudioContext=Audio;
const sound=await import('data:text/javascript;base64,'+Buffer.from(outputFiles[0].text).toString('base64'));
async function test(name,run){await run();report.push({name,passed:true});}
const save=(patch)=>{const value=sound.notificationSoundPreferences();return sound.saveNotificationSoundPreferences({...value,...patch});};
try{
 await test('corrupt-settings-fall-back-without-mutating-defaults',()=>{memory.set(sound.NOTIFICATION_SOUND_KEY,'{bad');assert.deepEqual(sound.notificationSoundPreferences(),sound.SOUND_DEFAULTS);memory.clear();});
 await test('complete-and-error-have-different-notes',async()=>{assert.equal(await sound.playNotificationSound('complete','complete-1'),true);const first=oscillators.map(node=>node.frequencyValue);now+=10;assert.equal(await sound.playNotificationSound('error','error-1'),true);assert.notDeepEqual(oscillators.slice(3).map(node=>node.frequencyValue),first);assert.equal(oscillators.length,6);assert.ok(oscillators.slice(0,3).every(node=>node.stopped));});
 await test('same-event-does-not-play-again',async()=>{now+=1000;const before=oscillators.length;assert.equal(await sound.playNotificationSound('error','error-1'),false);assert.equal(oscillators.length,before);});
 await test('rapid-printer-events-coalesce-but-critical-errors-preempt-success',async()=>{now+=1000;assert.equal(await sound.playNotificationSound('complete','job-two'),true);assert.equal(await sound.playNotificationSound('complete','job-three'),false);assert.equal(await sound.playNotificationSound('runout','runout-one'),true);});
 await test('master-disable-and-zero-volume-are-silent',async()=>{save({enabled:false});const before=oscillators.length;assert.equal(await sound.playNotificationSound('complete',undefined,true),false);save({enabled:true,volume:0});assert.equal(await sound.playNotificationSound('error',undefined,true),false);assert.equal(oscillators.length,before);});
 await test('individual-event-switch-and-manual-preview',async()=>{const value=sound.notificationSoundPreferences();save({volume:0.35,events:{...value.events,complete:false}});now+=1000;assert.equal(await sound.playNotificationSound('complete','muted-type'),false);assert.equal(await sound.playNotificationSound('complete',undefined,true),true);assert.equal(sound.notificationSoundPreferences().volume,0.35);});
 await test('offline-sound-is-optional-and-preferences-roundtrip',async()=>{const value=sound.notificationSoundPreferences();now+=1000;assert.equal(await sound.playNotificationSound('offline','offline-one'),false);const saved=save({events:{...value.events,offline:true}});assert.deepEqual(sound.notificationSoundPreferences(),saved);assert.equal(await sound.playNotificationSound('offline','offline-two'),true);});
 await test('minimized-flag-does-not-suppress-scheduled-audio',async()=>{document.hidden=true;now+=1000;assert.equal(await sound.playNotificationSound('error','hidden-error'),true);assert.ok(oscillators.at(-1).stopAt>oscillators.at(-1).startAt);});
 await test('unsupported-audio-fails-without-breaking-notifications',async()=>{window.AudioContext=undefined;assert.equal(await sound.playNotificationSound('error',undefined,true),false);window.AudioContext=Audio;});
 await test('install-and-cleanup-are-idempotent',()=>{const first=sound.installNotificationSound(),second=sound.installNotificationSound();document.dispatchEvent(new Event('pointerdown'));first();first();second();});
 await test('muting-during-audio-resume-does-not-play-a-delayed-tone',async()=>{const audio=contexts.at(-1);audio.state='suspended';let resume;audio.resume=()=>new Promise(resolve=>{resume=()=>{audio.state='running';resolve();};});const before=oscillators.length,pending=sound.playNotificationSound('error',undefined,true);save({enabled:false});resume();assert.equal(await pending,false);assert.equal(oscillators.length,before);save({enabled:true});});
 await test('cancel-offline-and-suspended-prints-do-not-notify-success',()=>{const status={state:'ready',connectionState:'online',printStatsState:'complete'};assert.equal(sound.printerCompletionNotificationAllowed(status),true);for(const printStatsState of ['cancelled','canceled','error','failed','interrupted'])assert.equal(sound.printerCompletionNotificationAllowed({...status,printStatsState}),false);assert.equal(sound.printerCompletionNotificationAllowed({...status,connectionState:'offline'}),false);assert.equal(sound.printerCompletionNotificationAllowed({...status,remoteControlSuspended:true}),false);});
}finally{Date.now=realNow;}
if(process.env.KF_R127_SOUND_PROOF)fs.writeFileSync(process.env.KF_R127_SOUND_PROOF,JSON.stringify({passed:report.length,report,audioGraphEmulated:true},null,2));
console.log(`R127 sound notifications: ${report.length} cases passed (settings, notes, dedupe, mute, completion guards).`);
