import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { build } from 'esbuild';
const root=path.resolve(import.meta.dirname,'..'),report=[];
const {outputFiles}=await build({stdin:{contents:"export {MoonrakerClient} from './src/lib/moonraker';export {setAuthSession} from './src/lib/auth';",resolveDir:root,loader:'ts'},bundle:true,write:false,format:'esm',platform:'node',target:'node22',plugins:[{name:'native-boundary',setup(builder){
  builder.onResolve({filter:/^@tauri-apps\/api\/(core|event)$/},args=>({path:args.path,namespace:'native'}));
  builder.onLoad({filter:/.*/,namespace:'native'},()=>({contents:'export const invoke=(c,a)=>globalThis.__native(c,a);export const listen=async()=>()=>{};',loader:'js'}));
}}]});
const realNow=Date.now;let now=realNow();Date.now=()=>now;
globalThis.window={setTimeout:(fn,ms)=>{now+=Math.max(1,ms);queueMicrotask(fn);return 1},clearTimeout:()=>{},dispatchEvent:()=>{}};
globalThis.document={hidden:false,addEventListener:()=>{},removeEventListener:()=>{}};
const {MoonrakerClient,setAuthSession}=await import('data:text/javascript;base64,'+Buffer.from(outputFiles[0].text).toString('base64'));
setAuthSession({token:'test-only',user:{id:'operator',role:'operator'}});
try{
 for(const test of [
  {name:'direct-start-after-ten-seconds',delay:10_000,ok:true},
  {name:'actor-six-second-timeout-recovered-without-resend',actor:true,unknown:true,delay:16_000,ok:true},
  {name:'actor-unknown-result-recovered-by-fresh-query',actor:true,unknownResult:true,delay:8_000,ok:true},
  {name:'acknowledgement-without-status-is-not-confirmation',actor:true,delay:9_000,ok:true},
  {name:'idle-for-entire-window-stays-unconfirmed',delay:Infinity,ok:false},
  {name:'same-basename-different-directory-is-not-confirmation',filename:'other/calibration_cube.gcode',delay:0,ok:false},
  {name:'paused-matching-file-is-confirmed',delay:0,state:'paused',ok:true},
  {name:'explicit-rejection-is-not-recovered-or-repeated',reject:true,ok:false},
  {name:'printer-error-does-not-become-unconfirmed',delay:0,state:'error',ok:false},
  {name:'emergency-cancels-readonly-wait',delay:Infinity,abort:true,ok:false},
 ]){
  now+=100_000;const sentAt=now;
  const client=new MoonrakerClient({id:'test',name:'Flashforge 5M',host:'127.0.0.1:7125',profile:{preset:'flashforge-ad5m'}});
  client.actorActive=!!test.actor;client.actorEpoch=1;
  let starts=0,queries=0;
  globalThis.__native=async(command,args)=>{
   assert.ok(['printer_actor_rpc','moonraker_rpc','moonraker_ws_rpc'].includes(command),command);
   if(args.method==='printer.print.start'){
    starts++;
    if(test.reject)throw new Error('RPC_ERROR: File not found');
    if(test.unknown){now+=6100;throw new Error('INTERNAL_ERROR: PRINT_START_UNCONFIRMED: state=standby');}
    return test.actor?{operationId:'op',sessionEpoch:1,state:test.unknownResult?'unknown':'confirmed',result:'ok'}:'ok';
   }
   assert.equal(args.method,'printer.objects.query');queries++;
   assert.deepEqual(args.params,{objects:{print_stats:null}});
   if(test.abort)client.requestScheduler.close();
   const ready=now-sentAt>=test.delay;
   const status={print_stats:{state:ready?test.state??'printing':'standby',filename:ready?test.filename??'calibration_cube.gcode':'',message:test.state==='error'?'Test heater failure':''}};
   return test.actor?{operationId:'read',sessionEpoch:1,state:'confirmed',result:{status}}:{status};
  };
  try{
   const result=await Promise.allSettled([client.start('calibration_cube.gcode')]);
   assert.equal(result[0].status,test.ok?'fulfilled':'rejected',test.name);
   assert.equal(starts,1,'A start was sent more than once');
   if(test.ok){assert.ok(queries>0);assert.equal(client.lastState,test.state??'printing');}
   if(test.reject)assert.equal(queries,0);
   if(test.abort)assert.equal(queries,1);
   if(test.state==='error')assert.match(String(result[0].reason),/PRINT_START_REJECTED/);
   if(!test.ok&&!test.abort&&!test.reject&&test.state!=='error')assert.match(String(result[0].reason),/PRINT_START_UNCONFIRMED/);
   report.push({name:test.name,passed:true,starts,queries,elapsedMs:now-sentAt});
  }finally{client.disconnect();}
 }
 {
  const client=new MoonrakerClient({id:'check',name:'K1 Max',host:'127.0.0.1:7125',profile:{preset:'creality-k1-max'}});let starts=0,queries=0;
  globalThis.__native=async(_command,args)=>{if(args.method==='printer.print.start')starts++;else queries++;return {status:{print_stats:{state:'printing',filename:'calibration_cube.gcode'}}}};
  assert.equal((await client.checkPrintStart('calibration_cube.gcode')).confirmed,true);assert.equal(starts,0);assert.ok(queries>=1);
  report.push({name:'manual-recheck-never-sends-start',passed:true});client.disconnect();
 }
 {
  const client=new MoonrakerClient({id:'double',name:'K1 Max',host:'127.0.0.1:7125',profile:{preset:'creality-k1-max'}});let starts=0;
  globalThis.__native=async(_command,args)=>{if(args.method==='printer.print.start'){starts++;return 'ok'}return {status:{print_stats:{state:'printing',filename:'calibration_cube.gcode'}}}};
  const result=await Promise.allSettled([client.start('calibration_cube.gcode'),client.start('calibration_cube.gcode')]);
  assert.equal(result[0].status,'fulfilled');assert.equal(result[1].status,'rejected');assert.equal(starts,1);client.disconnect();
  report.push({name:'concurrent-double-click-sends-one-start',passed:true});
 }
}finally{Date.now=realNow;}
if(process.env.KF_R127_PRINT_PROOF)fs.writeFileSync(process.env.KF_R127_PRINT_PROOF,JSON.stringify({passed:report.length,report,nativeBoundaryEmulated:true},null,2));
console.log(`R127 print start: ${report.length} cases passed; late confirmation and read-only recheck, no repeated starts.`);
