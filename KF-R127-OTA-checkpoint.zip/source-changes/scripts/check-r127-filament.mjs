import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import ts from './typescript-runtime.mjs';
const root = path.resolve(import.meta.dirname, '..');
const compile = (file, imports = {}) => {
  let code = ts.transpileModule(fs.readFileSync(path.join(root, file), 'utf8'), { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ES2022 } }).outputText;
  for (const [name, url] of Object.entries(imports)) code = code.replaceAll(`from '${name}'`, `from '${url}'`);
  return `data:text/javascript;base64,${Buffer.from(code).toString('base64')}`;
};
const coreUrl = compile('src/lib/filamentInventory.ts');
const { emptyFilamentInventory, restoreFilamentInventory, reduceFilamentInventory, filamentDayKey } = await import(coreUrl);
const { filamentAnalytics, filamentUsageInPeriod } = await import(compile('src/lib/filamentAnalytics.ts', { './filamentInventory': coreUrl }));
const report = [], today = new Date(2026, 9, 20, 14).getTime();
const day = (offset, hour = 14) => new Date(2026, 9, 20 + offset, hour).getTime();
let state = emptyFilamentInventory(day(-40));
const apply = (command, at = today) => { state = reduceFilamentInventory(state, command, at).state; };
function test(name, run) { run(); report.push({ name, passed: true }); }
test('new-inventory-starts-with-empty-daily-history', () => {
  assert.equal(filamentAnalytics(state, today).month, 0);
  assert.equal(filamentAnalytics(state, today).hasHistory, true);
});
test('manual-debits-share-daily-buckets-and-preserve-stock', () => {
  apply({ type: 'add-stock', material: 'PLA', grams: 20000 }, day(-40));
  for (const [when, grams] of [[-31, 50], [-29, 100], [-7, 200], [-6, 300], [-1, 400], [0, 500], [0, 250]]) apply({ type: 'manual-writeoff', printerId: 'one', material: 'PLA', grams }, day(when));
  assert.equal(state.materials.PLA.looseGrams, 18200);
  assert.equal(state.usageHistory.days.length, 6);
  assert.equal(state.usageHistory.days.find(row => row.day === filamentDayKey(today)).manualGrams, 750);
  const analytics = filamentAnalytics(state, today);
  assert.equal(analytics.today, 750); assert.equal(analytics.week, 1450); assert.equal(analytics.month, 1750); assert.equal(analytics.legacyGrams, 0);
});
test('spool-colors-persist-and-transferring-stock-is-not-consumption', () => {
  const before = JSON.stringify(state.usageHistory);
  apply({ type: 'add-spools', material: 'PLA', count: 2, weightGrams: 1000, color: '#f59e0b', source: 'existing-stock' });
  assert.equal(state.spools[0].color, '#f59e0b');
  assert.equal(state.materials.PLA.looseGrams, 16200);
  apply({ type: 'edit-spool', spoolId: state.spools[0].id, remainingGrams: 800, color: '#123abc' });
  assert.equal(state.spools[0].color, '#123abc');
  assert.equal(JSON.stringify(state.usageHistory), before);
  assert.throws(() => reduceFilamentInventory(state, { type: 'edit-spool', spoolId: state.spools[0].id, remainingGrams: 1, color: 'url(https://invalid.test)' }, today));
});
test('automatic-history-uses-completion-date-and-is-idempotent', () => {
  apply({ type: 'bind-printer', printerId: 'two', material: 'PLA' }, day(-3));
  apply({ type: 'history-baseline', printerId: 'two', bindingId: state.printers.two.binding.id, at: day(-3), jobs: [] }, day(-3));
  const job = { printerId: 'two', jobId: 'printed', filename: 'part.gcode', startTime: day(-2), endTime: day(-1, 23), status: 'completed', usedMm: 10000 };
  apply({ type: 'observe-job', job });
  const amount = state.printers.two.usedGrams;
  assert.ok(amount > 0);
  assert.equal(state.usageHistory.days.find(row => row.printerId === 'two').day, filamentDayKey(day(-1)));
  const before = JSON.stringify(state); apply({ type: 'observe-job', job }); assert.equal(JSON.stringify(state), before);
  apply({ type: 'observe-job', job: { ...job, usedMm: 20000 } });
  assert.ok(Math.abs(state.usageHistory.days.find(row => row.printerId === 'two').calculatedGrams - amount * 2) < 1e-7);
});
test('period-breakdown-retains-removed-printers', () => {
  const values = filamentUsageInPeriod(state, filamentDayKey(day(-6)), filamentDayKey(today));
  assert.equal(values.one, 1450); assert.ok(values.two > 0);
});
test('old-format-is-read-without-mutation-or-invented-dates', () => {
  const old = JSON.parse(JSON.stringify(state)); delete old.usageHistory;
  const before = JSON.stringify(old); restoreFilamentInventory(old);
  const analytics = filamentAnalytics(old, today);
  assert.equal(analytics.hasHistory, false); assert.equal(analytics.today, 0);
  assert.equal(analytics.legacyGrams, analytics.totalUsed); assert.equal(JSON.stringify(old), before);
  const result = reduceFilamentInventory(old, { type: 'manual-writeoff', printerId: 'one', material: 'PLA', grams: 10 }, today).state;
  assert.equal(result.usageHistory.days.length, 1); assert.equal(filamentAnalytics(result, today).today, 10);
  assert.equal(filamentAnalytics(result, today).legacyGrams, analytics.totalUsed);
});
test('failed-debit-does-not-mutate-daily-history-or-stock', () => {
  const before = JSON.stringify(state);
  assert.throws(() => reduceFilamentInventory(state, { type: 'manual-writeoff', printerId: 'one', material: 'PLA', grams: 1e8 }, today));
  assert.equal(JSON.stringify(state), before);
});
test('restoration-rejects-corrupted-daily-records', () => {
  for (const mutation of [copy => { copy.usageHistory.days[0].manualGrams = -1; }, copy => { copy.usageHistory.days[0].day = '2026-02-30'; }, copy => { copy.usageHistory.days.push(copy.usageHistory.days[0]); }]) {
    const copy = JSON.parse(JSON.stringify(state)); mutation(copy); assert.throws(() => restoreFilamentInventory(copy));
  }
  assert.deepEqual(restoreFilamentInventory(JSON.parse(JSON.stringify(state))), state);
});
test('calendar-days-handle-month-boundaries-and-local-midnight', () => {
  const at = new Date(2026, 2, 9, 0, 1).getTime();
  const keys = filamentAnalytics(state, at).days.map(row => row.key);
  assert.equal(keys.length, new Set(keys).size); assert.equal(keys.at(-1), '2026-03-09'); assert.equal(keys.at(-2), '2026-03-08');
});
if (process.env.KF_R127_CORE_PROOF) fs.writeFileSync(process.env.KF_R127_CORE_PROOF, JSON.stringify({ timezone: Intl.DateTimeFormat().resolvedOptions().timeZone, cases: report }, null, 2));
console.log(`R127 warehouse accounting: ${report.length} meaningful cases passed (${Intl.DateTimeFormat().resolvedOptions().timeZone}).`);
