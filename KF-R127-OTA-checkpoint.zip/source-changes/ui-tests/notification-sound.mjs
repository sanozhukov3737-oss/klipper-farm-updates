import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import {build} from 'vite';
const root=path.resolve(import.meta.dirname,'..'),out=fs.mkdtempSync(path.join(os.tmpdir(),'kf-sound-r127-')),report=[],errors=[],shots=process.env.KF_UI_SCREENSHOTS;
let server,browser;
try{
 await build({root,logLevel:'error',build:{outDir:out,emptyOutDir:true,rollupOptions:{input:path.join(root,'ui-tests/notification-sound.html')}}});
 server=http.createServer((req,res)=>{const file=path.resolve(out,new URL(req.url,'http://localhost').pathname.slice(1));if(!file.startsWith(out+path.sep)||!fs.existsSync(file)){res.writeHead(404).end();return}res.setHeader('Content-Type',({'.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml','.webp':'image/webp'})[path.extname(file)]??'application/octet-stream');res.end(fs.readFileSync(file));});
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const origin=`http://127.0.0.1:${server.address().port}`;
 const {chromium}=await import(process.env.PLAYWRIGHT_MODULE_PATH??'playwright');
 browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_EXECUTABLE,args:['--no-sandbox','--disable-dev-shm-usage']});
 if(shots)fs.mkdirSync(shots,{recursive:true});
 for(const theme of ['light','dark'])for(const width of [390,1366]){
  const page=await browser.newPage({viewport:{width,height:950},locale:'ru-RU'});page.on('pageerror',error=>errors.push(error.message));
  await page.route('**/*',route=>route.request().url().startsWith(origin+'/')?route.continue():route.abort());
  await page.goto(origin+'/ui-tests/notification-sound.html');await page.evaluate(theme=>document.documentElement.dataset.theme=theme,theme);
  await page.getByRole('button',{name:'Приложение',exact:true}).click();
  const panel=page.getByRole('region',{name:'Звуки событий печати',exact:true});await panel.scrollIntoViewIfNeeded();
  await panel.getByRole('button',{name:'Послушать завершение',exact:true}).click();await panel.getByRole('status').filter({hasText:'Проверка:'}).waitFor();
  const success=await page.evaluate(()=>window.__voices.map(value=>value.frequency));assert.equal(success.length,3);
  await panel.getByRole('button',{name:'Послушать ошибку',exact:true}).click();
  await panel.getByRole('status').filter({hasText:'Ошибка печати'}).waitFor();
  const error=await page.evaluate(()=>window.__voices.slice(3).map(value=>value.frequency));assert.equal(error.length,3);assert.notDeepEqual(success,error);
  const slider=panel.getByRole('slider',{name:/Громкость/});await slider.focus();await page.keyboard.press('Home');for(let i=0;i<7;i++)await page.keyboard.press('ArrowRight');
  assert.equal(await slider.inputValue(),'35');
  await panel.getByRole('checkbox',{name:'Печать завершена',exact:true}).uncheck();
  assert.equal(await page.evaluate(()=>window.__printSound('complete','disabled-complete')),false);
  await panel.getByRole('checkbox',{name:'Включён',exact:true}).uncheck();
  assert.ok(await panel.getByRole('button',{name:'Послушать ошибку',exact:true}).isDisabled());
  const before=await page.evaluate(()=>window.__voices.length);assert.equal(await page.evaluate(()=>window.__printSound('error','master-disabled')),false);assert.equal(await page.evaluate(()=>window.__voices.length),before);
  await page.reload();await page.evaluate(theme=>document.documentElement.dataset.theme=theme,theme);await page.getByRole('button',{name:'Приложение',exact:true}).click();await panel.scrollIntoViewIfNeeded();
  assert.equal(await panel.getByRole('checkbox',{name:'Включён',exact:true}).isChecked(),false);assert.equal(await slider.inputValue(),'35');assert.equal(await panel.getByRole('checkbox',{name:'Печать завершена',exact:true}).isChecked(),false);
  await panel.getByRole('checkbox',{name:'Включён',exact:true}).check();
  await panel.getByRole('button',{name:'Послушать ошибку',exact:true}).click();await panel.getByRole('status').filter({hasText:'Ошибка печати'}).waitFor();
  const layout=await panel.evaluate(element=>{const area=element.closest('.systemPanel');const b=element.getBoundingClientRect();return {scroll:area.scrollWidth,width:area.clientWidth,left:b.left,right:b.right,viewport:innerWidth}});
  assert.ok(layout.scroll<=layout.width+1&&layout.left>=0&&layout.right<=layout.viewport+1,JSON.stringify(layout));
  assert.equal(await page.evaluate(()=>document.documentElement.dataset.theme),theme);
  const skin=await panel.evaluate(element=>{const style=getComputedStyle(element.closest('.systemPanel'));return {clip:style.clipPath,radius:parseFloat(style.borderRadius)}});assert.equal(skin.clip,'none');assert.ok(skin.radius>=12);
  if(shots)await page.screenshot({path:path.join(shots,`sound-settings-${theme}-${width}.png`)});
  report.push({theme,width,realWebAudioGraph:true,differentEventTones:true,volume:35,mute:true,individualEvents:true,reopenPersisted:true,noHorizontalOverflow:true});await page.close();
 }
 assert.deepEqual(errors,[]);const result={passed:report.length,report,runtimeErrors:errors,scope:'Production SystemPanel and actual browser WebAudio; native notifications emulated, Windows mixer/minimization not tested.'};
 if(shots)fs.writeFileSync(path.join(shots,'sound-settings-ui.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
}finally{await browser?.close();await new Promise(resolve=>server?server.close(resolve):resolve());fs.rmSync(out,{recursive:true,force:true});}
