import {useState} from 'react';
import {createRoot} from 'react-dom/client';
import {PrinterFilesPanel} from '../src/components/PrinterFilesPanel';
import {PrinterSettings} from '../src/components/PrinterSettings';
import {MoonrakerClient} from '../src/lib/moonraker';
import {I18nProvider} from '../src/i18n';
import {AppDialogHost} from '../src/lib/appDialogs';
import {setAuthSession} from '../src/lib/auth';
import {analyzeGCodeByteChunks} from '../src/lib/gcodeAnalysis';
import type {PrinterModel} from '../src/types';
import '../src/styles.css';
const w=window as any,params=new URLSearchParams(location.search);
w.__calls=[];w.__options={hold:false,nativeDelay:0,changed:false,uploadFailure:false,rejectStart:false,recheckStarted:false};
w.__finish=[];w.__printed=0;w.__frames=[];w.__frameEvents=[];
let lastFrame=performance.now();function frame(){const now=performance.now();w.__frames.push(now-lastFrame);if(now-lastFrame>100)w.__frameEvents.push({gap:now-lastFrame,command:w.__calls.at(-1)?.command});lastFrame=now;requestAnimationFrame(frame)}requestAnimationFrame(frame);w.__resetFrames=()=>{w.__frames=[];w.__frameEvents=[];lastFrame=performance.now()};
const header='; printer_model = Creality K1C 2025\n; filament_type = PLA\n; nozzle_diameter = 0.4\nG90\nG1 X10 Y10 Z0.2\nG1 X20 Y20 E1\n';
let source=new TextEncoder().encode(header+'; harmless benchmark padding\n'.repeat(Number(params.get('mb')||0)*1024*1024/29));
const hash='a'.repeat(64),memory=new Map(),reads=new Map<string,number>();let counter=0;
setAuthSession({token:'test-only',user:{id:'admin',name:'Admin',role:'admin',enabled:true,createdAt:0}});
w.__TAURI_INTERNALS__={invoke:async(command:string,args:any={})=>{
 w.__calls.push({command,args:{...args,data:undefined,dataLength:args.data?.length}});
 if(command==='db_get_json')return memory.get(args.key)||null;
 if(command==='db_set_json'){memory.set(args.key,args.value);return null}
 if(command==='audit_add')return null;
 if(command==='local_library_merge_scopes')return {moved:0,renamed:0,duplicates:0,conflicts:0};
 if(command==='local_library_list')return {files:[{path:'calibration_cube.gcode',size:source.length,modified:Date.now()},{path:'Samples/benchy.gcode',size:1024,modified:Date.now()}],legacyFiles:0,legacySize:0};
 if(command==='local_library_read_preview_text')return header;
 if(command==='local_library_read_begin'){const readId='read-'+(++counter);reads.set(readId,counter);return {readId,size:source.length,chunkSize:512*1024}}
 if(command==='local_library_read_chunk'){
  const end=Math.min(source.length,args.offset+512*1024),done=end===source.length;
  return {data:Array.from(source.subarray(args.offset,end)),nextOffset:end,done,sha256:done?(w.__options.changed&&reads.get(args.readId)!==1?'b'.repeat(64):hash):undefined};
 }
 if(command==='local_library_read_abort')return true;
 if(command==='local_library_upload_to_printer'){
  if(args.expectedSha256!==hash||w.__options.changed)throw new Error('G-code изменился после проверки. Запустите проверку повторно');
  if(w.__options.uploadFailure)throw new Error('Upload HTTP 500: upload file fail');
  if(w.__options.hold)return new Promise((resolve,reject)=>w.__finish.push({resolve:()=>resolve('calibration_cube.gcode'),reject}));
  if(w.__options.nativeDelay)await new Promise(resolve=>setTimeout(resolve,w.__options.nativeDelay));
  return 'calibration_cube.gcode';
 }
 throw new Error('Unexpected file fixture command '+command);
}};
const printer:PrinterModel={id:'printer-0',name:'Creality K1C 2025',host:'192.168.1.105:7125',icon:'k1c',webcams:[],status:{state:'ready',connectionState:'online',progress:0,printDuration:0,nozzle:0,nozzleTarget:0,bed:0,bedTarget:0},profile:{preset:'creality-k1c-2025',bedX:220,bedY:220,maxZ:250,nozzle:.4,materials:['PLA','PETG'],enclosed:true},modelSelection:{mode:'manual',selectedPreset:'creality-k1c-2025',source:'manual',lastDetection:{decision:'conflict',status:'ambiguous',model:'custom',confidence:'low',score:78,margin:62,fingerprint:'test-fingerprint',engineVersion:6,candidates:[{model:'flashforge-ad5m',score:78},{model:'creality-k1c-2025',score:16},{model:'creality-k1-max',score:16}],evidence:[],conflicts:[{id:'geometry-mismatch'}]} as any}};
const client=new MoonrakerClient(printer);
client.fileEntries=async()=>[];client.metadata=async()=>({filename:'calibration_cube.gcode'});
client.start=async(filename,options)=>{w.__calls.push({command:'print.start',args:{filename,options}});w.__printed++;if(w.__options.rejectStart)throw new Error('Confirmation timeout');return 'ok'};
client.checkPrintStart=async(filename)=>{w.__calls.push({command:'print.check',args:{filename}});return {confirmed:!!w.__options.recheckStarted,state:w.__options.recheckStarted?'printing':'standby',filename:w.__options.recheckStarted?filename:'',message:''}};
client.enqueue=async(paths)=>{w.__calls.push({command:'queue.add',args:{paths}});return {}};
function Fixture(){
 const [current,setCurrent]=useState(printer),[open,setOpen]=useState(true);
 w.__patchPrinter=(patch:Partial<PrinterModel>)=>setCurrent(value=>({...value,...patch}));
 w.__close=()=>setOpen(false);
 w.__parserBenchmark=async(mb=20)=>{
  const block=new TextEncoder().encode('G1 X10 Y20 E0.1\n'.repeat(4096));
  async function* chunks(){for(let i=0;i<Math.ceil(mb*1024*1024/block.length);i++)yield block}
  await new Promise(requestAnimationFrame);w.__resetFrames();const start=performance.now();const result=await analyzeGCodeByteChunks(chunks());
  await new Promise(resolve=>setTimeout(resolve,50));return {duration:performance.now()-start,frames:w.__frames.length,maxFrameGap:Math.max(...w.__frames),moves:result.bounds};
 };
 return !open?<button onClick={()=>setOpen(true)}>Открыть окно</button>:params.get('view')==='settings'?<PrinterSettings printer={current} onSave={async value=>{w.__saved=value}} onDelete={async()=>{}} onClose={()=>setOpen(false)}/>:<PrinterFilesPanel printer={current} printers={[current]} client={client} canOperate={true} onClose={()=>setOpen(false)}/>;
}
createRoot(document.getElementById('root')!).render(<I18nProvider><AppDialogHost><Fixture/></AppDialogHost></I18nProvider>);
