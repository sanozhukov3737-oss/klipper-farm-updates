import './system-panel-fixture';
import { installNotificationSound, playNotificationSound } from '../src/lib/notificationSound';

const w = window as any;
const NativeAudio = window.AudioContext;
w.__voices = [];
class ObservedAudio extends NativeAudio {
  createOscillator() {
    const oscillator = super.createOscillator(), entry: { frequency?: number; started?: boolean; stopped?: boolean } = {};
    w.__voices.push(entry);
    const set = oscillator.frequency.setValueAtTime.bind(oscillator.frequency);
    oscillator.frequency.setValueAtTime = (value, time) => { entry.frequency = value; return set(value, time); };
    const start = oscillator.start.bind(oscillator), stop = oscillator.stop.bind(oscillator);
    oscillator.start = (when) => { entry.started = true; start(when); };
    oscillator.stop = (when) => { entry.stopped = true; stop(when); };
    return oscillator;
  }
}
window.AudioContext = ObservedAudio;
installNotificationSound();
w.__printSound = playNotificationSound;
