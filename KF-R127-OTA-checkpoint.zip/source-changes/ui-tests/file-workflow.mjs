import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import http from 'node:http';
import {build} from 'vite';
const root=path.resolve(import.meta.dirname,'..'),out=fs.mkdtempSync(path.join(os.tmpdir(),'kf-file-workflow-'));
const {chromium}=await import(process.env.PLAYWRIGHT_MODULE_PATH??'playwright');
await build({root,logLevel:'warn',build:{outDir:out,emptyOutDir:true,rollupOptions:{input:path.join(root,'ui-tests/file-workflow.html')}}});
const server=http.createServer((req,res)=>{const file=path.resolve(out,new URL(req.url,'http://localhost').pathname.slice(1));if(!file.startsWith(out+path.sep)||!fs.existsSync(file)){res.writeHead(404);res.end();return}res.setHeader('Content-Type',({'.js':'text/javascript','.css':'text/css','.html':'text/html','.png':'image/png'})[path.extname(file)]??'application/octet-stream');res.end(fs.readFileSync(file))});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_EXECUTABLE,args:['--no-sandbox','--disable-dev-shm-usage']});
const url=`http://127.0.0.1:${server.address().port}/ui-tests/file-workflow.html`;
const report=[];const screen=process.env.KF_UI_SCREENSHOTS;if(screen)fs.mkdirSync(screen,{recursive:true});
async function within(page,selector){const bad=await page.locator(selector).evaluateAll(els=>els.flatMap(el=>{const r=el.getBoundingClientRect();return r.x<-.5||r.right>innerWidth+.5||el.scrollWidth>el.clientWidth+2?[{selector:el.className,x:r.x,right:r.right,sw:el.scrollWidth,cw:el.clientWidth}]:[]}));assert.deepEqual(bad,[],selector+' overflow')}
async function openLocal(page,params=''){await page.goto(url+'?view=files'+params);await page.locator('.printerFilesSourceTabs>button').nth(1).click();await page.locator('.localFileCard').first().waitFor()}
async function prepare(page,queue=false){await page.locator('.localFileCard').first().getByRole('button',{name:queue?'В очередь':'Печать',exact:true}).click();await page.locator('.printerFileDialog').waitFor({timeout:30000})}
async function confirm(page){await page.locator('.printerFileDialog>footer .primary').click()}
async function options(page,value){await page.evaluate(value=>Object.assign(window.__options,value),value)}
async function calls(page,command){return page.evaluate(command=>window.__calls.filter(x=>x.command===command),command)}
try{
 for(const theme of (process.env.KF_FILE_WORKFLOW_ONLY?[]:['dark','light']))for(const [width,height] of [[1920,1200],[1536,960],[1366,768],[1093,614],[910,512],[768,1024],[390,844]])for(const view of ['settings','files']){
  const page=await browser.newPage({viewport:{width,height},locale:'ru-RU'}),errors=[];page.on('pageerror',e=>errors.push(e.message));
  if(view==='settings'){
   await page.goto(url+'?view=settings');await page.evaluate(theme=>document.documentElement.dataset.theme=theme,theme);
   await within(page,'.printerSetup, .printerSetup .field, .printerSetup .modelDetectionControls, .printerSetup .modelCandidateList, .printerSetupActions');
   const inputs=await page.locator('.printerSetup .field :is(input,select)').evaluateAll(els=>els.map(el=>({clip:getComputedStyle(el).clipPath,radius:parseFloat(getComputedStyle(el).borderRadius),bg:getComputedStyle(el).backgroundColor})));for(const s of inputs){assert.equal(s.clip,'none');assert.ok(s.radius>=8);assert.notEqual(s.bg,'rgb(3, 12, 20)')}
   const footer=await page.locator('.printerSetupActions').boundingBox(),body=await page.locator('.printerSetupLayout').boundingBox();assert.ok(body.y+body.height<=footer.y+1,'footer overlays body');assert.ok(footer.y+footer.height<=height+1);
   await page.getByText('Материалы',{exact:true}).scrollIntoViewIfNeeded();const field=await page.getByText('Материалы',{exact:true}).boundingBox();assert.ok(field.y+field.height<=footer.y,'last fields inaccessible');
   await page.locator('.printerSetupLayout').evaluate(el=>el.scrollTop=0);
   assert.ok((await page.locator('.modelDetectionReport strong').textContent()).includes('вручную'));
   if(screen&&width===1536)await page.screenshot({path:path.join(screen,theme+'-printer-settings.png')});
   await page.getByLabel('Название в Klipper Farm').fill('Тестовый принтер');await page.getByRole('button',{name:'Сохранить настройки'}).click();await page.waitForFunction(()=>window.__saved?.name==='Тестовый принтер');
  }else{
   await openLocal(page);await page.evaluate(theme=>document.documentElement.dataset.theme=theme,theme);
   await within(page,'.printerFilesPanel,.localLibraryHero,.localLibraryImport,.localLibraryToolbar,.localFileCard');
   assert.equal(await page.locator('.localLibraryImport').evaluate(el=>getComputedStyle(el).borderStyle),'solid');
   await prepare(page);await within(page,'.printerFileDialog,.printerFileDialog>footer button');
   assert.equal(await page.locator('.printerFileDialog').evaluate(el=>getComputedStyle(el).clipPath),'none');
   await options(page,{hold:true});await confirm(page);await page.locator('.printerFileTransfer').waitFor();
   await page.locator('.printerFileTransfer').getByRole('button',{name:'Отменить действие',exact:true}).waitFor();
   await within(page,'.printerFileDialog,.printerFileTransfer');
   if(screen&&width===1536)await page.screenshot({path:path.join(screen,theme+'-file-transfer.png')});
   await page.locator('.printerFileTransfer').getByRole('button',{name:'Отменить действие',exact:true}).click();await page.evaluate(()=>window.__finish.splice(0).forEach(x=>x.resolve()));await page.locator('.printerFileOperationError').waitFor();assert.equal((await calls(page,'print.start')).length,0);
  }
  assert.deepEqual(errors,[]);await page.close();report.push({theme,width,height,view,status:'passed'});console.log('PASS layout '+theme+' '+width+' '+view);
 }
 for(const test of ['normal-start','queue','duplicate-click','cancel-upload','changed-source','native-upload-failure','offline-before-launch','switch-same-model','close-during-transfer','start-unknown','large-file','parser-20mb'].filter(test=>!process.env.KF_FILE_TEST||test===process.env.KF_FILE_TEST)){
  const page=await browser.newPage({viewport:{width:1536,height:960}}),errors=[];page.on('pageerror',e=>errors.push(e.message));
  await openLocal(page,test==='large-file'?'&mb=20':'');
  if(test==='parser-20mb'){
   const result=await page.evaluate(()=>window.__parserBenchmark(20));assert.ok(result.frames>5,'parser blocked animation');assert.ok(result.maxFrameGap<250,'parser long frame '+JSON.stringify(result));report.push({test,result,status:'passed'});await page.close();continue;
  }
  await page.evaluate(()=>window.__resetFrames());
  await prepare(page,test==='queue');
  assert.equal(await page.locator('.printerFileDialog>header b').textContent(),'Проверка G-code пройдена');
  if(['cancel-upload','offline-before-launch','switch-same-model','close-during-transfer','duplicate-click'].includes(test))await options(page,{hold:true});
  if(test==='changed-source')await options(page,{changed:true});
  if(test==='native-upload-failure')await options(page,{uploadFailure:true});
  if(test==='start-unknown')await options(page,{rejectStart:true});
  if(test==='large-file')await options(page,{nativeDelay:150});
  await confirm(page);
  if(test==='duplicate-click'){
   await page.locator('.printerFileDialog>footer .primary').evaluate(el=>{el.click();el.click()});
   await page.waitForFunction(()=>window.__finish.length>0);await page.evaluate(()=>window.__finish.splice(0).forEach(x=>x.resolve()));
  }else if(test==='cancel-upload'){
   await page.waitForFunction(()=>window.__finish.length>0);
   await page.locator('.printerFileTransfer').getByRole('button',{name:'Отменить действие',exact:true}).click();
   await page.getByText('Действие отменено. Ожидаем завершения передачи…',{exact:true}).waitFor();
   assert.ok(await page.locator('.printerFileDialog>footer .primary').isDisabled(),'in-flight native transfer was released early');
   assert.equal((await calls(page,'print.start')).length,0);assert.equal((await calls(page,'transactional_upload_abort')).length,0);
   await page.evaluate(()=>window.__finish.splice(0).forEach(x=>x.resolve()));
   await page.locator('.printerFileOperationError').waitFor();assert.equal((await calls(page,'print.start')).length,0);
  }else if(test==='offline-before-launch'){
   await page.waitForFunction(()=>window.__finish.length>0);await page.evaluate(()=>{window.__patchPrinter({status:{state:'offline',connectionState:'offline',nozzle:0,nozzleTarget:0,bed:0,bedTarget:0}});setTimeout(()=>window.__finish.splice(0).forEach(x=>x.resolve()),50)});
   await page.locator('.printerFileOperationError').waitFor();assert.equal((await calls(page,'print.start')).length,0);
  }else if(test==='switch-same-model'||test==='close-during-transfer'){
   await page.waitForFunction(()=>window.__finish.length>0);
   await page.evaluate(test=>test==='close-during-transfer'?window.__close():window.__patchPrinter({id:'other-printer',host:'192.168.1.104:7125'}),test);
   await page.evaluate(()=>window.__finish.splice(0).forEach(x=>x.resolve()));
   await page.waitForTimeout(100);assert.equal((await calls(page,'print.start')).length,0);
  }else if(test==='changed-source'||test==='native-upload-failure'){
   await page.locator('.printerFileOperationError').waitFor();assert.equal((await calls(page,'print.start')).length,0);
   assert.equal(await page.locator('.printerFileDialog>header b').textContent(),'Отправка не завершена');
   assert.equal((await calls(page,'local_library_upload_to_printer')).length,1);
   assert.equal((await calls(page,'transactional_upload_finish')).length,0);
   if(test==='native-upload-failure')assert.ok((await page.locator('.printerFileOperationError').textContent()).includes('Upload HTTP 500'));
  }else if(test==='start-unknown'){
   await page.locator('.printerFileOperationError').waitFor();assert.equal(await page.locator('.printerFileDialog>header b').textContent(),'Запуск не подтверждён');assert.equal((await calls(page,'print.start')).length,1);
   const check=page.getByRole('button',{name:'Проверить состояние',exact:true});assert.ok(await check.isEnabled());
   await check.click();await page.getByText(/Запуск пока не подтверждён/).waitFor();
   assert.equal((await calls(page,'print.start')).length,1);assert.equal((await calls(page,'local_library_upload_to_printer')).length,1);
   await options(page,{recheckStarted:true});await check.click();await page.locator('.printerFileDialog').waitFor({state:'detached'});
   assert.equal((await calls(page,'print.check')).length,2);assert.equal((await calls(page,'print.start')).length,1);
  }
  if(['normal-start','queue','duplicate-click','large-file'].includes(test)){
   await page.locator('.printerFileDialog').waitFor({state:'detached',timeout:45000});assert.equal((await calls(page,test==='queue'?'queue.add':'print.start')).length,1);
   const uploads=await calls(page,'local_library_upload_to_printer');assert.equal(uploads.length,1);assert.equal((await calls(page,'transactional_upload_begin')).length,0);
   if(test==='large-file'){assert.equal(uploads[0].args.dataLength,undefined,'large local library file crossed WebView IPC as bytes');const frames=await page.evaluate(()=>({max:Math.max(...window.__frames),count:window.__frames.length,longFrames:window.__frameEvents}));assert.ok(frames.count>5);assert.ok(frames.max<400,'large-file frame '+JSON.stringify(frames));report.push({test,bytes:20*1024*1024,nativeUploads:uploads.length,frames,status:'passed'});await page.close();continue}
  }
  assert.deepEqual(errors,[]);report.push({test,status:'passed'});console.log('PASS workflow '+test);await page.close();
 }
 console.log(JSON.stringify({passed:report.length,report},null,2));
}finally{await browser.close();await new Promise(resolve=>server.close(resolve));fs.rmSync(out,{recursive:true,force:true})}
