import type { PrinterModel, Spool } from '../types';
import { calculatedFilamentGrams, filamentDayKey, type FilamentInventory } from './filamentInventory';
import { filamentUsageInPeriod } from './filamentAnalytics';
import { jobFreshness } from './printerTelemetry';
import { tvPrinterState } from './tvDashboard';

export type TvFilamentStats = {
  currentLabel: string;
  currentHint: string;
  todayLabel: string;
  todayHint: string;
  totalLabel: string;
  totalHint: string;
  materialLabel: string;
  spoolLabel: string;
  spoolHint: string;
  spoolColor?: string;
  spoolFraction?: number;
  boundSpool?: Spool;
  spoolDiameter?: number;
  weeklyDays: { key: string; label: string; grams: number | null; today: boolean }[];
  weeklyLabel: string;
  weeklyHint: string;
};

const nonnegative = (value: unknown): value is number => typeof value === 'number' && Number.isFinite(value) && value >= 0;
const number = (value: number, maximumFractionDigits: number) => new Intl.NumberFormat('ru-RU', { maximumFractionDigits }).format(value);
const weight = (grams: number) => grams >= 1000 ? `${number(grams / 1000, 2)} кг` : `${number(grams, grams < 10 ? 1 : 0)} г`;
const length = (mm: number) => `${number(mm / 1000, 2)} м`;

/** Presentation only: live extrusion never writes to, or pre-debits, the ledger. */
export function tvFilamentStats(printer: PrinterModel, inventory: FilamentInventory | undefined, now = Date.now()): TvFilamentStats {
  const result: TvFilamentStats = {
    currentLabel: '—', currentHint: 'Нет свежих данных о расходе',
    todayLabel: '—', todayHint: 'Учтённые списания за сегодня',
    totalLabel: '—', totalHint: 'С начала учёта в приложении',
    materialLabel: 'Пластик не выбран', spoolLabel: '—', spoolHint: 'Катушка не выбрана',
    weeklyDays: [], weeklyLabel: '—', weeklyHint: 'Нет истории учёта за эти дни',
  };
  const account = inventory?.printers[printer.id], binding = account?.binding;
  const material = binding && inventory?.materials[binding.material];
  if (binding) {
    result.materialLabel = binding.material;
    if (!binding.spoolId) {
      result.spoolLabel = 'Общий запас';
      result.spoolHint = `Без отдельной катушки · ${binding.material}`;
    } else {
      const spool = inventory?.spools.find(row => row.id === binding.spoolId && row.material === binding.material);
      if (spool && nonnegative(spool.remainingWeight)) {
        result.spoolLabel = weight(spool.remainingWeight);
        result.spoolHint = `${spool.name} · учтённый остаток`;
        if (/^#[\da-f]{3}(?:[\da-f]{3})?$/i.test(spool.color ?? '')) result.spoolColor = spool.color;
        if (nonnegative(spool.initialWeight) && spool.initialWeight > 0) {
          result.spoolFraction = Math.max(0, Math.min(1, spool.remainingWeight / spool.initialWeight));
          result.boundSpool = spool;
          if (material && Number.isFinite(material.diameter) && material.diameter >= .5 && material.diameter <= 4) result.spoolDiameter = material.diameter;
        }
      }
    }
  }
  if (account && nonnegative(account.usedGrams)) result.totalLabel = weight(account.usedGrams);
  const day = filamentDayKey(now), history = inventory?.usageHistory;
  if (inventory && account && history && Number.isFinite(history.startedAt) && history.startedAt <= now) {
    const today = filamentUsageInPeriod(inventory, day, day)[printer.id] ?? 0;
    if (nonnegative(today)) result.todayLabel = weight(today);
  }

  const today = new Date(now);
  today.setHours(0, 0, 0, 0);
  const firstDay = new Date(today);
  firstDay.setDate(firstDay.getDate() - 6);
  const bindingDates = account ? [...account.bindings, ...(binding ? [binding] : [])]
    .map(row => row.effectiveAt).filter(value => Number.isFinite(value) && value > 0 && value <= now) : [];
  const printerTrackingAt = account && Number.isFinite(account.trackingAt) && account.trackingAt! > 0
    ? account.trackingAt! : bindingDates.length ? Math.min(...bindingDates) : undefined;
  const coverageStart = history && Number.isFinite(history.startedAt) && history.startedAt > 0 && history.startedAt <= now && printerTrackingAt !== undefined && printerTrackingAt <= now
    ? Math.max(history.startedAt, printerTrackingAt) : undefined;
  const recordedDays = new Set(history?.days.filter(row => row.printerId === printer.id).map(row => row.day) ?? []);
  let recordedOutsideCoverage = false;
  result.weeklyDays = Array.from({ length: 7 }, (_, index) => {
    // Local calendar arithmetic avoids repeating or skipping a day across DST.
    const date = new Date(firstDay);
    date.setDate(date.getDate() + index);
    const followingDay = new Date(date);
    followingDay.setDate(followingDay.getDate() + 1);
    const key = filamentDayKey(date.getTime());
    const covered = inventory && account && coverageStart !== undefined && coverageStart < followingDay.getTime();
    const recorded = !!account && recordedDays.has(key);
    // Resolving an older pending print may commit a dated row before automatic
    // tracking began. That real debit remains visible; neighbouring missing
    // dates still cannot become invented zero-usage days.
    if (recorded && !covered) recordedOutsideCoverage = true;
    const value = inventory && (covered || recorded) ? filamentUsageInPeriod(inventory, key, key)[printer.id] ?? 0 : undefined;
    return { key, label: date.toLocaleDateString('ru-RU', { weekday: 'short' }), grams: nonnegative(value) ? value : null, today: key === day };
  });
  const knownDays = result.weeklyDays.filter(row => row.grams !== null);
  if (knownDays.length) {
    result.weeklyLabel = weight(knownDays.reduce((sum, row) => sum + row.grams!, 0));
    result.weeklyHint = recordedOutsideCoverage ? 'Неполная история · учтённые списания'
      : coverageStart !== undefined && coverageStart > firstDay.getTime()
        ? `Учёт с ${new Date(coverageStart).toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })} · учтённые списания`
        : 'Учтённые списания за 7 дней';
  }

  const state = tvPrinterState(printer, now), status = printer.status;
  if ((state !== 'printing' && state !== 'paused') || status.connectionState !== 'online' || status.remoteControlSuspended || jobFreshness(status, now) !== 'live' || !nonnegative(status.filamentUsedMm)) return result;
  const usedMm = status.filamentUsedMm;
  result.currentLabel = length(usedMm);
  result.currentHint = 'Длина по данным принтера';
  // A new material binding in the middle of a print cannot explain the mass
  // extruded before that binding. Preserve the real length in that case.
  const startedAt = nonnegative(status.printDuration) ? now - status.printDuration * 1000 : undefined;
  const wholePrintMaterial = binding && !binding.baselinePending && !(binding.activeBaseline && binding.activeBaseline.usedMm > 0)
    && startedAt !== undefined && binding.effectiveAt <= startedAt;
  const materialParametersKnown = material && Number.isFinite(material.diameter) && material.diameter >= .5 && material.diameter <= 4
    && Number.isFinite(material.density) && material.density >= .1 && material.density <= 10;
  if (wholePrintMaterial && materialParametersKnown) {
    const grams = calculatedFilamentGrams(usedMm, material);
    if (grams !== undefined) {
      result.currentLabel = `≈ ${weight(grams)}`;
      result.currentHint = `${length(usedMm)} от принтера · вес рассчитан`;
    }
  }
  return result;
}
