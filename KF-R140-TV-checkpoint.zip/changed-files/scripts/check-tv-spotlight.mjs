import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import ts from './typescript-runtime.mjs';

const root=path.resolve(import.meta.dirname,'..'),modules=new Map();
const compile=filename=>{
  if(modules.has(filename))return modules.get(filename);
  const compiled=ts.transpileModule(fs.readFileSync(filename,'utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ES2022},fileName:filename,reportDiagnostics:true});
  assert.equal(compiled.diagnostics?.length??0,0,'TV spotlight helper TypeScript syntax');
  const source=compiled.outputText.replace(/from\s+(['"])(\.\/[^'"]+)\1/g,(_match,_quote,specifier)=>`from '${compile(path.resolve(path.dirname(filename),specifier+'.ts'))}'`);
  const url=`data:text/javascript;base64,${Buffer.from(source).toString('base64')}`;modules.set(filename,url);return url;
};
const {tvFilamentStats}=await import(compile(path.join(root,'src/lib/tvSpotlight.ts')));
const {emptyFilamentInventory,filamentDayKey}=await import(compile(path.join(root,'src/lib/filamentInventory.ts')));
const now=new Date(2026,9,25,16,35,0).getTime(),cases=[];
const check=(name,run)=>{run();cases.push({name,passed:true});console.log('PASS '+name)};
const printer=(extra={})=>({id:'p1',name:'K1 Max',host:'192.168.1.102',webcams:[],status:{state:'printing',connectionState:'online',filename:'part.gcode',progress:.54,printDuration:3600,nozzle:255,nozzleTarget:255,bed:80,bedTarget:80,telemetryUpdatedAt:now,jobUpdatedAt:now,filamentUsedMm:10000,...extra}});
const inventory=()=>{
  const value=emptyFilamentInventory(now-86400000);
  value.printers.p1={binding:{id:'b1',material:'PETG',spoolId:'s1',effectiveAt:now-7200000,baselinePending:false},bindings:[],status:'tracking',usedGrams:2345,calculatedGrams:2300,manualGrams:45,pendingJobs:0,lastMilestoneKg:2,byMaterial:{PETG:2345}};
  value.spools.push({id:'s1',name:'Катушка PETG',material:'PETG',initialWeight:1000,remainingWeight:684,color:'#287dd0',price:0,currency:'RUB',createdAt:now-86400000});
  value.usageHistory.days=[{day:filamentDayKey(now),printerId:'p1',material:'PETG',calculatedGrams:123,manualGrams:7},{day:filamentDayKey(now),printerId:'p2',material:'PETG',calculatedGrams:900,manualGrams:0},{day:filamentDayKey(now-86400000),printerId:'p1',material:'PETG',calculatedGrams:500,manualGrams:0}];
  return value;
};
check('reported length becomes explicitly approximate configured mass',()=>{const r=tvFilamentStats(printer(),inventory(),now);assert.match(r.currentLabel,/^≈ 31 г$/);assert.match(r.currentHint,/10 м от принтера.*вес рассчитан/)});
check('daily and total use the exact printer ledger only',()=>{const r=tvFilamentStats(printer(),inventory(),now);assert.equal(r.todayLabel,'130 г');assert.equal(r.totalLabel,'2,35 кг');assert.match(r.totalHint,/С начала учёта в приложении/)});
check('spool balance remains the confirmed ledger value during extrusion',()=>{const data=inventory();const first=tvFilamentStats(printer(),data,now),second=tvFilamentStats(printer({filamentUsedMm:20000}),data,now);assert.equal(first.spoolLabel,'684 г');assert.equal(second.spoolLabel,'684 г');assert.equal(first.spoolFraction,.684);assert.equal(first.spoolColor,'#287dd0');assert.match(first.spoolHint,/учтённый остаток/)});
check('missing ledger preserves real metres without inventing historical zero',()=>{const r=tvFilamentStats(printer(),undefined,now);assert.equal(r.currentLabel,'10 м');assert.equal(r.todayLabel,'—');assert.equal(r.totalLabel,'—');assert.equal(r.spoolLabel,'—')});
check('untracked printer never borrows another printer totals',()=>{const r=tvFilamentStats({...printer(),id:'untracked'},inventory(),now);assert.equal(r.todayLabel,'—');assert.equal(r.totalLabel,'—');assert.equal(r.materialLabel,'Пластик не выбран')});
check('missing dated history cannot become today zero',()=>{const data=inventory();delete data.usageHistory;const r=tvFilamentStats(printer(),data,now);assert.equal(r.todayLabel,'—');assert.equal(r.totalLabel,'2,35 кг')});
check('known tracked empty day is a genuine zero',()=>{const data=inventory();data.usageHistory.days=[];assert.equal(tvFilamentStats(printer(),data,now).todayLabel,'0 г')});
check('future history start is not treated as tracked day',()=>{const data=inventory();data.usageHistory.startedAt=now+60000;assert.equal(tvFilamentStats(printer(),data,now).todayLabel,'—')});
check('unknown configured material parameters retain reported metres',()=>{const data=inventory();delete data.materials.PETG;assert.equal(tvFilamentStats(printer(),data,now).currentLabel,'10 м')});
check('pending initial baseline cannot assign mass to an entire old print',()=>{const data=inventory();data.printers.p1.binding.baselinePending=true;assert.equal(tvFilamentStats(printer(),data,now).currentLabel,'10 м')});
check('mid-print material binding preserves length rather than guessing mass',()=>{const data=inventory();data.printers.p1.binding.effectiveAt=now-60000;assert.equal(tvFilamentStats(printer(),data,now).currentLabel,'10 м')});
check('material baseline with previous extrusion cannot convert entire print',()=>{const data=inventory();data.printers.p1.binding.activeBaseline={jobKey:'job',startTime:now-3600000,usedMm:5000,at:now-60000};assert.equal(tvFilamentStats(printer(),data,now).currentLabel,'10 м')});
check('fresh paused print can retain its measured usage',()=>{assert.match(tvFilamentStats(printer({state:'paused'}),inventory(),now).currentLabel,/^≈ /)});
check('missing or invalid extrusion is unknown, real zero is retained',()=>{for(const filamentUsedMm of[undefined,NaN,Infinity,-1])assert.equal(tvFilamentStats(printer({filamentUsedMm}),inventory(),now).currentLabel,'—');assert.equal(tvFilamentStats(printer({filamentUsedMm:0}),inventory(),now).currentLabel,'≈ 0 г')});
check('inactive, offline, suspended, shutdown and stale jobs never look live',()=>{for(const extra of[{state:'ready'},{connectionState:'offline'},{connectionState:'degraded'},{remoteControlSuspended:true},{klippyState:'shutdown'},{state:'error'},{jobUpdatedAt:now-20001},{jobUpdatedAt:undefined}])assert.equal(tvFilamentStats(printer(extra),inventory(),now).currentLabel,'—')});
check('unmounted stock does not invent a separate spool balance',()=>{const data=inventory();delete data.printers.p1.binding.spoolId;const r=tvFilamentStats(printer(),data,now);assert.equal(r.spoolLabel,'Общий запас');assert.equal(r.spoolFraction,undefined)});
check('missing or wrong material spool stays unavailable',()=>{for(const mutate of[data=>{data.spools=[]},data=>{data.spools[0].material='ABS'}]){const data=inventory();mutate(data);const r=tvFilamentStats(printer(),data,now);assert.equal(r.spoolLabel,'—');assert.equal(r.spoolFraction,undefined)}});
check('empty spool is a genuine zero and fraction is bounded',()=>{const data=inventory();data.spools[0].remainingWeight=0;assert.equal(tvFilamentStats(printer(),data,now).spoolLabel,'0 г');assert.equal(tvFilamentStats(printer(),data,now).spoolFraction,0);data.spools[0].remainingWeight=1500;assert.equal(tvFilamentStats(printer(),data,now).spoolFraction,1)});
check('invalid spool colour is not forwarded into CSS',()=>{const data=inventory();data.spools[0].color='url(https://example.invalid)';assert.equal(tvFilamentStats(printer(),data,now).spoolColor,undefined)});
check('projection never mutates the source printer or inventory',()=>{const data=inventory(),p=printer(),before=JSON.stringify({data,p});for(let i=0;i<30;i++)tvFilamentStats(p,data,now+i*100);assert.equal(JSON.stringify({data,p}),before)});
const report={passed:cases.length,cases,scope:'Read-only TV projections from fresh printer telemetry and existing filament ledger; no physical printer or stock writes.'};
if(process.env.KF_TV_SPOTLIGHT_PROOF){const target=path.resolve(process.env.KF_TV_SPOTLIGHT_PROOF);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,JSON.stringify(report,null,2)+'\n')}
console.log(JSON.stringify(report));
