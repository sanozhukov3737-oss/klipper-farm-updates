import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import http from 'node:http';
import { createHash } from 'node:crypto';
import { build } from 'vite';

const root = path.resolve(import.meta.dirname, '..');
const out = fs.mkdtempSync(path.join(os.tmpdir(), 'kf-tv-spotlight-r140-'));
const proof = path.resolve(process.env.KF_R140_TV_PROOF_DIR || process.env.KF_UI_SCREENSHOTS || path.join(root, '../r140-tv-proof'));
const reportPath = path.resolve(process.env.KF_R140_TV_UI_PROOF || path.join(proof, 'tv-spotlight-r140-report.json'));
const cases = [], runtimeErrors = [], externalRequests = [];
const cameraRequests = new WeakMap();
const sourceFiles = ['src/components/TvDashboard.tsx', 'src/components/TvDashboard.css', 'src/lib/tvSpotlight.ts'];
const sourceHashes = () => Object.fromEntries(sourceFiles.map(name => [name, createHash('sha256').update(fs.readFileSync(path.join(root, name))).digest('hex')]));
const productionSources = sourceHashes();
let browser, server, currentPage, currentCase = 'initialization';
const approx = (actual, expected, tolerance, label) => assert.ok(Math.abs(actual - expected) <= tolerance, `${label}: ${actual}, expected ${expected} ± ${tolerance}`);
const grams = label => {
  const text = label.replaceAll(/[\s\u00a0\u202f]/g, '').replace(',', '.').replace(/^≈/, '');
  const number = parseFloat(text); assert.ok(Number.isFinite(number), 'Expected numeric mass, got ' + label);
  return text.includes('кг') ? number * 1000 : number;
};
const activeId = page => page.locator('.tvSpotlight').getAttribute('data-printer-id');
const single = async page => assert.equal(await page.locator('.tvSpotlight').count(), 1, 'Exactly one printer article must be mounted');
const stat = (page, name) => page.locator(`.tvSpotlightStats .tvStat[data-stat="${name}"] strong`);
const cameraReady = async page => {
  await page.locator('.tvSpotlightCamera[data-ready="true"] img').waitFor();
  await page.waitForFunction(() => document.querySelector('.tvSpotlightCamera img')?.complete && document.querySelector('.tvSpotlightCamera img')?.naturalWidth > 0);
};
const waitForRendererBoundary = async (page, predicate, label) => {
  // The browser's real IntersectionObserver/module loader is independent of
  // the intentionally paused application clock used by the slide tests.
  const deadline = Date.now() + 10_000;
  while (Date.now() < deadline) {
    if (await page.evaluate(predicate)) return;
    await new Promise(resolve => setTimeout(resolve, 20));
  }
  throw new Error(label + ': ' + JSON.stringify(await page.evaluate(() => window.__tvFixture.thumbnailStats())));
};
const approvedSpool = async page => {
  // Only screenshot cases advance rendering time. Exact slide-deadline cases
  // retain a frozen t=0 until their explicit clock assertions below.
  const stage = page.locator('.tvSpotlightStage'), previousScroll = await stage.evaluate(element => element.scrollTop);
  await page.locator('.tvSpoolFeature [data-spool-thumbnail="true"]').scrollIntoViewIfNeeded();
  await waitForRendererBoundary(page, () => { const state = window.__tvFixture.thumbnailStats(); return state.pending > 0 || state.cached > 0 || state.unavailable; }, 'Thumbnail observer did not admit a visible spool');
  await page.clock.runFor(150);
  const image = page.locator('.tvSpoolFeature [data-thumbnail-cached="true"] > img');
  await image.waitFor();
  await page.waitForFunction(() => { const image = document.querySelector('.tvSpoolFeature [data-thumbnail-cached="true"] > img'); return image instanceof HTMLImageElement && image.complete && image.naturalWidth > 0; });
  await stage.evaluate((element, previous) => { element.scrollTop = previous; }, previousScroll);
  return image;
};
const select = async (page, id) => {
  const names = await page.evaluate(() => window.__tvFixture.printers().map(printer => ({ id: printer.id, name: printer.name })));
  const printer = names.find(value => value.id === id); assert.ok(printer, 'Fixture printer exists');
  await page.getByRole('button', { name: 'Показать ' + printer.name, exact: true }).click();
  await page.waitForFunction(expected => document.querySelector('.tvSpotlight')?.getAttribute('data-printer-id') === expected, id);
  await single(page);
};
const geometry = async page => {
  const diagnostics = await page.evaluate(() => {
    const selectors = ['.tvDashboard', '.tvDashboardHead', '.tvSpotlight', '.tvSpotlightInfo', '.tvSpotlightDetails', '.tvInsightRail', '.tvSpoolFeature', '.tvWeekUsage', '.tvWeekChart', '.tvSpotlightStats', '.tvStat', '.tvDashboardFoot'];
    const failed = selectors.flatMap(selector => Array.from(document.querySelectorAll(selector)).flatMap(element => {
      const box = element.getBoundingClientRect();
      return box.left < -.75 || box.right > innerWidth + .75 || element.scrollWidth > element.clientWidth + 2 ? [{ selector, box: box.toJSON(), clientWidth: element.clientWidth, scrollWidth: element.scrollWidth }] : [];
    }));
    const article = document.querySelector('.tvSpotlight');
    return { failed, article: article ? { height: article.clientHeight, scrollHeight: article.scrollHeight, box: article.getBoundingClientRect().toJSON() } : null };
  });
  assert.deepEqual(diagnostics.failed, [], 'TV horizontal overflow: ' + JSON.stringify(diagnostics.failed));
  if (await page.evaluate(() => innerWidth >= 1100 && innerHeight >= 700)) {
    assert.ok(diagnostics.article && diagnostics.article.scrollHeight <= diagnostics.article.height + 2, 'Desktop spotlight needs no internal scrolling: ' + JSON.stringify(diagnostics.article));
  }
};
const noTVWrites = async page => {
  const calls = await page.evaluate(() => window.__tvFixture.calls);
  assert.deepEqual(calls.filter(call => !['db_get_json'].includes(call.command)), [], 'TV must read existing state and never dispatch print, inventory or camera operations in the default view');
};
const passed = (name, details = {}) => { cases.push({ name, passed: true, ...details }); console.log('PASS ' + name); };
try {
  await build({ root, base: './', logLevel: 'error', build: { outDir: out, emptyOutDir: true, rollupOptions: { input: path.join(root, 'ui-tests/tv-spotlight-r140.html') } } });
  if (process.argv.includes('--build-only')) { console.log('TV spotlight fixture build passed'); }
  else {
    server = http.createServer((req, res) => {
      const file = path.resolve(out, new URL(req.url, 'http://localhost').pathname.slice(1));
      if (!file.startsWith(out + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) { res.writeHead(404).end(); return; }
      res.setHeader('Content-Type', ({ '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.webp': 'image/webp', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml' })[path.extname(file)] || 'application/octet-stream');
      res.end(fs.readFileSync(file));
    });
    await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
    const origin = 'http://127.0.0.1:' + server.address().port;
    const { chromium } = await import(process.env.PLAYWRIGHT_MODULE_PATH || 'playwright');
    browser = await chromium.launch({ headless: true, executablePath: process.env.CHROMIUM_EXECUTABLE, args: ['--no-sandbox', '--disable-dev-shm-usage', '--enable-unsafe-swiftshader'] });
    fs.mkdirSync(proof, { recursive: true });
    const open = async ({ theme = 'dark', width = 1920, height = 1080, count = 7, reducedMotion = 'reduce', history, spool, camera, webgl = true } = {}) => {
      const page = await browser.newPage({ viewport: { width, height }, locale: 'ru-RU', reducedMotion }); currentPage = page;
      const attempts = []; cameraRequests.set(page, attempts);
      page.on('request', request => { if (request.url().includes('/fixture-camera-failed.png')) attempts.push(request.url()); });
      page.setDefaultTimeout(10_000); page.on('pageerror', error => runtimeErrors.push(error.message));
      await page.route('**/*', route => { if (route.request().url().startsWith(origin + '/')) return route.continue(); externalRequests.push(route.request().url()); return route.abort(); });
      if (!webgl) await page.addInitScript(() => { const original = HTMLCanvasElement.prototype.getContext; HTMLCanvasElement.prototype.getContext = function(type, ...args) { if (/^webgl|^experimental-webgl/.test(type)) return null; return Reflect.apply(original, this, [type, ...args]); }; });
      await page.clock.install({ time: new Date('2026-10-25T12:00:00.000Z') });
      await page.clock.pauseAt(new Date('2026-10-25T12:00:01.000Z'));
      const query = new URLSearchParams({ theme, count: String(count), ...(history ? { history } : {}), ...(spool ? { spool } : {}), ...(camera ? { camera } : {}) });
      await page.goto(`${origin}/ui-tests/tv-spotlight-r140.html?${query}`);
      await page.getByRole('dialog', { name: 'TV-панель фермы', exact: true }).waitFor();
      if (count) { await single(page); await stat(page, 'today').waitFor(); await page.waitForFunction(() => window.__tvFixture.calls.some(call => call.command === 'db_get_json')); }
      return page;
    };
    for (const theme of ['dark', 'light']) for (const [width, height] of [[1920, 1080], [1366, 768], [390, 844]]) {
      currentCase = `layout-${theme}-${width}x${height}`;
      const page = await open({ theme, width, height });
      assert.equal(await activeId(page), 'printer-0');
      await page.waitForFunction(() => document.querySelector('.tvStat[data-stat="spool"] strong')?.textContent?.match(/[0-9]/));
      await approvedSpool(page);
      assert.equal(await page.getByRole('button', { name: 'Камеры', exact: true }).getAttribute('aria-pressed'), 'true', 'Configured cameras are enabled automatically');
      await cameraReady(page);
      assert.equal(await page.locator('.tvSpotlight').getAttribute('data-live-printing'), 'true');
      await geometry(page);
      if (width >= 1100) {
        const plots = await page.locator('.tvTemperatures [data-testid^="temperature-history-"]').evaluateAll(elements => elements.map(element => element.getBoundingClientRect().height));
        assert.equal(plots.length, 2); for (const height of plots) assert.ok(height >= 28, 'Actual temperature plots are enlarged on desktop');
      }
      if (width === 1920) {
        const typography = await page.locator('.tvSpotlightDetails').evaluate(element => ({ width: element.getBoundingClientRect().width, filename: parseFloat(getComputedStyle(element.querySelector('.tvSpotlightJob strong')).fontSize) }));
        assert.ok(typography.width >= 300 && typography.width <= 560, 'Central text occupies a compact column: ' + JSON.stringify(typography));
        assert.ok(typography.filename <= 24, 'Filename is compact instead of oversized: ' + JSON.stringify(typography));
      }
      approx(grams(await stat(page, 'current').innerText()), 30.55, .6, 'Current real extrusion converted with configured PETG');
      assert.match(await stat(page, 'current').innerText(), /≈/, 'Current mass must be marked as a calculation');
      approx(grams(await stat(page, 'today').innerText()), 127.5, .6, 'Today ledger usage');
      approx(grams(await stat(page, 'total').innerText()), 2345.6, 5, 'Cumulative app-accounted usage');
      approx(grams(await stat(page, 'spool').innerText()), 678.9, .6, 'Ledger spool remaining');
      assert.match(await page.locator('.tvSpotlight').innerText(), /PETG/);
      assert.ok(await page.locator('[data-testid="temperature-history-nozzle"]').count() > 0, 'Actual received temperature samples produce the sparkline');
      assert.equal(await page.locator('.tvSpotlightCamera').count(), 1, 'Default view mounts only the current configured camera');
      await noTVWrites(page);
      await page.screenshot({ path: path.join(proof, `tv-spotlight-${theme}-${width}x${height}.png`) });
      if (theme === 'dark' && width === 1920) {
        await page.getByRole('button', { name: 'Камеры', exact: true }).click();
        await page.locator('.tvSpotlightCamera').waitFor({ state: 'detached' }); await page.locator('.tvSpotlightArtwork').waitFor();
        await page.screenshot({ path: path.join(proof, 'tv-spotlight-approved-spool-artwork.png') });
      }
      await page.keyboard.press('Escape');
      await page.locator('.tvDashboard').waitFor({ state: 'detached' });
      assert.equal(await page.evaluate(() => window.__tvFixture.closed), 1);
      assert.notEqual(await page.evaluate(() => document.body.style.overflow), 'hidden');
      assert.equal(await page.evaluate(() => document.activeElement?.id), 'fixtureOpener', 'Close returns focus to the opening control');
      passed(currentCase, { actualComponent: true, syntheticNativeBoundary: true }); await page.close();
    }
    {
      currentCase = 'weekly-printer-only-values-and-installed-spool'; const page = await open();
      await page.locator('.tvWeekDay[data-known="true"]').nth(6).waitFor();
      const days = await page.locator('.tvWeekDay').evaluateAll(elements => elements.map(element => ({ grams: Number(element.getAttribute('data-grams')), known: element.getAttribute('data-known'), today: element.getAttribute('data-today'), label: element.getAttribute('aria-label'), role: element.getAttribute('role') })));
      assert.equal(days.length, 7); assert.deepEqual(days.map(day => day.grams), [32, 0, 87, 45, 110, 63, 127.5], 'Bars show this printer’s seven ledger days, including a genuine zero');
      assert.ok(days.every(day => day.known === 'true' && day.role === 'listitem'));
      assert.deepEqual(days.map(day => day.today), ['false', 'false', 'false', 'false', 'false', 'false', 'true']);
      assert.ok(days.every(day => /^2026-10-\d{2}/.test(day.label)), 'Accessible day labels retain their full calendar dates');
      approx(grams(await page.locator('.tvWeekUsage header strong').innerText()), 464.5, .6, 'Seven-day total includes only this printer’s ledger entries');
      const thumbnail = page.locator('.tvSpoolFeature [data-spool-thumbnail="true"]');
      await thumbnail.waitFor(); assert.equal(await thumbnail.count(), 1);
      assert.equal(await thumbnail.getAttribute('data-filament-color'), '#4a92d8');
      assert.equal(Number(await thumbnail.getAttribute('data-filament-grams')), 678.9, 'Installed spool visual receives the same confirmed remaining grams');
      assert.equal(await thumbnail.getAttribute('data-thumbnail-cached'), 'false', 'Before the real thumbnail worker runs the TV keeps a neutral placeholder');
      const visibleFallbacks = await thumbnail.locator('svg').evaluateAll(elements => elements.filter(element => getComputedStyle(element).display !== 'none' && getComputedStyle(element).visibility !== 'hidden').length);
      assert.equal(visibleFallbacks, 0, 'TV does not substitute the generic SVG for the approved spool');
      assert.match(await page.locator('.tvSpoolFeature').innerText(), /PETG/);
      await select(page, 'printer-1'); assert.equal(await page.locator('.tvWeekDay[data-known="true"]').count(), 0, 'Another printer never inherits this printer’s usage bars');
      assert.ok((await page.locator('.tvWeekDay').evaluateAll(elements => elements.map(element => element.getAttribute('data-grams')))).every(value => value === null), 'Untracked daily values remain absent');
      assert.equal(await page.locator('.tvSpoolFeature [data-spool-thumbnail="true"]').count(), 0, 'Another printer never inherits the bound spool');
      await noTVWrites(page); passed(currentCase); await page.close();
    }
    {
      currentCase = 'missing-week-history-and-no-bound-spool'; const page = await open({ history: 'missing', spool: 'none' });
      await stat(page, 'total').filter({ hasText: /2/ }).waitFor();
      assert.equal(await page.locator('.tvWeekDay').count(), 7);
      assert.equal(await page.locator('.tvWeekDay[data-known="false"]').count(), 7, 'Missing history renders seven unknown days');
      assert.equal(await page.locator('.tvWeekDay[data-grams]').count(), 0, 'Unknown days are not encoded as zero usage');
      const labels = await page.locator('.tvWeekDay').evaluateAll(elements => elements.map(element => element.getAttribute('aria-label')));
      assert.ok(labels.every(label => /Нет данных/.test(label)), 'Missing day data is stated in the accessible chart');
      await page.locator('.tvNoSpool').waitFor();
      assert.equal(await page.locator('.tvSpoolFeature [data-spool-thumbnail="true"]').count(), 0, 'No bound spool means no invented spool visual');
      assert.equal(await stat(page, 'spool').innerText(), 'Общий запас'); assert.equal(await stat(page, 'today').innerText(), '—');
      await noTVWrites(page); passed(currentCase); await page.close();
    }
    {
      currentCase = 'ten-second-autorotation-and-manual-wrap'; const page = await open();
      await page.clock.runFor(9000);
      await page.evaluate(() => window.__tvFixture.patchStatus('printer-0', { progress: .61, nozzle: 256, jobUpdatedAt: Date.now(), telemetryUpdatedAt: Date.now() }));
      await page.locator('[role="progressbar"][aria-valuenow="61"]').waitFor();
      await page.clock.runFor(900); assert.equal(await activeId(page), 'printer-0', 'No premature slide change');
      await page.clock.runFor(200); assert.equal(await activeId(page), 'printer-1', 'Next printer after ten seconds'); await single(page);
      await page.clock.runFor(6000); await select(page, 'printer-4');
      await page.clock.runFor(9900); assert.equal(await activeId(page), 'printer-4', 'Manual selection restarts the full interval');
      await page.clock.runFor(200); assert.equal(await activeId(page), 'printer-5');
      await select(page, 'printer-0'); await page.getByRole('button', { name: 'Предыдущий принтер', exact: true }).click(); assert.equal(await activeId(page), 'printer-6');
      await page.getByRole('button', { name: 'Следующий принтер', exact: true }).click(); assert.equal(await activeId(page), 'printer-0');
      assert.equal(await page.evaluate(() => window.__tvFixture.calls.filter(call => call.command === 'db_get_json').length), 1, 'Telemetry rerenders and rotations reuse the single inventory read');
      await noTVWrites(page); passed(currentCase); await page.close();
    }
    {
      currentCase = 'pause-resume-and-hidden-document'; const page = await open();
      await page.getByRole('button', { name: 'Приостановить смену принтеров', exact: true }).click();
      await page.clock.runFor(30_000); assert.equal(await activeId(page), 'printer-0');
      await page.getByRole('button', { name: 'Продолжить смену принтеров', exact: true }).click();
      await page.clock.runFor(9900); assert.equal(await activeId(page), 'printer-0');
      await page.clock.runFor(200); assert.equal(await activeId(page), 'printer-1');
      await page.evaluate(() => window.__tvFixture.setHidden(true)); await page.clock.runFor(35_000); assert.equal(await activeId(page), 'printer-1', 'Hidden document does not rotate');
      await page.evaluate(() => window.__tvFixture.setHidden(false)); await page.clock.runFor(9900); assert.equal(await activeId(page), 'printer-1', 'Visible document starts a fresh interval');
      await page.clock.runFor(200); assert.equal(await activeId(page), 'printer-2');
      await noTVWrites(page); passed(currentCase); await page.close();
    }
    {
      currentCase = 'all-printers-states-and-stale-data'; const page = await open();
      for (let index = 0; index < 7; index++) {
        await select(page, 'printer-' + index);
        assert.equal(await page.locator('.tvSpotlight').getAttribute('data-live-printing') === 'true', index === 0, 'Only fresh confirmed printing animates');
        if (index === 2) assert.match(await page.locator('.tvSpotlight').innerText(), /Пауза|приостановлен/);
        if (index === 3) assert.match(await page.locator('.tvSpotlight').innerText(), /Нагрев сопла не подтверждён/);
        if (index === 4) assert.match(await page.locator('.tvSpotlight').innerText(), /Нет связи/);
        if (index === 5) assert.match(await page.locator('.tvSpotlight').innerText(), /устарели|Устарели/);
        if (index === 6) assert.match(await page.locator('.tvSpotlight').innerText(), /Нет данных|Ожидаем/);
        if (index === 2 || index === 4) await page.screenshot({ path: path.join(proof, index === 2 ? 'tv-spotlight-paused.png' : 'tv-spotlight-offline.png') });
        if (index !== 0) { assert.equal(await stat(page, 'total').innerText(), '—', 'Missing ledger is unknown, not a fabricated zero'); assert.equal(await stat(page, 'spool').innerText(), '—'); }
      }
      await select(page, 'printer-0'); await page.evaluate(() => window.__tvFixture.patchStatus('printer-0', { remoteControlSuspended: true }));
      await page.locator('.tvSpotlight[data-live-printing="false"]').waitFor();
      assert.notEqual(await page.locator('.tvSpotlight').getAttribute('data-live-printing'), 'true'); assert.equal(await stat(page, 'current').innerText(), '—');
      assert.equal(await page.locator('.tvSpotlightCamera').count(), 0, 'An identity conflict closes the camera as well as printer controls');
      assert.equal(await page.locator('.tvSpotlightArtwork').count(), 1);
      await noTVWrites(page); passed(currentCase); await page.close();
    }
    {
      currentCase = 'selection-survives-reorder-deletion-and-empty-fleet'; const page = await open();
      await select(page, 'printer-4'); await page.evaluate(() => window.__tvFixture.setPrinters(window.__tvFixture.printers().reverse()));
      await page.locator('.tvSpotlightHead').getByText('ПРИНТЕР 03 / 07', { exact: true }).waitFor();
      assert.equal(await activeId(page), 'printer-4', 'Selection follows physical card ID on reorder');
      await page.evaluate(() => window.__tvFixture.setPrinters(window.__tvFixture.printers().filter(printer => printer.id !== 'printer-4')));
      await page.locator('.tvSpotlight[data-printer-id="printer-4"]').waitFor({ state: 'detached' });
      await single(page); const selected = await activeId(page); assert.notEqual(selected, 'printer-4'); assert.ok(await page.evaluate(id => window.__tvFixture.printers().some(printer => printer.id === id), selected));
      await page.evaluate(() => window.__tvFixture.setPrinters(window.__tvFixture.printers().filter(printer => printer.id === 'printer-0')));
      await page.locator('.tvSpotlight[data-printer-id="printer-0"]').waitFor();
      await page.clock.runFor(30_000); assert.equal(await activeId(page), 'printer-0'); await single(page);
      await page.evaluate(() => window.__tvFixture.setPrinters([])); await page.getByRole('heading', { name: 'Пока нет принтеров', exact: true }).waitFor(); await page.clock.runFor(30_000); assert.equal(await page.locator('.tvSpotlight').count(), 0);
      await noTVWrites(page); passed(currentCase); await page.close();
    }
    {
      currentCase = 'inventory-subscription-is-read-only-and-current-usage-is-separate'; const page = await open();
      await page.waitForFunction(() => document.querySelector('.tvStat[data-stat="spool"] strong')?.textContent?.match(/[0-9]/));
      const before = await page.evaluate(() => window.__tvFixture.inventory()); await noTVWrites(page);
      await page.evaluate(() => window.__tvFixture.patchStatus('printer-0', { filamentUsedMm: 20_000 }));
      await stat(page, 'current').filter({ hasText: /61/ }).waitFor();
      approx(grams(await stat(page, 'current').innerText()), 61.1, .6, 'Received job extrusion updates current estimate');
      approx(grams(await stat(page, 'spool').innerText()), 678.9, .6, 'Current print estimate never silently debits stock');
      assert.deepEqual(await page.evaluate(() => window.__tvFixture.inventory()), before, 'TV presentation leaves ledger byte-equivalent');
      await page.evaluate(() => window.__tvFixture.updateInventory({ type: 'manual-writeoff', printerId: 'printer-0', material: 'PETG', spoolId: 'spool-0', grams: 15, note: 'Synthetic fixture subscription event' }));
      await stat(page, 'spool').filter({ hasText: /664/ }).waitFor();
      approx(grams(await stat(page, 'today').innerText()), 142.5, .6, 'Actual store subscription updates daily usage');
      approx(grams(await stat(page, 'total').innerText()), 2360.6, 5, 'Actual store subscription updates cumulative usage');
      approx(grams(await stat(page, 'spool').innerText()), 663.9, .6, 'Actual store subscription updates confirmed stock');
      assert.equal(Number(await page.locator('.tvSpoolFeature [data-spool-thumbnail="true"]').getAttribute('data-filament-grams')), 663.9, 'The actual spool visual follows the same confirmed ledger update');
      const writes = await page.evaluate(() => window.__tvFixture.calls.filter(call => call.command === 'filament_inventory_commit').length); assert.equal(writes, 1, 'Only the explicit fixture update writes to the store');
      passed(currentCase); await page.close();
    }
    {
      currentCase = 'camera-only-current-visible-slide'; const page = await open();
      await cameraReady(page);
      assert.equal(await page.getByRole('button', { name: 'Камеры', exact: true }).getAttribute('aria-pressed'), 'true', 'Camera display is automatic');
      assert.equal(await page.locator('.tvSpotlightCamera').count(), 1);
      await page.evaluate(() => window.__tvFixture.setHidden(true));
      await page.locator('.tvSpotlightCamera img[src],.tvSpotlightCamera video[src]').waitFor({ state: 'detached' });
      assert.equal(await page.locator('.tvSpotlightCamera img[src],.tvSpotlightCamera video[src]').count(), 0, 'Hidden document closes the current camera source');
      await page.evaluate(() => window.__tvFixture.setHidden(false)); await cameraReady(page);
      await select(page, 'printer-2'); assert.equal(await page.locator('.tvSpotlightCamera').count(), 0, 'Switching cards unmounts the previous camera');
      assert.match(await page.locator('.tvSpotlight').innerText(), /Камера не настроена/);
      await select(page, 'printer-0'); await page.getByRole('button', { name: 'Камеры', exact: true }).click(); await page.locator('.tvSpotlightCamera').waitFor({ state: 'detached' }); assert.equal(await page.locator('.tvSpotlightCamera').count(), 0);
      assert.equal(await page.getByRole('button', { name: 'Камеры', exact: true }).getAttribute('aria-pressed'), 'false');
      await page.getByRole('button', { name: 'Камеры', exact: true }).click();
      await cameraReady(page);
      assert.equal(await page.getByRole('button', { name: 'Камеры', exact: true }).getAttribute('aria-pressed'), 'true');
      await page.getByRole('button', { name: 'Контроль камер', exact: true }).click(); assert.equal(await page.evaluate(() => window.__tvFixture.openedGuard), 1);
      await noTVWrites(page); passed(currentCase); await page.close();
    }
    {
      currentCase = 'failed-camera-fallback-is-remembered-until-retry-or-config-change'; const page = await open({ camera: 'failed' });
      await page.locator('.tvCameraRetry').waitFor(); await page.locator('.tvSpotlightArtwork').waitFor();
      assert.equal(await page.locator('.tvSpotlightCamera').count(), 0); assert.equal(cameraRequests.get(page).length, 1, 'The failed configured stream is attempted once');
      await select(page, 'printer-1'); await select(page, 'printer-0'); await page.locator('.tvCameraRetry').waitFor();
      assert.equal(await page.locator('.tvSpotlightCamera').count(), 0); assert.equal(cameraRequests.get(page).length, 1, 'Returning to a slide does not repeatedly probe a failed camera');
      await page.getByRole('button', { name: 'Камеры', exact: true }).click(); await page.getByRole('button', { name: 'Камеры', exact: true }).click();
      assert.equal(cameraRequests.get(page).length, 1, 'The ordinary on/off switch preserves the known camera failure');
      const retryRequest = page.waitForRequest(request => request.url().includes('/fixture-camera-failed.png'));
      await page.locator('.tvCameraRetry').click(); await retryRequest;
      await page.locator('.tvCameraRetry').waitFor(); await page.locator('.tvSpotlightCamera').waitFor({ state: 'detached' });
      assert.equal(cameraRequests.get(page).length, 2, 'Only explicit retry reattempts the same failed source');
      await page.evaluate(() => window.__tvFixture.repairCamera());
      await cameraReady(page); await page.locator('.tvSpotlightArtwork').waitFor({ state: 'detached' });
      assert.equal(await page.locator('.tvSpotlightArtwork').count(), 0, 'An updated camera configuration is tried automatically');
      assert.equal(cameraRequests.get(page).length, 2);
      await noTVWrites(page); passed(currentCase); await page.close();
    }
    {
      currentCase = 'no-webgl-keeps-approved-spool-placeholder-without-alternate-model'; const page = await open({ webgl: false });
      await stat(page, 'spool').filter({ hasText: /679/ }).waitFor();
      await waitForRendererBoundary(page, () => window.__tvFixture.thumbnailStats().pending > 0, 'No-WebGL thumbnail was not admitted');
      await page.clock.runFor(150);
      await waitForRendererBoundary(page, () => window.__tvFixture.thumbnailStats().unavailable === true, 'No-WebGL renderer did not report its unavailable state');
      const thumbnail = page.locator('.tvSpoolFeature [data-spool-thumbnail="true"]');
      assert.equal(await thumbnail.getAttribute('data-thumbnail-cached'), 'false');
      assert.equal(await thumbnail.locator('img').count(), 0, 'No fabricated raster replaces the approved model');
      const visibleFallbacks = await thumbnail.locator('svg').evaluateAll(elements => elements.filter(element => getComputedStyle(element).display !== 'none' && getComputedStyle(element).visibility !== 'hidden').length);
      assert.equal(visibleFallbacks, 0, 'The generic alternate SVG stays hidden in TV');
      await page.locator('.tvApprovedSpoolPending').waitFor({ state: 'visible' });
      approx(grams(await stat(page, 'spool').innerText()), 678.9, .6, 'Confirmed stock remains available without WebGL');
      assert.equal(Number(await thumbnail.getAttribute('data-filament-grams')), 678.9);
      await geometry(page); await noTVWrites(page);
      await page.screenshot({ path: path.join(proof, 'tv-spotlight-no-webgl-placeholder.png') });
      passed(currentCase); await page.close();
    }
    for (const count of [0, 1, 20]) {
      currentCase = 'fleet-size-' + count; const page = await open({ count, width: 1366, height: 768 });
      if (count === 0) { await page.getByRole('heading', { name: 'Пока нет принтеров', exact: true }).waitFor(); await page.clock.runFor(30_000); assert.equal(await page.locator('.tvSpotlight').count(), 0); }
      else if (count === 1) { await page.clock.runFor(30_000); await single(page); assert.equal(await activeId(page), 'printer-0'); }
      else { await select(page, 'printer-19'); await geometry(page); await page.getByRole('button', { name: 'Следующий принтер', exact: true }).click(); assert.equal(await activeId(page), 'printer-0'); }
      await page.getByRole('button', { name: 'На весь экран', exact: true }).click();
      await page.waitForFunction(() => document.fullscreenElement?.classList.contains('tvDashboard') || document.querySelector('.tvDashboard')?.textContent?.includes('Полный экран недоступен'));
      await page.getByRole('button', { name: 'Закрыть TV-панель', exact: true }).click(); await page.waitForFunction(() => !document.fullscreenElement && !document.querySelector('.tvDashboard'));
      await noTVWrites(page); passed(currentCase); await page.close();
    }
    {
      currentCase = 'reduced-motion-and-live-data-stop-on-expiry'; const page = await open();
      const animated = await page.locator('.tvDashboard').evaluate(element => Array.from(element.querySelectorAll('*')).filter(child => getComputedStyle(child).animationName !== 'none' && parseFloat(getComputedStyle(child).animationDuration) > .01).map(child => child.className));
      assert.deepEqual(animated, [], 'Reduced motion disables decorative animation');
      await page.getByRole('button', { name: 'Приостановить смену принтеров', exact: true }).click(); await page.clock.runFor(21_000);
      assert.notEqual(await page.locator('.tvSpotlight').getAttribute('data-live-printing'), 'true', 'Freshness expiry stops printing animation');
      assert.equal(await stat(page, 'current').innerText(), '—', 'Expired live extrusion is not shown as a current measurement');
      await noTVWrites(page); passed(currentCase); await page.close();
    }
    assert.deepEqual(runtimeErrors, []); assert.deepEqual(externalRequests, []);
    assert.deepEqual(sourceHashes(), productionSources, 'Production source changed during browser acceptance; rerun against a frozen snapshot');
    const result = { passed: cases.length, cases, runtimeErrors, externalRequests, productionSources, actualReactComponent: true, physicalPrintersTested: false, scope: 'Actual TvDashboard with synthetic native storage, received telemetry and a local configured camera. No physical printer or installed Windows build tested.' };
    fs.mkdirSync(path.dirname(reportPath), { recursive: true }); fs.writeFileSync(reportPath, JSON.stringify(result, null, 2) + '\n'); console.log(JSON.stringify(result));
  }
} catch (error) {
  fs.mkdirSync(proof, { recursive: true });
  if (currentPage && !currentPage.isClosed()) { await currentPage.screenshot({ path: path.join(proof, 'tv-spotlight-r140-failure.png') }).catch(() => {}); fs.writeFileSync(path.join(proof, 'tv-spotlight-r140-failure-state.json'), JSON.stringify({ currentCase, error: String(error.stack || error), runtimeErrors, externalRequests, renderer: await currentPage.evaluate(() => window.__tvFixture.thumbnailStats()), html: await currentPage.content() }, null, 2)); }
  throw error;
} finally { await browser?.close(); if (server) await new Promise(resolve => server.close(resolve)); fs.rmSync(out, { recursive: true, force: true }); }
