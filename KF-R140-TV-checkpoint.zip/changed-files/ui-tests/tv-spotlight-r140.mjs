import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import http from 'node:http';
import { createHash } from 'node:crypto';
import { build } from 'vite';

const root = path.resolve(import.meta.dirname, '..');
const out = fs.mkdtempSync(path.join(os.tmpdir(), 'kf-tv-spotlight-r140-'));
const proof = path.resolve(process.env.KF_R140_TV_PROOF_DIR || process.env.KF_UI_SCREENSHOTS || path.join(root, '../r140-tv-proof'));
const reportPath = path.resolve(process.env.KF_R140_TV_UI_PROOF || path.join(proof, 'tv-spotlight-r140-report.json'));
const cases = [], runtimeErrors = [], externalRequests = [];
const sourceFiles = ['src/components/TvDashboard.tsx', 'src/components/TvDashboard.css', 'src/lib/tvSpotlight.ts'];
const sourceHashes = () => Object.fromEntries(sourceFiles.map(name => [name, createHash('sha256').update(fs.readFileSync(path.join(root, name))).digest('hex')]));
const productionSources = sourceHashes();
let browser, server, currentPage, currentCase = 'initialization';
const approx = (actual, expected, tolerance, label) => assert.ok(Math.abs(actual - expected) <= tolerance, `${label}: ${actual}, expected ${expected} ± ${tolerance}`);
const grams = label => {
  const text = label.replaceAll(/[\s\u00a0\u202f]/g, '').replace(',', '.').replace(/^≈/, '');
  const number = parseFloat(text); assert.ok(Number.isFinite(number), 'Expected numeric mass, got ' + label);
  return text.includes('кг') ? number * 1000 : number;
};
const activeId = page => page.locator('.tvSpotlight').getAttribute('data-printer-id');
const single = async page => assert.equal(await page.locator('.tvSpotlight').count(), 1, 'Exactly one printer article must be mounted');
const stat = (page, name) => page.locator(`.tvSpotlightStats .tvStat[data-stat="${name}"] strong`);
const select = async (page, id) => {
  const names = await page.evaluate(() => window.__tvFixture.printers().map(printer => ({ id: printer.id, name: printer.name })));
  const printer = names.find(value => value.id === id); assert.ok(printer, 'Fixture printer exists');
  await page.getByRole('button', { name: 'Показать ' + printer.name, exact: true }).click();
  await page.waitForFunction(expected => document.querySelector('.tvSpotlight')?.getAttribute('data-printer-id') === expected, id);
  await single(page);
};
const geometry = async page => {
  const diagnostics = await page.evaluate(() => {
    const selectors = ['.tvDashboard', '.tvDashboardHead', '.tvSpotlight', '.tvSpotlightStats', '.tvStat', '.tvDashboardFoot'];
    const failed = selectors.flatMap(selector => Array.from(document.querySelectorAll(selector)).flatMap(element => {
      const box = element.getBoundingClientRect();
      return box.left < -.75 || box.right > innerWidth + .75 || element.scrollWidth > element.clientWidth + 2 ? [{ selector, box: box.toJSON(), clientWidth: element.clientWidth, scrollWidth: element.scrollWidth }] : [];
    }));
    const article = document.querySelector('.tvSpotlight');
    return { failed, article: article ? { height: article.clientHeight, scrollHeight: article.scrollHeight, box: article.getBoundingClientRect().toJSON() } : null };
  });
  assert.deepEqual(diagnostics.failed, [], 'TV horizontal overflow: ' + JSON.stringify(diagnostics.failed));
  if (await page.evaluate(() => innerWidth >= 1100 && innerHeight >= 700)) {
    assert.ok(diagnostics.article && diagnostics.article.scrollHeight <= diagnostics.article.height + 2, 'Desktop spotlight needs no internal scrolling: ' + JSON.stringify(diagnostics.article));
  }
};
const noTVWrites = async page => {
  const calls = await page.evaluate(() => window.__tvFixture.calls);
  assert.deepEqual(calls.filter(call => !['db_get_json'].includes(call.command)), [], 'TV must read existing state and never dispatch print, inventory or camera operations in the default view');
};
const passed = (name, details = {}) => { cases.push({ name, passed: true, ...details }); console.log('PASS ' + name); };
try {
  await build({ root, base: './', logLevel: 'error', build: { outDir: out, emptyOutDir: true, rollupOptions: { input: path.join(root, 'ui-tests/tv-spotlight-r140.html') } } });
  if (process.argv.includes('--build-only')) { console.log('TV spotlight fixture build passed'); }
  else {
    server = http.createServer((req, res) => {
      const file = path.resolve(out, new URL(req.url, 'http://localhost').pathname.slice(1));
      if (!file.startsWith(out + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) { res.writeHead(404).end(); return; }
      res.setHeader('Content-Type', ({ '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.webp': 'image/webp', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml' })[path.extname(file)] || 'application/octet-stream');
      res.end(fs.readFileSync(file));
    });
    await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
    const origin = 'http://127.0.0.1:' + server.address().port;
    const { chromium } = await import(process.env.PLAYWRIGHT_MODULE_PATH || 'playwright');
    browser = await chromium.launch({ headless: true, executablePath: process.env.CHROMIUM_EXECUTABLE, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
    fs.mkdirSync(proof, { recursive: true });
    const open = async ({ theme = 'dark', width = 1920, height = 1080, count = 7, reducedMotion = 'reduce' } = {}) => {
      const page = await browser.newPage({ viewport: { width, height }, locale: 'ru-RU', reducedMotion }); currentPage = page;
      page.setDefaultTimeout(10_000); page.on('pageerror', error => runtimeErrors.push(error.message));
      await page.route('**/*', route => { if (route.request().url().startsWith(origin + '/')) return route.continue(); externalRequests.push(route.request().url()); return route.abort(); });
      await page.clock.install({ time: new Date('2026-10-25T12:00:00.000Z') });
      await page.clock.pauseAt(new Date('2026-10-25T12:00:01.000Z'));
      await page.goto(`${origin}/ui-tests/tv-spotlight-r140.html?theme=${theme}&count=${count}`);
      await page.getByRole('dialog', { name: 'TV-панель фермы', exact: true }).waitFor();
      if (count) { await single(page); await stat(page, 'today').waitFor(); await page.waitForFunction(() => window.__tvFixture.calls.some(call => call.command === 'db_get_json')); }
      return page;
    };
    for (const theme of ['dark', 'light']) for (const [width, height] of [[1920, 1080], [1366, 768], [390, 844]]) {
      currentCase = `layout-${theme}-${width}x${height}`;
      const page = await open({ theme, width, height });
      assert.equal(await activeId(page), 'printer-0');
      await page.waitForFunction(() => document.querySelector('.tvStat[data-stat="spool"] strong')?.textContent?.match(/[0-9]/));
      assert.equal(await page.locator('.tvSpotlight').getAttribute('data-live-printing'), 'true');
      await geometry(page);
      approx(grams(await stat(page, 'current').innerText()), 30.55, .6, 'Current real extrusion converted with configured PETG');
      assert.match(await stat(page, 'current').innerText(), /≈/, 'Current mass must be marked as a calculation');
      approx(grams(await stat(page, 'today').innerText()), 127.5, .6, 'Today ledger usage');
      approx(grams(await stat(page, 'total').innerText()), 2345.6, 5, 'Cumulative app-accounted usage');
      approx(grams(await stat(page, 'spool').innerText()), 678.9, .6, 'Ledger spool remaining');
      assert.match(await page.locator('.tvSpotlight').innerText(), /PETG/);
      assert.ok(await page.locator('[data-testid="temperature-history-nozzle"]').count() > 0, 'Actual received temperature samples produce the sparkline');
      assert.equal(await page.locator('.tvSpotlightCamera').count(), 0, 'Default view must not mount a camera');
      await noTVWrites(page);
      await page.screenshot({ path: path.join(proof, `tv-spotlight-${theme}-${width}x${height}.png`) });
      await page.keyboard.press('Escape');
      await page.locator('.tvDashboard').waitFor({ state: 'detached' });
      assert.equal(await page.evaluate(() => window.__tvFixture.closed), 1);
      assert.notEqual(await page.evaluate(() => document.body.style.overflow), 'hidden');
      assert.equal(await page.evaluate(() => document.activeElement?.id), 'fixtureOpener', 'Close returns focus to the opening control');
      passed(currentCase, { actualComponent: true, syntheticNativeBoundary: true }); await page.close();
    }
    {
      currentCase = 'ten-second-autorotation-and-manual-wrap'; const page = await open();
      await page.clock.runFor(9000);
      await page.evaluate(() => window.__tvFixture.patchStatus('printer-0', { progress: .61, nozzle: 256, jobUpdatedAt: Date.now(), telemetryUpdatedAt: Date.now() }));
      await page.locator('[role="progressbar"][aria-valuenow="61"]').waitFor();
      await page.clock.runFor(900); assert.equal(await activeId(page), 'printer-0', 'No premature slide change');
      await page.clock.runFor(200); assert.equal(await activeId(page), 'printer-1', 'Next printer after ten seconds'); await single(page);
      await page.clock.runFor(6000); await select(page, 'printer-4');
      await page.clock.runFor(9900); assert.equal(await activeId(page), 'printer-4', 'Manual selection restarts the full interval');
      await page.clock.runFor(200); assert.equal(await activeId(page), 'printer-5');
      await select(page, 'printer-0'); await page.getByRole('button', { name: 'Предыдущий принтер', exact: true }).click(); assert.equal(await activeId(page), 'printer-6');
      await page.getByRole('button', { name: 'Следующий принтер', exact: true }).click(); assert.equal(await activeId(page), 'printer-0');
      assert.equal(await page.evaluate(() => window.__tvFixture.calls.filter(call => call.command === 'db_get_json').length), 1, 'Telemetry rerenders and rotations reuse the single inventory read');
      await noTVWrites(page); passed(currentCase); await page.close();
    }
    {
      currentCase = 'pause-resume-and-hidden-document'; const page = await open();
      await page.getByRole('button', { name: 'Приостановить смену принтеров', exact: true }).click();
      await page.clock.runFor(30_000); assert.equal(await activeId(page), 'printer-0');
      await page.getByRole('button', { name: 'Продолжить смену принтеров', exact: true }).click();
      await page.clock.runFor(9900); assert.equal(await activeId(page), 'printer-0');
      await page.clock.runFor(200); assert.equal(await activeId(page), 'printer-1');
      await page.evaluate(() => window.__tvFixture.setHidden(true)); await page.clock.runFor(35_000); assert.equal(await activeId(page), 'printer-1', 'Hidden document does not rotate');
      await page.evaluate(() => window.__tvFixture.setHidden(false)); await page.clock.runFor(9900); assert.equal(await activeId(page), 'printer-1', 'Visible document starts a fresh interval');
      await page.clock.runFor(200); assert.equal(await activeId(page), 'printer-2');
      await noTVWrites(page); passed(currentCase); await page.close();
    }
    {
      currentCase = 'all-printers-states-and-stale-data'; const page = await open();
      for (let index = 0; index < 7; index++) {
        await select(page, 'printer-' + index);
        assert.equal(await page.locator('.tvSpotlight').getAttribute('data-live-printing') === 'true', index === 0, 'Only fresh confirmed printing animates');
        if (index === 2) assert.match(await page.locator('.tvSpotlight').innerText(), /Пауза|приостановлен/);
        if (index === 3) assert.match(await page.locator('.tvSpotlight').innerText(), /Нагрев сопла не подтверждён/);
        if (index === 4) assert.match(await page.locator('.tvSpotlight').innerText(), /Нет связи/);
        if (index === 5) assert.match(await page.locator('.tvSpotlight').innerText(), /устарели|Устарели/);
        if (index === 6) assert.match(await page.locator('.tvSpotlight').innerText(), /Нет данных|Ожидаем/);
        if (index === 2 || index === 4) await page.screenshot({ path: path.join(proof, index === 2 ? 'tv-spotlight-paused.png' : 'tv-spotlight-offline.png') });
        if (index !== 0) { assert.equal(await stat(page, 'total').innerText(), '—', 'Missing ledger is unknown, not a fabricated zero'); assert.equal(await stat(page, 'spool').innerText(), '—'); }
      }
      await select(page, 'printer-0'); await page.evaluate(() => window.__tvFixture.patchStatus('printer-0', { remoteControlSuspended: true }));
      await page.locator('.tvSpotlight[data-live-printing="false"]').waitFor();
      assert.notEqual(await page.locator('.tvSpotlight').getAttribute('data-live-printing'), 'true'); assert.equal(await stat(page, 'current').innerText(), '—');
      await noTVWrites(page); passed(currentCase); await page.close();
    }
    {
      currentCase = 'selection-survives-reorder-deletion-and-empty-fleet'; const page = await open();
      await select(page, 'printer-4'); await page.evaluate(() => window.__tvFixture.setPrinters(window.__tvFixture.printers().reverse()));
      await page.locator('.tvSpotlightHead').getByText('ПРИНТЕР 03 / 07', { exact: true }).waitFor();
      assert.equal(await activeId(page), 'printer-4', 'Selection follows physical card ID on reorder');
      await page.evaluate(() => window.__tvFixture.setPrinters(window.__tvFixture.printers().filter(printer => printer.id !== 'printer-4')));
      await page.locator('.tvSpotlight[data-printer-id="printer-4"]').waitFor({ state: 'detached' });
      await single(page); const selected = await activeId(page); assert.notEqual(selected, 'printer-4'); assert.ok(await page.evaluate(id => window.__tvFixture.printers().some(printer => printer.id === id), selected));
      await page.evaluate(() => window.__tvFixture.setPrinters(window.__tvFixture.printers().filter(printer => printer.id === 'printer-0')));
      await page.locator('.tvSpotlight[data-printer-id="printer-0"]').waitFor();
      await page.clock.runFor(30_000); assert.equal(await activeId(page), 'printer-0'); await single(page);
      await page.evaluate(() => window.__tvFixture.setPrinters([])); await page.getByRole('heading', { name: 'Пока нет принтеров', exact: true }).waitFor(); await page.clock.runFor(30_000); assert.equal(await page.locator('.tvSpotlight').count(), 0);
      await noTVWrites(page); passed(currentCase); await page.close();
    }
    {
      currentCase = 'inventory-subscription-is-read-only-and-current-usage-is-separate'; const page = await open();
      await page.waitForFunction(() => document.querySelector('.tvStat[data-stat="spool"] strong')?.textContent?.match(/[0-9]/));
      const before = await page.evaluate(() => window.__tvFixture.inventory()); await noTVWrites(page);
      await page.evaluate(() => window.__tvFixture.patchStatus('printer-0', { filamentUsedMm: 20_000 }));
      await stat(page, 'current').filter({ hasText: /61/ }).waitFor();
      approx(grams(await stat(page, 'current').innerText()), 61.1, .6, 'Received job extrusion updates current estimate');
      approx(grams(await stat(page, 'spool').innerText()), 678.9, .6, 'Current print estimate never silently debits stock');
      assert.deepEqual(await page.evaluate(() => window.__tvFixture.inventory()), before, 'TV presentation leaves ledger byte-equivalent');
      await page.evaluate(() => window.__tvFixture.updateInventory({ type: 'manual-writeoff', printerId: 'printer-0', material: 'PETG', spoolId: 'spool-0', grams: 15, note: 'Synthetic fixture subscription event' }));
      await stat(page, 'spool').filter({ hasText: /664/ }).waitFor();
      approx(grams(await stat(page, 'today').innerText()), 142.5, .6, 'Actual store subscription updates daily usage');
      approx(grams(await stat(page, 'total').innerText()), 2360.6, 5, 'Actual store subscription updates cumulative usage');
      approx(grams(await stat(page, 'spool').innerText()), 663.9, .6, 'Actual store subscription updates confirmed stock');
      const writes = await page.evaluate(() => window.__tvFixture.calls.filter(call => call.command === 'filament_inventory_commit').length); assert.equal(writes, 1, 'Only the explicit fixture update writes to the store');
      passed(currentCase); await page.close();
    }
    {
      currentCase = 'camera-only-current-visible-slide'; const page = await open();
      await page.getByRole('button', { name: 'Камеры', exact: true }).click();
      await page.waitForFunction(() => document.querySelector('.tvSpotlightCamera img')?.complete && document.querySelector('.tvSpotlightCamera img')?.naturalWidth > 0);
      assert.equal(await page.locator('.tvSpotlightCamera').count(), 1);
      await page.evaluate(() => window.__tvFixture.setHidden(true));
      await page.locator('.tvSpotlightCamera img[src],.tvSpotlightCamera video[src]').waitFor({ state: 'detached' });
      assert.equal(await page.locator('.tvSpotlightCamera img[src],.tvSpotlightCamera video[src]').count(), 0, 'Hidden document closes the current camera source');
      await page.evaluate(() => window.__tvFixture.setHidden(false)); await page.waitForFunction(() => document.querySelector('.tvSpotlightCamera img')?.complete && document.querySelector('.tvSpotlightCamera img')?.naturalWidth > 0);
      await select(page, 'printer-2'); assert.equal(await page.locator('.tvSpotlightCamera').count(), 0, 'Switching cards unmounts the previous camera');
      assert.match(await page.locator('.tvSpotlight').innerText(), /Камера не настроена/);
      await select(page, 'printer-0'); await page.getByRole('button', { name: 'Показатели', exact: true }).click(); await page.locator('.tvSpotlightCamera').waitFor({ state: 'detached' }); assert.equal(await page.locator('.tvSpotlightCamera').count(), 0);
      await page.getByRole('button', { name: 'Контроль камер', exact: true }).click(); assert.equal(await page.evaluate(() => window.__tvFixture.openedGuard), 1);
      await noTVWrites(page); passed(currentCase); await page.close();
    }
    for (const count of [0, 1, 20]) {
      currentCase = 'fleet-size-' + count; const page = await open({ count, width: 1366, height: 768 });
      if (count === 0) { await page.getByRole('heading', { name: 'Пока нет принтеров', exact: true }).waitFor(); await page.clock.runFor(30_000); assert.equal(await page.locator('.tvSpotlight').count(), 0); }
      else if (count === 1) { await page.clock.runFor(30_000); await single(page); assert.equal(await activeId(page), 'printer-0'); }
      else { await select(page, 'printer-19'); await geometry(page); await page.getByRole('button', { name: 'Следующий принтер', exact: true }).click(); assert.equal(await activeId(page), 'printer-0'); }
      await page.getByRole('button', { name: 'На весь экран', exact: true }).click();
      await page.waitForFunction(() => document.fullscreenElement?.classList.contains('tvDashboard') || document.querySelector('.tvDashboard')?.textContent?.includes('Полный экран недоступен'));
      await page.getByRole('button', { name: 'Закрыть TV-панель', exact: true }).click(); await page.waitForFunction(() => !document.fullscreenElement && !document.querySelector('.tvDashboard'));
      await noTVWrites(page); passed(currentCase); await page.close();
    }
    {
      currentCase = 'reduced-motion-and-live-data-stop-on-expiry'; const page = await open();
      const animated = await page.locator('.tvDashboard').evaluate(element => Array.from(element.querySelectorAll('*')).filter(child => getComputedStyle(child).animationName !== 'none' && parseFloat(getComputedStyle(child).animationDuration) > .01).map(child => child.className));
      assert.deepEqual(animated, [], 'Reduced motion disables decorative animation');
      await page.getByRole('button', { name: 'Приостановить смену принтеров', exact: true }).click(); await page.clock.runFor(21_000);
      assert.notEqual(await page.locator('.tvSpotlight').getAttribute('data-live-printing'), 'true', 'Freshness expiry stops printing animation');
      assert.equal(await stat(page, 'current').innerText(), '—', 'Expired live extrusion is not shown as a current measurement');
      await noTVWrites(page); passed(currentCase); await page.close();
    }
    assert.deepEqual(runtimeErrors, []); assert.deepEqual(externalRequests, []);
    assert.deepEqual(sourceHashes(), productionSources, 'Production source changed during browser acceptance; rerun against a frozen snapshot');
    const result = { passed: cases.length, cases, runtimeErrors, externalRequests, productionSources, actualReactComponent: true, physicalPrintersTested: false, scope: 'Actual TvDashboard with synthetic native storage, received telemetry and a local configured camera. No physical printer or installed Windows build tested.' };
    fs.mkdirSync(path.dirname(reportPath), { recursive: true }); fs.writeFileSync(reportPath, JSON.stringify(result, null, 2) + '\n'); console.log(JSON.stringify(result));
  }
} catch (error) {
  fs.mkdirSync(proof, { recursive: true });
  if (currentPage && !currentPage.isClosed()) { await currentPage.screenshot({ path: path.join(proof, 'tv-spotlight-r140-failure.png') }).catch(() => {}); fs.writeFileSync(path.join(proof, 'tv-spotlight-r140-failure-state.json'), JSON.stringify({ currentCase, error: String(error.stack || error), runtimeErrors, externalRequests, html: await currentPage.content() }, null, 2)); }
  throw error;
} finally { await browser?.close(); if (server) await new Promise(resolve => server.close(resolve)); fs.rmSync(out, { recursive: true, force: true }); }
