import { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { TvDashboard } from '../src/components/TvDashboard';
import { I18nProvider } from '../src/i18n';
import { setAuthSession } from '../src/lib/auth';
import { emptyFilamentInventory, filamentDayKey, FILAMENT_INVENTORY_KEY, type FilamentCommand } from '../src/lib/filamentInventory';
import { updateFilamentInventory } from '../src/lib/filamentInventoryStore';
import { observePrinterVisualActivity } from '../src/lib/printerVisualActivity';
import type { PrinterModel } from '../src/types';
import type { MaintenanceState } from '../src/lib/maintenance';
import demoCamera from '../src/assets/camera-demo.png';
import '../src/styles.css';

const w = window as any, params = new URLSearchParams(location.search), now = Date.now();
document.documentElement.dataset.theme = params.get('theme') === 'light' ? 'light' : 'dark';
const names = ['Creality K1 Max', 'Ender-3 V3 KE · свободен', 'Flashforge Adventurer 5M', 'Ender-3 V3 KE · ошибка нагрева', 'Creality K1C · нет связи', 'Ender-3 V3 KE · устарели данные', 'Ender-3 V3 KE · ожидаем данные'];
const states = ['printing', 'ready', 'paused', 'error', 'offline', 'printing', 'ready'] as const;
const count = Math.max(0, Math.min(30, Number(params.get('count') ?? 7)));
let currentPrinters: PrinterModel[] = Array.from({ length: count }, (_, index) => {
  const slot = index % 7, age = slot === 5 ? 45_000 : slot === 6 ? 180_000 : 0;
  return {
    id: 'printer-' + index, name: index < 7 ? names[index] : `Принтер ${index + 1} · Ender-3 V3 KE`,
    host: index === 0 ? location.host : `192.168.1.${110 + index}:7125`, icon: slot === 0 ? 'k1max' : 'ender',
    profile: { preset: slot === 0 ? 'creality-k1-max' : slot === 2 ? 'flashforge-ad5m' : 'custom', bedX: 220, bedY: 220, maxZ: 250, nozzle: .4, materials: ['PLA', 'PETG'] },
    webcams: index === 0 ? [{ name: 'Камера тестового принтера', enabled: true, stream_url: demoCamera, snapshot_url: demoCamera }] : [],
    status: {
      state: states[slot], connectionState: slot === 4 ? 'offline' : 'online',
      progress: slot === 1 ? 0 : .54, printDuration: 3660, totalDuration: 3700,
      currentLayer: 108, totalLayers: 200,
      filename: slot === 1 ? undefined : 'Корпус_детали_PETG_очень-длинное-название_проверка-читаемости.gcode',
      nozzle: 255, nozzleTarget: 260, bed: 80, bedTarget: 80, fanSpeed: .4,
      filamentUsedMm: 10_000, printStatsState: states[slot],
      jobUpdatedAt: now - age, telemetryUpdatedAt: now - age, lastSeen: now - (slot === 4 ? 180_000 : age),
      message: slot === 3 ? 'Нагрев сопла не подтверждён' : undefined,
    },
  };
});
const ledger = emptyFilamentInventory(now - 10 * 86_400_000);
ledger.materials.PETG.looseGrams = 2000;
ledger.materials.PETG.usedGrams = 2345.6;
ledger.spools.push({ id: 'spool-0', name: 'PETG синий', material: 'PETG', color: '#4a92d8', finish: 'normal', initialWeight: 1000, remainingWeight: 678.9, price: 1500, currency: 'RUB', createdAt: now - 5 * 86_400_000, printerId: 'printer-0' });
const binding = { id: 'binding-0', material: 'PETG', spoolId: 'spool-0', effectiveAt: now - 3 * 86_400_000, baselinePending: false };
ledger.printers['printer-0'] = { binding, bindings: [binding], trackingAt: now - 3 * 86_400_000, status: 'tracking', usedGrams: 2345.6, calculatedGrams: 2300.6, manualGrams: 45, pendingJobs: 0, lastMilestoneKg: 2, byMaterial: { PETG: 2345.6 } };
ledger.usageHistory!.days.push({ day: filamentDayKey(now), printerId: 'printer-0', material: 'PETG', calculatedGrams: 123, manualGrams: 4.5 });
const memory = new Map<string, string>([[FILAMENT_INVENTORY_KEY, JSON.stringify(ledger)]]), calls: { command: string; args: any }[] = [];
w.__TAURI_INTERNALS__ = { invoke: async (command: string, args: any = {}) => {
  calls.push({ command, args });
  if (command === 'db_get_json') return memory.get(args.key) ?? null;
  if (command === 'filament_inventory_commit') { memory.set(FILAMENT_INVENTORY_KEY, args.value); return null; }
  if (command === 'native_notify') return null;
  throw new Error('Unexpected TV spotlight fixture command ' + command);
} };
setAuthSession({ token: 'tv-spotlight-fixture-only', user: { id: 'operator', name: 'Operator', role: 'operator', enabled: true, createdAt: 0 } });
const maintenance: MaintenanceState = { version: 1, tasks: [{ id: 'task-nozzle', printerId: 'printer-0', title: 'Очистить сопло', intervalHours: 50, lastAt: now - 1000, baselineSeconds: 0, cycleId: 'cycle-1' }], meters: { 'printer-0': { totalSeconds: 50 * 3600 } }, configuredPrinterIds: ['printer-0'] };
for (let index = 9; index >= 0; index--) {
  const at = now - index * 10_000;
  observePrinterVisualActivity(currentPrinters.map(printer => ({ ...printer, status: { ...printer.status, nozzle: printer.status.nozzle - index * .3, bed: printer.status.bed - index * .1, telemetryUpdatedAt: at } })), at);
}
let hidden = false;
const fixture = {
  calls, closed: 0, openedGuard: 0,
  printers: () => structuredClone(currentPrinters),
  inventory: () => JSON.parse(memory.get(FILAMENT_INVENTORY_KEY)!),
  setPrinters: (_value: PrinterModel[]) => {},
  patchStatus: (_id: string, _patch: Record<string, unknown>) => {},
  refreshTelemetry: () => {},
  setHidden: (value: boolean) => { hidden = value; document.dispatchEvent(new Event('visibilitychange')); },
  updateInventory: (command: FilamentCommand) => updateFilamentInventory(command),
};
Object.defineProperty(document, 'hidden', { configurable: true, get: () => hidden });
Object.defineProperty(document, 'visibilityState', { configurable: true, get: () => hidden ? 'hidden' : 'visible' });
w.__tvFixture = fixture;
function Fixture() {
  const [printers, setPrinters] = useState(currentPrinters), [open, setOpen] = useState(true);
  fixture.setPrinters = value => { currentPrinters = value; setPrinters(value); };
  fixture.patchStatus = (id, patch) => fixture.setPrinters(currentPrinters.map(printer => printer.id === id ? { ...printer, status: { ...printer.status, ...patch } } : printer));
  fixture.refreshTelemetry = () => fixture.setPrinters(currentPrinters.map(printer => ({ ...printer, status: { ...printer.status, jobUpdatedAt: Date.now(), telemetryUpdatedAt: Date.now(), lastSeen: Date.now() } })));
  useEffect(() => observePrinterVisualActivity(printers, Date.now()), [printers]);
  return open ? <TvDashboard printers={printers} maintenance={maintenance} cameraWatch={{ 'printer-0': { label: 'Камера наблюдает за печатью', tone: 'success' } }} onOpenCameraWatch={() => fixture.openedGuard++} onClose={() => { fixture.closed++; setOpen(false); }} /> : <button id="fixtureClosed">Панель закрыта</button>;
}
document.getElementById('fixtureOpener')!.focus();
createRoot(document.getElementById('root')!).render(<I18nProvider><Fixture /></I18nProvider>);
