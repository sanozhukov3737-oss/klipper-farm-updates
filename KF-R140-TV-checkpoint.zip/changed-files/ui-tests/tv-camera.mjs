import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import http from 'node:http';
import {build} from 'vite';

const root=path.resolve(import.meta.dirname,'..'),out=fs.mkdtempSync(path.join(os.tmpdir(),'kf-tv-camera-'));
const option=name=>process.argv.find(value=>value.startsWith('--'+name+'='))?.slice(name.length+3);
const screenshotDir=process.env.KF_UI_SCREENSHOTS??option('screenshot-dir');
const expectedNames=['K1 Max · рабочий','Ender KE · свободен','Flashforge 5M · пауза','Ender KE · ошибка нагрева','Ender KE · нет связи','Ender KE · устарели данные','Ender KE · ожидаем данные'];
try{
  await build({root,logLevel:'warn',build:{outDir:out,emptyOutDir:true,rollupOptions:{input:path.join(root,'ui-tests/tv-camera.html')}}});
  if(process.argv.includes('--build-only'))console.log('TV/camera fixture build OK: actual dashboard, configured camera and native store mock');
  else{
    const {chromium}=await import(process.env.PLAYWRIGHT_MODULE_PATH??'playwright');
    const server=http.createServer((req,res)=>{
      const file=path.resolve(out,new URL(req.url,'http://localhost').pathname.slice(1));
      if(!file.startsWith(out+path.sep)||!fs.existsSync(file)||!fs.statSync(file).isFile()){res.writeHead(404);res.end();return}
      res.setHeader('Content-Type',({'.js':'text/javascript','.css':'text/css','.html':'text/html','.png':'image/png','.svg':'image/svg+xml','.wasm':'application/wasm'})[path.extname(file)]??'application/octet-stream');res.end(fs.readFileSync(file));
    });
    await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
    const origin=`http://127.0.0.1:${server.address().port}`,report=[],errors=[];
    let browser,currentPage,currentCase={test:'initialization'};
    const noHorizontalOverflow=async page=>{
      const failures=await page.evaluate(()=>[document.documentElement,document.body,...document.querySelectorAll('.tvDashboard,.tvDashboardHead,.tvFarmStatus,.tvAttention,.tvDashboardGrid,.tvSpotlight,.tvTemperatures,.tvDashboardFoot,.cameraGuardPanel')].flatMap(element=>{
        const box=element.getBoundingClientRect();return box.left<-.75||box.right>innerWidth+.75||element.scrollWidth>element.clientWidth+2?[{className:element.className,box:box.toJSON(),scrollWidth:element.scrollWidth,clientWidth:element.clientWidth}]:[];
      }));
      assert.deepEqual(failures,[],'TV/camera panel horizontal overflow');
    };
    const reachable=async(locator,label)=>{
      await locator.scrollIntoViewIfNeeded();
      const geometry=await locator.evaluate(element=>{
        const box=element.getBoundingClientRect();let top=0,left=0,right=innerWidth,bottom=innerHeight;
        for(let parent=element.parentElement;parent;parent=parent.parentElement){
          if(parent===document.scrollingElement)continue;
          const style=getComputedStyle(parent),bounds=parent.getBoundingClientRect();
          if(/auto|scroll|hidden|clip/.test(style.overflowY)){top=Math.max(top,bounds.top+parent.clientTop);bottom=Math.min(bottom,bounds.top+parent.clientTop+parent.clientHeight)}
          if(/auto|scroll|hidden|clip/.test(style.overflowX)){left=Math.max(left,bounds.left+parent.clientLeft);right=Math.min(right,bounds.left+parent.clientLeft+parent.clientWidth)}
          // The fixed dashboard/backdrop is clipped by the viewport. Its
          // zero-height document body does not clip fixed descendants.
          if(style.position==='fixed')break;
        }
        return {reachable:box.top>=top-1&&box.bottom<=bottom+1&&box.left>=left-1&&box.right<=right+1,box:box.toJSON(),clip:{left,right,top,bottom}};
      });
      if(!geometry.reachable){const error=new Error('TV/camera control is clipped: '+label);error.geometry=geometry;throw error}
    };
    const saveFailure=async error=>{
      const directory=screenshotDir??path.join(os.tmpdir(),'kf-tv-camera-failure-'+Date.now());fs.mkdirSync(directory,{recursive:true});
      const label=Object.values(currentCase).join('-').replaceAll(/[^\w.-]/g,'_'),diagnostic={case:currentCase,error:String(error.stack??error),geometry:error.geometry,report,pageErrors:errors,files:{}};
      if(currentPage&&!currentPage.isClosed()){
        try{const file=path.join(directory,label+'-failure.png');await currentPage.screenshot({path:file});diagnostic.files.screenshot=file}catch(captureError){diagnostic.screenshotError=String(captureError)}
        try{const file=path.join(directory,label+'-failure.html');fs.writeFileSync(file,await currentPage.content());diagnostic.files.dom=file}catch(captureError){diagnostic.domError=String(captureError)}
        try{diagnostic.state=await currentPage.evaluate(()=>({calls:window.__calls,closed:window.__closed,bodyOverflow:getComputedStyle(document.body).overflow,panels:[...document.querySelectorAll('.tvDashboard,.tvDashboardGrid,.tvSpotlight,.tvSpotlightFoot,.tvDashboardHead,.tvFarmStatus,.tvAttention,.tvDashboardFoot,.cameraGuardPanel')].map(element=>({className:element.className,box:element.getBoundingClientRect().toJSON(),scrollHeight:element.scrollHeight,clientHeight:element.clientHeight,scrollWidth:element.scrollWidth,clientWidth:element.clientWidth}))}))}catch(captureError){diagnostic.stateError=String(captureError)}
      }
      fs.writeFileSync(path.join(directory,'tv-camera-failure.json'),JSON.stringify(diagnostic,null,2));console.error('TV/camera failure diagnostics: '+path.join(directory,'tv-camera-failure.json'));
    };
    const open=async(theme,width,height,extra='')=>{
      currentCase={test:'dashboard',theme,width,height,extra};
      const page=await browser.newPage({viewport:{width,height},locale:'ru-RU'});currentPage=page;page.on('pageerror',error=>errors.push(error.message));
      await page.route('**/*',route=>route.request().url().startsWith(origin+'/')?route.continue():route.abort());
      await page.goto(`${origin}/ui-tests/tv-camera.html?theme=${theme}${extra}`);await page.getByRole('dialog',{name:extra.includes('view=guard')?'Контроль печати по камере':'TV-панель фермы',exact:true}).waitFor();if(!extra.includes('view=guard')){const pause=page.getByRole('button',{name:'Приостановить смену принтеров',exact:true});if(await pause.count())await pause.click()}return page;
    };
    const nameAt=index=>index<7?expectedNames[index]:`Принтер ${String(index+1).padStart(2,'0')} · Ender KE`;
    const selectPrinter=async(page,index)=>{
      const picker=page.getByRole('button',{name:'Показать '+nameAt(index),exact:true});
      await reachable(picker,'printer picker '+index);await picker.click();
      await page.locator(`.tvSpotlight[data-printer-id="printer-${index}"]`).waitFor();
      assert.equal(await page.locator('.tvSpotlight').count(),1,'one printer, never a grid or overlapping live cards');
      return page.locator('.tvSpotlight');
    };
    const visitAllPrinters=async(page,count=7)=>{
      const names=[],states=[];
      for(let index=0;index<count;index++){
        const card=await selectPrinter(page,index);names.push(await card.locator('.tvPrinterName').innerText());states.push(await card.locator('.tvPrinterStatus').innerText());
        await reachable(card.locator('.tvPrinterName'),'printer name');await reachable(card.locator('.tvSpotlightProgress>strong'),'printer progress');await reachable(card.locator('.tvSpotlightFoot'),'printer freshness');
        await noHorizontalOverflow(page);
      }
      assert.equal(names.length,count);assert.equal(new Set(names).size,count,'each printer must be reachable exactly once through the picker');
      await selectPrinter(page,0);
      return {names,states};
    };
    try{
      browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_EXECUTABLE,args:['--no-sandbox','--disable-dev-shm-usage']});if(screenshotDir)fs.mkdirSync(screenshotDir,{recursive:true});
      for(const theme of['dark','light'])for(const [width,height]of[[1920,1080],[910,512],[390,844]]){
        const page=await open(theme,width,height),dialog=page.getByRole('dialog',{name:'TV-панель фермы',exact:true});
        await noHorizontalOverflow(page);
        assert.deepEqual(await page.locator('.tvFarmStatus>div').evaluateAll(elements=>elements.map(element=>Number(element.querySelector('strong').textContent))),[2,1,1,1,1,1]);
        assert.equal(await page.locator('.tvSpotlightCamera').count(),0,'camera streams must stay unmounted in default metrics view');
        const first=page.locator('.tvSpotlight');assert.equal((await first.locator('.tvSpotlightProgress>strong').innerText()).replace(/\s/g,''),'42%');assert.notEqual(await first.locator('.tvTimeMetric').first().locator('strong').innerText(),'—','fresh active print keeps its actual remaining estimate');
        assert.match(await first.locator('.tvServiceDue').innerText(),/Обслуживание.*1/);assert.match(await first.locator('.tvCameraWatch').innerText(),/признаки сбоя/);
        const notices=await page.locator('.tvNoticeList').innerText(),noticeDetails=await page.locator('.tvNoticeList article').evaluateAll(elements=>elements.map(element=>element.getAttribute('title')??'').join('\n'));assert.match(notices,/Ошибка/);assert.match(notices,/Пора обслужить/);assert.match(notices,/Контроль камеры/);assert.match(noticeDetails,/Нагрев сопла не подтверждён/);assert.match(noticeDetails,/Данные устарели/);assert.match(noticeDetails,/признаки сбоя/,'camera warning detail must remain available in the compact global strip');
        const all=await visitAllPrinters(page);assert.deepEqual(all.names,expectedNames);assert.deepEqual(all.states,['Печатает','Готов','Пауза','Ошибка','Нет связи','Печатает','Нет данных']);
        if(width===1920){
          assert.equal(await page.locator('.tvSpotlight').count(),1,'TV presents one full-screen printer at a time');
          const geometry=await page.locator('.tvSpotlight').evaluate(element=>({scrollHeight:element.scrollHeight,clientHeight:element.clientHeight,nameSize:parseFloat(getComputedStyle(element.querySelector('.tvPrinterName')).fontSize),progressSize:parseFloat(getComputedStyle(element.querySelector('.tvSpotlightProgress>strong')).fontSize)}));
          assert.ok(geometry.scrollHeight<=geometry.clientHeight+2,'single TV card must be readable without scrolling at1080p');assert.ok(geometry.nameSize>=20&&geometry.progressSize>=40,'TV names and progress must remain large');
          const stale=await selectPrinter(page,5);assert.match(await stale.locator('.tvFreshness').innerText(),/устарели.*45 с/);assert.equal(await stale.locator('.tvTimeMetric').first().locator('strong').innerText(),'Уточняется','stale status must not invent a running ETA');
          const unknown=await selectPrinter(page,6);assert.equal(await unknown.locator('.tvSpotlightProgress>strong').innerText(),'—');assert.deepEqual(await unknown.locator('.tvTemperatures strong').allTextContents(),['—','—']);
          await selectPrinter(page,0);
        }
        if(screenshotDir)await page.screenshot({path:path.join(screenshotDir,`${theme}-tv-${width}x${height}.png`)});
        await page.getByRole('button',{name:'Камеры',exact:true}).click();await page.waitForFunction(()=>document.querySelector('.tvSpotlightCamera img')?.complete&&document.querySelector('.tvSpotlightCamera img')?.naturalWidth>0);
        assert.equal(await page.locator('.tvSpotlightCamera').count(),1,'only configured and visible printers may open a camera');assert.equal(await page.getByRole('button',{name:'Показатели',exact:true}).getAttribute('aria-pressed'),'true');
        await noHorizontalOverflow(page);await reachable(first.locator('.tvSpotlightFoot'),'camera view footer');
        if(width===1920){
          const geometry=await page.locator('.tvSpotlight').evaluate(element=>({scrollHeight:element.scrollHeight,clientHeight:element.clientHeight}));
          assert.ok(geometry.scrollHeight<=geometry.clientHeight+2,'camera must not hide warning or metrics behind scrolling at1080p');
        }
        if(screenshotDir&&width===1920)await page.screenshot({path:path.join(screenshotDir,`${theme}-tv-camera-${width}x${height}.png`)});
        await page.getByRole('button',{name:'Следующий принтер',exact:true}).click();
        await page.locator('.tvSpotlight[data-printer-id="printer-1"]').waitFor();
        assert.equal(await page.locator('.tvSpotlightCamera').count(),0,'changing printer must unmount the preceding camera');
        assert.ok(await page.locator('.tvNoCamera').count()>=1,'printer without a camera needs a compact truthful label');
        await page.getByRole('button',{name:'Предыдущий принтер',exact:true}).click();
        await page.locator('.tvSpotlight[data-printer-id="printer-0"]').waitFor();
        await page.getByRole('button',{name:'Показатели',exact:true}).click();assert.equal(await page.locator('.tvSpotlightCamera').count(),0);
        await page.getByRole('button',{name:'Контроль камер',exact:true}).click();assert.equal(await page.evaluate(()=>window.__openGuard),1);
        await reachable(page.getByRole('button',{name:'Закрыть TV-панель',exact:true}),'dashboard close');await page.keyboard.press('Escape');await dialog.waitFor({state:'detached'});assert.equal(await page.evaluate(()=>window.__closed),1);assert.notEqual(await page.evaluate(()=>document.body.style.overflow),'hidden');
        assert.equal(await page.evaluate(()=>window.__calls.some(call=>/^(print|queue)\.|upload|gcode|pause|resume/.test(call.command))),false,'dashboard must not dispatch printer operations');
        assert.deepEqual(errors,[]);report.push({test:'seven-printer-states-camera-slide-Escape',theme,width,height,status:'passed'});console.log(`PASS TV dashboard ${theme} ${width}x${height}`);await page.close();
      }
      for(const count of[9,17,40]){
        const page=await open('dark',1920,1080,'&count='+count);currentCase={test:'all-printer-slides',count};const all=await visitAllPrinters(page,count);assert.equal(all.names[0],expectedNames[0]);assert.equal(all.names.at(-1),nameAt(count-1));
        await page.getByRole('button',{name:'Предыдущий принтер',exact:true}).click();await page.locator(`.tvSpotlight[data-printer-id="printer-${count-1}"]`).waitFor();
        await page.getByRole('button',{name:'Следующий принтер',exact:true}).click();await page.locator('.tvSpotlight[data-printer-id="printer-0"]').waitFor();
        report.push({test:'all-printers-through-individual-slides',count,status:'passed'});console.log('PASS TV spotlight '+count+' printers');await page.close();
      }
      {
        const page=await open('dark',910,512,'&count=0');currentCase={test:'empty-fullscreen-and-close'};await page.getByRole('heading',{name:'Пока нет принтеров',exact:true}).waitFor();await noHorizontalOverflow(page);
        await page.getByRole('button',{name:'На весь экран',exact:true}).click();await page.waitForFunction(()=>document.fullscreenElement?.classList.contains('tvDashboard')||document.querySelector('.tvDashboardFoot')?.textContent?.includes('Полный экран недоступен'));
        await page.getByRole('button',{name:'Закрыть TV-панель',exact:true}).click();await page.waitForFunction(()=>!document.fullscreenElement&&!document.querySelector('.tvDashboard'));report.push({test:'empty-fullscreen-and-close',status:'passed'});console.log('PASS TV empty/fullscreen and cleanup');await page.close();
      }
      for(const theme of['dark','light'])for(const [width,height]of[[1920,1080],[910,512],[390,844]]){
        const page=await open(theme,width,height,'&view=guard');currentCase={test:'camera-guard-layout-settings',theme,width,height};await page.waitForFunction(()=>window.__guard.ready);
        await noHorizontalOverflow(page);assert.equal(await page.locator('.cameraGuardPrinter').count(),7);assert.equal(await page.locator('.cameraGuardPrinter select').count(),7);
        assert.match(await page.locator('.cameraGuardIntro').innerText(),/локально на этом ПК/);assert.match(await page.locator('.cameraGuardIntro').innerText(),/открытой программе/);assert.match(await page.locator('.cameraGuardModes').innerText(),/Возобновление — вручную/);
        const first=page.getByRole('combobox',{name:'Контроль камеры: '+expectedNames[0],exact:true}),second=page.getByRole('combobox',{name:'Контроль камеры: '+expectedNames[1],exact:true});
        assert.equal(await first.inputValue(),'off');assert.equal(await first.locator('option[value="notify"]').evaluate(element=>element.disabled),false);assert.equal(await first.locator('option[value="pause"]').evaluate(element=>element.disabled),false);
        assert.equal(await second.locator('option[value="notify"]').evaluate(element=>element.disabled),true);assert.equal(await second.locator('option[value="pause"]').evaluate(element=>element.disabled),true);
        const appearance=await page.locator('.cameraGuardPanel').evaluate(element=>{const style=getComputedStyle(element),select=getComputedStyle(element.querySelector('select'));return {radius:parseFloat(style.borderRadius),selectRadius:parseFloat(select.borderRadius),clip:style.clipPath,selectClip:select.clipPath,background:style.backgroundColor,selectBackground:select.backgroundColor}});
        assert.ok(appearance.radius>=12&&appearance.selectRadius>=8,'camera panel/field corners must be rounded: '+JSON.stringify(appearance));assert.equal(appearance.clip,'none');assert.equal(appearance.selectClip,'none');if(theme==='light'){const rgb=appearance.selectBackground.match(/[\d.]+/g).slice(0,3).map(Number);assert.ok(rgb.reduce((sum,n)=>sum+n,0)/3>=190,'camera select must follow the light theme')}
        await reachable(page.locator('.cameraGuardPrinter').last().getByRole('combobox'),'last camera mode');await reachable(first,'first camera mode');
        await first.selectOption('notify');await page.waitForFunction(()=>window.__guard.settings.printers['printer-0']?.mode==='notify');
        assert.equal(await page.evaluate(()=>JSON.parse(window.__memory.get('production.cameraGuard.v1')).printers['printer-0'].mode),'notify');
        await first.selectOption('pause');await page.waitForFunction(()=>window.__guard.settings.printers['printer-0']?.mode==='pause');assert.equal(await page.evaluate(()=>JSON.parse(window.__memory.get('production.cameraGuard.v1')).printers['printer-0'].mode),'pause');
        await page.evaluate(()=>window.__remountGuard());await page.waitForFunction(()=>window.__guard.ready&&window.__guard.settings.printers['printer-0']?.mode==='pause');assert.equal(await first.inputValue(),'pause','saved camera mode must survive controller remount');
        await page.evaluate(()=>window.__guard.unavailable('printer-0','Камера не передаёт свежий кадр. Проверьте подключение.'));await page.waitForFunction(()=>document.querySelector('.cameraGuardPrinterStatus')?.textContent?.includes('не передаёт свежий кадр'));
        await noHorizontalOverflow(page);await reachable(page.locator('.cameraGuardPrinterStatus').first(),'camera unavailable warning');
        await first.selectOption('off');await page.waitForFunction(()=>window.__guard.settings.printers['printer-0']?.mode==='off');assert.equal(await page.evaluate(()=>JSON.parse(window.__memory.get('production.cameraGuard.v1')).printers['printer-0'].mode),'off');assert.deepEqual(await page.evaluate(()=>window.__guard.activePrinterIds),[]);
        await page.locator('.cameraGuardBody').evaluate(element=>{element.scrollTop=0});if(screenshotDir)await page.screenshot({path:path.join(screenshotDir,`${theme}-camera-guard-${width}x${height}.png`)});
        assert.equal(await page.evaluate(()=>window.__calls.some(call=>/^(print|queue)\.|upload|gcode|pause|resume/.test(call.command))),false,'changing camera settings without evidence must never issue printer commands');
        await reachable(page.getByRole('button',{name:'Закрыть контроль камеры',exact:true}),'camera guard close');await page.keyboard.press('Escape');await page.locator('.cameraGuardPanel').waitFor({state:'detached'});assert.equal(await page.evaluate(()=>window.__closed),1);
        assert.deepEqual(errors,[]);report.push({test:'camera-guard-layout-and-durable-modes',theme,width,height,status:'passed'});console.log(`PASS camera guard ${theme} ${width}x${height}`);await page.close();
      }
      {
        const page=await open('dark',910,512,'&view=guard&stored=invalid');currentCase={test:'unknown-settings-fail-closed'};await page.getByRole('alert').waitFor();
        assert.match(await page.getByRole('alert').innerText(),/Автопауза выключена/);assert.equal(await page.evaluate(()=>window.__guard.ready),false);assert.deepEqual(await page.evaluate(()=>window.__guard.activePrinterIds),[]);assert.ok((await page.locator('.cameraGuardPrinter select').evaluateAll(elements=>elements.map(element=>element.disabled))).every(Boolean));assert.equal(await page.evaluate(()=>window.__calls.some(call=>call.command==='db_set_json')),false,'unknown stored modes must not be overwritten or armed silently');
        await page.evaluate(()=>window.__memory.set('production.cameraGuard.v1',JSON.stringify({version:1,printers:{'printer-0':{mode:'off'}}})));await page.getByRole('button',{name:'Повторить',exact:true}).click();await page.waitForFunction(()=>window.__guard.ready&&!window.__guard.error);assert.equal(await page.getByRole('alert').count(),0);report.push({test:'unknown-settings-fail-closed-retry',status:'passed'});console.log('PASS unknown camera settings fail closed/retry');await page.close();
      }
      {
        const page=await open('dark',910,512,'&view=guard&failWrites=1');currentCase={test:'camera-mode-write-failure'};await page.waitForFunction(()=>window.__guard.ready);
        const mode=page.getByRole('combobox',{name:'Контроль камеры: '+expectedNames[0],exact:true});await mode.selectOption('pause');await page.getByRole('alert').waitFor();assert.match(await page.getByRole('alert').innerText(),/не сохранён.*не включена/);assert.equal(await mode.inputValue(),'off');assert.deepEqual(await page.evaluate(()=>window.__guard.activePrinterIds),[]);assert.equal(await page.evaluate(()=>window.__memory.has('production.cameraGuard.v1')),false);
        await page.evaluate(()=>{window.__failWrites=false});await page.getByRole('button',{name:'Повторить',exact:true}).click();await page.waitForFunction(()=>window.__guard.settings.printers['printer-0']?.mode==='pause'&&!window.__guard.error);assert.equal(await mode.inputValue(),'pause');report.push({test:'arming-requires-durable-settings-write',status:'passed'});console.log('PASS camera arming requires durable settings write');await page.close();
      }
      {
        const page=await open('light',390,844,'&view=guard&readonly=1');currentCase={test:'camera-read-only'};assert.ok((await page.locator('.cameraGuardPrinter select').evaluateAll(elements=>elements.map(element=>element.disabled))).every(Boolean));await page.evaluate(()=>window.__guard.setMode('printer-0','pause'));assert.deepEqual(await page.evaluate(()=>window.__guard.activePrinterIds),[]);assert.deepEqual(await page.evaluate(()=>window.__calls),[],'read-only controller must not access or mutate privileged state');await noHorizontalOverflow(page);report.push({test:'read-only-cannot-arm-camera-guard',status:'passed'});console.log('PASS camera read-only gate');await page.close();
      }
      {
        const page=await open('dark',910,512);currentCase={test:'actual-camera-frame-pixels'};const frames=await page.evaluate(()=>window.__prepareFrames());assert.match(frames.rejects.black,/тёмный или пустой/);assert.match(frames.rejects.blank,/тёмный или пустой/);assert.match(frames.rejects.small,/слишком маленький/);assert.equal(frames.hashes[0],frames.hashes[1],'identical decoded frames must keep the same identity');assert.notEqual(frames.hashes[0],frames.hashes[2],'changed pixels must get a different identity');assert.equal(frames.hashes[0].length,64);assert.equal(frames.width,128);assert.equal(frames.height,128);assert.deepEqual(frames.scaled,{width:1280,height:960},'large camera frames must be bounded before inference');report.push({test:'actual-dark-blank-small-and-repeated-frame-quality',status:'passed'});console.log('PASS actual browser camera frame quality/hashes');await page.close();
      }
      assert.deepEqual(errors,[]);const result={passed:report.length,browser:browser.version(),report};if(screenshotDir)fs.writeFileSync(path.join(screenshotDir,'tv-camera-report.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
    }catch(error){await saveFailure(error);throw error}
    finally{await browser?.close();await new Promise(resolve=>server.close(resolve))}
  }
}finally{fs.rmSync(out,{recursive:true,force:true})}
