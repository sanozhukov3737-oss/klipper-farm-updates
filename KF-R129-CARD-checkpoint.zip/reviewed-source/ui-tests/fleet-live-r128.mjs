import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import { build } from 'vite';
const root = path.resolve(import.meta.dirname, '..'), out = fs.mkdtempSync(path.join(os.tmpdir(), 'kf-r128-fleet-'));
const shots = process.env.KF_UI_SCREENSHOTS, cases = [], errors = [];
let browser, server, current;
try {
  await build({ root, logLevel: 'error', build: { outDir: out, emptyOutDir: true, rollupOptions: { input: path.join(root, 'ui-tests/fleet-live-r128.html') } } });
  server = http.createServer((req, res) => {
    const file = path.resolve(out, new URL(req.url, 'http://localhost').pathname.slice(1));
    if (!file.startsWith(out + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) { res.writeHead(404).end(); return; }
    res.setHeader('Content-Type', ({ '.js': 'text/javascript', '.css': 'text/css', '.html': 'text/html', '.svg': 'image/svg+xml', '.png': 'image/png', '.webp': 'image/webp' })[path.extname(file)] ?? 'application/octet-stream'); res.end(fs.readFileSync(file));
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const origin = `http://127.0.0.1:${server.address().port}`;
  const { chromium } = await import(process.env.PLAYWRIGHT_MODULE_PATH ?? 'playwright');
  browser = await chromium.launch({ headless: true, executablePath: process.env.CHROMIUM_EXECUTABLE, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  if (shots) fs.mkdirSync(shots, { recursive: true });
  for (const theme of ['dark', 'light']) for (const width of [1536, 910, 390]) {
    const page = await browser.newPage({ viewport: { width, height: 1100 }, locale: 'ru-RU', timezoneId: 'Europe/Moscow' }); current = page;
    page.on('pageerror', error => errors.push(error.message));
    await page.route('**/*', route => route.request().url().startsWith(origin + '/') ? route.continue() : route.abort());
    await page.clock.install({ time: new Date('2026-10-20T16:30:00Z') });
    await page.clock.pauseAt(new Date('2026-10-20T16:30:01Z'));
    await page.goto(`${origin}/ui-tests/fleet-live-r128.html?theme=${theme}`);
    await page.getByTestId('live-printer-printer-7').waitFor();
    const timeline = page.getByTestId('farm-finish-timeline');
    assert.equal(await page.getByTestId(/^live-printer-/).count(), 7);
    assert.equal(await timeline.locator('[data-forecast="estimated"]').count(), 2);
    for (const id of [3, 5, 6, 7]) assert.equal(await page.getByTestId(`finish-row-printer-${id}`).getAttribute('data-forecast'), 'unavailable');
    assert.match(await timeline.innerText(), /за шкалой/);
    await timeline.getByRole('button', { name: '12 ч', exact: true }).click();
    assert.equal(await timeline.getByRole('button', { name: '12 ч', exact: true }).getAttribute('aria-pressed'), 'true');
    assert.doesNotMatch(await timeline.innerText(), /за шкалой/);
    await timeline.getByRole('button', { name: '4 ч', exact: true }).click();
    const first = page.getByTestId('live-printer-printer-1');
    await first.locator('[data-filament-color]').waitFor();
    assert.equal(await first.locator('[data-filament-color]').getAttribute('data-filament-color'), '#e7963b');
    assert.equal(await page.getByTestId('live-printer-printer-2').locator('[data-filament-color]').getAttribute('data-filament-color'), '#60b5a7');
    assert.match(await first.innerText(), /720 г/);
    assert.match(await first.innerText(), /Слой 70 \/ 100/);
    assert.equal(await page.getByTestId('live-printer-printer-7').getByTestId('printer-finish').innerText(), 'Состояние\nНет связи');
    await first.getByRole('button', { name: /^Открыть/ }).focus(); await page.keyboard.press('Enter');
    await timeline.getByTestId('finish-row-printer-2').click();
    assert.deepEqual(await page.evaluate(() => window.__opened), ['printer-1', 'printer-2']);
    const filter = page.getByRole('group', { name: 'Показать принтеры' });
    await filter.getByRole('button', { name: /^Требуют внимания/ }).click();
    assert.equal(await page.getByTestId(/^live-printer-/).count(), 2);
    await filter.getByRole('button', { name: /^Все/ }).click();
    const overflow = await page.locator('[data-testid^="live-printer-"], [data-testid="farm-finish-timeline"], [data-testid^="finish-row-"]').evaluateAll(elements => elements.filter(el => { const r = el.getBoundingClientRect(); return r.left < -1 || r.right > innerWidth + 1 || el.scrollWidth > el.clientWidth + 2; }).map(el => ({ className: el.className, scrollWidth: el.scrollWidth, clientWidth: el.clientWidth })));
    assert.deepEqual(overflow, [], `${theme}/${width} horizontal overflow`);
    assert.equal(await page.evaluate(() => window.__calls.filter(call => call.command !== 'db_get_json').length), 0, 'viewing the farm must not write inventory or control printers');
    await page.getByTestId('live-printer-printer-7').scrollIntoViewIfNeeded();
    await first.scrollIntoViewIfNeeded();
    if (shots) {
      await page.setViewportSize({ width, height: width === 1536 ? 1800 : 1100 });
      await timeline.scrollIntoViewIfNeeded();
      await page.screenshot({ path: path.join(shots, `fleet-r128-${theme}-${width}.png`), fullPage: true });
    }
    cases.push({ name: `${theme}-${width}: seven cards, actual spool colors, uncertain states, range, filters, keyboard, no writes or overflow`, passed: true });
    if (theme === 'dark' && width === 1536) {
      await page.evaluate(() => window.__changeSpool());
      await page.waitForFunction(() => document.querySelector('[data-testid="live-printer-printer-1"] [data-filament-color]')?.getAttribute('data-filament-color') === '#d34d6b');
      assert.match(await first.innerText(), /310 г/);
      await page.evaluate(() => window.__patchPrinter('printer-1', { currentLayer: 71, totalLayers: 101 }));
      await page.getByText('Слой 71 / 101', { exact: true }).waitFor();
      const before = await first.getByTestId('printer-finish').innerText();
      await page.clock.runFor(10_000);
      assert.equal((await first.getByTestId('printer-finish').innerText()).split('\n')[1], before.split('\n')[1], 'finish time cannot drift forward with the clock');
      await page.clock.runFor(11_000);
      await page.waitForFunction(() => document.querySelectorAll('[data-forecast="estimated"]').length === 0);
      assert.match(await first.getByTestId('printer-finish').innerText(), /Данные устарели/);
      await page.evaluate(() => window.__patchPrinter('printer-1', { jobUpdatedAt: Date.now(), telemetryUpdatedAt: Date.now(), progress: .8, printDuration: 4000, currentLayer: 80 }));
      await page.waitForFunction(() => document.querySelectorAll('[data-forecast="estimated"]').length === 1);
      assert.match(await first.innerText(), /80%/);
      await page.evaluate(() => window.__patchPrinter('printer-1', { state: 'paused' }));
      await page.waitForFunction(() => document.querySelectorAll('[data-forecast="estimated"]').length === 0);
      await page.evaluate(() => window.__idleAll());
      await page.getByText('Сейчас нет активных заданий', { exact: true }).waitFor();
      assert.equal(await page.getByTestId(/^finish-row-/).count(), 0);
      cases.push({ name: 'live layer and inventory updates, anchored clock, stale forecast suppression, recovery, pause and empty farm', passed: true });
    }
    await page.close(); current = undefined;
  }
  assert.deepEqual(errors, []);
  if (shots) fs.writeFileSync(path.join(shots, 'fleet-r128-report.json'), JSON.stringify({ passed: cases.length, cases, runtimeErrors: errors }, null, 2) + '\n');
  console.log(`R128 live fleet: ${cases.length} browser scenarios passed`);
} catch (error) {
  if (shots && current) await current.screenshot({ path: path.join(shots, 'fleet-r128-failure.png'), fullPage: true }).catch(() => {});
  throw error;
} finally { await browser?.close(); await new Promise(resolve => server ? server.close(resolve) : resolve()); fs.rmSync(out, { recursive: true, force: true }); }
