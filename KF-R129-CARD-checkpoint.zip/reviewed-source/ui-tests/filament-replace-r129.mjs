import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import { build } from 'vite';
const root = path.resolve(import.meta.dirname, '..'), out = fs.mkdtempSync(path.join(os.tmpdir(), 'kf-r129-replace-'));
const shots = process.env.KF_UI_SCREENSHOTS, cases = [], errors = [];
let browser, server, current;
try {
  await build({ root, logLevel: 'error', build: { outDir: out, emptyOutDir: true, rollupOptions: { input: path.join(root, 'ui-tests/fleet-live-r128.html') } } });
  server = http.createServer((req, res) => {
    const file = path.resolve(out, new URL(req.url, 'http://localhost').pathname.slice(1));
    if (!file.startsWith(out + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) { res.writeHead(404).end(); return; }
    res.setHeader('Content-Type', ({ '.js': 'text/javascript', '.css': 'text/css', '.html': 'text/html', '.svg': 'image/svg+xml', '.png': 'image/png', '.webp': 'image/webp' })[path.extname(file)] ?? 'application/octet-stream'); res.end(fs.readFileSync(file));
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const origin = `http://127.0.0.1:${server.address().port}`;
  const { chromium } = await import(process.env.PLAYWRIGHT_MODULE_PATH ?? 'playwright');
  browser = await chromium.launch({ headless: true, executablePath: process.env.CHROMIUM_EXECUTABLE, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  if (shots) fs.mkdirSync(shots, { recursive: true });

  const openPage = async (theme = 'dark', width = 1536, extra = '') => {
    const page = await browser.newPage({ viewport: { width, height: 1000 }, locale: 'ru-RU', timezoneId: 'Europe/Moscow' }); current = page;
    page.on('pageerror', error => errors.push(error.message));
    await page.route('**/*', route => route.request().url().startsWith(origin + '/') ? route.continue() : route.abort());
    await page.goto(`${origin}/ui-tests/fleet-live-r128.html?replace=1&theme=${theme}${extra}`);
    await page.getByTestId('live-printer-printer-7').waitFor();
    await page.getByTestId('live-printer-printer-1').locator('[data-filament-color]').waitFor();
    return page;
  };
  const firstCard = page => page.getByTestId('live-printer-printer-1');
  const openPicker = async (page, id = 1) => {
    await page.getByTestId(`live-printer-printer-${id}`).getByRole('button', { name: /^(Сменить|Выбрать) пластик:/ }).click();
    const dialog = page.getByRole('dialog', { name: 'Заменить пластик', exact: true });
    await dialog.getByRole('radio', { name: /PETG вишнёвый/ }).waitFor();
    return dialog;
  };
  const save = dialog => dialog.getByRole('button', { name: 'Установить катушку', exact: true });
  const writes = page => page.evaluate(() => window.__calls.filter(call => call.command === 'filament_inventory_commit').length);
  const snapshot = page => page.evaluate(() => window.__getInventory());
  for (const theme of ['dark', 'light']) for (const width of [1536, 910, 390]) {
    const page = await openPage(theme, width), before = await snapshot(page), dialog = await openPicker(page);
    assert.deepEqual(await page.evaluate(() => window.__opened), [], 'clicking filament cannot open printer details');
    assert.equal(await save(dialog).isDisabled(), true, 'current spool must be a no-op');
    assert.equal(await dialog.getByRole('radio', { name: /На Ender-3 V3 KE · 02/ }).isDisabled(), true);
    assert.equal(await dialog.getByRole('radio', { name: /Пустая катушка/ }).isDisabled(), true);
    assert.equal(await writes(page), 0, 'opening picker cannot mutate inventory');
    await dialog.getByRole('radio', { name: /PETG вишнёвый/ }).check();
    const overflow = await dialog.evaluate(el => { const r = el.getBoundingClientRect(); return r.left < 0 || r.right > innerWidth || r.top < 0 || r.bottom > innerHeight || el.scrollWidth > el.clientWidth + 2; });
    assert.equal(overflow, false, `${theme}/${width} dialog must fit viewport`);
    assert.equal(await page.locator('button button').count(), 0, 'no nested interactive buttons');
    if (shots) await page.screenshot({ path: path.join(shots, `filament-replace-r129-${theme}-${width}.png`), fullPage: true });
    await save(dialog).click();
    await dialog.waitFor({ state: 'detached' });
    const after = await snapshot(page), binding = after.printers['printer-1'].binding;
    assert.equal(binding.material, 'PETG');
    assert.equal(after.spools.find(spool => spool.id === binding.spoolId).name, 'PETG вишнёвый');
    assert.equal(after.spools.find(spool => spool.id === binding.spoolId).printerId, 'printer-1');
    assert.equal(after.spools[0].printerId, undefined, 'old spool must return to free stock');
    assert.equal(after.printers['printer-1'].bindings.length, before.printers['printer-1'].bindings.length + 1);
    assert.equal(after.printers['printer-1'].binding.baselinePending, true);
    assert.equal(after.printers['printer-1'].usedGrams, before.printers['printer-1'].usedGrams);
    assert.deepEqual(after.materials, before.materials, 'replacement cannot add or debit stock');
    assert.deepEqual(after.spools.map(({ printerId, ...spool }) => spool), before.spools.map(({ printerId, ...spool }) => spool));
    for (const id of Object.keys(before.printers).filter(id => id !== 'printer-1')) assert.deepEqual(after.printers[id], before.printers[id]);
    assert.equal(await firstCard(page).locator('[data-filament-color]').getAttribute('data-filament-color'), '#d34d6b');
    assert.match(await firstCard(page).innerText(), /PETG[\s\S]*850 г/);
    assert.equal(await writes(page), 1);
    await firstCard(page).getByRole('button', { name: /^Открыть/ }).focus(); await page.keyboard.press('Enter');
    assert.deepEqual(await page.evaluate(() => window.__opened), ['printer-1']);
    cases.push({ name: `${theme}-${width}: card click, actual colors, disabled occupied/empty spools, atomic replacement, weights and history preserved, immediate card refresh`, passed: true });
    await page.close(); current = undefined;
  }
  {
    const page = await openPage(), before = await snapshot(page), dialog = await openPicker(page);
    await dialog.getByRole('radio', { name: /PETG вишнёвый/ }).check();
    await page.evaluate(() => { window.__failCommit = true; });
    await save(dialog).click();
    await dialog.getByRole('alert').filter({ hasText: 'Не удалось сохранить замену' }).waitFor();
    assert.deepEqual(await snapshot(page), before, 'failed transaction cannot lose previous binding or stock');
    assert.equal(await firstCard(page).locator('[data-filament-color]').getAttribute('data-filament-color'), '#e7963b');
    await page.evaluate(() => { window.__holdCommit = true; });
    await save(dialog).click();
    await page.waitForFunction(() => typeof window.__resolveCommit === 'function');
    assert.equal(await save(dialog).count(), 0, 'saving label replaces submit');
    assert.equal(await dialog.getByRole('button', { name: 'Сохранение…', exact: true }).isDisabled(), true);
    await page.keyboard.press('Escape'); assert.equal(await dialog.isVisible(), true, 'busy picker cannot close before commit');
    await page.evaluate(() => window.__resolveCommit()); await dialog.waitFor({ state: 'detached' });
    assert.equal(await writes(page), 2, 'one failed and one successful attempt, no duplicate save');
    cases.push({ name: 'failed SQLite transaction preserves exact inventory, retry succeeds once, saving prevents duplicate submit and premature close', passed: true });
    await page.close();
  }
  {
    const page = await openPage(), before = await snapshot(page), trigger = firstCard(page).getByRole('button', { name: /^Сменить пластик:/ });
    await openPicker(page); await page.keyboard.press('Escape');
    assert.equal(await page.getByRole('dialog').count(), 0);
    assert.equal(await trigger.evaluate(el => el === document.activeElement), true, 'Escape restores focus to originating material button');
    assert.deepEqual(await snapshot(page), before); assert.equal(await writes(page), 0);
    await openPicker(page); await page.evaluate(() => window.__setViewer());
    await page.getByRole('dialog').waitFor({ state: 'detached' });
    assert.equal(await page.getByRole('button', { name: /^(Сменить|Выбрать) пластик:/ }).count(), 0);
    assert.equal(await writes(page), 0);
    cases.push({ name: 'Escape/cancel restores keyboard focus without mutation; permission downgrade removes editing immediately', passed: true });
    await page.close();
    const viewer = await openPage('light', 390, '&role=viewer');
    assert.equal(await viewer.getByRole('button', { name: /^(Сменить|Выбрать) пластик:/ }).count(), 0);
    assert.equal(await writes(viewer), 0); await viewer.close();
  }
  {
    const page = await openPage(), dialog = await openPicker(page);
    await dialog.getByRole('radio', { name: /PETG вишнёвый/ }).check();
    await page.evaluate(() => window.__occupyFree());
    await page.waitForFunction(() => document.querySelector('dialog input[value^="spool:"]:checked')?.disabled === true);
    assert.equal(await save(dialog).isDisabled(), true, 'live inventory update prevents stealing a newly occupied spool');
    await dialog.getByRole('radio', { name: /PLA белый/ }).check(); await save(dialog).click();
    await dialog.waitFor({ state: 'detached' });
    const inventory = await snapshot(page);
    assert.equal(inventory.spools.find(spool => spool.name === 'PETG вишнёвый').printerId, 'printer-7');
    assert.equal(inventory.spools.find(spool => spool.name === 'PLA белый').printerId, 'printer-1');
    cases.push({ name: 'concurrent spool assignment refreshes availability and preserves another printer binding', passed: true });
    await page.close();
  }
  {
    const page = await openPage(), before = await snapshot(page), dialog = await openPicker(page, 4);
    await dialog.getByRole('radio', { name: /TPU 550 г без катушки/ }).check(); await save(dialog).click();
    await dialog.waitFor({ state: 'detached' });
    const after = await snapshot(page);
    assert.equal(after.printers['printer-4'].binding.material, 'TPU');
    assert.equal(after.printers['printer-4'].binding.spoolId, undefined);
    assert.deepEqual(after.spools, before.spools); assert.deepEqual(after.materials, before.materials);
    assert.match(await page.getByTestId('live-printer-printer-4').innerText(), /TPU[\s\S]*Из запаса/);
    cases.push({ name: 'previously unbound printer can use existing loose stock without creating a spool or changing quantities', passed: true });
    await page.close();
  }
  {
    const page = await openPage(); await page.evaluate(() => { window.__failRead = true; });
    await firstCard(page).getByRole('button', { name: /^Сменить пластик:/ }).click();
    const dialog = page.getByRole('dialog'); await dialog.getByRole('alert').waitFor();
    assert.match(await dialog.innerText(), /Хранилище временно недоступно/); assert.equal(await save(dialog).isDisabled(), true);
    await page.evaluate(() => { window.__failRead = false; }); await dialog.getByRole('button', { name: 'Повторить', exact: true }).click();
    await dialog.getByRole('radio', { name: /PETG вишнёвый/ }).waitFor();
    await dialog.getByRole('button', { name: 'Открыть склад', exact: true }).click();
    assert.equal(await page.evaluate(() => window.__warehouse), true); assert.equal(await page.getByRole('dialog').count(), 0); assert.equal(await writes(page), 0);
    cases.push({ name: 'storage failure is recoverable without blanking data; warehouse shortcut closes picker without mutation', passed: true });
    await page.close();
  }
  assert.deepEqual(errors, []);
  if (shots) fs.writeFileSync(path.join(shots, 'filament-replace-r129-report.json'), JSON.stringify({ passed: cases.length, cases, runtimeErrors: errors }, null, 2) + '\n');
  console.log(`R129 filament replacement: ${cases.length} browser scenarios passed`);
} catch (error) {
  if (shots && current) await current.screenshot({ path: path.join(shots, 'filament-replace-r129-failure.png'), fullPage: true }).catch(() => {});
  throw error;
} finally { await browser?.close(); await new Promise(resolve => server ? server.close(resolve) : resolve()); fs.rmSync(out, { recursive: true, force: true }); }
